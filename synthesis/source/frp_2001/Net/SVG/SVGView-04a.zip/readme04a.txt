IBM(R) SVGView - Release notes. 0.4a

Readme updated : 17th April, 2000

Highlights
----------

This version of SVGView matches the 20000303 (March 3rd 2000) Public Working
Draft level of the Scalable Vector Graphics (SVG) specification and DTD with
documented restrictions and exceptions.  That specification can be located at
http://www.w3.org/TR/2000/03/WD-SVG-20000303

SVGView has a comprehensive "user friendly" interface including tool bars,
interactive zoom rectangles, bookmark support, history window, basic print
support, and support for interactive links between SVG files.

SVGView now comes with more than 125 fully annotated SVG sample files.

SVGView is a useful SVG prototyping tool.

Entirely written in Java(TM) using Java 2

This is the sixth public release of SVGView to appear on alphaWorks.

SVGView has now been downloaded more than 7200 times since it was first released
on July-30th 1999 via alphaWorks - we appreciate your interest and your
comments.


What's new in the 0.4a release ?
--------------------------------

  With this release some significant new features have been added plus some bugs
  have been fixed.  Full details of all changes are documented in the change
  history section of this file (see section 7.1).

  NOTE: Section 5.1 of this file now includes details of the most common
        install problems people have reported/run into and give details of
        the most likely cause of the problem and the solution.

  Here is just a summary of some of the new things in this version, see section
  7.1 of the Change History for further details of all the updates and changes:


  1. A new graphical DOM Tree View window has been added that allows the actual
     SVG (XML) DOM tree as maintained internally by SVGView to be viewed by the
     user. The DOM View window can be displayed by selecting it from the pop-up
     menu (right click in the display area) or from the View menu in the SVGView
     menu bar. The DOM viewer can also be used to dynamically edit the contents
     of the DOM. By simply double clicking (sometimes three clicks are required)
     on an attribute value or a text node you can go into "edit mode" and edit
     the values. When you press the Enter key on the keyboard to finish editing
     a particular node, SVGView will reprocess the edited DOM and you will see
     the results of your changes. We hope that SVG prototypers will find this
     both useful and insightful. Only attributes and text nodes can be edited
     in this version.

  2. Fixed the SourceView window so that it is not blank when displaying large
     SVG files. This was caused by an AWT TextArea limitation on some operating
     system platforms which has been resolved by re-implementing the Source
     Viewer using Swing components.

  3. Further improved performance of both initial rendering and re-rendering
     of SVG files. Added additional internal caching so that re-rendering, such
     as zoom-in and zoom-out, of a loaded file is faster.

  4. Made changes to prevent unnecessary repaints that would occur under certain
     circumstances. Painting performance is also now improved as a result.

  5. Added a progress bar in the bottom right hand corner of the viewer window
     that shows a percentage complete status during the rendering of an SVG
     image. This is useful feedback, particular during the rendering of large
     SVG files.

  6. Added the ability to save the current view as a JPEG file by selecting
     the new "Save as JPEG" option from the file menu.

  7. All of the samples have been updated to use, and have been tested with, the
     SVG-20000303 levels of the SVG DTDs. Also, to allow early prototypers to
     experiment with the exchange SVG syntax, some support for "Exchange SVG"
     has been added in this release and some samples that use the exchange SVG
     syntax have been added to the samples package. The samples directory now
     has two sub-directories called style and exchange to reflect this addition
     to the package.



SPECIAL NOTE - If you see Java exceptions when viewing paths.
-------------------------------------------------------------

During our testing we have seen Java exceptions generated (they are displayed on
the console window) for paths that contain arcs if the JIT compiler is enabled.
We have attempted to code a bypass for this apparent Java problem but if you
should still see exceptions when trying to view SVG files that contain paths
that include elliptical arcs you should close the viewer, disable the JIT
compiler and restart the viewer and retry the file.  You can disable the JIT
compiler by entering the command:

       set java_compiler=xxx

on the command line before starting the viewer.  In general the viewer will run
more slowly if the JIT is disabled so it is best to turn it off only if you
suspect that you are seeing this specific problem.



Contents of this file
---------------------

   1.  Feedback/Reporting problems
   2.  Status and overview
   3.  System requirements
   4.  Installation notes

   5.  STARTING THE VIEWER
   5.1  Common installation problems/solutions

   6.  DETAILED STATUS OF THE VIEWER & RENDERER
   6.1   Supported SVG functionality
   6.2   Supported SVG elements.
   6.3   Supported CSS style properties.
   6.4   Known issues with the Viewer application (non SVG related).
   6.5   Known renderer issues/deviations from the 19991203 SVG spec.

   7.  CHANGE HISTORY
   7.1   Version 0.4a  -  April-11th 2000          6th version on alphaWorks
   7.2   Version 0.3c  -  December-8th 1999        5th version on alphaWorks
   7.3   Version 0.3b  -  November-23rd 1999       4th version on alphaWorks
   7.4   Version 0.3a  -  October-14th 1999        3rd version on alphaWorks
   7.5   Version 0.2a  -  August-17th 1999         2nd version on alphaWorks
   7.6   Version 0.1g  -  August-3rd 1999                 .
   7.7   Version 0.1f  -  July-30th 1999                  .
   7.8   Version 0.1e  -  July-7th  1999                  .
   7.9   Version 0.1d  -  June-30th 1999           1st version on alphaWorks
   7.10  Version 0.1c  -  June-18th 1999                  .
   7.11  Version 0.1b  -  June-14th 1999                  .
   7.12  Version 0.1a  -  June-11th 1999                  .

   8.    Acknowledgements

   9.    Trademarks , Copyrights


1. Feedback/Reporting problems
------------------------------

Please send all feedback and comments via e-mail to us at ibmsvg@us.ibm.com or
you can add a message to the SVGView discussion group accessible from the
SVGView download page at www.alphaWorks.ibm.com.

We plan to put out regular updates as the viewer progresses so please tell us
what you like, what you don't like and what you'd like to see next.

When reporting problems please attach to the e-mail an SVG file that causes the
problem to occur.

You may also find useful discussion of this and other SVG related tools and
issues at www-svg@w3.org which is a e-mail list maintained by the W3C for the
public discussion of SVG topics.  Details of how to subscribe to the public
e-mail list are contained near the front of the SVG specification document.


2. Status and overview
----------------------

SVGView is a prototype SVG viewer written entirely in Java.  It utilizes Java 2
and the Xerces XML parser.

Like the SVG specification this SVG viewer is still evolving and there is still
a lot of work to do as both this prototype viewer and the SVG spec evolve.
However, there is a very significant amount of the SVG specification that is
supported by SVGView.  See Detailed status below for more information.

The SVG processor currently is based upon the August-12th public working  draft
of the SVG specification.

The SVGView user interface is fairly feature rich including a toolbar, support
for links, a zoom selection rectangle, source view window and print support.

The underlying rendering and processing components are invisible to the end user
but architecturally, there is complete separation between the shell (viewer)
program and the underlying SVG processor.  In a future release, we hope to be
able to provide documentation for this rendering/processing "bean" so that
different viewer applications can be built based upon the rendering/processing
core engine or "bean".


3. System requirements
----------------------

SVGView requires that you have Java 2 installed on your system and correctly
configured in the path and classpath.  SVGView also requires that the Xerces
parser be installed and correctly in the classpath.  Xerces is an XML parser
entirely written in Java and (starting with the 0.4a release of SVGView) is now
included as part of the SVGView download.

This code has been tested with Java 2 at the 1.2.2 level.  The viewer will work
with earlier releases of Java 2 but there are known performance issues.  Also,
printing of text only really works at the 1.2.2 level as there are other bug
fixes also in that version.  We therefore recommend using Java 2 at the 1.2.2
level or higher.

This code has been tested with Xerces version 1.0.3 and is known to work at that
level.


4. Installation notes
---------------------

Installation method for Windows 95, Windows 98, Windows NT

  SVGView.zip:

   Prerequisites
   -------------

     a) Download the Java 2 package and install it
        The Java 2 package is available for download at
        http://java.sun.com/products/OV_jdkProduct.html

     b) Add xerces.jar to your classpath

   To install with SVGView.zip
   ---------------------------

     a) Create a directory called SVGView

     b) Unzip SVGView.zip into the SVGView directory

     c) Run env-svg.bat to add SVGView.jar to your classpath

     d) To run the viewer, change directory (cd) to the
        directory where SVGView is installed and run the
        following script:

          SVGView.bat

     e) To uninstall, delete all the files in the directory
        where the viewer was installed, and then remove the
        directory.


5. STARTING THE VIEWER
----------------------

Once you have checked that the following 3 statements are true (see notes above)

  1. You have Java 2 installed and configured.
  2. You have Xerces.jar in the classpath.
  3. You have SVGView.jar in the classpath.

you can start the viewer, from the directory containing the files, by simply
typing SVGView, which will start the SVGView.bat file and in turn bring up the
viewer.  If everything has worked in a few moments you should see the SVGView
main window and a welcome screen with a few simple SVG graphics on it.

Reminder: you can use the env-svg.bat file to add SVGView to your classpath.

Two sub-directories are created when you install SVGView.  The \doc
sub-directory contains the documentation for SVGView in both SVG and HTML
format.  The \samples sub-directory contains all of the SVG sample files.


5.1 Common install errors/mistakes

   Several people have had trouble getting SVGView to run the very first time.
   In all cases so far the cause has been one of the three cases detailed below.
   If you get an error message when you try to start SVGView, please reiew the
   information below.

   a. If the following error message appears on starting SVGView:
      Exception in thread "main" java.lang.NoClassDefFoundError: Viewer

      ==> SVGView.jar is not in the classpath or Java 1.2.x is not installed
          properly.

   b. If the following error message appears on starting SVGView:
      Exception in thread "main" java.lang.NoClassDefFoundError: org/w3c/dom/Node

      ==> Xerces.jar is not in the classpath.


6. DETAILED STATUS OF THE VIEWER & RENDERER
-------------------------------------------

The following sections provide a detailed summary of known limitations and
problems with the viewer itself (user interface issues) and the SVG rendering
code.  This section also describes in detail the SVG features that are currently
supported.


6.1 Viewer Features
-------------------

SVGView supports the following features:

   Zoom Image
   Rotate Image
   Bookmarks
   History
   Source Window
   Links
   Printing
   SVG Validation
   Debug Trace

For more notes on some of these features see section 6.5 below.


6.2 Supported SVG functionality
-------------------------------

Support is provided in part or in full for the following list
of features:

  Basic Shapes
    - rectangles
    - circles
    - ellipses
    - lines
    - polylines
    - polygons
  Paths
  Clipping
  Transforms
  Opacity
  Colors
  Images
  Text
  Fonts
  Patterns & textures (image patterns)
  Linear gradients
  Radial gradients
  Stroking
    - Line ends
    - Line joins
    - Line widths
    - Dashing
  Filling
    - even odd rule
    - non zero rule
  Text antialiasing
  Shape antialiasing
  Links
  Symbols


6.3 Supported SVG elements
--------------------------

The currently supported SVG element names (in alphabetical
order) are:

    <a>
    <circle>
    <clipPath>
    <data>
    <defs>
    <ellipse>
    <g>
    <image>
    <line>
    <linearGradient>
    <path>
    <pattern>
    <polygon>
    <polyline>
    <radialGradient>
    <rect>
    <stop>
    <style>
    <svg>
    <symbol>
    <text>
    <tspan>
    <use>


6.4 Stylable SVG and Exchange SVG support.
------------------------------------------

This section has details of the support for Stylable SVG and Exchange SVG.


6.4.1 Supported CSS style properties
------------------------------------

The currently supported CSS style properties (in alphabetical
order) are:

    clip-path
    color
    fill
    fill-opacity
    fillrule
    font-family
    font-size
    font-style
    font-weight
    shape-rendering
    stroke
    stroke-dasharray
    stroke-dashoffset
    stroke-linecap
    stroke-linejoin
    stroke-miterlimit
    stroke-opacity
    stroke-width
    text-rendering
    text-anchor
    visibility

6.4.2 Supported CSS selectors
-----------------------------

Only the class selector is currently supported (multiple styles can be defined
in a single style element and referenced using the class= attribute. See
class1.svg in the samples\style directory for an example of this support.

Note that currently it is required that the definition within a <style>
element be defined within a CDATA section. This is a limitation of the current
implementation.

Here is an example of style being applied using a class selector.

        <svg width="300px" height="300px"  >
          <defs>
            <style> <![CDATA[
               .krl1 { fill:blue ; stroke:red  ; stroke-width:4 } ]]>
            </style>
          </defs>
          <rect class="krl1" x="25"  y="50"  width="100" height="50" />
        </svg>


6.4.3 Supported exchange SVG attributes.
----------------------------------------

The cuurently supported set of exchange SVG attributes (in alphabetical order)
are:

    fill
    font-size
    shape-rendering
    stroke
    stroke-linecap
    stroke-linejoin
    stroke-width
    text-rendering

Note that not all of the exchange SVG attributes are supported in this release
but a limited set has been supported to allow people to prototype with the new
Exchange SVG syntax that was introduced int the March 3rd 2000 spec. This is
intended to allow SVG prototypers to experiment with this new syntax. A set of
examples of SVG files that use the Exchange SVG syntax have been added to the
samples package in the samples\exchange directory.


6.5 Viewer features and issues (non SVG syntax related)
-------------------------------------------------------

6.5.1 Zoom Rectangle

      One useful feature of SVGView is the zoom rectangle. Simply click and
      hold the left mouse button then drag the mouse across the screen. Once
      you have enclosed the area of the SVG image you want to zoom in to,
      select "Zoom In" from the toolbar and the image will be enlarged so
      the area within the rectangle now occupies the whole window.


6.5.2 Source Window

      The source for the currently displayed SVG file can be viewed from within
      SVGView by opening the View Source window. Select "View", "Source..."
      from the menu bar.

      NOTE: Larger SVG files may not load into the View Source window. If that
      happens, the window will appear empty.


6.5.3 Bookmarks and History

      The Bookmarks and History features have been improved to make them more
      useful. You may now edit the name of a bookmark by selecting "Edit
      Bookmarks" from the "Bookmarks" menu.


6.5.4 Validating SVG Files

      SVGView provides a mechanism for validating SVG files.
      If an SVG file does not load, or appears to be incorrectly drawn,
      validation can be switched on to obtain more detailed messages during
      the loading, parsing, and rendering of the SVG file.

      To switch on validation from the command line, start SVGView as follows:

         SVGView -v

      Validation can be turned on and configured from within the application -
      select "View", "Validation Settings..." from the menu bar. Messages can
      be selected to appear on the Java console or can be written to the log
      file "valid.log" in the current directory.

      Six levels of validation output are available, but in most cases the level
      needs only to be set as high as "Warning". This level will print out
      warning messages for any SVG file SVGView cannot parse or render
      correctly.

      A useful tip for debugging an SVG file is to keep an editor open alongside
      SVGView, and load an SVG file into both the applications. You can then
      make changes to the SVG source in the editor, save those changes, and
      click on the "Reload" button in SVGView. The SVG file will be reloaded
      from disk and you will see the results of the changes made.


6.5.5 Debug Trace Options

      If SVGView fails to operate correctly, extra debug trace can be turned
      on by starting SVGView as follows:

         SVGView -d

      This enables the debug dialog; select "Help", "Debug Options" from the
      menu bar. Several levels of debug and validation trace details can be
      selected from this dialog. The debug information can be sent to the
      Java console or the log file "debug.log" in the current directory.

      If SVGView appears to hang or crash for any reason, turning on the
      debug trace will help to identify the problem.


6.5.6 Printing

      SVGView supports very basic printing of SVG documents. This support is not
      yet complete and should be viewed more as a statement of intent than as a
      fully working feature.

      NOTE: SVGView assumes you are using a printer resolution set to 600dpi.
      If your printer is set to any other resolution the image printed will not
      be the correct size.

      On some systems, printing fails and a message box containing the text
      "An error ocurred during this operation" is displayed. This is a
      limitation of the current release. There is currently no known workaround
      to this problem.


6.5.7 Clipping Problems

      Clipping problems that were visible when a document containing one or
      more clip paths was zoomed or scrolled have been resolved with the 0.3b
      release.

6.5.8 Color depths

      Operation in a 32 bit color depth display mode may cause incorrect colors
      to be displayed. Use a 16 or 24 bit mode.

6.5.9 Viewer seems to hang ?

      If the viewer appears to hang while loading an SVG file or
      the file fails to load immediately

      There are some cases where the viewer may appear to hang while loading an
      SVG file, or the message "Error parsing file" may appear immediately and
      no file is displayed. If this happens, you should first of all check the
      Java console window (typically the command shell window you issued the
      SVGView command from) for additional messages that may be helpful. The
      reasons that the above symptoms may happen are:

      a. You are behind a firewall

      If you are behind a firewall and the SVG file you are loading references a
      DTD that is on a web server outside of your firewall, the viewer may not
      be able to access that file without being told about your socks server
      (see below).  After 30 seconds the viewer will time out trying to access
      the remote DTD and will attempt to find the DTD locally.  If the DTD
      cannot be found locally then an error message should be displayed.  A
      local copy of the svg-19990812.dtd file is included with this viewer in
      the samples directory.

      Also, you can force the viewer to always substitute a local DTD for a
      remote DTD by enabling the USE_LOCAL_DTD setting in the SVGView.properties
      file.

      If you have a socks server, you can tell SVGView about it (which should
      allow you to pass through your firewall to get remote files) by editing
      the SOCKS section of the SVGView.properties file.

      b. The local DTD file specified is missing

      If the SVG file you are attempting to view refers to a local copy of the
      DTD but that copy of the DTD does not exist in the directory containing
      the SVG file being loaded then the viewer will abort trying to load the
      file and a message will be displayed.  Again, if this happens, check the
      Java console for more detailed information.

      c. The SVG file does not include a DTD reference

      If the SVG file does not contain a reference to any DTD then you may see
      lots of warning messages on the Java console during the parsing of the
      file but the viewer will still attempt to display the file.  It is
      possible you may see some odd output as the SVG DTD does contain some
      meaningful default values for certain attributes but the viewer attempts
      to duplicate these values in cases where there is no DTD reference in the
      SVG file and you should get reasonable output.

6.5.10 Occasional viewer hangs.

      On some systems we have seen the viewer lock up while trying to load and
      display the curved text sample, curvedtext.svg.  We have temporarily
      removed this sample from the samples directory for this release but are
      including this warning in case people kept an old copy of the sample from
      one of the previous releases.  This appears to be a system dependant,
      timing related, issue and there is currently no workaround.  We have not
      seen this happen on Windows NT systems but have seen it on both Windows 95
      and Windows 98 systems.  If this happens, you can usually press <ctrl>
      <alt> and <delete> , and terminate the SVGView application from the Close
      Program dialog.

6.5.11 DOM Viewer Window

     A new graphical DOM Tree View window was added in the 0.4a release
     that allows the actual SVG (XML) DOM tree as maintained internally by
     SVGView to be viewed by the user.  The DOM View window can be displayed by
     selecting it from the pop-up menu (right click in the display area) or from
     the View menu in the SVGView menu bar.

     The DOM viewer can also be used to dynamically edit the contents of the
     DOM.  By simply double clicking (sometimes three clicks are required) on an
     attribute value or a text node's text you can go into "edit mode" and edit
     the values.  When you press the Enter key on the keyboard to finish editing
     a particular node, SVGView will reprocess the edited DOM and you will see
     the results of your changes.  We hope that SVG prototypers will find this
     both useful for experimenting with SVG attributes and properties and also
     insightful into what an SVG DOM looks like on the inside .  Only attributes
     and text nodes can be edited in this version.


6.6 Known renderer issues and other notes.
------------------------------------------

  This version of SVGView is based upon the March 3rd 2000 public working draft
  of the SVG specification and DTD.

  Below is a list, that we have made as comprehensible as possible of the
  known major areas of the SVG spec that are either not implemented, only
  partially implemented. Also below are a set of general notes about the
  current implementation.

6.6.1. Paths & Path commands

        The path command processing has now been updated to match the "Last
        Call" version of the SVG spec.

        The detailed list of path command support is below:

        a. The old "A" and "R" commands are no longer recognized as being
           Absolute/Relative mode switches as they were in earlier revisions
           of the SVG specification.

        b. The "A" command is now correctly recognized as the elliptical arc
           command.

        b. The smooth quadratic Bezier command, "T" is also now recognized.

        c. Numbers separated by decimal points,specified as valid by the path
           eBNF such as 1.23.45.6 are still not recognized correctly.

        d. Numbers separated by minus signs, specified as valid by the path eBNF
           such as -1-2-3-4 are correctly recognized.

        e. Scientific notation such as "M100,1E2" is now correctly recognized.

        f. Error checking is not always consistent. All parameters are required
           by the spec but this is not yet always fully enforced by the SVG
           processor.

        The full set of recognized path commands is:

          A = Elliptical arc (absolute)
          a = Elliptical arc (relative)
          C = Draw a cubic bezier using control points (absolute).
          c = Draw a cubic bezier using control points (relative).
          H = Draw a horizontal line, previous value of y is assumed (absolute).
          h = Draw a horizontal line, previous value of y is assumed (relative).
          L = Line to point (absolute).
          l = Line to point (relative).
          M = Move to point (absolute).
          m = Move to point (relative).
          Q = Quadratic Bezier (absolute).
          q = quadratic bezier (relative).
          S = Smooth curve (absolute).
          s = Smooth curve (relative).
          T = Smooth quadratic Bezier (absolute).
          t = Smooth quadratic Bezier (relative).
          V = Draw a vertical line, previous value of x is assumed (absolute).
          v = Draw a vertical line, previous value of x is assumed (relative).
          Z = Close the path.
          z = Close the path.


6.6.2. Basic shapes

        The basic shapes are fully supported.

6.6.3. Filter effects

        a. None of the filter effects chapter of the spec is supported.

6.6.4.  Gradients

        Both linear and radial gradients are supported. Support was added in
        the  0.2a level of the renderer with the following limitations:

        a. For linear gradients only the x1, y1, x2, y2 attributes are
           recognized. See (e) below.

        b. For radial gradients only the cx, cy, r, fx and fy attributes are
           recognized. See (e) below.

        c. Gradient stop offsets are fully supported both absolute (values
           between 0.0 and 1.0) and percentages are supported and the stops can
           be specified in any order.

        d. Gradient stop colors are supported with the same limitations as other
           CSS color parsing described in this file. (See section 6.5.11)

        e. The following gradient related features are not supported:

            - bounding boxes (objectBoundingBox)
            - gradient units (always assumes user space)
            - relative cx, cy, r (percentages)
            - focal point - fx, fy (will accept parameters but just will ignore
              them)
            - cyclic linear gradients

6.6.5.  Opacity

        a. The group level 'opacity' property is not supported but the
           'stroke-opacity' and 'fill-opacity' properties are supported.

6.6.6.  Symbols - the <symbol> element

        Support for symbols was added in the 0.3b release and improved
        significantly in the 0.3c release. Style can now be applied to a
        symbol both on the <symbol> and <use> elements. The support has the
        following limitations.


        a. The refX and refY attributes are currently ignored by SVGView.

        b. The viewBox attribute is currently ignored (for symbols) by
           SVGView. This means that all symbols will be defined in terms of
           the current user space.

        c. The preserveAspectRatio attribute is currently ignored (for symbols)
           by SVGView.

        Note: Several samples (symbol1.svg, symbol2.svg... etc.) have been
              added to the samples directory to demonstrate some of the many
              uses of the SVG <symbol> and <use> elements.

6.6.7.  The <use> element

        Support for the <use> element was added in the 0.3b release and
        significantly improved in the 0.3c release. Any <symbol> or other
        shape with an ID (such as a path, a rectangle or an ellipse) can be
        referenced for drawing by a <use> element.

        a. The x= and y= attributes on the <use> element will not
           position a symbol correctly unless it was defined with a (0,0)
           origin. A transform can be placed on the <use> element to get the
           desired result. See the samples for examples of this.

        b. The width= and height= attributes will be ignored by SVGView
           when processing <use> elements.

        c. Text can be referenced by a <use> element so long as it is defined
           inside of a <symbol> element and the ID of the symbol is referenced
           by the <use> element. Stand alone <text> elements with ID's will
           not be correctly drawn if referenced on a <use> element.

        d. See 6.6.6 above for more details of <use> in conjunction with
           symbols.

        Note: Several samples (symbol1.svg, symbol2.svg... etc.) have been
              added to the samples directory to demonstrate some of the many
              uses of the SVG <symbol> and <use> elements.

6.6.8.  Patterns - the <pattern> element

        Support for the <pattern> element was added in the 0.1e version of the
        renderer.  Patterns should work as per the SVG spec and can contain both
        SVG artwork and images.  You will find some samples that use patterns
        and textures in the sample file set (see 6.6.99 below).

6.6.9.  Numbers and units

        a. Not all of the CSS units identifiers are supported.
           Examples of CSS units are: 25%, 12pt, 24px, 5cm and 4in

           The following table indicates the names of the possible units an
           whether or not they are supported by the SVG processor:

           Unit type    Identifier    Example    Supported

            Number         none         27.3        Yes
            Inches         in           3in         Yes
            Pixels         px           120px       Yes
            Percentage     %            50%         Yes
            Millimetres    mm           77mm        Yes
            Centimetres    cm           7cm         Yes
            Points         pt           24pt        No
            em-Square      em                       No
            x-width        ex                       No

           Any units that are not supported will be returned as a zero
           value to the SVG processor by the CSS style parser.


6.6.10. Color

        a. Colors can be specified by name, ie "red" or using the #rrggbb format
           such as #FF0000 or using #rgb format such as #f00 to indicate red.
           CSS2 also allows the following forms which are also now supported
           (as of the 0.3b release):

                rgb(255,0,0) to also indicate red, and

                rgb( 100%,0%,0%) as well

        b. the icc-color-profile property is not supported.

        c. Although the CSS 2 specification only defines the names of 16 basic
           colors, such as "red", "green" and "lime", the renderer recognizes
           about 309 colors by name. This is because most existing web
           applications including the major browsers seem to recognize these
           names and it is possible they may be added to standards one day.

6.6.11. Masking

        a. Support for masking is not implemented.

        b. The following properties are not recognized by the processor:
           - mask
           - mask-method
           - mask-width
           - mask-height
           - mask-bbox

6.6.12.  Markers - the <marker> element

        a. Support for markers is not implemented.


6.6.13. Clipping

        a. The 'clip-rule' property is not supported but the 'clip-path'
           property is supported.

        b. The clip-path property now correctly recognizes the CSS URL syntax
           for references to objects.  An example would be
           style="clip-path:URL(#myCLip)".  This is the correct notation per the
           SVG specification and all references to clips should now be specified
           in this way in your SVG files.  The viewer will no longer recognize
           any of the earlier forms of reference that were supported in earlier
           versions of SVGView.

        c. Currently, only paths and basic shapes (like rect or ellipse) can be
           used to define clips.  The SVG spec allows, other things such as
           text, for example, to also be used.  when defining a clipping path
           but that is not supported in this version.

        d. The <clipPath> element is now recognized and is tested by the
           processor to see if it was defined inside of a <defs> element, also
           the ID of the clipPath is now correctly handled if it is placed on
           the <clipPath> element itself so that complex clips made up of
           multiple parts (sub-elements) can now be defined.

           See the sample clip1.svg for an example of clipping support.

        e. If a path with an ID is defined inside of a <defs> element, it can
           still be used as a clipping path successfully. This is a temporary
           side effect of the way clip support is implemented.

6.6.14. References and ID's

        a. The form "url(#myref)" is recognized on 'stroke' and 'fill' and also
           in the 0.3a version on 'clip-path'.

        b. Naming an element using an ID attribute currently only works for
           paths, patterns and gradients.

6.6.15. Processing of the <SVG> element

        a. The x,y, width and height attributes of the <SVG> element are all
           handled and nested <svg> elements can be used to define new viewports.

        b. The viewBox attribute is correctly handled but the other aspect ratio
           specific attributes are not.

6.6.16. Script

        a. If a <script> tag is present in the SVG file it will be ignored.

6.6.17. The <defs> element

        a. The <defs> element is supported. Any elements defined inside
           of a <defs> ... </defs> section will not be rendered. These items
           may be re-used later, for example as a clip path. See current
           limitations regarding the <use> element and also clipping support.

        b. As an aid to validating SVG files the renderer will check to see if
           elements it knows could be defined inside of a <defs> element are
           defined inside of <defs> and will generate a warning message to the
           console if they are not.

6.6.18. Visibility

        a. The 'visibility' property is not always handled correctly
           by the SVG processor. Visibility should work for groups, paths and
           basic shapes but does not work for text elements.

6.6.19. The <title> and <desc> elements

        a. The <title> and <desc> elements are ignored by the processor.

6.6.20. Text & Font support

        a. The <text> and <tspan> elements are now both supported. However, not
           all of the possible attributes that can be specified on the <tspan>
           element are currently recognized.

        b. The x and y values must be specified for each <text> element
           or the text will be drawn at location (0,0) and will be invisible.

        c. The font-weight property is recognized but you can also include
           weight information in a font-name property such as "Times New Roman
           Bold" to get bold and italic support etc.

        d. The text on a path feature is not supported.

        e. The following list shows which of the text and font related
           properties are recognized and which ones are not. Most of the
           properties are not currently supported; however, fairly decent text
           rendering is still possible. You may want to refer to the sample
           files ( see 6.5.99 below) for examples of using text and fonts.

                Property name            Supported
                -------------            ---------

                font-family              yes
                font-style               yes
                font-variant             no
                font-weight              yes
                font-size                yes
                font-stretch             no
                font-size-adjust         no
                font                     no

                text-anchor              yes
                glyph-anchor             no
                text-decoration          no
                letter-spacing           no
                word-spacing             no
                direction                no
                unicode-bidi             no

        f. SVG fonts defined using the <font> element are not supported in this
           version of the viewer.

6.6.21. Font performance

        a. Due to a known problem in Java 2 (prior to the 1.2.2 level),
           if a font with a name other than one derived from "Times Roman",
           "Courier" or "Helvetica" is used there will be a delay (can be up to
           30 seconds) the first time the font is used while Java queries the
           system fonts.  After that the font will be cached by the SVG
           processor and there is no delay the next time it is used.  The font
           name matching in SVGView is fairly flexible, for example all of the
           following will be recognized and handled correctly:

                "Times Roman"
                "Times Roman Bold"
                "Times New Roman"
                "Times New Roman Bold"
                "Times New Roman Bold Italic"
                "Tms Rmn"

6.6.22. Links - the <a> element

        a. Initial support for links was added in the 0.1e level of the
           renderer. You can add links to your SVG documents. As the mouse
           passes over a link the pointer will change to the "hand" icon and you
           can then click on the link. The linked SVG file will then be loaded
           and displayed.

6.6.23. Events

        a. SVG events like 'onmouseover' are not supported as they are really
           intended for a scripting environment such as a browser.

6.6.24. Performance

        a. This version of the viewer has not undergone detailed performance
           analysis and has not been optimized for speed.

6.6.25. Transforms

        a. All of the possible commands that can be specified using the
           transform attribute are supported and can be combined to produce
           compound transforms.  The transform implementation (starting with
           version 0.1f of the SVG renderer) exactly matches the SVG
           specification and transform commands must be separated by spaces if
           there is more than one command in a list.  In earlier versions of the
           renderer a semi-colon was required.  This did not match the spec.
           Semi-colons are no longer recognized as a valid delimitter for
           transform commands.

           Examples of supported commands are:

              transform="matrix(1 0 0 1 20 30)"
              transform="scale(2,3)"
              transform="matrix(1 0 0 1 0 0) scale(2)"
              transform="translate(-10,-10) rotate(45) translate(10,10)"

6.6.26. Exceptions

        a. You may see some Java exceptions displayed on the console. SVGView
           does not catch all numeric exceptions. The viewer will still be
           usable even if this does happen for particular SVG files.

6.6.27. Print support

        a. Very basic print support was added for the first time in the 0.1b
           release. This support is not fully working and should be viewed more
           as a statement of intent than as a fully working feature.

6.6.28. Image support - the <image> element

        a. The <image> element is supported but only the set of image file
           formats supported by Java 2 are supported. These are GIF and JPEG.

        b. PNG files are supported by Java 2 at the JDK 1.3 level but we have
           not yet tested SVGView in that environment although it is known
           to run.

        c. It is valid to point to another SVG file using the <image> element
           but that is not supported by the viewer.

6.6.29. Antialiasing/Rendering hints

        a. The viewer now correctly recognizes the new 'shape-rendering' and
           'text-rendering' properties. These replace the prior
           'stroke-antialiasing' and 'text-antialiasing' properties which are no
           longer recognized by the viewer.

           You can use the following table to find out whether or not the viewer
           will use antialiasing for each of the possible values of the text and
           shape rendering hints.

           'shape-rendering'

              VALUE                       ANTIALIAS Y/N ?

              auto                           yes
              optimizeSpeed                  no
              crispEdges                     no
              geometricPrecision             yes


           'text-rendering'

              VALUE                       ANTIALIAS Y/N ?

              auto                           yes
              optimizeSpeed                  no
              optimizeLegibility             yes
              geometricPrecision             yes

           Note that the default value assumed by the viewer for both
           'text-rendering' and 'shape-rendering' is "auto".  In other words,
           if values are not explicitly given for 'shape-rendering' then by
           default shapes will be antialiased.  Likewise, if the
           'text-rendering' property is not specified in the SVG file then by
           default text will be antialiased.


6.6.30. Animation

        a. None of the SVG animation features are currently supported.


6.6.99 Samples

        SVGView comes with more than 125  fully annotated sample SVG files as
        well as a copy of the March 3rd 2000 DTD, against which
        all of the samples have been validated and tested.

        Examples of most if not all of the supported parts of the SVG grammar
        can be found in the sample SVG files that accompany SVGView.

        The sample SVG files currently match the March 3rd 2000 DTD.

        The sample files directory contains an index file (itself an SVG
        document) for the samples, called index.svg. It contains links to all of
        the styleable samples so you can use it to quickly browse some or all
        of the sample files.


7. CHANGE HISTORY
-----------------

7.1 Version 0.4a (April-11th 2000) - LATEST VERSION

  1. A new graphical DOM Tree View window has been added that allows the actual
     SVG (XML) DOM tree as maintained internally by SVGView to be viewed by the
     user. The DOM View window can be displayed by selecting it from the pop-up
     menu (right click in the display area) or from the View menu in the SVGView
     menu bar. The DOM viewer can also be used to dynamically edit the contents
     of the DOM. By simply double clicking (sometimes three clicks are required)
     on an attribute value or a text node you can go into "edit mode" and edit
     the values. When you press the Enter key on the keyboard to finish editing
     a particular node, SVGView will reprocess the edited DOM and you will see
     the results of your changes. We hope that SVG prototypers will find this
     both useful and insightful. Only attributes and text nodes can be edited
     in this version.

  2. Fixed the SourceView window so that it is not blank when displaying large
     SVG files. This was caused by an AWT TextArea limitation on some operating
     system platforms which has been resolved by re-implementing the Source
     Viewer using Swing components.

  3. Further improved performance of both initial rendering and re-rendering
     of SVG files. Added additional internal caching so that re-rendering, such
     as zoom-in and zoom-out, of a loaded file is faster.

  4. Made changes to prevent unnecessary repaints that would occur under certain
     circumstances. Painting performance is also now improved as a result.

  5. Added a progress bar in the bottom right hand corner of the viewer window
     that shows a percentage complete status during the rendering of an SVG
     image. This is useful feedback, particular during the rendering of large
     SVG files.

  6. The SVG rendering engine has been re-coded to use just the W3C DOM API as
     exported by the Xerces parser and to no longer use the TX parser extensions
     that were provided by the earler XML4J parser. This has resulted in visibly
     less time being spent during the parsing of SVG documents. This was a
     fairly major change to the internal structure of the code but is only
     visible to the end user in that parsing is now significantly faster. The
     processing of the DOM (once the SVG document has been parsed) is now more
     efficient also.

  7. Added the ability to save the current view as a JPEG file by selecting
     the new "Save as JPEG" option from the file menu.

  8. Added support for the CSS 'color' property and added support so that
     the value 'currentColor' is recognized by the 'fill' and 'stroke'
     properties such that style rules such as the following may be applied:

       style = "color:blue ; fill:currentColor"

     The file colors5.svg was added to the samples directory to demonstrate this
     capability.

  9. Fixed a bug that would cause an exception during rendering if a
     'stroke-width' property was specified with a value that used CSS units.
     Examples of failing cases were:

       stroke-width:0.1cm
       stroke-width:10cm

 10. Fixed a bug that could cause an exception when SVGView was reading the
     SVGView.properties file entry for progressive rendering if there were
     spaces after the number.

 11. Fixed a bug in the support for the <rect> element that was causing the
     rx and ry attributes to not be handled correctly (for rounded corners)
     and would cause the rectangles to have incorrect rounding of the corners.

 12. Fixed the renderer to recognize the fill rule property under its new name
     of 'fill-rule' rather than it's old name of 'fillrule'. The relevant
     samples in the samples directory were also updated.

 13. Fixed a bug that would cause the renderer to take an exception while
     processing <linearGradient> elements if any of the x1, y1, x2 and y2
     attributes were omitted from the defintion of the gradient in the SVG file.
     If any of these values are omitted, the renderer will now map the
     respective values as follows (relative to the current viewport)

       x1  <== 0%
       y1  <== 0%
       x2  <== 100%
       y2  <== 0%

 14. Fixed a bug that would cause the SVG file not to parse cleanly (and fail to
     load) if the SVG file referenced the SVG DTD using a relative path
     reference such as SYSTEM "svg-20000202.dtd" and the DTD in the same
     directory as the SVG file being loaded but a copy of the DTD was not also
     present in the same directory as SVGView.jar.  This is now fixed.  SVGView
     will now find DTD's that are in the same directory as the file being loaded
     and nowhere else.  This allows (as SVG evolves) for different versions of
     the DTD to be referenced by different files.  Of course, it is strongly
     recommended that all SVG files, where possible, reference the "master" SVG
     DTD at the W3C web site.  This will be especially true once SVG is a W3C
     recommendation.

 15. Fixed the SVG processing code so that an exception will no longer be taken
     if the value specified for 'font-size' is not numeric.

 16. Fixed a bug where the viewer was not reloading images used in SVG files
     when the reload button was pressed, instead the images were being taken
     from the viewers image cache (even though the SVG file itself was reloaded
     and reparsed).

 17. Due to more efficient memory usage, the built in default maximum zoom level
     (used when the value is not set using the SVGView.properties file) has
     been changed from 45 times to 450 times. As before, this value can be
     adjusted by editing the SVGView.properties file.

 18. Changed the SVG processor to no longer recognize the value "default" for
     the rendering properties such as 'shape-rendering' but instead to
     recognize the value "auto". This brings SVGView into line with the current
     SVG spec's definition of this value. All of the samples have also been
     updated to reflect this.

 19. Fixed a bug whereby pattern fills were incorrectly getting inherited.

     For example, in for the following svg snippet:

      <g style="fill:url(#myPattern)">
        <rect x="50" y="50" width="100" height="100"/>

        <g style="fill:blue">
          <rect x="200" y="200" width="100" height="100"/>
        </g>
      </g>

      The second rectangle would have been filled with the pattern rather
      than with the color blue. This is now fixed.

 20. Improved networking support.

     a. The viewer will now recognize the MIME type image/svg-xml as well as
        image/svg (for compatiblity with some existing SVG files).

     b. Added a timeout value to the SVGView.properties file that can be used
        to specify how much time to wait before the socket times out. This is
        useful when dealing (for example) with servers that may take a while
        to respond to an initial connection.

     c. Added an additional timeout value to the properties file that can be
        used to specifiy how long the viewer should wait (with an open
        connection) for data. Again this is very useful when getting SVG
        data from servers that may be very busy or take a while to generate
        the data (for example due to complex transcoding of large files to
        generate the SVG on the server before returning that data to the
        client).

 21. Updated the SVG renderer's support for transforms to parse transforms
     of the form "translate(100,100) rotate(45) translate(-100,-100)" in the
     order they are found. This makes SVGView consistent with the current
     SVG specification. Many of the samples have been updated to reflect
     this change. This was also reported to us as a bug against the previous
     version. We also fixed the transform code to prevent an exception that
     would occur if there was a space in the transform string after the closing
     bracket ")".

 22. Updated the renderer so that stroking of text now works. Added some
     samples to the samples directory that demonstrate this capability.

 23. The code has been updated to work with the Xerces XML parser. That
     parser is now also bundled with SVGView as part of the distribution.

 24. The samples directory now has two sub-directories called style and
     exchange. These directories contain examples of each of the current
     SVG syntaxes (as described above).

 25. All of the samples have been updated to use, and have been tested with, the
     SVG-20000303 levels of the SVG DTDs. Both the stylable and exchange
     versions of the DTDs are supported and copies of each are included in the
     samples directories.


================================================================================

7.2 Version 0.3c (December-8th 1999)

  1. Moved the renderer up to the latest level of the SVG specification and
     DTD (December 3rd 1999) with the limitations and restrictions documented
     earlier in this file.

  2. Support for <symbol> and <use> has been significantly enhanced. Many new
     samples have been added to demonstrate many of the new features.

  3. Added smart caching of paths so that the first time an SVG file loads
     (or when it is reloaded) the entire path geometry is parsed but on
     subsequent re-paints (such as when zooming on an image) the path data
     is not regenerated. This means that rendering is now significantly
     faster after the initial load of an SVG file. As a test, try loading
     the Ausmap.svg file (from the samples directory) and then zoom it to
     125%.  In prior versions of SVGView all paths would be re-parsed each time
     the SVG file was rendered. This is no longer done. You should see a
     noticebale reduction in rendering time.

  4. Fixed a bug that caused a closepath (Z) command after an arc command (A)
     in a path to sometimes draw the closing line to the wrong place.

  5. Improved performance of text rendering.

  6. Added several more sample SVG files to the samples directory. All of the
     sample files have been updated to the 19991203 level of the SVG DTD and a
     copy of that DTD is included with the samples.

  7. Did some internal restructuring of source code to improve maintainability
     of the codebase. Not visible to the end user.

================================================================================

7.3 Version 0.3b (November-23rd 1999)

  1. Added configurable progressive rendering support to the viewer. This means
     for large files that you will see them being rendered rather than waiting
     for the completed image to be rendered. Configuration is via the properties
     file.

  2. Improved support for the <clipPath> element such that an id= can be
     specified as an attribute to the clip definition. This means that complex
     clips made up of multiple parts can now be defined and referenced by name
     (id). The clipping samples have been updated to reflect this improvement.

  3. Improved text handling support so that text strings can now be filled with
     both linear and radial gradients. Added several new samples, including
     gradients6.svg to the samples directory to demonstrate some of this.

  4. Improved text handling support so that text strings can now be filled with
     patterns (and textures). Added patterns5.svg and patterns6.svg to the
     samples to demonstrate this. Also added a new logo screen (svgview2.svg)
     that uses gradients, textures and opacity.

  5. Improved support for colors to include the remaining color specification
     styles that had previously not been supported. The following examples
     are now recognized as valid

              rgb( 100%,100%,50% )
              rgb( 255,255,127 )

  6. Improved handling of nested <svg> elements such that the x,y,width and
     height attributes are all recognized and can be used to define new
     viewports. Added several samples to the samples directory to demonstrate
     this. See viewports1.svg, viewports2.svg etc.

  7. Fixed a bug that stopped printing from working (just displayed an error
     message popup) on some systems.

  8. Added several new samples to demonstrate gradients and patterns being used
     to fill text strings and several additional miscellaneous other samples.

  9. Added support such that stroke-opacity and fill-opacity now correctly
     recognize percentage units (%) as well as numbers such as 0.4, 0.5 etc.
     Valid examples of opacity supported now include:

       stroke-opacity:50%
       stroke-opacity:0.5

 10. Fixed a bug that could cause the viewer to hang while rendering in certain
     cases.

 11. Added support for the <symbol> element (see 6.6.7).

 12. Added support for the <use> element (see 6.6.13).

 13. Added support for the text-anchor property. Added a new sample called
     textanchor.svg to demonstrate this feature.

 14. Corrected gradient stop processing to recognize the 'stop-color' property
     rather than the 'stop' property. Updated all samples that use gradients.

 15. Fixed a bug that meant that scrolling and zooming did not work if clipping
     was applied in the SVG file at the group <g> level. This could be seen by
     viewing the file clip3.svg from the samples directory and trying to zoom in
     on it or scroll the image.

 16. Added index.svg to the samples directory. This file displays a list of all
     the SVG samples and allows user to select them for viewing by clicking on
     their names.

 17. Added a new entry to the SVGView.properties file that allows the dots per
     inch (DPI) value of a printer to be overridden. This allows for more
     accurate scaling of SVG images when printed.

 18. Generally improved zooming and rotating using the viewer's toolbar. Fixed
     some bugs and improved the positioning of the image relative to the
     viewport after a zoom or rotate.


================================================================================

7.4 Version 0.3a (October-14th 1999)

  1. Updated the path processor to match latest spec. See 6.6.2 above for full
     details.

  2. Added socks support so that remote DTD's on the internet can be accessed
     even if the viewer is being run from behind a firewall.

  3. Added DTD caching support so that remote DTD's will be automatically cached
     locally by the viewer so that SVG files that refer to remote DTD's can
     still be viewed locally while off-line (i.e. on an aircraft).

  4. Added support for URL's such that the name of an SVG file can be entered
     into the filename entry field such as http://myserver/myfile.svg.

  5. Upgraded the source viewer to correctly handle remote files accessed by
     URL and allow the source to be viewed.

  6. Updated the CSS property support to recognize the new 'shape-rendering' and
     'text-rendering' properties that replace the previous 'stroke-antialiasing'
     and 'text-antialiasing' properties. The samples have also been updated to
     reflect these changes. Please see section 6.6.30 above for more details
     about these new properties and the use of antialiased rendering techniques.

  7. Added support for the <tspan> element. See section 6.6.21 above for details
     of some limitations relative to support for <tspan> in the current version.
     Also added a "tspan.svg" file to the sample file directory.

  8. Fixed a bug that caused styles to be ignored if the string terminated with
     a semi-colon and a space, as in:

           style="stroke:blue; fill:green; "

  9. Fixed a small bug that could cause a 1 pixel by 1 pixel zoom rectangle to
     be left visible on the screen.

 10. The SVGView.properties file is now correctly read at application start
     time. You can edit this file to tell the viewer about socks servers and
     configure other network and more general viewer settings. See also section
     6.5.9 for full details of these settings.

 11. Fixed bug that caused the viewer to fail to find files and images when
     spaces were present in the directory and/or file name

 12. Updated the SVG processor so that CSS units are handled correctly on x and
     y type attributes as well as width and height. Per the latest spec this is
     now allowed. For example, the following SVG fragment would have caused
     earlier versions of the SVG renderer to take an exception while processing
     the x and y attributes. This use of CSS units is now handled correctly in
     this release.

        <rext x="0.5in" y="0.2in"  width="2in" height="4in" />

     CSS units should now be handled correctly for any occurrence of the
     following attributes:

         x
         y
         x1
         y1
         x2
         y2
         rx
         ry
         r
         width
         height


 13. Enhanced Debugging support to log environment, working directory and build
     values.

 14. Improved performance of hit test code that detects when the mouse is over
     an object with an associated link.

 15. Changed the SVG rendering code to recognize the new viewBox attribute on
     the <SVG> element. This replaces the previous fitBoxToViewport attribute
     which is no longer recognized by the renderer.

 16. Changed the SVG rendering code to recognize "xlink:href" rather than just
     "href" when linking to images and patterns. The "href" attribute by itself
     is no longer recognized by the renderer.

 17. Changed the renderer to recognize the new 'clip-path' property which is
     functionally equivalent to but replaces the previous 'clippath' property.
     The 'clippath' property is no longer recognized by the renderer.

 18. Updated the SVG renderer so that the URL syntax is now supported for the
     clip-path property. This support previously only worked for the 'stroke'
     and 'fill' properties. An example would be style="clip-path:URL(#myClip)".

 19. Added support to the renderer so that basic shapes can now also be used
     (previously only paths were supported) to define clips. See the new samples
     clip4.svg and clipimage2.svg for examples of this. See also the
     restrictions documented above in section 6.6.14 for some limitations in
     clipping support.

 20. Added initial support for the <clipPath> element with limitations.
     See 6.6.14 above.

 21. Fixed a bug that meant that if the URL was specified in lowercase as part
     of a stroke or fill reference to a pattern it was not recognized. Both
     upper and lower case spellings of URL are now recognized.

 22. Verified that SVGView worked with the latest XML4J version 2.0.15



================================================================================

7.5 Version 0.2a (August-18th 1999)

  1. Second version to appear on alphaWorks.

  2. Support was added for linear and radial gradients. See the description
     above in section 6.5.5 for details of a few current limitations.

  3. Font support improved.

     Support for additional properties added:

     a. font-weight
     b. font-style
     c. Improved support for font family so that a list of candidate names can
        be provided and the first match will be chosen (if there are any
        matches). For example:

        <text x="20" y="240"
          style="font-family: Baskerville, Heisi Mincho W3, Symbol, serif">
            Hello World
        </text>

  4. Some general clean up and bug fixing was done to the renderer based on our
     testing and feedback from users.


================================================================================

7.6 Version 0.1g (August-3rd 1999)

  1. Changed fitBoxToViewport implementation so that the box definition is
     interpreted as an upper left coordinate followed by a width and a height
     rather than upper left and lower right coordinates.  This correctly matches
     the SVG specification.

  2. The <style> element is supported as is the class attribute where applicable.
     This allows for named styles to be defined and applied using the class
     attribute. A simple example of this would be:

        <svg width="300px" height="300px"  >
          <defs>
            <style> <![CDATA[
               .krl1 { fill:blue ; stroke:red  ; stroke-width:4 } ]]>
            </style>
          </defs>
          <rect class="krl1" x="25"  y="50"  width="100" height="50" />
        </svg>

   3. The xmlns= attribute on the SVG element (set as a fixed value by the SVG
      DTD) is recognized and ignored by the renderer. This prevents an
      unrecognized attribute warning message being displayed.


================================================================================


7.7 Version 0.1f (July-30th 1999)

   1. The fitBoxToViewport attribute is recognized on the outermost <SVG> node
      of the document.

   2. Changed transform code to parse multi command transforms according to the
      latest SVG spec. The only change is that whereas before transforms were
      delimitted by semi-colons they must be delimitted by spaces. For example:

          transform = "scale(2);translate(50,50)"

      must be written as:

          transform = "scale(2) translate(50,50)"


================================================================================

7.8 Version 0.1e (July-7th 1999)

    1. Changed the default value of the 'fillrule' property to be "evenodd"
       rather than "nonzero". This correctly matches the SVG spec.

    2. The <pattern> element is supported.

    3. Links, the <a> element is supported.


================================================================================

7.9 Version 0.1d (June-30th 1999)

    1. This was the first version to be made publicly available on alphaWorks.

    2. Transforms

       The skew-x and skew-y transform commands are supported. This means
       that all of the transform commands are supported. The complete list
       of supported transforms is:

             matrix
             translate
             scale
             rotate
             skew-x
             skew-y

    3. Definitions - the <defs> element

       The <defs> element is supported. Items declared inside of a
       <defs> ... </defs> section will not be rendered at the time they
       are processed (there may be rare cases where they still appear but
       these will be fixed soon). This is not very useful at this time but
       is the groundwork required for the implementation of the <use> element
       which will be done in a pending version.

    4. Colors

       The CSS style shorthand for RGB colors #rgb is supported. So as
       well as the long form of #rrggbb (such as #ff0000 for red), the short
       form such as #f00 can also be used.

    5. Visibility

       The visibility property is recognized in "style=" strings.
       An example of its use is:

            <rect with="100" height="100" style="visibility:true" />

       Visibility is not supported for text elements but is supported
       correctly for elements such as <rect>, <circle> and <path>.

    6. Units and numbers

       Support for CSS units has been improved. The following units are
       correctly supported:

            numbers  - 27     (number)
            "px"     - 4px    (pixels)
            "%"      - 50%    (percentage)
            "in"     - 3in    (inches)
            "cm"     - 12cm   (centimeters)
            "mm"     - 20mm   (millimeters)

    7. Text

       Improved text support to correctly coalesce whitespace characters and
       replace with a single space. So a string containing carriage returns
       (depicted as <cr>) such as:

               "Hello<cr><cr><cr>World"

       will be rendered as:

                Hello World

       This is consistent with the whitespace handling rules as defined in the
       XML 1.0 specification that the SVG spec follows.

       The xml:space attribute is recognized. If xml:space="default" (or is not
       specified) then all whitespace will be coalesced and replaced with a
       single space. If xml:space="preserve" then all whitespace characters will
       be replaced with actual spaces. So if xml:space was set to "preserve"
       then the string above would be rendered as:

               "Hello   World"

       Added a new sample whitespace1.svg to the sample set that demonstrates
       this feature.


================================================================================

7.10 Version 0.1c (June-18th 1999)

    1. Rounded rectangles

       Rectangle rounding is supported. The rx and ry attributes on
       the <rect> element will be recognized and processed.


================================================================================

7.11 Version 0.1b (June-14th 1999)

    1. SVG elements

       <SVG> elements can be nested although the viewport changing attributes
       are still ignored.

    2. Basic shapes

       The <circle> and <ellipse> elements recognize the correct attribute names
       as per the June-25th DTD. Namely cx,cy and r for <circle> and cx,cy,rx
       and ry for <ellipse>

    3. Samples

       All of the samples have been updated to indicate which level of the SVG
       spec they support and a <!DOCTYPE ... > line has been added to include
       the DTD. Also, a copy of the DTD is bundled with the samples.

    4. CSS Units processing

       Using CSS units (such as "4in" for width and height attributes no longer
       causes a Java exception. However, only pixel 'px' units are handled
       correctly. All other unit types will, temporarily in this release, yield
       a 0 value.

    5. Print support

       Very basic print support has been added. It has lots of problems and will
       be improved over time - this is work in progress and is not complete in
       this version. Also, the Java JDK needs to be at the 1.2.2 level or higher
       otherwise no text output will appear when printed.


================================================================================

7.12 Version 0.1a (June-11th 1999)

    1. This was the initial version.


================================================================================


8. ACKNOWLEDGEMENTS
-------------------

Our thanks to Vincent Hardy, Java Architect, Sun Microsystems, Inc.
The implementation of radial and linear gradients is based upon sample code
contained in his Graphics Layer Framework package (GLF). For further details
see http://developer.java.sun.com/developer/Books/2dgraphics/


9. TRADEMARKS, COPYRIGHTS
-------------------------

IBM is a registered trademark of International Business
Machines Corporation in the U.S., or other countries, or
both.

Java and all Java-based marks are trademarks or registered
trademarks of Sun Microsystems, Inc.  in the U.S. and other
countries.

Windows is a registered trademarks of Microsoft Corp.  in
the United States and/or other countries.

Other company, product, and service names may be trademarks
or service marks of others.

THIS DOCUMENT IS PROVIDED "AS IS" WITHOUT WARRANTY
OF ANY KIND.  IBM AND DISCLAIMS ALL
WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
FITNESS FOR A PARTICULAR PURPOSE AND
MERCHANTABILITY WITH RESPECT TO THE INFORMATION IN
THIS DOCUMENT.  BY FURNISHING THIS DOCUMENT, IBM
GRANTS NO LICENSES TO ANY PATENTS OR COPYRIGHTS.


Copyright (c) IBM Corporation 1999, All rights reserved.

[END OF README]

