CR2V - celinea Raster to Vector converter
       http://www.celinea.com

usage  : cr2v input_file [parameters]
example: cr2v modele32.jpg modele32.set

Input formats: BMP,GIF,JPEG,PNG,PNG,TIFF
After conversion, the result is saved under the input_file name
with extension .svg and .ps
        		        * * *

Parameters are read from a text file (named .set)
Edit default.set to set your own parameters :

1) low_color_threshold
Number between 0 and 440.
This represents the minimum color difference between regions.
EXAMPLE: 20 for bad contrasted photography up to 40 for
well contrasted ones. 

2) hi_color_threshold
Number between low_color_threshold and 440.
This represents the minimum color difference between details.
To obtain the maximum details, set this number to low_color_threshold
EXAMPLE: 100 for correct details, 200 for few details.

3) minimum_area
Minimum size for regions which are not details.
EXAMPLE: For an image 500�500, 10 corresponds to small details,
50 for big ones.

4) abs_curvefit or rel_curvefit
Gives the maximum error in pixels between shapes and the fitted
Bezier curves.
The error given by rel_curvefit depends on the length of the outline
(relative) whereas the abs_curvefit is an absolute error.
EXAMPLE: An absolute error of 1 to 3 pixels is generally used.

Use rel_curvefit to smooth big shapes while maintaining small ones.
EXAMPLE: 0.2 for smooth shapes, 0.3 for very smooth.

5) linear_simplify
Use this coefficient to simplify some curves into lines.
The coefficient linear_simplify is the maximum error admitted between 
a curve and the approximated line.
EXAMPLE: The most commonly used coefficient is 0.5.


Known Issues:
The Microsoft C runtime libraries (msvcrtd.dll and msvcrt.dll) are needed to run the program. 

        		        * * *
CV 30/10/2000


