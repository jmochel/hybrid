
Installing Proj Clock 

Use the setup program to make the initial install on a network location for a multi-user environment, or on a local drive for a single-user.  For a network install it is best to use the Network option of the setup program.  This is because the default setup creates a program group and a Windows uninstall string.  See the Network Setup shortcut for an example on using this option.


Using Your Old Data

Version 3.00 of this software now has a different name and thus will be installed into a different default folder.  If you have used a previous version of this software you must either install the program into the old folder or install it into a new folder and copy your data files over to the new folder.  

If you used version 2.X of the software you must copy to the new folder all the files ending with the Dat extension.  On running Proj Clock the old data should be automatically imported.
