This binary is distributed under the terms of the Gnu Public License.
See http://cvshome.org for a full copy of the license.  Source code is
available at the same site.

No warranties, express or implied, not even for merchantability or fitness
for a particular purpose.

Please be aware that the included CVS 1.11 executable has undergone only
cursory command line testing.  The test suite does not currently run under
Windows and has not been run.
