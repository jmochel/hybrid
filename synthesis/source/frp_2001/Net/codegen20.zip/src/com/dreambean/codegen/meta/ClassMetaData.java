/*
 * Copyright 1999 by dreamBean Software,
 * All rights reserved.
 */
package com.dreambean.codegen.meta;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.dreambean.codegen.CodeGenerator;
import com.dreambean.codegen.MetaData;
import com.dreambean.codegen.tags.ClassTags;

/**
 *   This is a source code generator. It's primary use is to generate classes derived from other classes such as RMI-stubs, object-proxies etc.
 *   This is done by writing a code-template using a XML-like language and then subclass this class and implement the tags that have been used in the template file.
 *		
 *   @author Rickard �berg
 *   @version 1.3
 */
public class ClassMetaData
	implements MetaData
{
   // Attributes ----------------------------------------------------
   Class clazz;
   
   // Static --------------------------------------------------------
   /**
    *   Removes the package name from a full classname
    *
    * @param   className  the full classname
    * @return     the classname
    */
   static String removePackage(String className)
   {
      if (className.lastIndexOf('.') != -1)
         className = className.substring(className.lastIndexOf('.')+1);
         
      return className;
   }

   // Public --------------------------------------------------------
   public void setGenerator(CodeGenerator codegen)
	{
		String clazz = codegen.getConfiguration().getProperty("class");
		if (clazz != null)
		{
			try
			{
				setClass(Class.forName(clazz));
				codegen.addTags(new ClassTags());
			} catch (Exception e)
			{
				throw new IllegalArgumentException("Could not load class "+clazz);
			}
		}
	}
   
   /**
    *   Set the class to extract metadata from
    *
    * @param   class the class
    */
   public void setClass(Class clazz)
   {
   	this.clazz = clazz;
   }

   public Method[] getPublicMethods()
   {
   	return clazz.getMethods();
   }

	public String getFullClassName()
	{
		return clazz.getName();
	}
	
	public String getClassName()
	{
		return removePackage(getFullClassName());
	}
	
	public String getPackage()
	{
      String packageName = clazz.getName();
      if (packageName.lastIndexOf('.') == -1)
         return "";
      else
         return packageName.substring(0,packageName.lastIndexOf('.'));
	}

	public Constructor[] getConstructors()
	{
		return clazz.getConstructors();
	}
}