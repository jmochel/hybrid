/*
 * Copyright 1999 by dreamBean Software,
 * All rights reserved.
 */
package com.dreambean.codegen;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/**
 *   This is a source code generator. It's primary use is to generate classes derived from other classes such as RMI-stubs, object-proxies etc.
 *   This is done by writing a code-template using a XML-like language and then subclass this class and implement the tags that have been used in the template file.
 *		
 *   @author Rickard �berg
 *   @version 1.3
 */
public interface MetaData
{
   // Public --------------------------------------------------------
   /**
    *   This is the main generating code. It looks through a given template and attempts to find XML-tags (e.g. "Header goes here <method>Generate this</method> and here's the footer") and calls the methods which corresponds to the tagnames.
    *
    * @param   template  the "XML"-template
    */
   public void setGenerator(CodeGenerator gen);
}