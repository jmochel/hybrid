/*
 * Copyright 1999 by dreamBean Software,
 * All rights reserved.
 */
package com.dreambean.codegen.tags;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.dreambean.codegen.CodeGenerator;
import com.dreambean.codegen.TagLibrary;
import com.dreambean.codegen.meta.ClassMetaData;

/**
 *   This is a source code generator. It's primary use is to generate classes derived from other classes such as RMI-stubs, object-proxies etc.
 *   This is done by writing a code-template using a XML-like language and then subclass this class and implement the tags that have been used in the template file.
 *		
 *   @author Rickard �berg
 *   @version 1.3
 */
public class CommonTags
	implements TagLibrary
{
   // Attributes ----------------------------------------------------
   protected CodeGenerator gen;
   
   // Public --------------------------------------------------------
   /**
    *   Include a template that is a resource (i.e. a file accessible from the classpath)
    *
    * @param   inFilename  the name of the template
    */
   public void includeResource(String name)
      throws IOException
   {
      InputStream in;
      in = getClass().getResourceAsStream("/"+name);
         
      if (in == null)
      {
         throw new IOException("Template '"+name+"' does not exist");
      }
   
      gen.generate(in);
   }
   
   /**
    *   Return todays date. Useful for code headers
    *
    * @return     todays date as a string
    */
   public String now()
   {
      return new java.util.Date().toString();
   }

   /**
    *   Template comment. Do nothing
    *
    */
   public void comment(String template)
   {
   }
   
   // TagLibrary implementation -------------------------------------
   public void setGenerator(CodeGenerator gen)
	{
		this.gen = gen;
	}
	
	// Protected -----------------------------------------------------
}