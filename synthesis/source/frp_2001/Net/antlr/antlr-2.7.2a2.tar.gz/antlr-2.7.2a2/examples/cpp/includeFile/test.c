int a,b;
#include "incl.h"
int c;
