#include <iostream>
#include "SupportTest.hpp"

int main()
{
	SupportTest::main();
	return 0;
}

