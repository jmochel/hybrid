package antlr;

/* ANTLR Translator Generator
 * Project led by Terence Parr at http://www.jGuru.com
 * Software rights: http://www.antlr.org/RIGHTS.html
 *
 * $Id: //depot/code/org.antlr/main/main/antlr/TokenStream.java#4 $
 */

public interface TokenStream {
    public Token nextToken() throws TokenStreamException;
}
