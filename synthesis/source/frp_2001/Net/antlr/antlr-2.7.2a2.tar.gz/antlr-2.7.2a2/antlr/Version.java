package antlr;

public class Version {
    public static final String version = "2";
    public static final String subversion = "7";
    public static final String patchlevel = "2a2";
    public static final String datestamp = "20020112";
    public static final String project_version = "2.7.2a2 (20020112-1)";
}
