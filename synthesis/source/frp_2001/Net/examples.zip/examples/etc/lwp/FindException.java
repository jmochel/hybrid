package com.imaginary.lwp;

public class FindException extends Exception {
    public FindException() {
        super();
    }

    public FindException(String rsn) {
        super(rsn);
    }
}
