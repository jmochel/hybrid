package com.imaginary.lwp;

public class LookupException extends Exception {
    public LookupException() {
        super();
    }

    public LookupException(String rsn) {
        super(rsn);
    }
}
