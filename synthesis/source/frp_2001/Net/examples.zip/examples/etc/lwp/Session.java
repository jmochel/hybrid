package com.imaginary.lwp;

import java.rmi.Remote;

public interface Session extends Remote {
    
}
