// This code has been generated. Do not modify!
package java.util;

/*
 *  This is a template for debugging classes. It implements a given interface and upon 
 *  method call it delegates to another object of the same interface and write some debug info
 *  to System.err. It is very useful for debugging control flow.
 */
public class ObserverDebug
  implements Observer
{
   Observer obj;

   public ObserverDebug(Observer obj)
   {
     this.obj = obj;
   }
   
   
   public void update(java.util.Observable arg0, java.lang.Object arg1)
      
   {
      System.out.println(obj+".update("+arg0+", "+arg1+""+")");
       obj.update(arg0, arg1);
   }
   
   
}
