/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xwingml.*;


public class DOMTreeModel extends DefaultTreeModel
{
   public DOMTreeModel()
   {
      super(new DefaultMutableTreeNode("DOM"));
   }

   public void setDOM(Document document)
   {
      DefaultMutableTreeNode  rootNode;


      rootNode = new DefaultMutableTreeNode("DOM");
      addChildren(rootNode, document);
      setRoot(rootNode);
      reload();
   }

   protected void addChildren(DefaultMutableTreeNode parentNode, Node domNode)
   {
      NodeList                childNodes;
      NamedNodeMap            attributes;
      Node                    node;
      String                  nodeName;
      String                  nodeValue;
      Node                    attrNode;
      DefaultMutableTreeNode  treeNode;
      DefaultMutableTreeNode  attributesNode;
      DefaultMutableTreeNode  attributeNode;
      int                     i;
      int                     j;


      childNodes = domNode.getChildNodes();
      if (childNodes != null)
      {
         for (i = 0; i < childNodes.getLength(); i++)
         {
            node = childNodes.item(i);
            switch (node.getNodeType())
            {
               case Node.CDATA_SECTION_NODE:
                  nodeName = "CDATA";
                  break;

               case Node.COMMENT_NODE:
                  nodeName = "COMMENT";
                  break;

               case Node.DOCUMENT_FRAGMENT_NODE:
                  nodeName = "DOCUMENT FRAGMENT";
                  break;

               case Node.DOCUMENT_NODE:
                  nodeName = "DOCUMENT";
                  break;

               case Node.ELEMENT_NODE:
                  nodeName = "ELEMENT[" + node.getNodeName() + "]";
                  break;

               case Node.ENTITY_NODE:
                  nodeName = "ENTITY[" + node.getNodeName() + "]";
                  break;

               case Node.ENTITY_REFERENCE_NODE:
                  nodeName = "ENTITY REFERENCE[" + node.getNodeName() + "]";
                  break;

               case Node.NOTATION_NODE:
                  nodeName = "NOTATION";
                  break;

               case Node.PROCESSING_INSTRUCTION_NODE:
                  nodeName = "PI";
                  break;

               case Node.TEXT_NODE:
                  nodeName = "TEXT";
                  break;

               default:
                  nodeName = "UNKNOWN";
                  break;
            }
            nodeValue = node.getNodeValue();
            if (nodeValue != null)
            {
               if (nodeValue.length() > 32)
               {
                  nodeValue = nodeValue.substring(0, 29) + "...";
               }
            }
            else
            {
               nodeValue = "";
            }
            treeNode = new DefaultMutableTreeNode(nodeName + ": " + nodeValue);
            parentNode.add(treeNode);
            attributes = node.getAttributes();
            if ((attributes != null) && (attributes.getLength() > 0))
            {
               attributesNode = new DefaultMutableTreeNode("Attributes");
               treeNode.add(attributesNode);
               for (j = 0; j < attributes.getLength(); j++)
               {
                  attrNode = attributes.item(j);
                  attributeNode = new DefaultMutableTreeNode(attrNode.getNodeName()+ "=\"" + attrNode.getNodeValue() +"\"");
                  attributesNode.add(attributeNode);
               }
            }
            if (node.hasChildNodes())
            {
               addChildren(treeNode, node);
            }
         }
      }
   }
}
