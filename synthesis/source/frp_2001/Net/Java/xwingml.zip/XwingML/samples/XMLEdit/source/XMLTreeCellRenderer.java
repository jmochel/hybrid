/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import com.bluestone.xwingml.*;

public class XMLTreeCellRenderer implements TreeCellRenderer, XwingMLIPlugIn
{
   protected XwingMLIContext  m_context;
   protected JLabel           m_iconLabel;
   protected ImageIcon        m_fileIcon;
   protected ImageIcon        m_folderExpandedIcon;
   protected ImageIcon        m_folderCollapsedIcon;
   protected JLabel           m_textLabel;
   protected Color            m_background;
   protected Color            m_foreground;
   protected Color            m_selectionBackground;
   protected Color            m_selectionForeground;
   protected JPanel           m_panel;


   public XMLTreeCellRenderer()
   {
      m_iconLabel = new JLabel();
      m_iconLabel.setBorder(null);
      m_textLabel = new JLabel();
      m_textLabel.setOpaque(true);
      m_textLabel.setFont(UIManager.getFont("Tree.font"));
      m_textLabel.setBorder(null);
      m_panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
      m_panel.setOpaque(false);
      m_panel.add(m_iconLabel);
      m_panel.add(m_textLabel);
      m_foreground = UIManager.getColor("Tree.foreground");
      m_background = UIManager.getColor("Tree.background");
      m_selectionForeground = UIManager.getColor("Tree.selectionForegorund");
      m_selectionBackground = UIManager.getColor("Tree.selectionBackground");
   }

   public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
   {
      if (leaf)
      {
         m_iconLabel.setIcon(m_fileIcon);
      }
      else
      {
         if (expanded)
         {
            m_iconLabel.setIcon(m_folderExpandedIcon);
         }
         else
         {
            m_iconLabel.setIcon(m_folderCollapsedIcon);
         }
      }
      m_textLabel.setText(value.toString());
      if (selected)
      {
         m_textLabel.setForeground(m_selectionForeground);
         m_textLabel.setBackground(m_selectionBackground);
      }
      else
      {
         m_textLabel.setForeground(m_foreground);
         m_textLabel.setBackground(m_background);
      }
      return m_panel;
   }

   public void setContext(XwingMLIContext context)
   {
      m_context = context;
      m_fileIcon = m_context.getImageIcon("file.gif");
      m_folderCollapsedIcon = m_context.getImageIcon("folderCollapsed.gif");
      m_folderExpandedIcon = m_context.getImageIcon("folderExpanded.gif");
   }

   public XwingMLIContext getContext()
   {
      return m_context;
   }
}