/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/


package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import java.util.jar.*;
import java.text.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLContext - The default implementation of the XwingMLIContext interface
 *
 * @see XwingMLIContext
 */

public class XwingMLContext implements XwingMLIContext, WindowListener, InternalFrameListener
{
   protected XwingML          m_xwingml;
   protected XMLIParser       m_parser;
   protected Vector           m_xwingmlListeners;
   protected Hashtable        m_properties;
   protected Vector           m_propertyChangeListeners;
   protected Vector           m_frames;
   protected Vector           m_dialogs;
   protected Vector           m_windows;
   protected Vector           m_internalFrames;
   protected Vector           m_resourceDirectories;
   protected Vector           m_resourceJars;
   protected Vector           m_xmlDirectories;
   protected Hashtable        m_classInstances;

   protected static Hashtable m_imageIcons;

   static
   {
      m_imageIcons = new Hashtable();
   }


   /**
    * Constructor - XwingMLConetext
    *
    * @param xwingml the XwingML instance for which this context is being constructed
    */

   public XwingMLContext(XwingML xwingml)
   {
      String                  resourceDirectories;
      String                  xmlDirectories;
      StringTokenizer         stringTokenizer;
      String                  token;


      m_xwingml = xwingml;
      m_parser = XMLParserFactory.makeIParser();
      m_xwingmlListeners = null;
      m_properties = new Hashtable();
      m_propertyChangeListeners = null;
      m_frames = new Vector();
      m_dialogs = new Vector();
      m_windows = new Vector();
      m_internalFrames = new Vector();
      m_resourceDirectories = new Vector();
      m_resourceJars = new Vector();
      m_xmlDirectories = new Vector();
      m_classInstances = new Hashtable();
      resourceDirectories = System.getProperty("resource.path");
      if (resourceDirectories != null)
      {
         stringTokenizer = new StringTokenizer(resourceDirectories, System.getProperty("path.separator"));
         while (stringTokenizer.hasMoreTokens())
         {
            token = stringTokenizer.nextToken().trim();
            if (token.length() > 0)
            {
               if (token.endsWith(".jar"))
               {
                  addResourceJar(token);
               }
               else
               {
                  addResourceDirectory(token);
               }
            }
         }
      }
      xmlDirectories = System.getProperty("xml.path");
      if (xmlDirectories != null)
      {
         stringTokenizer = new StringTokenizer(xmlDirectories, System.getProperty("path.separator"));
         while (stringTokenizer.hasMoreTokens())
         {
            token = stringTokenizer.nextToken().trim();
            if (token.length() > 0)
            {
               addXMLDirectory(token);
            }
         }
      }
   }

   /**
    * Method - getXwingML - Get XwingML instance
    *
    * @return xwingml the XwingML instance
    */

   public XwingML getXwingML()
   {
      return m_xwingml;
   }

   /**
    * Method - getXMLIparser - Get XML parser interface (abstracted parser (e.g. IBM or Sun parser))
    *
    * @return parser the parser interface
    */

   public XMLIParser getParser()
   {
      return m_parser;
   }

   /**
    * Method - addXwingMLListener - Add XwingML listener
    *
    * @param listener the listener to add
    */

   public void addXwingMLListener(XwingMLIListener listener)
   {
      if (m_xwingmlListeners == null)
      {
         m_xwingmlListeners = new Vector();
      }
      m_xwingmlListeners.addElement(listener);
   }

   /**
    * Method - removeXwingMLListener - Remove XwingML listener
    *
    * @param listener the listener to remove
    */

   public void removeXwingMLListener(XwingMLIListener listener)
   {
      if (m_xwingmlListeners != null)
      {
         if (m_xwingmlListeners.contains(listener))
         {
            m_xwingmlListeners.removeElement(listener);
         }
      }
   }

   /**
    * Method - fireXwingMLWarning - Fire XwingML warning
    *
    * @param evt XwingMLEvent instance
    */

   public void fireXwingMLWarning(XwingMLEvent evt)
   {
      int                     i;


      if (m_xwingmlListeners != null)
      {
         for (i = 0; i < m_xwingmlListeners.size(); i++)
         {
            ((XwingMLIListener)m_xwingmlListeners.elementAt(i)).warningEncountered(evt);
         }
      }
   }

   /**
    * Method - fireXwingMLError - Fire XwingML error
    *
    * @param evt XwingMLEvent instance
    */

   public void fireXwingMLError(XwingMLEvent evt)
   {
      int                     i;


      if (m_xwingmlListeners != null)
      {
         for (i = 0; i < m_xwingmlListeners.size(); i++)
         {
            ((XwingMLIListener)m_xwingmlListeners.elementAt(i)).errorEncountered(evt);
         }
      }
   }

   /**
    * Method - addPropertyChangeListener - Add property change listener
    *
    * @param listener the listener to add
    */

   public void addPropertyChangeListener(PropertyChangeListener listener)
   {
      if (m_propertyChangeListeners == null)
      {
         m_propertyChangeListeners = new Vector();
      }
      m_propertyChangeListeners.addElement(listener);
   }

   /**
    * Method - removePropertyChangeListener - Remove property change listener
    *
    * @param listener the listener to remove
    */

   public void removePropertyChangeListener(PropertyChangeListener listener)
   {
      if (m_propertyChangeListeners != null)
      {
         if (m_propertyChangeListeners.contains(listener))
         {
            m_propertyChangeListeners.removeElement(listener);
         }
      }
   }

   /**
    * Method - firePropertyChange - Fire property change (when a property is set or removed)
    *
    * @param evt PropertyChangeEvent instance
    */

   protected void firePropertyChange(PropertyChangeEvent evt)
   {
      int                     i;


      if (m_propertyChangeListeners != null)
      {
         for (i = 0; i < m_propertyChangeListeners.size(); i++)
         {
            ((PropertyChangeListener)m_propertyChangeListeners).propertyChange(evt);
         }
      }
   }

   /**
    * Method - setProperty - Set property
    *
    * @param key the property's key
    * @param value the property's value (may be null, in which case the property is removed)
    */

   public void setProperty(String key, Object value)
   {
      Object                  oldValue;


      if (value != null)
      {
         oldValue = m_properties.get(key);
         m_properties.put(key, value);
         firePropertyChange(new PropertyChangeEvent(this, key, oldValue, value));
      }
      else
      {
         removeProperty(key);
      }
   }

   /**
    * Method - getProperty - Get property
    *
    * @param key the property's key
    * @return value the property's value (or null if not found)
    */

   public Object getProperty(String key)
   {
      return m_properties.get(key);
   }

   /**
    * Method - removeProperty - Remove property
    *
    * @param key property's key
    */

   public void removeProperty(String key)
   {
      Object                  oldValue;


      if (m_properties.containsKey(key))
      {
         oldValue = m_properties.get(key);
         m_properties.remove(key);
         firePropertyChange(new PropertyChangeEvent(this, key, oldValue, null));
      }
   }

   /**
    * Method - hasPropertyKey - Has property key ?
    *
    * @param key property's key
    * @return result true/false depending on whether the context has the property key or not
    */

   public boolean hasPropertyKey(String key)
   {
      return m_properties.containsKey(key);
   }

   /**
    * Method - hasPropertyValue - Has property value?
    *
    * @param value property's value
    * @return result true/false depending on whether the context has the property value or not
    */

   public boolean hasPropertyValue(Object value)
   {
      return m_properties.containsValue(value);
   }

   /**
    * Method - propertyValues - Get enumeration of property values currently set
    *
    * @return propertyValues enumration of property values currently set
    */

   public Enumeration propertyKeys()
   {
      return m_properties.keys();
   }

   /**
    * Method - getImageIcon - Get image icon
    *
    * @param imageName name of image .gif or .jpg/.jpeg file
    * @return imageIcon the image icon or null if the file could not be found
    */

   public Enumeration propertyValues()
   {
      return m_properties.elements();
   }

   /**
    * Method - getImage - Get image
    *
    * @param imageName name of image .gif or .jpg/.jpeg file
    * @return image the image or null if the file could not be found
    */

   public ImageIcon getImageIcon(String imageName)
   {
      ImageIcon               imageIcon;
      Enumeration             resourceDirectories;


      imageIcon = XwingMLContext.getCachedImageIcon(imageName);
      if (imageIcon == null)
      {
         imageIcon = new ImageIcon(imageName);
         if (imageIcon.getImageLoadStatus() == MediaTracker.ERRORED)
         {
            imageIcon = null;
            resourceDirectories = getResourceDirectories();
            while ((resourceDirectories.hasMoreElements()) && (imageIcon == null))
            {
               imageIcon = new ImageIcon((String)resourceDirectories.nextElement() + imageName);
               if (imageIcon.getImageLoadStatus() == MediaTracker.ERRORED)
               {
                  imageIcon = null;
               }
            }
         }
         if (imageIcon != null)
         {
            XwingMLContext.addCachedImageIcon(imageName, imageIcon);
         }
      }
      return imageIcon;
   }

   /**
    * Method - getImage - Get image
    *
    * @param imageName name of image .gif or .jpg/.jpeg file
    * @return image the image or null if the file could not be found
    */

   public Image getImage(String imageName)
   {
      Image                   image;
      ImageIcon               imageIcon;


      imageIcon = getImageIcon(imageName);
      if (imageIcon != null)
      {
         image = imageIcon.getImage();
      }
      else
      {
         image = null;
      }
      return image;
   }

   /**
    * Method - getXMLFile - Get XML file
    *
    * @param fileName the .xml file name
    * @return file the .xml file or null if it could not be found
    */

   public File getXMLFile(String fileName)
   {
      File                    file;
      Enumeration             xmlDirectories;


      file = new File(fileName);
      if ((!file.isFile()) || (!file.exists()))
      {
         file = null;
         xmlDirectories = getXMLDirectories();
         while ((xmlDirectories.hasMoreElements()) && (file == null))
         {
            file = new File((String)xmlDirectories.nextElement() + fileName);
            if ((!file.isFile()) || (!file.exists()))
            {
               file = null;
            }
         }
      }
      return file;
   }

   /**
    * Method - getFrame - Get frame registered with XwingML
    *
    * @param name the name of the frame to retrieve
    * @return frame the requested frame or null if not found
    */

   public JFrame getFrame(String name)
   {
      JFrame                  frame;
      int                     i;


      frame = null;
      for (i = 0; (i < m_frames.size()) && (frame == null); i++)
      {
         frame = (JFrame)m_frames.elementAt(i);
         if (!name.equals(frame.getName()))
         {
            frame = null;
         }
      }
      return frame;
   }

   /**
    * Method - getDialog - Get dialog registered with XwingML
    *
    * @param name the name of the dialog to retrieve
    * @return dialog the requested dialog or null if not found
    */

   public JDialog getDialog(String name)
   {
      JDialog                 dialog;
      int                     i;


      dialog = null;
      for (i = 0; (i < m_dialogs.size()) && (dialog == null); i++)
      {
         dialog = (JDialog)m_dialogs.elementAt(i);
         if (!name.equals(dialog.getName()))
         {
            dialog = null;
         }
      }
      return dialog;
   }

   /**
    * Method - getWindow - Get window registered with XwingML
    *
    * @param name the name of the window to retrieve
    * @return window the requested window or null if not found
    */

   public JWindow getWindow(String name)
   {
      JWindow                 window;
      int                     i;


      window = null;
      for (i = 0; (i < m_windows.size()) && (window == null); i++)
      {
         window = (JWindow)m_windows.elementAt(i);
         if (!name.equals(window.getName()))
         {
            window = null;
         }
      }
      return window;
   }

   /**
    * Method - getInternalFrame - Get internal frame registered with XwingML
    *
    * @param name the name of the internal frame to retrieve
    * @return internalFrame the requested internal frame or null if not found
    */

   public JInternalFrame getInternalFrame(String name)
   {
      JInternalFrame          internalFrame;


      internalFrame = null;
      return internalFrame;
   }

   /**
    * Method - findComponent - Find component belonging to a container (recurses through child containers)
    *
    * @param name name of component to find
    * @param container container to find component in
    * @return component the requested component or null if not found
    */

   public Component findComponent(String name, Container container)
   {
      return findComponent(name, container, null);
   }

   /**
    * Method - findJComponent - Find Swing component belonging to a container (recurses through child containers)
    *
    * @param name name of Swing component to find
    * @param container container to find component in
    * @return component the requested Swing component or null if not found
    */

   public JComponent findJComponent(String name, Container container)
   {
      return (JComponent)findComponent(name, container, JComponent.class);
   }

   /**
    * Method - findJPanel - Find Swing panel belonging to a container (recurses through child containers)
    *
    * @param name name of Swing panel to find
    * @param container container to find panel in
    * @return panel the requested Swing panel or null if not found
    */

   public JPanel findJPanel(String name, Container container)
   {
      return (JPanel)findComponent(name, container, JPanel.class);
   }

   /**
    * Method - findJScrollPane - Find Swing scroll pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing scroll pane to find
    * @param container container to find scroll pane in
    * @return scrollPane the requested Swing scroll pane or null if not found
    */

   public JScrollPane findJScrollPane(String name, Container container)
   {
      return (JScrollPane)findComponent(name, container, JScrollPane.class);
   }

   /**
    * Method - findJSplitPane - Find Swing split pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing split pane to find
    * @param container container to find split pane in
    * @return splitPane the requested Swing split pane or null if not found
    */

   public JSplitPane findJSplitPane(String name, Container container)
   {
      return (JSplitPane)findComponent(name, container, JSplitPane.class);
   }

   /**
    * Method - findJTabbedPane - Find Swing tabbed pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tabbed pane to find
    * @param container container to find tabbed pane in
    * @return tabbedPane the requested Swing tabbed pane or null if not found
    */

   public JTabbedPane findJTabbedPane(String name, Container container)
   {
      return (JTabbedPane)findComponent(name, container, JTabbedPane.class);
   }

   /**
    * Method - findJButton - Find Swing button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing button to find
    * @param container container to find button in
    * @return button the requested Swing button or null if not found
    */

   public JButton findJButton(String name, Container container)
   {
      return (JButton)findComponent(name, container, JButton.class);
   }

   /**
    * Method - findJToggleButton - Find Swing toggle button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing toggle button to find
    * @param container container to find toggle button in
    * @return toggleButton the requested Swing toggle button or null if not found
    */

   public JToggleButton findJToggleButton(String name, Container container)
   {
      return (JToggleButton)findComponent(name, container, JToggleButton.class);
   }

   /**
    * Method - findJCheckBox - Find Swing check box belonging to a container (recurses through child containers)
    *
    * @param name name of Swing check box to find
    * @param container container to find check box in
    * @return checkBox the requested Swing check box or null if not found
    */

   public JCheckBox findJCheckBox(String name, Container container)
   {
      return (JCheckBox)findComponent(name, container, JCheckBox.class);
   }

   /**
    * Method - findJRadioButton - Find Swing radio button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing radio button to find
    * @param container container to find radio button in
    * @return radioButton the requested Swing radio button or null if not found
    */

   public JRadioButton findJRadioButton(String name, Container container)
   {
      return (JRadioButton)findComponent(name, container, JRadioButton.class);
   }

   /**
    * Method - findJToolBar - Find Swing tool bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tool bar to find
    * @param container container to find tool bar in
    * @return toolBar the requested Swing tool bar or null if not found
    */

   public JToolBar findJToolBar(String name, Container container)
   {
      return (JToolBar)findComponent(name, container, JScrollBar.class);
   }

   /**
    * Method - findJTextField - Find Swing text field belonging to a container (recurses through child containers)
    *
    * @param name name of Swing text field to find
    * @param container container to find text field in
    * @return textField the requested Swing text field or null if not found
    */

   public JLabel findJLabel(String name, Container container)
   {
      return (JLabel)findComponent(name, container, JLabel.class);
   }

   /**
    * Method - findJTextField - Find Swing text field belonging to a container (recurses through child containers)
    *
    * @param name name of Swing text field to find
    * @param container container to find text field in
    * @return textField the requested Swing text field or null if not found
    */

   public JTextField findJTextField(String name, Container container)
   {
      return (JTextField)findComponent(name, container, JTextField.class);
   }

   /**
    * Method - findJPasswordField - Find Swing password field belonging to a container (recurses through child containers)
    *
    * @param name name of Swing password field to find
    * @param container container to find password field in
    * @return textField the requested Swing password field or null if not found
    */

   public JPasswordField findJPasswordField(String name, Container container)
   {
      return (JPasswordField)findComponent(name, container, JPasswordField.class);
   }

   /**
    * Method - findJTextArea - Find Swing text area belonging to a container (recurses through child containers)
    *
    * @param name name of Swing text area to find
    * @param container container to find text area in
    * @return textArea the requested Swing text area or null if not found
    */

   public JTextArea findJTextArea(String name, Container container)
   {
      return (JTextArea)findComponent(name, container, JTextArea.class);
   }

   /**
    * Method - findJEditorPane - Find Swing editor pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing editor pane to find
    * @param container container to find editor pane in
    * @return editorPane the requested Swing editor pane or null if not found
    */

   public JEditorPane findJEditorPane(String name, Container container)
   {
      return (JEditorPane)findComponent(name, container, JEditorPane.class);
   }

   /**
    * Method - findJTextPane - Find Swing text pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing editor pane to find
    * @param container container to find text pane in
    * @return textPane the requested Swing text pane or null if not found
    */

   public JTextPane findJTextPane(String name, Container container)
   {
      return (JTextPane)findComponent(name, container, JTextPane.class);
   }

   /**
    * Method - findJComboBox - Find Swing combo box belonging to a container (recurses through child containers)
    *
    * @param name name of Swing combo box to find
    * @param container container to find combo box in
    * @return comboBox the requested Swing combo box or null if not found
    */

   public JComboBox findJComboBox(String name, Container container)
   {
      return (JComboBox)findComponent(name, container, JComboBox.class);
   }

   /**
    * Method - findJList - Find Swing list belonging to a container (recurses through child containers)
    *
    * @param name name of Swing list to find
    * @param container container to find list in
    * @return list the requested Swing list or null if not found
    */

   public JList findJList(String name, Container container)
   {
      return (JList)findComponent(name, container, JList.class);
   }

   /**
    * Method - findJTree - Find Swing tree belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tree to find
    * @param container container to find tree in
    * @return tree the requested Swing tree or null if not found
    */

   public JTree findJTree(String name, Container container)
   {
      return (JTree)findComponent(name, container, JTree.class);
   }

   /**
    * Method - findJTable - Find Swing table belonging to a container (recurses through child containers)
    *
    * @param name name of Swing table to find
    * @param container container to find table in
    * @return table the requested Swing table or null if not found
    */

   public JTable findJTable(String name, Container container)
   {
      return (JTable)findComponent(name, container, JTable.class);
   }

   /**
    * Method - findJSlider - Find Swing slider belonging to a container (recurses through child containers)
    *
    * @param name name of Swing slider to find
    * @param container container to slider table in
    * @return slider the requested Swing slider or null if not found
    */
   public JSlider findJSlider(String name, Container container)
   {
      return (JSlider)findComponent(name, container, JSlider.class);
   }

   /**
    * Method - findJProgessBar - Find Swing progress bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing progress bar to find
    * @param container container to progress bar table in
    * @return progressBar the requested Swing progress bar or null if not found
    */

   public JProgressBar findJProgressBar(String name, Container container)
   {
      return (JProgressBar)findComponent(name, container, JProgressBar.class);
   }

   /**
    * Method - findJScrollBar - Find Swing scroll bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing scroll bar to find
    * @param container container to scroll bar table in
    * @return scrollBar the requested Swing scroll bar or null if not found
    */

   public JScrollBar findJScrollBar(String name, Container container)
   {
      return (JScrollBar)findComponent(name, container, JScrollBar.class);
   }

   /**
    * Method - findJComponent - Find Swing component belonging to a container (recurses through child containers)
    *
    * @param name name of Swing component to find
    * @param container container to find component in
    * @param containerClass Java class of component to find
    * @return component the requested Swing component or null if not found
    */

   public Component findComponent(String name, Container container, Class componentClass)
   {
      Component               component;
      Component               components[];
      int                     i;


      component = null;
      if (container instanceof JFrame)
      {
         container = ((JFrame)container).getContentPane();
      }
      else if (container instanceof JDialog)
      {
         container = ((JDialog)container).getContentPane();
      }
      else if (container instanceof JWindow)
      {
         container = ((JWindow)container).getContentPane();
      }
      else if (container instanceof JInternalFrame)
      {
         container = ((JInternalFrame)container).getContentPane();
      }
      components = container.getComponents();
      for (i = 0; (i < components.length) && (component == null); i++)
      {
         if (name.equals(components[i].getName()))
         {
            if ((componentClass == null) || (componentClass.isAssignableFrom(components[i].getClass())))
            {
               component = components[i];
            }
         }
      }
      if (component == null)
      {
         for (i = 0; (i < components.length) && (component == null); i++)
         {
            if (components[i] instanceof Container)
            {
               component = findComponent(name, (Container)components[i], componentClass);
            }
         }
      }
      return component;
   }

   /**
    * Method - addResourceDirectory - Add resource directory (The XwingML context holds a list of directories in which
    * to look for resources (like .gif and .jpg/.jpeg files)).
    *
    * @param path the path of the resource directory to add
    */

   public void addResourceDirectory(String path)
   {
      if (!path.endsWith(System.getProperty("file.separator")))
      {
         path += System.getProperty("file.separator");
      }
      if (!m_resourceDirectories.contains(path))
      {
         m_resourceDirectories.addElement(path);
      }
   }

   /**
    * Method - removeResourceDirectory - Remove resource directory
    *
    * @param path the path of the resource directory to remove
    */

   public void removeResourceDirectory(String path)
   {
      if (m_resourceDirectories.contains(path))
      {
         m_resourceDirectories.removeElement(path);
      }
   }

   /**
    * Method - getResourceDirectories - Get enumeration of resource directories
    *
    * @return resourceDirectories enumeration of resource directories currently added to the context
    */

   public Enumeration getResourceDirectories()
   {
      return m_resourceDirectories.elements();
   }

   /**
    * Method - addResourceJar - Add resource jar
    *
    * @param jarName name of jar to add
    */

   public void addResourceJar(String jarName)
   {
      File                    file;
      JarFile                 jarFile;
      boolean                 found;
      int                     i;


      for (i = 0, found = false; (i < m_resourceJars.size()) && (!found); i++)
      {
         jarFile = (JarFile)m_resourceJars.elementAt(i);
         found = jarFile.getName().equals(jarName);
      }
      if (!found)
      {
         file = new File(jarName);
         if ((file.exists()) && (file.canRead()))
         {
            try
            {
               jarFile = new JarFile(file);
               m_resourceJars.add(jarFile);
            }
            catch (IOException e)
            {
            }
         }
      }
   }

   /**
    * Method - removeResourceJar - Remove resource jar
    *
    * @param jarName name of jar to remove
    */

   public void removeResourceJar(String jarName)
   {
      File                    file;
      JarFile                 jarFile;
      boolean                 found;
      int                     i;


      for (i = 0, found = false; (i < m_resourceJars.size()) && (!found); i++)
      {
         jarFile = (JarFile)m_resourceJars.elementAt(i);
         if (jarFile.getName().equals(jarName))
         {
            m_resourceDirectories.remove(jarFile);
            found = true;
         }
      }
   }

   /**
    * Method - getResourceJars - Get enumeration of resource jars
    *
    * @return resourceJars enumeration of resource jars currently added to the context
    */

   public Enumeration getResourceJars()
   {
      return m_resourceJars.elements();
   }

   /**
    * Method - addXMLDirectory - Add XML directory (The XwingML context holds a list of directories in which
    * to look for .xml files).
    *
    * @param path the path of the XML directory to add
    */

   public void addXMLDirectory(String path)
   {
      if (!path.endsWith(System.getProperty("file.separator")))
      {
         path += System.getProperty("file.separator");
      }
      if (!m_xmlDirectories.contains(path))
      {
         m_xmlDirectories.addElement(path);
      }
   }

   /**
    * Method - removeXMLDirectory - Remove XML directory
    *
    * @param path the path of the XML directory to remove
    */

   public void removeXMLDirectory(String path)
   {
      if (m_xmlDirectories.contains(path))
      {
         m_xmlDirectories.removeElement(path);
      }
   }

   /**
    * Method - getXMLDirectories - Get enumeration of XML directories
    *
    * @return xmlDirectories enumeration of XML directories currently added to the context
    */

   public Enumeration getXMLDirectories()
   {
      return m_xmlDirectories.elements();
   }

   /**
    * Method - addClassInstance - Add class instance to context
    *
    * @param name name of class instance (arbitrary name which can be used to reference a particular instance)
    * @param instance instance of any class imaginable
    */

   public void addClassInstance(String name, Object instance)
   {
      m_classInstances.put(name, instance);
   }

   /**
    * Method - getClassInstance - get class instance from context
    *
    * @param name name of class instance 
    * @return instance the requested instance or null if not found
    */

   public Object getClassInstance(String name)
   {
      return m_classInstances.get(name);
   }

   /**
    * Method - removeClassInstance - remove class instance from context
    *
    * @param name name of class instance to remove
    */

   public void removeClassInstance(String name)
   {
      m_classInstances.remove(name);
   }

   /**
    * Method - windowActivated - Window activated
    *
    * @param evt WindowEvent instance
    */

   public void windowActivated(WindowEvent evt)
   {
   }

   /**
    * Method - windowClosed - Window closed
    *
    * @param evt WindowEvent instance
    */

   public void windowClosed(WindowEvent evt)
   {
      Window                  window;


      window = evt.getWindow();
      if (window instanceof JFrame)
      {
         if (m_frames.contains(window))
         {
            m_frames.removeElement(window);
         }
      }
      else if (window instanceof JDialog)
      {
         if (m_dialogs.contains(window))
         {
            m_dialogs.removeElement(window);
         }
      }
      else if (window instanceof JWindow)
      {
         if (m_windows.contains(window))
         {
            m_windows.removeElement(window);
         }
      }
   }

   /**
    * Method - windowClosing - Window closing
    *
    * @param evt WindowEvent instance
    */

   public void windowClosing(WindowEvent evt)
   {
      Window                  window;


      window = evt.getWindow();
      if (window instanceof JFrame)
      {
         if (m_frames.contains(window))
         {
            m_frames.removeElement(window);
         }
      }
      else if (window instanceof JDialog)
      {
         if (m_dialogs.contains(window))
         {
            m_dialogs.removeElement(window);
         }
      }
      else if (window instanceof JWindow)
      {
         if (m_windows.contains(window))
         {
            m_windows.removeElement(window);
         }
      }
   }

   /**
    * Method - windowDeactivated - Window deactivated
    *
    * @param evt WindowEvent instance
    */

   public void windowDeactivated(WindowEvent evt)
   {
   }

   /**
    * Method - windowDeiconified - Window deiconified
    *
    * @param evt WindowEvent instance
    */

   public void windowDeiconified(WindowEvent evt)
   {
   }

   /**
    * Method - windowIconified - Window iconified
    *
    * @param evt WindowEvent instance
    */

   public void windowIconified(WindowEvent evt)
   {
   }

   /**
    * Method - windowOpened - Window opened
    *
    * @param evt WindowEvent instance
    */

   public void windowOpened(WindowEvent evt)
   {
      Window                  window;


      window = evt.getWindow();
      if (window instanceof JFrame)
      {
         if (!m_frames.contains(window))
         {
            m_frames.addElement(window);
         }
      }
      else if (window instanceof JDialog)
      {
         if (!m_dialogs.contains(window))
         {
            m_dialogs.addElement(window);
         }
      }
      else if (window instanceof JWindow)
      {
         if (!m_windows.contains(window))
         {
            m_windows.addElement(window);
         }
      }
   }

   /**
    * Method - internalFrameActivated - Internal frame activated
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameActivated(InternalFrameEvent evt)
   {
   }

   /**
    * Method - internalFrameClosed - Internal frame closed
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameClosed(InternalFrameEvent evt)
   {
      JInternalFrame          internalFrame;


      internalFrame = (JInternalFrame)evt.getSource();
      if (m_internalFrames.contains(internalFrame))
      {
         m_internalFrames.removeElement(internalFrame);
      }
   }

   /**
    * Method - internalFrameClosing - Internal frame closing
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameClosing(InternalFrameEvent evt)
   {
      JInternalFrame          internalFrame;


      internalFrame = (JInternalFrame)evt.getSource();
      if (m_internalFrames.contains(internalFrame))
      {
         m_internalFrames.removeElement(internalFrame);
      }
   }

   /**
    * Method - internalFrameDeactivated - Internal frame deactivated
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameDeactivated(InternalFrameEvent evt)
   {
   }

   /**
    * Method - internalFrameDeiconified - Internal frame deiconified
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameDeiconified(InternalFrameEvent evt)
   {
   }

   /**
    * Method - internalFrameIconified - Internal frame iconified
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameIconified(InternalFrameEvent evt)
   {
   }

   /**
    * Method - internalFrameActivated - Internal frame opened
    *
    * @param evt InternalFrameEvent instance
    */

   public void internalFrameOpened(InternalFrameEvent evt)
   {
      JInternalFrame          internalFrame;


      internalFrame = (JInternalFrame)evt.getSource();
      if (!m_internalFrames.contains(internalFrame))
      {
         m_internalFrames.addElement(internalFrame);
      }
   }

   /**
    * Method - addCachedImageIcon - Add cached image icon
    *
    * @param imageName the file name of the image
    * @param imageIcon the image icon
    */

   public static void addCachedImageIcon(String imageName, ImageIcon imageIcon)
   {
      m_imageIcons.put(imageName, imageIcon);
   }

   /**
    * Method - getCachedImageIcon - Get cached image icon
    *
    * @param imageName the file name of the image
    * @return imageIcon the image icon or null if not found
    */

   public static ImageIcon getCachedImageIcon(String imageName)
   {
      return (ImageIcon)m_imageIcons.get(imageName);
   }
}