/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLObjectFactory - XwingML Object factory
 */

public class XwingMLObjectFactory
{
   protected static Hashtable m_xmlObjects;

   protected static String    m_defaultObjects[][] = 
                              {
                                 {"Container", "com.bluestone.xwingml.XwingMLContainer"},
                                 {"JFrame", "com.bluestone.xwingml.XwingMLJFrame"},
                                 {"JInternalFrame", "com.bluestone.xwingml.XwingMLJInternalFrame"},
                                 {"JDialog", "com.bluestone.xwingml.XwingMLJDialog"},
                                 {"JWindow", "com.bluestone.xwingml.XwingMLJWindow"},
                                 {"JComponent", "com.bluestone.xwingml.XwingMLJComponent"},
                                 {"JPanel", "com.bluestone.xwingml.XwingMLJPanel"},
                                 {"JScrollPane", "com.bluestone.xwingml.XwingMLJScrollPane"},
                                 {"JSplitPane", "com.bluestone.xwingml.XwingMLJSplitPane"},
                                 {"JTabbedPane", "com.bluestone.xwingml.XwingMLJTabbedPane"},
                                 {"JPopupMenu", "com.bluestone.xwingml.XwingMLJPopupMenu"},
                                 {"JMenuBar", "com.bluestone.xwingml.XwingMLJMenuBar"},
                                 {"JMenu", "com.bluestone.xwingml.XwingMLJMenu"},
                                 {"JMenuItem", "com.bluestone.xwingml.XwingMLJMenuItem"},
                                 {"JRadioButtonMenuItem", "com.bluestone.xwingml.XwingMLJRadioButtonMenuItem"},
                                 {"JCheckBoxMenuItem", "com.bluestone.xwingml.XwingMLJCheckBoxMenuItem"},
                                 {"ButtonGroup", "com.bluestone.xwingml.XwingMLButtonGroup"},
                                 {"JButton", "com.bluestone.xwingml.XwingMLJButton"},
                                 {"JToggleButton", "com.bluestone.xwingml.XwingMLJToggleButton"},
                                 {"JCheckBox", "com.bluestone.xwingml.XwingMLJCheckBox"},
                                 {"JRadioButton", "com.bluestone.xwingml.XwingMLJRadioButton"},
                                 {"JToolBar", "com.bluestone.xwingml.XwingMLJToolBar"},
                                 {"JLabel", "com.bluestone.xwingml.XwingMLJLabel"},
                                 {"JTextField", "com.bluestone.xwingml.XwingMLJTextField"},
                                 {"JPasswordField", "com.bluestone.xwingml.XwingMLJPasswordField"},
                                 {"JTextArea", "com.bluestone.xwingml.XwingMLJTextArea"},
                                 {"JEditorPane", "com.bluestone.xwingml.XwingMLJEditorPane"},
                                 {"JTextPane", "com.bluestone.xwingml.XwingMLJTextPane"},
                                 {"JComboBox", "com.bluestone.xwingml.XwingMLJComboBox"},
                                 {"JList", "com.bluestone.xwingml.XwingMLJList"},
                                 {"JTree", "com.bluestone.xwingml.XwingMLJTree"},
                                 {"JTable", "com.bluestone.xwingml.XwingMLJTable"},
                                 {"TableColumn", "com.bluestone.xwingml.XwingMLTableColumn"},
                                 {"JSlider", "com.bluestone.xwingml.XwingMLJSlider"},
                                 {"JSeparator", "com.bluestone.xwingml.XwingMLJSeparator"},
                                 {"JProgressBar", "com.bluestone.xwingml.XwingMLJProgressBar"},
                                 {"JScrollBar", "com.bluestone.xwingml.XwingMLJScrollBar"},
                                 {"BorderLayout", "com.bluestone.xwingml.XwingMLBorderLayout"},
                                 {"BoxLayout", "com.bluestone.xwingml.XwingMLBoxLayout"},
                                 {"CardLayout", "com.bluestone.xwingml.XwingMLCardLayout"},
                                 {"FlowLayout", "com.bluestone.xwingml.XwingMLFlowLayout"},
                                 {"GridLayout", "com.bluestone.xwingml.XwingMLGridLayout"},
                                 {"GridBagLayout", "com.bluestone.xwingml.XwingMLGridBagLayout"},
                                 {"OverlayLayout", "com.bluestone.xwingml.XwingMLOverlayLayout"},
                                 {"BevelBorder", "com.bluestone.xwingml.XwingMLBevelBorder"},
                                 {"EtchedBorder", "com.bluestone.xwingml.XwingMLEtchedBorder"},
                                 {"EmptyBorder", "com.bluestone.xwingml.XwingMLEmptyBorder"},
                                 {"MatteBorder", "com.bluestone.xwingml.XwingMLMatteBorder"},
                                 {"TitledBorder", "com.bluestone.xwingml.XwingMLTitledBorder"},
                                 {"CompoundBorder", "com.bluestone.xwingml.XwingMLCompoundBorder"}
                              };

   static
   {
      int                     i;
      boolean                 result;


      m_xmlObjects = new Hashtable();
      for (i = 0; i < m_defaultObjects.length; i++)
      {
         result = registerXMLObject(m_defaultObjects[i][0], m_defaultObjects[i][1]);
         if (!result)
         {
            System.out.println("Registration failed for " + m_defaultObjects[i][0]);
         }
      }
   }

   /**
    * Method - createXMLObject - Create XML Object
    *
    * @param node the DOM node to create the object for
    * @param context the XwingMLIContext instance
    * @return xmlObject the requested object or null if it could not be built
    */

   public static XwingMLIObject createXMLObject(Node node, XwingMLIContext context)
   {
      XwingMLIObject          xmlObject;
      Class                   xmlObjectClass;


      xmlObject = null;
      if (node != null)
      {
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            xmlObjectClass = (Class)m_xmlObjects.get(node.getNodeName());
            if (xmlObjectClass != null)
            {
               try
               {
                  xmlObject = (XwingMLIObject)xmlObjectClass.newInstance();
                  xmlObject.setNode(node);
                  xmlObject.setContext(context);
               }
               catch (Throwable t)
               {
                  context.fireXwingMLError(new XwingMLErrorEvent(node, "Could not instatiate the XML object class '" + xmlObjectClass.getName() + "'"));
               }
            }
            else
            {
               context.fireXwingMLError(new XwingMLErrorEvent(node, "No XML object class registered for '" + node.getNodeName() + "'"));
            }
         }
         else
         {
            context.fireXwingMLError(new XwingMLErrorEvent(node, "The node to build an XML object from is not an element node"));
         }
      }
      else
      {
         context.fireXwingMLError(new XwingMLErrorEvent(node, "The node to build an XML object from is null"));
      }
      return xmlObject;
   }

   /**
    * Method - registerXMLObject - Register XML object
    *
    * @param componentName the name of XML component tag name
    * @param xmlObjectClassName the name of Java class responsible for building these types of objects
    * @return result true/false depending on whether the class could registered or not
    */

   public static boolean registerXMLObject(String componentName, String xmlObjectClassName)
   {
      boolean                 result;
      Class                   xmlObjectClass;


      try
      {
         xmlObjectClass = Class.forName(xmlObjectClassName);
         result = registerXMLObject(componentName, xmlObjectClass);
      }
      catch (ClassNotFoundException e)
      {
         result = false;
      }
      return result;
   }

   /**
    * Method - registerXMLObject - Register XML object
    *
    * @param componentName the name of XML component tag name
    * @param xmlObjectClass the Java class responsible for building these types of objects
    * @return result true/false depending on whether the class could registered or not
    */

   public static boolean registerXMLObject(String componentName, Class xmlObjectClass)
   {
      boolean                 result;
      Object                  xmlObjectInstance;


      try
      {
         xmlObjectInstance = xmlObjectClass.newInstance();
         if (xmlObjectInstance instanceof XwingMLIObject)
         {
            m_xmlObjects.put(componentName, xmlObjectClass);
            result = true;
         }
         else
         {
            result = false;
         }
      }
      catch (Throwable t)
      {
         result = false;
      }
      return result;
   }
}
