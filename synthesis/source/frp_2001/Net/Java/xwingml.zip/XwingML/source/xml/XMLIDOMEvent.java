/*=============================================================================*/
/* Copyright � 1998-1999 by Bluestone Software, Inc. All rights Reserved.      */
/*=============================================================================*/
/*
$Archive:: $
$Revision:: $
$Date:: $ 02/22/1999
$Author:: $ Jay Hiremath
*/
/*=============================================================================*/

package com.bluestone.xml;

import org.w3c.dom.*;

/**
* Event interface used in the Bluestone event model for
* DOM modifications.  Implement this interface and use it in 
* conjunction with other XML DOM event related classes in 
* com.bluestone.xml.
*
* @see com.bluestone.xml.XMLDOMEventObject
* @see com.bluestone.xml.XMLIDOMEventListener
* 
*/
public abstract interface XMLIDOMEvent
{
	public final static String DOM_EVENT_ELEMENT = new String("DOMEvent");
	public final static String DOM_EVENT_NAME_ATTR = new String("name");
	public final static String DOM_EVENT_CLASS_ATTR = new String("eventClass");
	public final static String DOM_EVENT_LISTENER_ATTR = new String("listnerInterface");
	public final static String DOM_EVENT_OBJECT_ATTR = new String("eventObj");
	public final static String DOM_EVENT_DEFAULT_LISTENER = new String("XMLIDOMEventListener");
	public final static String DOM_EVENT_DEFAULT_OBJECT = new String("XMLDOMEventObject");

	public boolean init (Node domEventNode);
	public void setName(String name);
	public String getName();
	public void setEventClass(String eventClass);
	public String getEventClass();	
	public void setListenerInterface(String listenerInterface);
	public String getListenerInterface();
	public void setEventObject(String eventObj);
	public String getEventObject();
	public void addListener(XMLIDOMEventListener listener);
	public void removeListener(XMLIDOMEventListener listener);
	public void fire(XMLDOMEventObject eventObj);	
}