/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLBevelBorder - XwingML BevelBorder class
 */

public class XwingMLTitledBorder extends XwingMLBorder
{
   protected XwingMLBorder    m_xmlBorder;
   protected String           m_title;
   protected int              m_titleJustification;
   protected int              m_titlePosition;
   protected String           m_fontName;
   protected int              m_fontStyle;
   protected int              m_fontSize;
   protected Color            m_titleColor;

   /**
    * Constructor - XwingMLBevelBorder
    */

   public XwingMLTitledBorder()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLBevelBorder
    *
    * @param node the DOM node to create the border from
    */

   public XwingMLTitledBorder(Node node)
   {
      super(node);
      m_xmlBorder = null;
   }

   /**
    * Method - getBevelBorder - Get bevel border
    *
    * @return object the object typecasted to a BevelBorder
    */

   public TitledBorder getTitledBorder()
   {
      return (TitledBorder)m_object;
   }

   /**
    * Method - getXwingMLJComponent - Get XwingML JComponent which has this border
    *
    * @return xmlJComponent the xmlJComponent which has this border or null if not set
    */

   public XwingMLJComponent getXMLJComponent()
   {
      XwingMLJComponent         xmlJComponent;


      if (m_xmlBorder != null)
      {
         xmlJComponent = m_xmlBorder.getXMLJComponent();
      }
      else
      {
         xmlJComponent = null;
      }
      return xmlJComponent;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_title = null;
      m_titleJustification = TitledBorder.LEFT;
      m_titlePosition = TitledBorder.TOP;
      m_fontName = null;
      m_fontStyle = -1;
      m_fontSize = -1;
      m_titleColor = null;
      return true;
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      Node                    node;
      String                  nodeValue;


      node = m_attributes.getNamedItem("title");
      if (node != null)
      {
         m_title = getString(node);
      }
      node = m_attributes.getNamedItem("titleJustification");
      if (node != null)
      {
         m_titleJustification = getTitleJustification(node);
      }
      node = m_attributes.getNamedItem("titlePosition");
      if (node != null)
      {
         m_titlePosition = getTitlePosition(node);
      }
      node = m_attributes.getNamedItem("fontName");
      if (node != null)
      {
         m_fontName = getString(node);
      }
      node = m_attributes.getNamedItem("fontStyle");
      if (node != null)
      {
         m_fontStyle = getFontStyle(node);
      }
      node = m_attributes.getNamedItem("fontSize");
      if (node != null)
      {
         m_fontSize = getInteger(node, true);
      }
      node = m_attributes.getNamedItem("titleColor");
      if (node != null)
      {
         m_titleColor = getColor(node);
      }
      return true;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      Node                    node;
      XwingMLIObject          xmlObject;
      XwingMLJComponent       xmlJComponent;
      TitledBorder            titledBorder;
      int                     i;


      result = true;
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
            if (xmlObject != null)
            {
               if (xmlObject instanceof XwingMLBorder)
               {
                  xmlObject.setParent(m_parent);
                  result = xmlObject.buildObject();
                  if (result)
                  {
                     m_xmlBorder = (XwingMLBorder)xmlObject;
                     titledBorder = BorderFactory.createTitledBorder(m_xmlBorder.getBorder(), m_title, m_titleJustification, m_titlePosition);
                     if ((m_fontName != null) || (m_fontStyle != -1) || (m_fontSize != -1))
                     {
                        if (m_fontName == null)
                        {
                           m_fontName = titledBorder.getTitleFont().getFontName();
                        }
                        if (m_fontStyle == -1)
                        {
                           m_fontStyle = titledBorder.getTitleFont().getStyle();
                        }
                        if (m_fontSize == -1)
                        {
                           m_fontSize = titledBorder.getTitleFont().getSize();
                        }
                        titledBorder.setTitleFont(new Font(m_fontName, m_fontStyle, m_fontSize));
                     }
                     if (m_titleColor != null)
                     {
                        titledBorder.setTitleColor(m_titleColor);
                     }
                     m_object = titledBorder;
                     xmlJComponent = getXMLJComponent();
                     if (xmlJComponent != null)
                     {
                        xmlJComponent.getJComponent().setBorder(getBorder());
                     }
                  }
               }
            }
            else
            {
               result = false;
            }
         }
      }
      return result;
   }

   /**
    * Method - getTitleJustification - Get title justification
    *
    * @param node the DOM node to obtain the title justification from
    * @return titleJustification the title justfication
    */

   protected int getTitleJustification(Node node)
   {
      int                     titleJustification;
      String                  nodeValue;


      titleJustification = TitledBorder.LEFT;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("LEFT"))
      {
         titleJustification = TitledBorder.LEFT;
      }
      else if (nodeValue.equals("CENTER"))
      {
         titleJustification = TitledBorder.CENTER;
      }
      else if (nodeValue.equals("RIGHT"))
      {
         titleJustification = TitledBorder.RIGHT;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The title justification '" + nodeValue + "' is unknown"));
      }
      return titleJustification;
   }

   /**
    * Method - getTitlePosition - Get title position
    *
    * @param node the DOM node to obtain the title position from
    * @return titlePosition the title position
    */

   protected int getTitlePosition(Node node)
   {
      int                     titlePosition;
      String                  nodeValue;


      titlePosition = TitledBorder.ABOVE_TOP;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("ABOVE_TOP"))
      {
         titlePosition = TitledBorder.ABOVE_TOP;
      }
      else if (nodeValue.equals("TOP"))
      {
         titlePosition = TitledBorder.TOP;
      }
      else if (nodeValue.equals("BELOW_TOP"))
      {
         titlePosition = TitledBorder.BELOW_TOP;
      }
      else if (nodeValue.equals("ABOVE_BOTTOM"))
      {
         titlePosition = TitledBorder.ABOVE_BOTTOM;
      }
      else if (nodeValue.equals("BOTTOM"))
      {
         titlePosition = TitledBorder.BOTTOM;
      }
      else if (nodeValue.equals("BELOW_BOTTOM"))
      {
         titlePosition = TitledBorder.BELOW_BOTTOM;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The title position '" + nodeValue + "' is unknown"));
      }
      return titlePosition;
   }

   /**
    * Method - getFontStyle - Get font style
    *
    * @param node the DOM node to obtain the font style from
    * @return fontStyle the fontStyle
    */

   protected int getFontStyle(Node node)
   {
      int                     fontStyle;
      String                  nodeValue;


      fontStyle = Font.PLAIN;
      nodeValue = getString(node);
      if (nodeValue.equals("PLAIN"))
      {
         fontStyle = Font.PLAIN;
      }
      else if (nodeValue.equals("BOLD"))
      {
         fontStyle = Font.BOLD;
      }
      else if (nodeValue.equals("ITALIC"))
      {
         fontStyle = Font.ITALIC;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The font style '" + nodeValue + "' is unknown"));
      }
      return fontStyle;
   }
}