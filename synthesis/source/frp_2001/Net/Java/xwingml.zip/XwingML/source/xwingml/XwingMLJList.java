/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLJList - XwingML JList class
 */

public class XwingMLJList extends XwingMLJComponent
{
   protected ListDataListener m_listDataListener;


   /**
    * Constructor - XwingMLJList
    */

   public XwingMLJList()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLJList
    *
    * @param node the DOM node decsribing the list to build
    */

   public XwingMLJList(Node node)
   {
      super(node);
   }

   /**
    * Method - buildObject - Build object (i.e. interpret XML from node and build Swing component
    *
    * @return result true/false depending on whether the component could be built or not
    */

   public boolean buildObject()
   {
      boolean                 result;


      m_listDataListener = null;
      result = super.buildObject();
      if (m_listDataListener != null)
      {
         getJList().getModel().addListDataListener(m_listDataListener);
      }
      return result;
   }

   /**
    * Method - getJList - Get Swing list
    *
    * @return object the object typecasted to a JList
    */

   public JList getJList()
   {
      return (JList)m_object;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(JList.class);
      return (m_object != null);
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      JList                   list;
      ListCellRenderer        listCellRenderer;
      ListModel               listModel;
      ListSelectionListener   listSelectionListener;
      ListSelectionModel      listSelectionModel;


      result = super.handleAttributes();
      if (result)
      {
         list = getJList();
         node = m_attributes.getNamedItem("cellRenderer");
         if (node != null)
         {
            listCellRenderer = createListCellRenderer(node);
            if (listCellRenderer != null)
            {
               list.setCellRenderer(listCellRenderer);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("fixedCellHeight");
         if (node != null)
         {
            list.setFixedCellHeight(getInteger(node));
         }
         node = m_attributes.getNamedItem("fixedCellWidth");
         if (node != null)
         {
            list.setFixedCellWidth(getInteger(node));
         }
         node = m_attributes.getNamedItem("model");
         if (node != null)
         {
            listModel = createListModel(node);
            if (listModel != null)
            {
               list.setModel(listModel);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("listDataListener");
         if (node != null)
         {
            m_listDataListener = createListDataListener(node);
            if (m_listDataListener == null)
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("listSelectionListener");
         if (node != null)
         {
            listSelectionListener = createListSelectionListener(node);
            if (listSelectionListener != null)
            {
               list.addListSelectionListener(listSelectionListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("selectionBackground");
         if (node != null)
         {
            list.setSelectionBackground(getColor(node));
         }
         node = m_attributes.getNamedItem("selectionForeground");
         if (node != null)
         {
            list.setSelectionForeground(getColor(node));
         }
         node = m_attributes.getNamedItem("selectionMode");
         if (node != null)
         {
            list.setSelectionMode(getSelectionMode(node));
         }
         node = m_attributes.getNamedItem("selectionModel");
         if (node != null)
         {
            listSelectionModel = createListSelectionModel(node);
            if (listSelectionModel != null)
            {
               list.setSelectionModel(listSelectionModel);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("visibleRowCount");
         if (node != null)
         {
            list.setVisibleRowCount(getInteger(node));
         }
      }
      return result;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      DefaultListModel        listModel;
      Node                    node;
      XwingMLIObject          xmlObject;
      int                     i;


      result = true;
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            if (node.getNodeName().equals("ListModelData"))
            {
               listModel = new DefaultListModel();
               result = handleListModelData(node.getChildNodes(), listModel);
               getJList().setModel(listModel);
            }
            else if (node.getNodeName().equals("JPopupMenu"))
            {
               xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
               if (xmlObject != null)
               {
                  xmlObject.setParent(getContainer());
                  result = xmlObject.buildObject();
                  if (result)
                  {
                     handlePopupMenu((XwingMLJPopupMenu)xmlObject);
                  }
               }
               else
               {
                  result = false;
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - handleListModelData - Handle list model data
    *
    * @param childNodes DOM child nodes containing the data
    * @param listModel list model to insert data into
    */

   public boolean handleListModelData(NodeList childNodes, DefaultListModel listModel)
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      StringTokenizer         stringTokenizer;
      String                  token;
      int                     i;


      result = true;
      if (childNodes != null)
      {
         for (i = 0; i < childNodes.getLength(); i++)
         {
            node = childNodes.item(i);
            if (node.getNodeType() == Node.TEXT_NODE)
            {
               nodeValue = node.getNodeValue();
               stringTokenizer = new StringTokenizer(nodeValue, "\n");
               while (stringTokenizer.hasMoreTokens())
               {
                  token = stringTokenizer.nextToken().trim();
                  if (token.length() > 0)
                  {
                     listModel.addElement(token);
                  }
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - createListModel - Create list model
    *
    * @param node the DOM node to obtain list model class name from
    * @return listModel list model or null if it could not be built
    */

   protected ListModel createListModel(Node node)
   {
      return (ListModel)createInstance(node, ListModel.class);
   }

   /**
    * Method - createListSelectionListener - Create list selection listener
    *
    * @param node the DOM node to obtain list selection listener class name from
    * @return listSelectionListener list selection listener or null if it could not be built
    */

   protected ListSelectionListener createListSelectionListener(Node node)
   {
      return (ListSelectionListener)createInstance(node, ListSelectionListener.class);
   }
}
