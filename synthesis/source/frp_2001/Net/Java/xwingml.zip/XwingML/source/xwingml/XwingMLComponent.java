/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/


package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLComponent - XwingML Component; super class for all XwingML Swing components
 */

public abstract class XwingMLComponent extends XwingMLObject
{
   /**
    * Constructor - XwingMLComponent
    */

   public XwingMLComponent()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLComponent
    *
    * @param node the DOM node decsribing the component to build
    */

   public XwingMLComponent(Node node)
   {
      super(node);
   }

   /**
    * Method - getComponent - Get component
    *
    * @return object the object typecasted to a Component
    */

   public Component getComponent()
   {
      return (Component)m_object;
   }

   /**
    * Method - createSwingComponent - Create Swing component
    *
    * @param compatibleClass class which the component must be assignment compatible with
    * @return swingInstance instance of class or null if it could not be built
    */

   public Object createSwingComponent(Class compatibleClass)
   {
      String                  swingClassName;
      Class                   swingClass;
      Object                  swingInstance;
      Node                    node;


      node = null;
      swingInstance = null;
      swingClass = compatibleClass;
      if (m_attributes != null)
      {
         node = m_attributes.getNamedItem("className");
         if (node != null)
         {
            swingClassName = node.getNodeValue();
            try
            {
               swingClass = Class.forName(swingClassName);
            }
            catch (ClassNotFoundException e)
            {
               m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + swingClassName + "' could not be found"));
            }
         }
      }
      if (compatibleClass.isAssignableFrom(swingClass))
      {
         try
         {
            swingInstance = swingClass.newInstance();
         }
         catch (Throwable t)
         {
            m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + swingClass.getName() + "' could not be instantiated"));
         }
      }
      else
      {
         m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + compatibleClass.getName() + "' is not a assignable from '" + swingClass.getName() + "'"));
      }
      return swingInstance;
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      Component               component;
      ComponentListener       componentListener;
      FocusListener           focusListener;
      InputMethodListener     inputMethodListener;
      KeyListener             keyListener;
      MouseListener           mouseListener;
      MouseMotionListener     mouseMotionListener;
      PropertyChangeListener  propertyChangeListener;
      String                  fontName;
      int                     fontStyle;
      int                     fontSize;


      result = true;
      component = getComponent();
      node = m_attributes.getNamedItem("background");
      if (node != null)
      {
         component.setBackground(getColor(node));
      }
      node = m_attributes.getNamedItem("componentListener");
      if (node != null)
      {
         componentListener = createComponentListener(node);
         if (componentListener != null)
         {
            component.addComponentListener(componentListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("enabled");
      if (node != null)
      {
         component.setEnabled(getBoolean(node));
      }
      node = m_attributes.getNamedItem("focusListener");
      if (node != null)
      {
         focusListener = createFocusListener(node);
         if (focusListener != null)
         {
            component.addFocusListener(focusListener);
         }
         else
         {
            result = false;
         }
      }
      fontName = null;
      fontStyle = -1;
      fontSize = -1;
      node = m_attributes.getNamedItem("fontName");
      if (node != null)
      {
         fontName = getString(node);
      }
      node = m_attributes.getNamedItem("fontStyle");
      if (node != null)
      {
         fontStyle = getFontStyle(node);
      }
      node = m_attributes.getNamedItem("fontSize");
      if (node != null)
      {
         fontSize = getInteger(node, true);
      }
      if ((fontName != null) || (fontStyle != -1) || (fontSize != -1))
      {
         if (fontName == null)
         {
            fontName = component.getFont().getName();
         }
         if (fontStyle == -1)
         {
            fontStyle = component.getFont().getStyle();
         }
         if (fontSize  == -1)
         {
            fontSize = component.getFont().getSize();
         }
         component.setFont(new Font(fontName, fontStyle, fontSize));
      }
      node = m_attributes.getNamedItem("foreground");
      if (node != null)
      {
         component.setForeground(getColor(node));
      }
      node = m_attributes.getNamedItem("inputMethodListener");
      if (node != null)
      {
         inputMethodListener = createInputMethodListener(node);
         if (inputMethodListener != null)
         {
            component.addInputMethodListener(inputMethodListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("keyListener");
      if (node != null)
      {
         keyListener = createKeyListener(node);
         if (keyListener != null)
         {
            component.addKeyListener(keyListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("mouseListener");
      if (node != null)
      {
         mouseListener = createMouseListener(node);
         if (mouseListener != null)
         {
            component.addMouseListener(mouseListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("mouseMotionListener");
      if (node != null)
      {
         mouseMotionListener = createMouseMotionListener(node);
         if (mouseMotionListener != null)
         {
            component.addMouseMotionListener(mouseMotionListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("name");
      if (node != null)
      {
         component.setName(getString(node, 1));
      }
      node = m_attributes.getNamedItem("propertyChangeListener");
      if (node != null)
      {
         propertyChangeListener = createPropertyChangeListener(node);
         if (propertyChangeListener != null)
         {
            component.addPropertyChangeListener(propertyChangeListener);
         }
         else
         {
            result = false;
         }
      }
      node = m_attributes.getNamedItem("visible");
      if (node != null)
      {
         component.setVisible(getBoolean(node));
      }
      return result;
   }

   /**
    * Method - getFontStyle - Get font style
    *
    * @param node the DOM node to obtaine the font style from
    * @return fontStyle the font style
    */

   protected int getFontStyle(Node node)
   {
      int                     fontStyle;
      String                  nodeValue;


      fontStyle = Font.PLAIN;
      nodeValue = getString(node);
      if (nodeValue.equals("PLAIN"))
      {
         fontStyle = Font.PLAIN;
      }
      else if (nodeValue.equals("BOLD"))
      {
         fontStyle = Font.BOLD;
      }
      else if (nodeValue.equals("ITALIC"))
      {
         fontStyle = Font.ITALIC;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The font style '" + nodeValue + "' is unknown"));
      }
      return fontStyle;
   }

   /**
    * Method - getConstraints - Get constraints
    *
    * @return constraints the constraints string
    */

   public String getConstraints()
   {
      String                  constraints;
      Node                    node;
      String                  nodeValue;


      constraints = BorderLayout.CENTER;
      node = m_attributes.getNamedItem("constraints");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("NORTH"))
         {
            constraints = BorderLayout.NORTH;
         }
         else if (nodeValue.equals("SOUTH"))
         {
            constraints = BorderLayout.SOUTH;
         }
         else if (nodeValue.equals("EAST"))
         {
            constraints = BorderLayout.EAST;
         }
         else if (nodeValue.equals("WEST"))
         {
            constraints = BorderLayout.WEST;
         }
         else if (nodeValue.equals("CENTER"))
         {
            constraints = BorderLayout.CENTER;
         }
         else
         {
            constraints = nodeValue;
            // m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The constraints '" + nodeValue + "' are unknown"));
         }
      }
      return constraints;
   }

   /**
    * Method - getIndex - Get index
    *
    * @return index the index
    */

   public int getIndex()
   {
      int                     index;
      Node                    node;


      node = m_attributes.getNamedItem("index");
      if (node != null)
      {
         index = getInteger(node, true);
      }
      else
      {
         index = -1;
      }
      return index;
   }

   /**
    * Method - getGridBagConstraints - Get GridBagConstraints
    *
    * @return the GridBagConstraints instance
    */

   public GridBagConstraints getGridBagConstraints()
   {
      GridBagConstraints      gridBagConstraints;
      Node                    node;
      String                  nodeValue;


      gridBagConstraints = new GridBagConstraints();
      node = m_attributes.getNamedItem("gridx");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("RELATIVE"))
         {
            gridBagConstraints.gridx = GridBagConstraints.RELATIVE;
         }
         else
         {
            gridBagConstraints.gridx = getInteger(node, true);
         }
      }
      node = m_attributes.getNamedItem("gridy");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("RELATIVE"))
         {
            gridBagConstraints.gridy = GridBagConstraints.RELATIVE;
         }
         else
         {
            gridBagConstraints.gridy = getInteger(node, true);
         }
      }
      node = m_attributes.getNamedItem("gridwidth");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("RELATIVE"))
         {
            gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
         }
         else if (nodeValue.equals("REMAINDER"))
         {
            gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
         }
         else
         {
            gridBagConstraints.gridwidth = getInteger(node, true);
         }
      }
      node = m_attributes.getNamedItem("gridheight");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("RELATIVE"))
         {
            gridBagConstraints.gridheight = GridBagConstraints.RELATIVE;
         }
         else if (nodeValue.equals("REMAINDER"))
         {
            gridBagConstraints.gridheight = GridBagConstraints.REMAINDER;
         }
         else
         {
            gridBagConstraints.gridheight = getInteger(node, true);
         }
      }
      node = m_attributes.getNamedItem("fill");
      if (node != null)
      {
         nodeValue = getString(node);
         if (nodeValue.equals("NONE"))
         {
            gridBagConstraints.fill = GridBagConstraints.NONE;
         }
         else if (nodeValue.equals("HORIZONTAL"))
         {
            gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
         }
         else if (nodeValue.equals("VERTICAL"))
         {
            gridBagConstraints.fill = GridBagConstraints.VERTICAL;
         }
         else if (nodeValue.equals("BOTH"))
         {
            gridBagConstraints.fill = GridBagConstraints.BOTH;
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The fill value '" + nodeValue + "' is unknown"));
         }
      }
      node = m_attributes.getNamedItem("ipadx");
      if (node != null)
      {
         gridBagConstraints.ipadx = getInteger(node, true);
      }
      node = m_attributes.getNamedItem("ipady");
      if (node != null)
      {
         gridBagConstraints.ipady = getInteger(node, true);
      }
      node = m_attributes.getNamedItem("insets");
      if (node != null)
      {
         gridBagConstraints.insets = getInsets(node);
      }
      node = m_attributes.getNamedItem("anchor");
      if (node != null)
      {
         nodeValue = node.getNodeValue();
         if (nodeValue.equals("NORTH"))
         {
            gridBagConstraints.anchor = GridBagConstraints.NORTH;
         }
         else if (nodeValue.equals("NORTHEAST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.NORTHEAST;
         }
         else if (nodeValue.equals("NORTHWEST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.NORTHWEST;
         }
         else if (nodeValue.equals("SOUTH"))
         {
            gridBagConstraints.anchor = GridBagConstraints.SOUTH;
         }
         else if (nodeValue.equals("SOUTHEAST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.SOUTHEAST;
         }
         else if (nodeValue.equals("SOUTHWEST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.SOUTHWEST;
         }
         else if (nodeValue.equals("EAST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.EAST;
         }
         else if (nodeValue.equals("WEST"))
         {
            gridBagConstraints.anchor = GridBagConstraints.WEST;
         }
         else if (nodeValue.equals("CENTER"))
         {
            gridBagConstraints.anchor = GridBagConstraints.CENTER;
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The anchor value '" + nodeValue + "' is unknown"));
         }
      }
      node = m_attributes.getNamedItem("weightx");
      if (node != null)
      {
         gridBagConstraints.weightx = getInteger(node, true);
      }
      node = m_attributes.getNamedItem("weighty");
      if (node != null)
      {
         gridBagConstraints.weighty = getInteger(node, true);
      }
      return gridBagConstraints;
   }

   /**
    * Method - createComponentListener - Create component listener
    *
    * @param node the DOM node to obtain component listener class name from
    * @return componentListener component listener or null if it could not be built
    */

   protected ComponentListener createComponentListener(Node node)
   {
      return (ComponentListener)createInstance(node, ComponentListener.class);
   }

   /**
    * Method - createFocusListener - Create focus listener
    *
    * @param node the DOM node to obtain focus listener class name from
    * @return focusListener focus listener or null if it could not be built
    */

   protected FocusListener createFocusListener(Node node)
   {
      return (FocusListener)createInstance(node, FocusListener.class);
   }

   /**
    * Method - createInputMethodListener - Create input method listener
    *
    * @param node the DOM node to obtain input method listener class name from
    * @return inputMethodListener input method listener or null if it could not be built
    */

   protected InputMethodListener createInputMethodListener(Node node)
   {
      return (InputMethodListener)createInstance(node, InputMethodListener.class);
   }

   /**
    * Method - createKeyListener - Create key listener
    *
    * @param node the DOM node to obtain key listener class name from
    * @return keyListener key listener or null if it could not be built
    */

   protected KeyListener createKeyListener(Node node)
   {
      return (KeyListener)createInstance(node, KeyListener.class);
   }

   /**
    * Method - createMouseListener - Create mouse listener
    *
    * @param node the DOM node to obtain mouse listener class name from
    * @return mouseListener mouse listener or null if it could not be built
    */

   protected MouseListener createMouseListener(Node node)
   {
      return (MouseListener)createInstance(node, MouseListener.class);
   }

   /**
    * Method - createMouseMotionListener - Create mouse motion listener
    *
    * @param node the DOM node to obtain mouse motion listener class name from
    * @return mouseMotionListener mouse motion listener or null if it could not be built
    */

   protected MouseMotionListener createMouseMotionListener(Node node)
   {
      return (MouseMotionListener)createInstance(node, MouseMotionListener.class);
   }

   /**
    * Method - createChangeListener - Create change listener
    *
    * @param node the DOM node to obtain change listener class name from
    * @return changeListener change listener or null if it could not be built
    */

   protected PropertyChangeListener createPropertyChangeListener(Node node)
   {
      return (PropertyChangeListener)createInstance(node, PropertyChangeListener.class);
   }
}