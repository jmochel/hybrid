/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xml;

import java.io.*;
import com.sun.xml.parser.*;
import com.sun.xml.tree.*;
import org.xml.sax.*;
import org.w3c.dom.*;

/**
 * Class - XMLSunParser - Bluestone XML Sun parser abstraction
 *
 * @see XMLAbstractParser
 */

public class XMLSunParser extends XMLAbstractParser
{
   protected com.sun.xml.parser.Parser m_parser = null;
   protected int                       m_parserErrors = 0;
   protected int                       m_parserWarnings = 0;


   /**
    * Method - parse - Parse XML from InputStream
    *
    * @param fileName logical name of XML file
    * @param inputStream input stream from which to read XML
    * @return document the parsed document
    */

   public synchronized Document parse(String fileName, InputStream inputStream)
   {
      Document                document;
      InputSource             inputSource;


      inputSource = new InputSource(inputStream);
      document = parse(inputSource);
      return document;
   }

   /**
    * Method - parse - Parse XML from Reader
    *
    * @param fileName logical name of XML file
    * @param reader reader from which to read XML
    * @return document the parsed document
    */

   public synchronized Document parse(String fileName, Reader reader)
   {
      Document                document;
      InputSource             inputSource;


      inputSource = new InputSource(reader);
      document = parse(inputSource);
      return document;
   }

   /**
    * Method - parse - Parse XML from InputSource
    *
    * @param inputSource input source from which to parse XML
    * @return document the parsed document
    */

   protected synchronized Document parse(InputSource inputSource)
   {
      Document                document;
      XmlDocumentBuilder      documentBuilder;


      m_parser = new com.sun.xml.parser.ValidatingParser();
      documentBuilder = new XmlDocumentBuilder();
      m_parser.setDocumentHandler(documentBuilder);
      m_parser.setErrorHandler(new XMLSunErrorHandler());
      m_parserErrors = 0;
      m_parserWarnings = 0;
      try
      {
         m_parser.parse(inputSource);
      }
      catch (Throwable t)
      {
      }
      document = documentBuilder.getDocument();
      return document;
   }

   /**
    * Method - getParserErrors - Get parser errors
    *
    * @return parserErrors number of errors encountered by the parser
    */

   public int getParserErrors()
   {
      return m_parserErrors;
   }

   /**
    * Method - getParserWarnings - Get parser warnings
    *
    * @return parserWarnings number of warnings encountered by the parser
    */

   public int getParserWarnings()
   {
      return m_parserWarnings;
   }

   /**
    * Class - XMLSunErrorHandler - Sun parser ErrorHandler
    */

   public class XMLSunErrorHandler implements ErrorHandler
   {
      public void error(SAXParseException e)
      {
         m_parserErrors++;
         fireParserError(e.getMessage());
      }

      public void fatalError(SAXParseException e)
      {
         m_parserErrors++;
         fireParserError(e.getMessage());
      }

      public void warning(SAXParseException e)
      {
         m_parserWarnings++;
         fireParserWarning(e.getMessage());
      }
   }
}