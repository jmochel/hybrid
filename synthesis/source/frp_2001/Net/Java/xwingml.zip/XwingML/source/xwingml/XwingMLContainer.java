/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/


package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLContainer - XwingML Container class
 */

public class XwingMLContainer extends XwingMLComponent
{
   /**
    * Constructor - XwingMLContainer
    */

   public XwingMLContainer()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLContainer
    *
    * @param node the DOM node decsribing the container to build
    */

   public XwingMLContainer(Node node)
   {
      super(node);
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(Container.class);
      return (m_object != null);
   }

   /**
    * Method - getContainer - Get container
    *
    * @return object the object typecasted to a Container
    */

   public Container getContainer()
   {
      return (Container)m_object;
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      Container               container;
      ContainerListener       containerListener;


      result = super.handleAttributes();
      if (result)
      {
         container = getContainer();
         node = m_attributes.getNamedItem("containerListener");
         if (node != null)
         {
            containerListener = createContainerListener(node);
            if (containerListener != null)
            {
               container.addContainerListener(containerListener);
            }
            else
            {
               result = false;
            }
         }
      }
      return result;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      Node                    node;
      XwingMLIObject          xmlObject;
      int                     i;


      result = true;
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
            if (xmlObject != null)
            {
               xmlObject.setParent(getContainer());
               result = xmlObject.buildObject();
               if (result)
               {
                  if (xmlObject instanceof XwingMLLayout)
                  {
                     handleLayout((XwingMLLayout)xmlObject);
                  }
                  else if (xmlObject instanceof XwingMLJPopupMenu)
                  {
                     handlePopupMenu((XwingMLJPopupMenu)xmlObject);
                  }
                  else if (xmlObject instanceof XwingMLButtonGroup)
                  {
                     handleButtonGroup((XwingMLButtonGroup)xmlObject);
                  }
                  else if (xmlObject instanceof XwingMLBorder)
                  {
                     handleBorder((XwingMLBorder)xmlObject);
                  }
                  else if (xmlObject instanceof XwingMLComponent)
                  {
                     handleComponent((XwingMLComponent)xmlObject);
                  }
               }
            }
            else
            {
               result = false;
            }
         }
      }
      return result;
   }

   /**
    * Method - handleLayout - Handle layout
    *
    * @param xmlLayout XwingML layout
    */

   protected void handleLayout(XwingMLLayout xmlLayout)
   {
      getContainer().setLayout(xmlLayout.getLayout());
   }

   /**
    * Method - handlePopupMenu - Handle popup menu
    *
    * @param xmlPopupMenu XwingML popup menu
    */

   protected void handlePopupMenu(XwingMLJPopupMenu xmlPopupMenu)
   {
      getContainer().addMouseListener(new XwingMLMouseListener(xmlPopupMenu.getJPopupMenu()));
   }

   /**
    * Method - handleButtonGroup - Handle button group
    *
    * @param xmlButtonGroup XwingML button group
    */

   protected void handleButtonGroup(XwingMLButtonGroup xmlButtonGroup)
   {
      Enumeration             buttons;


      buttons = xmlButtonGroup.getElements();
      while (buttons.hasMoreElements())
      {
         handleComponent((XwingMLComponent)buttons.nextElement());
      }
   }

   /**
    * Method - handleBorder - Handle border
    *
    * @param xmlBorder XwingML border
    */

   protected void handleBorder(XwingMLBorder xmlBorder)
   {
      XwingMLJComponent         xmlJComponent;


      xmlJComponent = xmlBorder.getXMLJComponent();
      if (xmlJComponent != null)
      {
         handleComponent(xmlJComponent);
      }
   }

   /**
    * Method - handleComponent - Handle component
    *
    * @param xmlComponent XwingML component
    */

   protected void handleComponent(XwingMLComponent xmlComponent)
   {
      Container               container;
      Component               component;
      LayoutManager           layout;
      GridBagLayout           gridBagLayout;
      GridBagConstraints      gridBagConstraints;
      String                  constraints;
      int                     index;


      container = getContainer();
      component = xmlComponent.getComponent();
      layout = container.getLayout();
      if (layout instanceof GridBagLayout)
      {
         gridBagLayout = (GridBagLayout)layout;
         gridBagConstraints = xmlComponent.getGridBagConstraints();
         gridBagLayout.setConstraints(component, gridBagConstraints);
         container.add(component);
      }
      else if (layout instanceof BorderLayout)
      {
         constraints = xmlComponent.getConstraints();
         container.add(component, constraints);
      }
      else if (layout instanceof CardLayout)
      {
         constraints = xmlComponent.getConstraints();
         container.add(component, constraints);
      }
      else
      {
         index = xmlComponent.getIndex();
         if (index >= 0)
         {
            container.add(component, index);
         }
         else
         {
            container.add(component);
         }
      }
   }

   /**
    * Method - createContainerListener - Create container listener
    *
    * @param node the DOM node to obtain the container listener class name from
    * @return containerListener the container listener or null if it could not be created
    */

   protected ContainerListener createContainerListener(Node node)
   {
      return (ContainerListener)createInstance(node, ContainerListener.class);
   }
}
