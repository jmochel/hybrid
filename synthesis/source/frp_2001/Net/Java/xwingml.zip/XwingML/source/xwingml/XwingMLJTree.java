/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLJTree - XwingML JTree class
 */

public class XwingMLJTree extends XwingMLJComponent
{
   protected TreeModelListener   m_treeModelListener;


   /**
    * Constructor - XwingMLJTree
    */

   public XwingMLJTree()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLJTree
    *
    * @param node the DOM node decsribing the tree to build
    */

   public XwingMLJTree(Node node)
   {
      super(node);
   }

   /**
    * Method - buildObject - Build object (i.e. interpret XML from node and build Swing component
    *
    * @return result true/false depending on whether the component could be built or not
    */

   public boolean buildObject()
   {
      boolean                 result;


      m_treeModelListener = null;
      result = super.buildObject();
      if (m_treeModelListener != null)
      {
         getJTree().getModel().addTreeModelListener(m_treeModelListener);
      }
      return result;
   }

   /**
    * Method - getJTree - Get Swing tree
    *
    * @return object the object typecasted to a JTree
    */

   public JTree getJTree()
   {
      return (JTree)m_object;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(JTree.class);
      return (m_object != null);
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      JTree                   tree;
      TreeExpansionListener   treeExpansionListener;
      TreeWillExpandListener  treeWillExpandListener;
      TreeSelectionListener   treeSelectionListener;
      TreeCellEditor          treeCellEditor;
      TreeCellRenderer        treeCellRenderer;
      TreeModel               treeModel;


      result = super.handleAttributes();
      if (result)
      {
         tree = getJTree();
         node = m_attributes.getNamedItem("treeExpansionListener");
         if (node != null)
         {
            treeExpansionListener = createTreeExpansionListener(node);
            if (treeExpansionListener != null)
            {
               tree.addTreeExpansionListener(treeExpansionListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("treeWillExandListener");
         if (node != null)
         {
            treeWillExpandListener = createTreeWillExpandListener(node);
            if (treeWillExpandListener != null)
            {
               tree.addTreeWillExpandListener(treeWillExpandListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("treeSelectionListener");
         if (node != null)
         {
            treeSelectionListener = createTreeSelectionListener(node);
            if (treeSelectionListener != null)
            {
               tree.addTreeSelectionListener(treeSelectionListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("cellEditor");
         if (node != null)
         {
            treeCellEditor = createTreeCellEditor(node);
            if (treeCellEditor != null)
            {
               tree.setCellEditor(treeCellEditor);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("cellRenderer");
         if (node != null)
         {
            treeCellRenderer = createTreeCellRenderer(node);
            if (treeCellRenderer != null)
            {
               tree.setCellRenderer(treeCellRenderer);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("editable");
         if (node != null)
         {
            tree.setEditable(getBoolean(node));
         }
         node = m_attributes.getNamedItem("invokesStopCellEditing");
         if (node != null)
         {
            tree.setInvokesStopCellEditing(getBoolean(node));
         }
         node = m_attributes.getNamedItem("largeModel");
         if (node != null)
         {
            tree.setLargeModel(getBoolean(node));
         }
         node = m_attributes.getNamedItem("model");
         if (node != null)
         {
            treeModel = createTreeModel(node);
            if (treeModel != null)
            {
               tree.setModel(treeModel);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("treeModelListener");
         if (node != null)
         {
            m_treeModelListener = createTreeModelListener(node);
            if (m_treeModelListener == null)
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("rootVisible");
         if (node != null)
         {
            tree.setRootVisible(getBoolean(node));
         }
         node = m_attributes.getNamedItem("rowHeight");
         if (node != null)
         {
            tree.setRowHeight(getInteger(node));
         }
         node = m_attributes.getNamedItem("scrollsOnExpand");
         if (node != null)
         {
            tree.setScrollsOnExpand(getBoolean(node));
         }
         node = m_attributes.getNamedItem("visibleRowCount");
         if (node != null)
         {
            tree.setVisibleRowCount(getInteger(node));
         }
      }
      return result;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      DefaultTreeModel        treeModel;
      DefaultMutableTreeNode  rootNode;
      Node                    node;
      XwingMLIObject          xmlObject;
      int                     i;


      result = true;
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            if (node.getNodeName().equals("TreeModelData"))
            {
               rootNode = new DefaultMutableTreeNode("Root");
               result = handleTreeModelData(node.getChildNodes(), rootNode);
               treeModel = new DefaultTreeModel(rootNode);
               getJTree().setModel(treeModel);
            }
            else if (node.getNodeName().equals("JPopupMenu"))
            {
               xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
               if (xmlObject != null)
               {
                  xmlObject.setParent(getContainer());
                  result = xmlObject.buildObject();
                  if (result)
                  {
                     handlePopupMenu((XwingMLJPopupMenu)xmlObject);
                  }
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - handleTreeModelData - Handle tree model data
    *
    * @param childNodes the DOM child nodes containing the tree model data
    * @param parentNode the tree node which is the parent node of this chunk of tree model data
    * @return result true/false depending on whether the tree model data could be handled successfully or not
    */

   protected boolean handleTreeModelData(NodeList childNodes, DefaultMutableTreeNode parentNode)
   {
      boolean                 result;
      Node                    node;
      Node                    textNode;
      String                  nodeValue;
      NamedNodeMap            attributes;
      DefaultMutableTreeNode  childNode;
      int                     i;


      result = true;
      if (childNodes != null)
      {
         for (i = 0; i < childNodes.getLength(); i++)
         {
            node = childNodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE)
            {
               if (node.getNodeName().equals("TreeNode"))
               {
                  attributes = node.getAttributes();
                  if (attributes != null)
                  {
                     textNode = attributes.getNamedItem("text");
                     if (textNode != null)
                     {
                        childNode = new DefaultMutableTreeNode(textNode.getNodeValue());
                        parentNode.add(childNode);
                        result = handleTreeModelData(node.getChildNodes(), childNode);
                     }
                  }
               }
            }
         }
      }
      return result;
   }


   /**
    * Method - createTreeExpansionListener - Create tree expansion listener
    *
    * @param node the DOM node to obtain tree expansion listener class name from
    * @return treeExpansionListener tree expansion listener or null if it could not be built
    */

   protected TreeExpansionListener createTreeExpansionListener(Node node)
   {
      return (TreeExpansionListener)createInstance(node, TreeExpansionListener.class);
   }

   /**
    * Method - createTreeWillExpandListener - Create tree will expand listener
    *
    * @param node the DOM node to obtain tree will expand listener class name from
    * @return treeWillExpandListener tree will expand listener or null if it could not be built
    */

   protected TreeWillExpandListener createTreeWillExpandListener(Node node)
   {
      return (TreeWillExpandListener)createInstance(node, TreeWillExpandListener.class);
   }

   /**
    * Method - createTreeSelectionListener - Create tree selection listener
    *
    * @param node the DOM node to obtain tree selection listener class name from
    * @return treeSelectionListener tree selection listener or null if it could not be built
    */

   protected TreeSelectionListener createTreeSelectionListener(Node node)
   {
      return (TreeSelectionListener)createInstance(node, TreeSelectionListener.class);
   }

   /**
    * Method - createTreeCellEditor - Create tree cell editor
    *
    * @param node the DOM node to obtain tree cell editor class name from
    * @return treeCellEditor tree cell editor or null if it could not be built
    */

   protected TreeCellEditor createTreeCellEditor(Node node)
   {
      return (TreeCellEditor)createInstance(node, TreeCellEditor.class);
   }

   /**
    * Method - createTreeCellRenderer - Create tree cell renderer
    *
    * @param node the DOM node to obtain tree cell renderer class name from
    * @return treeCellRenderer tree cell renderer or null if it could not be built
    */

   protected TreeCellRenderer createTreeCellRenderer(Node node)
   {
      return (TreeCellRenderer)createInstance(node, TreeCellRenderer.class);
   }

   /**
    * Method - createTreeModel - Create tree model
    *
    * @param node the DOM node to obtain tree model class name from
    * @return treeModel tree model or null if it could not be built
    */

   protected TreeModel createTreeModel(Node node)
   {
      return (TreeModel)createInstance(node, TreeModel.class);
   }

   /**
    * Method - createTreeModelListener - Create tree model listener
    *
    * @param node the DOM node to obtain tree model listener class name from
    * @return treeModelListener tree model listener or null if it could not be built
    */

   protected TreeModelListener createTreeModelListener(Node node)
   {
      return (TreeModelListener)createInstance(node, TreeModelListener.class);
   }
}
