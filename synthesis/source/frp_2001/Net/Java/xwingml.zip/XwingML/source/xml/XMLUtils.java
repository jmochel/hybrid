/*=============================================================================*/
/* Copyright � 1997-1999 by Bluestone Software, Inc. All rights Reserved.      */
/*=============================================================================*/
/*
$Archive:: $
$Revision:: $
$Date:: $ 01/22/1999
$Author:: $ Jay Hiremath
*/
/*=============================================================================*/

package com.bluestone.xml;

import java.io.*;
import java.util.*;
import org.xml.sax.*;
import org.w3c.dom.*;

/**
 * Class - XMLUtils - Some XML utilities
 *
 */

public class XMLUtils
{	
	/**
	 * Converts an XML document supplied in String format into the corresponding
	 * DOM.
	 * @param name used to report parser errors
	 * @param xml string
	 * @return Document
	 */
	public static Document getDocFromXMLString(String name, String xml)
	{
		class XMLParserListener implements XMLIParserListener
		{
			public void parserError(String message)
			{
				System.out.println("Parser Error: " + message);
			}

			public void parserWarning(String message)
			{
				System.out.println("Parser Warning: " + message);
			}
		}	
		
		if(xml == null || xml.length() < 1) 
		{
			return null;
		}
		XMLIParser parser = XMLParserFactory.makeIParser();
		if (parser == null)
		{
			return null;
		}
		XMLParserListener parserListener =  new XMLParserListener();
		parser.addParserListener(parserListener);
		Document document = parser.parse(name, xml);
		if (parser.getParserErrors() != 0)
		{
			System.out.println("XMLUtils: Could not obtain DOM for " + name);
			return null;
		}
		return document;
	}
		
	/**
	 * Retrives the attribute value.  If the attribute does not exist it returns
	 * and empty string!!
	 * 
	 * @param aNode the target node
	 * @param attribute name
	 * @return String representing the value
	 */
	public static String getAttributeValue(Node aNode, String attribute)
	{
		String val = "";
		NamedNodeMap attList = aNode.getAttributes();
		if(attList == null) 
		{
			return val;
		}
		Node attrNode = attList.getNamedItem(attribute);					
		if(attrNode == null) 
		{
			return val;
		}
		val = attrNode.getNodeValue();
		return val;		
	}
	/**
	 * Sets an attribute on the target node.  If the attribute does not exist
	 * it adds the attribute.
	 * 
	 * @param aNode the target node
	 * @param attribute name of the attribute
	 * @param value of the attribute
	 * @return oldvalue
	 */
	public static String setAttributeValue(Node aNode, String attribute, String value)
	{
		String rval = "";		
		NamedNodeMap attList = aNode.getAttributes();
		if(attList == null) 
		{
			return rval;
		}
		Node attrNode = attList.getNamedItem(attribute);					
		if(attrNode == null) 
		{
			addAttribute(aNode, attribute, value);
			return rval;
		}
		rval = attrNode.getNodeValue();		
		attrNode.setNodeValue(value);
		attList.setNamedItem(attrNode);
		return rval;		
	}
	
	/**
	 * Adds a new attribute to a DOM node
	 * 
	 * @param aNode target node
	 * @param attribute string
	 * @value value attribute value
	 */
	public static void addAttribute(Node aNode, String attribute, String value)
	{
		Document document = aNode.getOwnerDocument();
		Attr tAttr = document.createAttribute("populated");
		tAttr.setValue(value);
		NamedNodeMap aAttrs = aNode.getAttributes();
		aAttrs.setNamedItem(tAttr);
	}
	
	
	/**
	 * Returns a hashtable of attribute name value pairs
	 *
	 * @param aNode the node to operate on
	 * @return Hashtable of attribute name value pairs
	 */
	public static Hashtable getAttributes(Node aNode)
	{
		Hashtable outList = new Hashtable();
		NamedNodeMap attList = aNode.getAttributes();
		if(attList == null) 
		{			
			return outList;
		}
		for(int i = 0, aCount = attList.getLength(); i < aCount; i++) 
		{
			Node att = attList.item(i);
			if(att == null) 
			{
				continue;
			}
			String name = att.getNodeName();
			String val = att.getNodeValue();
			outList.put(name, val);
		}
		return outList;
	}	
	
	/**
	 * Searches through the previous siblings using getPreviousSibling and 
	 * returns the first node with type Node.ELEMENT_NODE.
	 * 
	 * @param anElement target element
	 * @return Element the first siblimng element, null if not found
	 */
	public static Element getPreviousSiblingElement(Element anElement)
	{
		Node theNode = (Node) anElement;
		Element rNode = null;
		try 
		{
			do {
				Node tNode = theNode.getPreviousSibling();
				if(tNode != null && tNode.getNodeType() == Node.ELEMENT_NODE) 
				{
					rNode = (Element)tNode;
					break;
				}
				theNode = tNode;
			}while(theNode != null);
		}
		catch(DOMException e) 
		{
			return (Element)rNode;
		}			
		return (Element)rNode;
	}
	/**
	 * Searches through the child node list and finds the first
	 * Element that has the matching attribute value.
	 *  
	 * @param Node parent node
	 * @return Element the first child element with matching criteria, null if not found
	 */
	public static Element findChildElementByAttribute(Node parent, String attr, String val)
	{
		Element rNode = null;
		if(parent == null){
			return null;
		}
		NodeList nList = parent.getChildNodes();
		for(int i = 0, nCount = nList.getLength(); i < nCount; i++) {
			Node aNode = nList.item(i);
			if(aNode.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			String tVal = getAttributeValue(aNode, attr);
			if(tVal.equals (val)) {
				return (Element)aNode;
			}
		}
		return null;
	}
	/**
	 * Searches through the next siblings using getNextSibling and 
	 * returns the first node with type Node.ELEMENT_NODE.
	 * 
	 * @param anElement target element
	 * @return Element the first sibling element, null if not found
	 */
	public static Element getNextSiblingElement(Element anElement)
	{
		Node theNode = (Node) anElement;
		Element rNode = null;
		try 
		{
			do {
				Node tNode = theNode.getNextSibling();
				if(tNode != null && tNode.getNodeType() == Node.ELEMENT_NODE) 
				{
					rNode = (Element)tNode;
					break;
				}
				theNode = tNode;
			}while(theNode != null);
		}
		catch(DOMException e) 
		{
			return rNode;
		}			
		return rNode;
	}
	/**
	 * Finds the first child element node.
	 *
	 * @param parentNode the parent node
	 * @return foundNode or null if not found.
	 */
	public static Node getFirstChildElementNode(Node parentNode)
	{
		Node eleNode = null;
		NodeList fList = parentNode.getChildNodes();
		if(fList == null)			
		{
			return eleNode;
		}
		for(int i = 0, fCount = fList.getLength(); i < fCount; i++) 
		{
			Node fNode = fList.item(i);
			if(fNode == null) 
			{
				continue;
			}
			if(fNode.getNodeType() == Node.ELEMENT_NODE) 
			{
				eleNode = fNode;
				break;
			}
		}
		return eleNode;
	}
    /**
     * Read a nodes attributes and create an XML Element describing it.
     * 
     * @param  node the node to describe.
     * @return an XML node string ( '<' tag [ attrname = 'attrval' ] '>' ) or null if input is null.
     */
    public static String node2XML( Node node )
    {
        StringBuffer    buf;
        NamedNodeMap    nodeMap;

        if ( node == null )
            return null;
        
        buf = new StringBuffer( 100 );
        
        buf.append( "<" );
        buf.append( node.getNodeName() );
        
        nodeMap = node.getAttributes();
        if ( nodeMap != null && nodeMap.getLength() > 0)
        {
            buf.append( " " );
            for ( int i = 0; i < nodeMap.getLength(); i++ )
            {
                Node attrNode = nodeMap.item( i );
                String attrName  = attrNode.getNodeName();
                String attrValue = attrNode.getNodeValue();

                buf.append( attrName );
                buf.append( "='" );
                buf.append( attrValue );
                buf.append( "' " );
            }
            buf.setLength( buf.length() - 1 );
        }
        if ( ! node.hasChildNodes() )
        {
            buf.append( "/>" );
        }
        else
        {
            buf.append( ">" );
        }
        return buf.toString();
    }


    /**
     * Retrieve the text associated with a DOM Node. This method
     * recursively searches the node and it's children in document order
     * 
     * @param   aNode an arbitrary DOM Node.
     * @return  a text string representing the text of this
     *          DOM subtree or an empty string if none found.
     */
    public static String getNodeText( Node aNode )
    {
        StringBuffer out = new StringBuffer();
        if ( aNode.hasChildNodes() )
        {
            NodeList children = aNode.getChildNodes();
            for ( int i = 0; i < children.getLength(); i++ )
            {
                out.append( getNodeText( children.item( i ) ) );
            }
        }
        else if ( aNode.getNodeType() == Node.TEXT_NODE ||
                  aNode.getNodeType() == Node.CDATA_SECTION_NODE )
        {
            Text textNode = (Text)aNode;
            out.append( textNode.getData() );
        }
        return out.toString();
    }
	
    /**
     * Retrieve the text associated with a DOM Node. This method
     * extracts text from child nodes that are text nodes.
     * 
     * @param   aNode an arbitrary DOM Node.
     * @return  a text string representing the text of this
     *          Node or an empty string if none found.
     */
    public static String getTextFromTextNodes( Node aNode )
    {
        StringBuffer out = new StringBuffer();
        if ( aNode.hasChildNodes() )
        {
            NodeList children = aNode.getChildNodes();
            for ( int i = 0; i < children.getLength(); i++ )
            {
				Node tNode = children.item(i);
				if ( tNode.getNodeType() == Node.TEXT_NODE ||
					 tNode.getNodeType() == Node.CDATA_SECTION_NODE ) {
						out.append(((Text)tNode).getData());
				}
            }
        }
        return out.toString();
    }
	

	/**
	 * Finds the first element encountered in a preorder search whose tag name match the parameter.
	 *
	 * @param aNode an Element or Document to search.
	 * @param tagName the tagName of the node to find.
	 * @return foundNode or null if not found.
	 */
	public static Element getFirstElementByTagName( Node aNode, String tagName )
	{
		Element retNode = null;

		if ( aNode != null )
		{			
			NodeList nodeList = null;
			if ( aNode instanceof Element )
			{
				nodeList = ((Element)aNode).getElementsByTagName( tagName );
			}
			else if ( aNode instanceof Document )
			{
				nodeList = ((Document)aNode).getElementsByTagName( tagName );
			}

			if ( nodeList != null && nodeList.getLength() > 0)
			{
				retNode = (Element) nodeList.item( 0 );
			}
		}
		return retNode;
	}
	/**
	 * Finds the first child element whose tag name matches the parameter.
	 *
	 * @param aNode an Element or Document to search.
	 * @param tagName the tagName of the node to find.
	 * @return foundNode or null if not found.
	 */
	public static Element getFirstChildElementByTagName( Node aNode, String tagName )
	{
		Element retNode = null;

		if ( aNode != null )
		{			
			NodeList nodeList = aNode.getChildNodes();
			if(nodeList != null) {
				for(int i = 0, cCount = nodeList.getLength(); i < cCount; i++) {
					Node tNode = nodeList.item(i);
					if(tNode == null || tNode.getNodeType() != Node.ELEMENT_NODE) {
						continue;
					}
					if(tagName.equals(tNode.getNodeName())) {
						retNode = (Element)tNode;
						break;
					}
				}
			}
		}
		return retNode;
	}

    /**
     * Get a string representation of the the owner of a node.  Note that the owner is not necessarily an ancestor of the node, but the document from which the node was created.
     */
    public static String getOwnerDocumentText( Node aNode )
    {
        String              ret;
        Document            doc;
        XMLIDocumentWriter  writer;

        ret = null;
        if ( aNode != null )
        {
            if ( aNode instanceof Document )
                doc = (Document)aNode;
            else
                doc = aNode.getOwnerDocument();
            
            if ( doc != null )
            {
                writer = XMLDocumentWriterFactory.makeIDocumentWriter( doc );
                if ( writer != null )
                {
                    ret = writer.getDocumentText();
                }
            }
        }
        return ret;
    }


    /**
     * Create a new document with this node at the root and return the document string.
     */
    public static String getNodeDocumentText( Node aNode )
    {
        String              ret;
        Document            doc;
        Node                nodeCopy;
        
        ret = null;
        if ( aNode != null )
        {
            doc = XMLDOMFactory.makeDocument();
            if ( doc != null )
            {
                nodeCopy = cloneNode( doc, aNode );
                if ( nodeCopy != null )
                {
                    doc.appendChild( nodeCopy );
                    ret = getOwnerDocumentText( doc );
                }
            }
        }
        return ret;
    }

    /**
     * Find the top level ancestor of the current node and return its document string.
     */
    public static String getAncestorDocumentText( Node aNode )
    {
        String      ret;
        Node        ancestor;

        ret = null;
        if ( aNode != null )
        {
            ancestor = getTopLevelAncestor( aNode );
            if ( ancestor != null )
            {
                ret = getNodeDocumentText( ancestor );
            }
        }

        return ret;
    }

    /**
     * Find the highest ancestor of aNode in document tree.
     */
    public static Node getTopLevelAncestor( Node aNode )
    {
        Node ret = aNode;
        Node ancestor = aNode;
        while ( ancestor != null )
        {
            ret = ancestor;
            ancestor = ancestor.getParentNode();
        }
        return ret;
    }

    /**
     * Clone a Node over documents including child nodes.
     * This method supports <CODE>Element, Text, CDATASection, Attr,
     * ProcessingInstruction, Comment, EntityReference</CODE>.
     *
     * @param factory A factory Document of new Node.
     * @param node Source Node.
     */
	public static Node cloneNode( Document factory, Node node )
	{
		return cloneNode( factory, node, true );
	}
	
    /**
     * Clone a Node over documents including child nodes.
     * This method supports <CODE>Element, Text, CDATASection, Attr,
     * ProcessingInstruction, Comment, EntityReference</CODE>.
     *
     * @param factory A factory Document of new Node.
     * @param node Source Node.
     * @param deep set to true to perform deep copy.
     */
    public static Node cloneNode(Document factory, Node node, boolean deep ) {
        Node ret = null;
        switch (node.getNodeType()) {
          case Node.ELEMENT_NODE:
            ret = factory.createElement(node.getNodeName());
            NamedNodeMap nnm = node.getAttributes();
            for (int i = 0;  i < nnm.getLength();  i ++) {
                Node a = nnm.item(i);
                ((Element)ret).setAttribute(a.getNodeName(), a.getNodeValue());
            }
            break;

          case Node.TEXT_NODE:
            ret = factory.createTextNode(node.getNodeValue());
            /*
            if (ret instanceof TXText && isAllWhitespaces(ret)) {
                ((TXText)ret).setIsIgnorableWhitespace(true);
            }
            */
            break;
          case Node.CDATA_SECTION_NODE:
            ret = factory.createCDATASection(node.getNodeValue());
            break;

          case Node.ATTRIBUTE_NODE:
            ret = factory.createAttribute(node.getNodeName());
            ret.setNodeValue(node.getNodeValue());
            break;

          case Node.PROCESSING_INSTRUCTION_NODE:
            ret = factory.createProcessingInstruction(node.getNodeName(), node.getNodeValue());
            break;

          case Node.COMMENT_NODE:
            ret = factory.createComment(node.getNodeValue());
            break;

          case Node.ENTITY_REFERENCE_NODE:
            ret = factory.createEntityReference(node.getNodeName());
            break;

          default:
            throw new RuntimeException("Converter#cloneNode(): Internal Error:"+node.getNodeType());
        }
        if (deep && ret != null && node.hasChildNodes()) {
            Node child = node.getFirstChild();
            while (child != null) {
                ret.insertBefore(cloneNode(factory, child, deep), null);
                child = child.getNextSibling();
            }
        }
        return ret;
    }    

    public static Node getNamedNodeFromList( NodeList list, String nodeName )
    {
        Node retNode = null;

        if ( list != null && nodeName != null ) {
            // otherwise do the slow and inefficient linear search..
            for ( int i = 0, len = list.getLength(); i < len; i++ ) {
                Node nextItem = list.item( i );
                if ( nextItem == null ) {
                    continue;
                }
                if ( nextItem.getNodeName().equals( nodeName ) ) {
                    retNode = nextItem;
                    break;
                }
            }
        }

        return retNode;
    }

    public static Node getNamedNodeFromList( NamedNodeMap list, String nodeName )
    {
        Node retNode = null;

        // this is easy with named node map, but the method is provided for consistency..
        if ( list != null && nodeName != null ) {
            retNode = ((NamedNodeMap)list).getNamedItem( nodeName );
        }

        return retNode;
    }
	/**
	 * Retrieves a vector of child elements.
	 *
	 * @param parentNode the parent node
	 * @return Vector of Child Elements
	 */
	public static Vector getChildElements(Node parentNode)
	{
		Vector rVal = new Vector();
		NodeList nList = parentNode.getChildNodes();
		int nCount = nList.getLength();
		if(nList == null || nCount < 1) {
			return rVal;
		}
		for(int i = 0; i < nCount; i++) {
			Node aNode = nList.item(i);
			if(aNode.getNodeType() == Node.ELEMENT_NODE){
				rVal.addElement (aNode);
			}
		}
		return rVal;
	}
	
	/**
	 * Retrieves a Vector of matching Elements that are descendants of 
	 * the parent node.
	 * 
	 * @param parentNode
	 * @param elementName used in lookup
	 */
	
	public Vector getElementsByName(Node parentNode, String elementName)
	{
		class ElementHandler implements NodeVisitor
		{
			ElementHandler(String aName){
				m_elementName = aName;
			}
			String m_elementName = "";
			public Vector ret = new Vector();
			public void visitPre( Node node )
			{
				if(node != null && 
				   node.getNodeType() == Node.ELEMENT_NODE &&
				   node.getNodeName().equals(m_elementName)) {
					ret.addElement(node);
				}
			}
			public void visitPost( Node node )
			{
			}
		}
		ElementHandler handler = new ElementHandler(elementName);
		DOMWalker.walk(parentNode, handler);
		return handler.ret;
	}
	
}
