/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLJComponent - XwingML JComponent class
 */

public class XwingMLJComponent extends XwingMLContainer
{
   /**
    * Constructor - XwingMLJComponent
    */

   public XwingMLJComponent()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLJComponent
    *
    * @param node the DOM node decsribing the combo box to build
    */

   public XwingMLJComponent(Node node)
   {
      super(node);
   }

   /**
    * Method - getJComponent - Get Swing component
    *
    * @return object the object typecasted to a JComponent
    */

   public JComponent getJComponent()
   {
      return (JComponent)m_object;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(JComponent.class);
      return (m_object != null);
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      JComponent              component;
      AncestorListener        ancestorListener;


      result = super.handleAttributes();
      if (result)
      {
         component = getJComponent();
         node = m_attributes.getNamedItem("ancestorListener");
         if (node != null)
         {
            ancestorListener = createAncestorListener(node);
            if (ancestorListener != null)
            {
               component.addAncestorListener(ancestorListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("maximumSize");
         if (node != null)
         {
            component.setMaximumSize(getDimension(node));
         }
         node = m_attributes.getNamedItem("minimumSize");
         if (node != null)
         {
            component.setMinimumSize(getDimension(node));
         }
         node = m_attributes.getNamedItem("opaque");
         if (node != null)
         {
            component.setOpaque(getBoolean(node));
         }
         node = m_attributes.getNamedItem("preferredSize");
         if (node != null)
         {
            component.setPreferredSize(getDimension(node));
         }
         node = m_attributes.getNamedItem("toolTipText");
         if (node != null)
         {
            component.setToolTipText(getString(node));
         }
      }
      return result;
   }

   /**
    * Method - getSelectionMode - Get selection mode
    *
    * @param node the DOM node obtain the selction mode from
    * @return selctionMode the selection mode
    */

   protected int getSelectionMode(Node node)
   {
      int                     selectionMode;
      String                  nodeValue;


      selectionMode = ListSelectionModel.SINGLE_SELECTION;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("SINGLE_SELECTION"))
      {
         selectionMode = ListSelectionModel.SINGLE_SELECTION;
      }
      else if (nodeValue.equals("SINGLE_INTERVAL_SELECTION"))
      {
         selectionMode = ListSelectionModel.SINGLE_INTERVAL_SELECTION;
      }
      else if (nodeValue.equals("MULTIPLE_INTERVAL_SELECTION"))
      {
         selectionMode = ListSelectionModel.MULTIPLE_INTERVAL_SELECTION;
      }
      else 
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The selection mode '" + nodeValue + "' is unknown"));
      }
      return selectionMode;
   }

   /**
    * Method - createActionListener - Create action listener
    *
    * @param node the DOM node to obatin the action listener class name from
    * @return actionListener the action listener or null if it could not be built
    */

   protected ActionListener createActionListener(Node node)
   {
      return (ActionListener)createInstance(node, ActionListener.class);
   }

   /**
    * Method - createAncestorListener - Create ancestor listener
    *
    * @param node the DOM node to obatin the ancestor listener class name from
    * @return ancestorListener the ancestor listener or null if it could not be built
    */

   protected AncestorListener createAncestorListener(Node node)
   {
      return (AncestorListener)createInstance(node, AncestorListener.class);
   }

   /**
    * Method - createChangeListener - Create change listener
    *
    * @param node the DOM node to obatin the change listener class name from
    * @return changeListener the change listener or null if it could not be built
    */

   protected ChangeListener createChangeListener(Node node)
   {
      return (ChangeListener)createInstance(node, ChangeListener.class);
   }

   /**
    * Method - createListCellRenderer - Create list cell renderer
    *
    * @param node the DOM node to obatin the list cell renderer listener class name from
    * @return listCellRenderer the list cell listener or null if it could not be built
    */

   protected ListCellRenderer createListCellRenderer(Node node)
   {
      return (ListCellRenderer)createInstance(node, ListCellRenderer.class);
   }

   /**
    * Method - createListSelectionModel - Create list selection model
    *
    * @param node the DOM node to obatin the list selection model class name from
    * @return listSelectionModel the list selection model or null if it could not be built
    */

   protected ListSelectionModel createListSelectionModel(Node node)
   {
      return (ListSelectionModel)createInstance(node, ListSelectionModel.class);
   }

   /**
    * Method - createListDataListener - Create list data listener
    *
    * @param node the DOM node to obatin the list data listener class name from
    * @return listDataListener the list data listener or null if it could not be built
    */

   protected ListDataListener createListDataListener(Node node)
   {
      return (ListDataListener)createInstance(node, ListDataListener.class);
   }
}