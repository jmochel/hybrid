/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLJScrollBar - XwingML JScrollBar class
 */

public class XwingMLJScrollBar extends XwingMLJComponent
{
   /**
    * Constructor - XwingMLJScrollBar
    */

   public XwingMLJScrollBar()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLJScrollBar
    *
    * @param node the DOM node decsribing the scroll bar to build
    */

   public XwingMLJScrollBar(Node node)
   {
      super(node);
   }

   /**
    * Method - getJScrollBar - Get Swing scroll bar
    *
    * @return object the object typecasted to a JScrollBar
    */

   public JScrollBar getJScrollBar()
   {
      return (JScrollBar)m_object;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(JScrollBar.class);
      return (m_object != null);
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      JScrollBar              scrollBar;
      AdjustmentListener      adjustmentListener;


      result = super.handleAttributes();
      if (result)
      {
         scrollBar = getJScrollBar();
         node = m_attributes.getNamedItem("adjustmentListener");
         if (node != null)
         {
            adjustmentListener = createAdjustmentListener(node);
            if (adjustmentListener != null)
            {
               scrollBar.addAdjustmentListener(adjustmentListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("blockIncrement");
         if (node != null)
         {
            scrollBar.setBlockIncrement(getInteger(node));
         }
         node = m_attributes.getNamedItem("unitIncrement");
         if (node != null)
         {
            scrollBar.setUnitIncrement(getInteger(node));
         }
         node = m_attributes.getNamedItem("maximum");
         if (node != null)
         {
            scrollBar.setMaximum(getInteger(node));
         }
         node = m_attributes.getNamedItem("minimum");
         if (node != null)
         {
            scrollBar.setMinimum(getInteger(node));
         }
         node = m_attributes.getNamedItem("orientation");
         if (node != null)
         {
            scrollBar.setOrientation(getOrientation(node));
         }
         node = m_attributes.getNamedItem("value");
         if (node != null)
         {
            scrollBar.setValue(getInteger(node));
         }
      }
      return result;
   }

   /**
    * Method - createAdjustmentListener - Create adjustment listener
    *
    * @param node the DOM node to obtain adjustment listener class name from
    * @return adjustmentListener adjustment listener or null if it could not be built
    */

   public AdjustmentListener createAdjustmentListener(Node node)
   {
      return (AdjustmentListener)createInstance(node, AdjustmentListener.class);
   }

   /**
    * Method - getOrientation - Get orientation
    *
    * @param node the DOM node to retrieve the orientation from
    * @return orientation the orientation retrieved from the node
    */

   protected int getOrientation(Node node)
   {
      int                     orientation;
      String                  nodeValue;


      nodeValue = node.getNodeValue();
      orientation = JScrollBar.HORIZONTAL;
      if (nodeValue.equals("HORIZONTAL"))
      {
         orientation = JScrollBar.HORIZONTAL;
      }
      else if (nodeValue.equals("VERTICAL"))
      {
         orientation = JScrollBar.VERTICAL;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The orientation '" + nodeValue + "' is unknown"));
      }
      return orientation;
   }
}
