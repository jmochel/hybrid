/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xml;

import java.io.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Interface - XMLIParser - Bluestone XML parser interface
 */

public interface XMLIParser
{
   /**
    * Method - addParserListener - Add parser listener
    *
    * @param listener XMLIParserListener listener
    */

   public void addParserListener(XMLIParserListener listener);

   /**
    * Method - removeParserListener - Remove parser listener
    *
    * @param listener XMLIParserListener listener
    */

   public void removeParserListener(XMLIParserListener listener);

   /**
    * Method - parse - Parse XML from InputStream
    *
    * @param file  XML file
    * @return document the parsed document
    */

   public Document parse(File file);

   /**
    * Method - parse - Parse XML from InputStream
    *
    * @param fileName logical name of XML file
    * @return document the parsed document
    */

   public Document parse(String fileName);

   /**
    * Method - parse - Parse XML from InputStream
    *
    * @param fileName logical name of XML file
    * @param inputStream input stream from which to read XML
    * @return document the parsed document
    */

   public Document parse(String fileName, InputStream inputStream);

   /**
    * Method - parse - Parse XML from Reader
    *
    * @param fileName logical name of XML file
    * @param reader reader from which to read XML
    * @return document the parsed document
    */

   public Document parse(String fileName, Reader reader);

   /**
    * Method - parse - Parse XML from String
    *
    * @param fileName logical name of XML file
    * @param string string from which to read XML
    * @return document the parsed document
    */

   public Document parse(String fileName, String string);

   /**
    * Method - parse - Parse XML from StringBuffer
    *
    * @param fileName logical name of XML file
    * @param stringBuffer string buffer from which to read XML
    * @return document the parsed document
    */

   public Document parse(String fileName, StringBuffer stringBuffer);

   /**
    * Method - parse - Parse XML from byte array
    *
    * @param fileName logical name of XML file
    * @param bytes byte array from which to read XML
    * @return document the parsed document
    */

   public Document parse(String fileName, byte bytes[]);

   /**
    * Method - getParserErrors - Get parser errors
    *
    * @return parserErrors number of errors encountered by the parser
    */

   public int getParserErrors();

   /**
    * Method - getParserWarnings - Get parser warnings
    *
    * @return parserWarnings number of warnings encountered by the parser
    */

   public int getParserWarnings();
}