/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/


package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLAbstractButton - XwingML AbstractButton class
 */

public abstract class XwingMLAbstractButton extends XwingMLJComponent
{
   /**
    * Constructor - XwingMLAbstractButton
    */

   public XwingMLAbstractButton()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLAbstractButton
    *
    * @param node the DOM node decsribing the button to build
    */

   public XwingMLAbstractButton(Node node)
   {
      super(node);
   }

   /**
    * Method - getAbstractButton - Get abstract button
    *
    * @return object the object typecasted to an AbstractButton
    */

   public AbstractButton getAbstractButton()
   {
      return (AbstractButton)m_object;
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      AbstractButton          button;
      ActionListener          actionListener;
      ChangeListener          changeListener;
      ItemListener            itemListener;


      result = super.handleAttributes();
      if (result)
      {
         button = getAbstractButton();
         node = m_attributes.getNamedItem("actionCommand");
         if (node != null)
         {
            button.setActionCommand(getString(node));
         }
         node = m_attributes.getNamedItem("actionListener");
         if (node != null)
         {
            actionListener = createActionListener(node);
            if (actionListener != null)
            {
               button.addActionListener(actionListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("changeListener");
         if (node != null)
         {
            changeListener = createChangeListener(node);
            if (changeListener != null)
            {
               button.addChangeListener(changeListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("disabledIcon");
         if (node != null)
         {
            button.setDisabledIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("disabledSelectedIcon");
         if (node != null)
         {
            button.setDisabledSelectedIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("horizontalAlignment");
         if (node != null)
         {
            button.setHorizontalAlignment(getHorizontalAlignment(node));
         }
         node = m_attributes.getNamedItem("horizontalTextPosition");
         if (node != null)
         {
            button.setHorizontalTextPosition(getHorizontalTextPosition(node));
         }
         node = m_attributes.getNamedItem("icon");
         if (node != null)
         {
            button.setIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("itemListener");
         if (node != null)
         {
            itemListener = createItemListener(node);
            if (itemListener != null)
            {
               button.addItemListener(itemListener);
            }
            else
            {
               result = false;
            }
         }
         node = m_attributes.getNamedItem("mnemonic");
         if (node != null)
         {
            button.setMnemonic(getChar(node));
         }
         node = m_attributes.getNamedItem("pressedIcon");
         if (node != null)
         {
            button.setPressedIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("rolloverEnabled");
         if (node != null)
         {
            button.setRolloverEnabled(getBoolean(node));
         }
         node = m_attributes.getNamedItem("rolloverIcon");
         if (node != null)
         {
            button.setRolloverIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("selected");
         if (node != null)
         {
            button.setSelected(getBoolean(node));
         }
         node = m_attributes.getNamedItem("selectedIcon");
         if (node != null)
         {
            button.setSelectedIcon(getImageIcon(node));
         }
         node = m_attributes.getNamedItem("text");
         if (node != null)
         {
            button.setText(getString(node));
         }
         node = m_attributes.getNamedItem("verticalAlignment");
         if (node != null)
         {
            button.setVerticalAlignment(getVerticalAlignment(node));
         }
         node = m_attributes.getNamedItem("verticalTextPosition");
         if (node != null)
         {
            button.setVerticalTextPosition(getVerticalTextPosition(node));
         }
      }
      return result;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      return true;
   }

   /**
    * Method - createItemListener - Create item listener
    *
    * @param node the DOM to create the item listener from
    * @return itemListener or null if it could not be created
    */

   protected ItemListener createItemListener(Node node)
   {
      return (ItemListener)createInstance(node, ItemListener.class);
   }
}