/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLObject - Abstract super class for all XwingML objects
 */

public abstract class XwingMLObject implements XwingMLIObject
{
   protected Node             m_node;
   protected NamedNodeMap     m_attributes;
   protected NodeList         m_childNodes;
   protected Object           m_object;
   protected Container        m_parent;
   protected XwingMLIContext  m_context;


   /**
    * Constructor - XwingMLObject
    */

   public XwingMLObject()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLObject
    *
    * @param node the DOM node describing the object to build
    */

   public XwingMLObject(Node node)
   {
      setNode(node);
      setParent(null);
   }

   /**
    * Method - setNode - Set node
    *
    * @param node the DOM node describing the object
    */

   public void setNode(Node node)
   {
      m_node = node;
      if (m_node != null)
      {
         m_attributes = m_node.getAttributes();
         m_childNodes = m_node.getChildNodes();
      }
   }

   /**
    * Method - setParent - Set parent
    *
    * @param parent the container which owns the Swing component
    */

   public void setParent(Container parent)
   {
      m_parent = parent;
   }

   /**
    * Method - getParent - Get parent
    *
    * @return parent the container which owns the Swing component or null if not set
    */

   public Container getParent()
   {
      return m_parent;
   }

   /**
    * Method - buildObject - Build object (i.e. interpret XML from node and build Swing component
    *
    * @return result true/false depending on whether the component could be built or not
    */

   public boolean buildObject()
   {
      boolean                 result;


      result = createObject();
      if (result)
      {
         if ((m_attributes != null) && (m_attributes.getLength() > 0))
         {
            result = handleAttributes();
         }
      }
      if (result)
      {
         if ((m_childNodes != null) && (m_childNodes.getLength() > 0))
         {
            result = handleChildNodes();
         }
         if (result)
         {
            if (m_object != null)
            {
               if (m_object instanceof XwingMLIPlugIn)
               {
                  ((XwingMLIPlugIn)m_object).setContext(m_context);
               }
               if (m_object instanceof JComponent)
               {
                  ((JComponent)m_object).putClientProperty("XwingML:context", m_context);
               }
            }
            else
            {
               result = false;
            }
         }
      }
      return result;
   }
   
   /**
    * Method - getObject - Get object
    *
    * @return object the instance of the object built by the buildObject method
    */

   public Object getObject()
   {
      return m_object;
   }

   /**
    * Method - setContext - Set context
    *
    * @param context instance of XwingMLIContext
    */

   public void setContext(XwingMLIContext context)
   {
      m_context = context;
   }

   /**
    * Method - getContext - Get context
    *
    * @return context instance of XwingMLIContext or null if not set
    */

   public XwingMLIContext getContext()
   {
      return m_context;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   protected abstract boolean createObject();

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   protected abstract boolean handleAttributes();

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   protected abstract boolean handleChildNodes();

   /**
    * Method - getBoolean - Get boolean value from node
    *
    * @param node DOM node to retrieve boolean value from
    * @return value boolean true/false
    */

   protected boolean getBoolean(Node node)
   {
      boolean                 value;
      String                  nodeValue;


      value = false;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("true"))
      {
         value = true;
      }
      else if (nodeValue.equals("false"))
      {
         value = false;
      }
      else 
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid boolean value"));
      }
      return value;
   }

   /**
    * Method - getByte - Get byte from node
    *
    * @param node DOM node to retrieve byte value from
    * @return value byte value
    */

   protected byte getByte(Node node)
   {
      byte                    value;
      String                  nodeValue;


      value = 0;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() == 1)
      {
         value = (byte)nodeValue.charAt(0);
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid byte"));
      }
      return value;
   }

   /**
    * Method - getChar - Get character from node
    *
    * @param node DOM node to retrieve character value from
    * @return value character value
    */

   protected char getChar(Node node)
   {
      char                    value;
      String                  nodeValue;


      value = ' ';
      nodeValue = node.getNodeValue();
      if (nodeValue.length() == 1)
      {
         value = nodeValue.charAt(0);
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid character"));
      }
      return value;
   }

   /**
    * Method - getInteger - Get integer from node
    *
    * @param node DOM node to retrieve integer from
    * @return value integer value
    */

   protected int getInteger(Node node)
   {
      return getInteger(node, false);
   }

   /**
    * Method - getInteger - Get integer from node
    *
    * @param node DOM node to retrieve integer from
    * @param unsigned true/false depending on whether the value is unsigned or not
    * @return value integer value
    */

   protected int getInteger(Node node, boolean unsigned)
   {
      int                     value;
      String                  nodeValue;


      value = 0;
      nodeValue = node.getNodeValue();
      try
      {
         value = Integer.parseInt(nodeValue);
         if ((unsigned) && (value < 0))
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' cannot be negative in this context"));
         }
      }
      catch (NumberFormatException e)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid integer"));
      }
      return value;
   }

   /**
    * Method - getFloat - Get float from node
    *
    * @param node DOM node to retrieve float from
    * @return value float value
    */

   protected float getFloat(Node node)
   {
      float                   value;
      String                  nodeValue;


      value = 0.0f;
      nodeValue = node.getNodeValue();
      try
      {
         value = Float.parseFloat(nodeValue);
      }
      catch (NumberFormatException e)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid float"));
      }
      return value;
   }

   /**
    * Method - getDouble - Get double from node
    *
    * @param node DOM node to retrieve double from
    * @return value double value
    */

   protected double getDouble(Node node)
   {
      double                  value;
      String                  nodeValue;


      value = 0.0;
      nodeValue = node.getNodeValue();
      try
      {
         value = Double.parseDouble(nodeValue);
      }
      catch (NumberFormatException e)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid double"));
      }
      return value;
   }

   /**
    * Method - getString - Get string from node
    *
    * @param node DOM node to retrieve string from
    * @return value string value
    */

   protected String getString(Node node)
   {
      String                  value;


      value = node.getNodeValue();
      return value;
   }

   /**
    * Method - getString - Get string from node
    *
    * @param node DOM node to retrieve string from
    * @param minLength minimum length of string
    * @return value string value
    */

   protected String getString(Node node, int minLength)
   {
      String                  value;


      value = node.getNodeValue();
      if (value.length() < minLength)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + value + "' must be at least " + minLength + " characters in this context"));
      }
      return value;
   }

   /**
    * Method - getString - Get string from node
    *
    * @param node DOM node to retrieve string from
    * @param minLength minimum length of string
    * @param maxLength maximum length of string
    * @return value string value
    */

   protected String getString(Node node, int minLength, int maxLength)
   {
      String                  value;


      value = node.getNodeValue();
      if (value.length() < minLength)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + value + "' must be at least " + minLength + " characters in this context"));
      }
      else
      {
         if (value.length() > maxLength)
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + value + "' cannot exceed " + maxLength + " characters in this context"));
         }
      }
      return value;
   }

   /**
    * Method - getImage - Get image
    *
    * @param node DOM node to retrieve image name from
    * @return image the image specified by the node
    */

   protected Image getImage(Node node)
   {
      Image                   image;
      String                  nodeValue;


      image = null;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() >0)
      {
         image = m_context.getImage(nodeValue);
         if (image == null)
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The image '" + nodeValue + "' cannot be found"));
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid image name"));
      }
      return image;
   }

   /**
    * Method - getImageIcon - Get image icon
    *
    * @param node DOM node to retrieve image icon name from
    * @return image the image icon specified by the node
    */

   protected Icon getImageIcon(Node node)
   {
      ImageIcon               imageIcon;
      String                  nodeValue;


      imageIcon = null;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() >0)
      {
         imageIcon = m_context.getImageIcon(nodeValue);
         if (imageIcon == null)
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The image icon '" + nodeValue + "' cannot be found"));
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + node.getNodeName() + "' is not a valid image icon name"));
      }
      return imageIcon;
   }

   /**
    * Method - getX - Get X coordinate (either absolut or percentage of screen width)
    *
    * @param node DOM node to retrieve X coordinate from
    * @return x X coordinate
    */

   protected int getX(Node node)
   {
      int                     x;
      int                     percentage;
      String                  nodeValue;


      x = 0;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() > 0)
      {
         if (nodeValue.endsWith("%"))
         {
            try
            {
               percentage = Integer.parseInt(nodeValue.substring(0, nodeValue.indexOf("%")));
               if ((percentage >= 0) && (percentage <= 100))
               {
                  x = (Toolkit.getDefaultToolkit().getScreenSize().width * percentage) / 100;
               }
               else
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value " + nodeValue + "' must be between 0% and 100% inclusive"));
               }
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid percentage"));
            }
         }
         else
         {
            try
            {
               x = Integer.parseInt(nodeValue);
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid x coordinate"));
            }
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "No value specified for x coordinate attribute"));
      }
      return x;
   }


   /**
    * Method - getY - Get Y coordinate (either absolut or percentage of screen height)
    *
    * @param node DOM node to retrieve Y coordinate from
    * @return y Y coordinate
    */

   protected int getY(Node node)
   {
      int                     y;
      int                     percentage;
      String                  nodeValue;


      y = 0;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() > 0)
      {
         if (nodeValue.endsWith("%"))
         {
            try
            {
               percentage = Integer.parseInt(nodeValue.substring(0, nodeValue.indexOf("%")));
               if ((percentage >= 0) && (percentage <= 100))
               {
                  y = (Toolkit.getDefaultToolkit().getScreenSize().height * percentage) / 100;
               }
               else
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value " + nodeValue + "' must be between 0% and 100% inclusive"));
               }
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid percentage"));
            }
         }
         else
         {
            try
            {
               y = Integer.parseInt(nodeValue);
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid y coordinate"));
            }
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "No value specified for y coordinate attribute"));
      }
      return y;
   }


   /**
    * Method - getWidth - Get width (either absolut or percentage of screen width)
    *
    * @param node DOM node to retrieve width from
    * @return width width
    */

   protected int getWidth(Node node)
   {
      int                     width;
      int                     percentage;
      String                  nodeValue;


      width = 0;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() > 0)
      {
         if (nodeValue.endsWith("%"))
         {
            try
            {
               percentage = Integer.parseInt(nodeValue.substring(0, nodeValue.indexOf("%")));
               if ((percentage >= 0) && (percentage <= 100))
               {
                  width = (Toolkit.getDefaultToolkit().getScreenSize().width * percentage) / 100;
               }
               else
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value " + nodeValue + "' must be between 0% and 100% inclusive"));
               }
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid percentage"));
            }
         }
         else
         {
            try
            {
               width = Integer.parseInt(nodeValue);
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid width"));
            }
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "No value specified for width attribute"));
      }
      return width;
   }

   /**
    * Method - getHeight - Get height (either absolut or percentage of screen height)
    *
    * @param node DOM node to retrieve height from
    * @return height height
    */

   protected int getHeight(Node node)
   {
      int                     height;
      int                     percentage;
      String                  nodeValue;


      height = 0;
      nodeValue = node.getNodeValue();
      if (nodeValue.length() > 0)
      {
         if (nodeValue.endsWith("%"))
         {
            try
            {
               percentage = Integer.parseInt(nodeValue.substring(0, nodeValue.indexOf("%")));
               if ((percentage >= 0) && (percentage <= 100))
               {
                  height = (Toolkit.getDefaultToolkit().getScreenSize().height * percentage) / 100;
               }
               else
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value " + nodeValue + "' must be between 0% and 100% inclusive"));
               }
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid percentage"));
            }
         }
         else
         {
            try
            {
               height = Integer.parseInt(nodeValue);
            }
            catch (NumberFormatException e)
            {
               m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The value '" + nodeValue + "' is not a valid height"));
            }
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "No value specified for height attribute"));
      }
      return height;
   }

   /**
    * Method - getAccelerator - Get accelerator key stroke
    *
    * @param node DOM node to retrieve accelerator from
    * @return keyStroke the accelerator
    */

   protected KeyStroke getAccelerator(Node node)
   {
      KeyStroke               keyStroke;
      String                  nodeValue;


      nodeValue = node.getNodeValue();
      keyStroke = XwingMLKeyStroke.getKeyStroke(nodeValue);
      if (keyStroke == null)
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "No value specified for accelerator attribute"));
      }
      else
      {
         if (keyStroke.getKeyCode() == KeyEvent.VK_UNDEFINED)
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The accelerator '" + nodeValue + "' is unknown or incorrect format"));
         }
      }
      return keyStroke;
   }

   /**
    * Method - getInsets - Get insets
    *
    * @param node the DOM node to retrieve insets from
    * @return insets the insets retrieved from the node
    */

   protected Insets getInsets(Node node)
   {
      Insets                  insets;
      String                  nodeValue;
      StringTokenizer         stringTokenizer;
      String                  token;
      int                     insetValues[] = {0, 0, 0, 0};
      int                     i;


      
      nodeValue = node.getNodeValue().trim();
      if ((nodeValue.startsWith("(")) && (nodeValue.endsWith(")")))
      {
         stringTokenizer = new StringTokenizer(nodeValue.substring(1, nodeValue.indexOf(")")), ",");
         if (stringTokenizer.countTokens() == 4)
         {
            for (i = 0; i < 4; i++)
            {
               token = stringTokenizer.nextToken().trim();
               try
               {
                  insetValues[i] = Integer.parseInt(token);
               }
               catch (NumberFormatException e)
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The inset value '" + token + "' is not a valid inset value"));
               }
            }
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The insets '" + nodeValue + "' must contain 4 values"));
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The insets '" + nodeValue + "' are not valid"));
      }
      insets = new Insets(insetValues[0], insetValues[1], insetValues[2], insetValues[3]);
      return insets;
   }

   /**
    * Method - getDimension - Get dimension
    *
    * @param node the DOM node to retrieve dimension from
    * @return dimension the dimension retrieved from the node
    */

   protected Dimension getDimension(Node node)
   {
      Dimension               dimension;
      String                  nodeValue;
      StringTokenizer         stringTokenizer;
      String                  token;
      int                     dimensionValues[] = {0, 0};
      int                     i;


      
      nodeValue = node.getNodeValue().trim();
      if ((nodeValue.startsWith("(")) && (nodeValue.endsWith(")")))
      {
         stringTokenizer = new StringTokenizer(nodeValue.substring(1, nodeValue.indexOf(")")), ",");
         if (stringTokenizer.countTokens() == 2)
         {
            for (i = 0; i < 2; i++)
            {
               token = stringTokenizer.nextToken().trim();
               try
               {
                  dimensionValues[i] = Integer.parseInt(token);
               }
               catch (NumberFormatException e)
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The dimension value '" + token + "' is not a valid dimension value"));
               }
            }
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The dimension '" + nodeValue + "' must contain 2 values"));
         }
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The dimension '" + nodeValue + "' is not valid"));
      }
      dimension = new Dimension(dimensionValues[0], dimensionValues[1]);
      return dimension;
   }

   /**
    * Method - getColor - Get color
    *
    * @param node the DOM node to retrieve the color from
    * @return color the color retrieved from the node
    */

   protected Color getColor(Node node)
   {
      Color                   color;
      String                  nodeValue;
      StringTokenizer         stringTokenizer;
      String                  token;
      int                     rgbValues[];
      int                     i;


      color = Color.white;
      nodeValue = node.getNodeValue();
      if ((nodeValue.startsWith("(")) && (nodeValue.endsWith(")")))
      {
         stringTokenizer = new StringTokenizer(nodeValue.substring(1, nodeValue.indexOf(")")), ",");
         if (stringTokenizer.countTokens() == 3)
         {
            rgbValues = new int[3];
            for (i = 0; i < 3; i++)
            {
               token = stringTokenizer.nextToken().trim();
               try
               {
                  rgbValues[i] = Integer.parseInt(token);
               }
               catch (NumberFormatException e)
               {
                  m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The RGB value '" + token + "' is not a valid RGB value"));
               }
            }
            color = new Color(rgbValues[0], rgbValues[1], rgbValues[2]);
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The RGB color '" + nodeValue + "' must contain 3 values"));
         }
      }
      else
      {
         if (nodeValue.equals("black"))
         {
            color = Color.black;
         }
         else if (nodeValue.equals("blue"))
         {
            color = Color.blue;
         }
         else if (nodeValue.equals("cyan"))
         {
            color = Color.cyan;
         }
         else if (nodeValue.equals("darkGray"))
         {
            color = Color.darkGray;
         }
         else if (nodeValue.equals("gray"))
         {
            color = Color.gray;
         }
         else if (nodeValue.equals("green"))
         {
            color = Color.green;
         }
         else if (nodeValue.equals("lightGray"))
         {
            color = Color.lightGray;
         }
         else if (nodeValue.equals("magenta"))
         {
            color = Color.magenta;
         }
         else if (nodeValue.equals("orange"))
         {
            color = Color.orange;
         }
         else if (nodeValue.equals("pink"))
         {
            color = Color.pink;
         }
         else if (nodeValue.equals("red"))
         {
            color = Color.red;
         }
         else if (nodeValue.equals("white"))
         {
            color = Color.white;
         }
         else if (nodeValue.equals("yellow"))
         {
            color = Color.yellow;
         }
         else
         {
            m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The color '" + nodeValue + "' is unknown"));
         }
      }
      return color;
   }

   /**
    * Method - getOrientation - Get orientation
    *
    * @param node the DOM node to retrieve the orientation from
    * @return orientation the orientation retrieved from the node
    */

   protected int getOrientation(Node node)
   {
      int                     orientation;
      String                  nodeValue;


      orientation = SwingConstants.HORIZONTAL;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("HORIZONTAL"))
      {
         orientation = SwingConstants.HORIZONTAL;
      }
      else if (nodeValue.equals("VERTICAL"))
      {
         orientation = SwingConstants.VERTICAL;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The orientation '" + nodeValue + "' is unknown"));
      }
      return orientation;
   }

   /**
    * Method - getTabPlacement - Get tab placement
    *
    * @param node the DOM node to retrieve the placement from
    * @return tabPlacement the tab placement retrieved from the node
    */

   protected int getTabPlacement(Node node)
   {
      int                     tabPlacement;
      String                  nodeValue;


      tabPlacement = JTabbedPane.TOP;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("TOP"))
      {
         tabPlacement = JTabbedPane.TOP;
      }
      else if (nodeValue.equals("BOTTOM"))
      {
         tabPlacement = JTabbedPane.BOTTOM;
      }
      else if (nodeValue.equals("LEFT"))
      {
         tabPlacement = JTabbedPane.LEFT;
      }
      else if (nodeValue.equals("RIGHT"))
      {
         tabPlacement = JTabbedPane.RIGHT;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The tab placement '" + nodeValue + "' is unknown"));
      }
      return tabPlacement;
   }

   /**
    * Method - getHorizontalAlignment - Get horizontal alignment
    *
    * @param node the DOM node to retrieve the alignment from
    * @return horizontalAlignment the horizontal alignment retrieved from the node
    */

   protected int getHorizontalAlignment(Node node)
   {
      int                     horizontalAlignment;
      String                  nodeValue;


      horizontalAlignment = SwingConstants.LEFT;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("LEFT"))
      {
         horizontalAlignment = SwingConstants.LEFT;
      }
      else if (nodeValue.equals("CENTER"))
      {
         horizontalAlignment = SwingConstants.CENTER;
      }
      else if (nodeValue.equals("RIGHT"))
      {
         horizontalAlignment = SwingConstants.RIGHT;
      }
      else if (nodeValue.equals("LEADING"))
      {
         horizontalAlignment = SwingConstants.LEADING;
      }
      else if (nodeValue.equals("TRAILING"))
      {
         horizontalAlignment = SwingConstants.TRAILING;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The horizontal alignment '" + nodeValue + "' is unknown"));
      }
      return horizontalAlignment;
   }

   /**
    * Method - getHorizontalTextPosition - Get horizontal text position
    *
    * @param node the DOM node to retrieve the text position from
    * @return horizontalAlignment the horizontal alignment retrieved from the node
    */

   protected int getHorizontalTextPosition(Node node)
   {
      int                     horizontalTextPosition;
      String                  nodeValue;


      horizontalTextPosition = SwingConstants.LEFT;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("LEFT"))
      {
         horizontalTextPosition = SwingConstants.LEFT;
      }
      else if (nodeValue.equals("CENTER"))
      {
         horizontalTextPosition = SwingConstants.CENTER;
      }
      else if (nodeValue.equals("RIGHT"))
      {
         horizontalTextPosition = SwingConstants.RIGHT;
      }
      else if (nodeValue.equals("LEADING"))
      {
         horizontalTextPosition = SwingConstants.LEADING;
      }
      else if (nodeValue.equals("TRAILING"))
      {
         horizontalTextPosition = SwingConstants.TRAILING;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The horizontal text position '" + nodeValue + "' is unknown"));
      }
      return horizontalTextPosition;
   }

   /**
    * Method - getVerticalAlignment - Get vertical alignment
    *
    * @param node the DOM node to retrieve the alignment from
    * @return verticalAlignment the vertical alignment retrieved from the node
    */

   protected int getVerticalAlignment(Node node)
   {
      int                     verticalAlignment;
      String                  nodeValue;


      verticalAlignment = SwingConstants.TOP;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("TOP"))
      {
         verticalAlignment = SwingConstants.TOP;
      }
      else if (nodeValue.equals("CENTER"))
      {
         verticalAlignment = SwingConstants.CENTER;
      }
      else if (nodeValue.equals("BOTTOM"))
      {
         verticalAlignment = SwingConstants.BOTTOM;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The vertical alignment '" + nodeValue + "' is unknown"));
      }
      return verticalAlignment;
   }

   /**
    * Method - getVerticalTextPosition - Get vertical text position
    *
    * @param node the DOM node to retrieve the text position from
    * @return verticalAlignment the vertical alignment retrieved from the node
    */

   protected int getVerticalTextPosition(Node node)
   {
      int                     verticalTextPosition;
      String                  nodeValue;


      verticalTextPosition = SwingConstants.TOP;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("TOP"))
      {
         verticalTextPosition = SwingConstants.TOP;
      }
      else if (nodeValue.equals("CENTER"))
      {
         verticalTextPosition = SwingConstants.CENTER;
      }
      else if (nodeValue.equals("BOTTOM"))
      {
         verticalTextPosition = SwingConstants.BOTTOM;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The vertical text position '" + nodeValue + "' is unknown"));
      }
      return verticalTextPosition;
   }

   /**
    * Method - getLayoutAlignment - Get layout alignment
    *
    * @param node the DOM node to retrieve the alignment from
    * @return layoutAlignment the layout alignment retrieved from the node
    */

   protected int getLayoutAlignment(Node node)
   {
      int                     layoutAlignment;
      String                  nodeValue;


      layoutAlignment = FlowLayout.LEFT;
      nodeValue = node.getNodeValue();
      if (nodeValue.equals("LEFT"))
      {
         layoutAlignment = FlowLayout.LEFT;
      }
      else if (nodeValue.equals("CENTER"))
      {
         layoutAlignment = FlowLayout.CENTER;
      }
      else if (nodeValue.equals("RIGHT"))
      {
         layoutAlignment = FlowLayout.RIGHT;
      }
      else if (nodeValue.equals("LEADING"))
      {
         layoutAlignment = FlowLayout.LEADING;
      }
      else if (nodeValue.equals("TRAILING"))
      {
         layoutAlignment = FlowLayout.TRAILING;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The layout alignment '" + nodeValue + "' is unknown"));
      }
      return layoutAlignment;
   }

   /**
    * Method - createInstance - Create instance of class
    *
    * @param node the DOM node to retrieve class name from
    * @param compatibleClass class which this instance must be compatible with
    * @return instance the requested instance or null if it could not be created or isn't compatible with the class
    */

   protected Object createInstance(Node node, Class compatibleClass)
   {
      Object                  instance;
      String                  className;
      Class                   instanceClass;


      instance = null;
      className = node.getNodeValue();
      if (className.length() > 0)
      {
         if (!className.equals("null"))
         {
            instance = m_context.getClassInstance(className);
            if (instance != null)
            {
               if (!compatibleClass.isInstance(instance))
               {
                  m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' is not assignment compatible with '" + compatibleClass.getName() + "'"));
                  instance = null;
               }  
            }
            else
            {
               try
               {
                  instanceClass = Class.forName(className);
                  try
                  {
                     instance = instanceClass.newInstance();
                     if (!compatibleClass.isInstance(instance))
                     {
                        m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' is not assignment compatible with '" + compatibleClass.getName() + "'"));
                        instance = null;
                     }
                     else
                     {
                        if (instance instanceof XwingMLIPlugIn)
                        {
                           ((XwingMLIPlugIn)instance).setContext(m_context);
                        }
                     }
                  }
                  catch (Throwable t)
                  {
                     m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' could not be instantiated"));
                  }
               }
               catch (ClassNotFoundException e)
               {
                  m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' could not be found"));
               }
            }
         }
      }
      else
      {
         m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class name must be specified"));
      }
      return instance;
   }
}