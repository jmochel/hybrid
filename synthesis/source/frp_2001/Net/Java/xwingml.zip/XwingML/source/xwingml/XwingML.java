/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.filechooser.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;

/**
 * Class - XwingML - Main XwingML class
 */

public class XwingML
{
   protected XwingMLIContext        m_context;
   protected XwingMLActionListener  m_actionListener;
   protected XwingMLChangeListener  m_changeListener;
   protected XwingMLListener        m_xwingmlListener;
   protected XwingMLParserListener  m_parserListener;
   protected XwingMLWindowListener  m_windowListener;
   protected JFrame                 m_frame;
   protected JPanel                 m_defaultPanel;
   protected JComponent             m_component;
   protected JTextArea              m_textArea;
   protected String                 m_fileName;
   protected XwingMLAboutBox        m_aboutBox;


   /**
    * Method - main - main method of XwingML
    *
    * @param args string array of arguments from command line (should be the name of the .xml file for XwingML)
    */

   public static void main(String args[])
   {
      new XwingML(args);
   }

   /**
    * Constructor - XwingML
    *
    * @param args string array of args passed from main
    */

   public XwingML(String args[])
   {
      Component               component;
      String                  version;
      JDialog                 dialog;
      JInternalFrame          internalFrame;


      version = System.getProperty("java.version");
      if (version.compareTo("1.2") < 0)
      {
         System.out.println("Sorry, XwingML requires at least Java 1.2");
         System.exit(0);
      }
      m_context = createDefaultContext();
      m_xwingmlListener = new XwingMLListener();
      m_parserListener = new XwingMLParserListener();
      if (args != null)
      {
         m_component = null;
         component = null;
         m_actionListener = new XwingMLActionListener();
         m_changeListener = new XwingMLChangeListener();
         m_windowListener = new XwingMLWindowListener();
         m_context.addXwingMLListener(m_xwingmlListener);
         if (args.length > 0)
         {
            component = createComponentFromXML(m_context.getXMLFile(args[0]));
            if (component == null)
            {
               System.out.println("No component returned");
            }
         }
         if (component instanceof JFrame)
         {
            m_frame = (JFrame)component;
         }
         else
         {
            m_frame = createDefaultFrame();
         }
         m_frame.addWindowListener(m_windowListener);
         m_frame.show();
         if (component != null)
         {
            if (component instanceof JDialog)
            {
               dialog = (JDialog)component;
               dialog.show();
            }
            else if (component instanceof JInternalFrame)
            {
               internalFrame = (JInternalFrame)component;
               m_frame.getLayeredPane().add(internalFrame, JLayeredPane.MODAL_LAYER);
            }
            else if (component instanceof JComponent)
            {
               m_component = (JComponent)component;
               if (m_defaultPanel != null)
               {
                  m_frame.getContentPane().remove(m_defaultPanel);
               }
               m_frame.getContentPane().add(m_component, BorderLayout.CENTER);
               m_frame.getContentPane().validate();
            }
         }
      }
   }

   /**
    * Constructor - XwingML
    */

   public XwingML()
   {
      this(null);
   }

   /**
    * Method - createComponentFromXML - Create a Swing component from an XML string
    *
    * @param fileName XML file name (used by XML parser)
    * @param xml string containing XML
    * @param parentFrame frame to be assigned as parent of e.g. JDialog or JInternalFrame
    * @return component component created by XwingML or null if component could not be created
    */

   public Component createComponentFromXML(String fileName, String xml, JFrame parentFrame)
   {
      Component               component;
      XMLIParser              parser;
      Document                document;
      Element                 documentElement;
      NodeList                childNodes;
      Node                    node;
      String                  nodeName;
      XwingMLIObject          xmlObject;
      boolean                 result;
      int                     i;



      component = null;
      xmlObject = null;
      parser = m_context.getParser();
      if (parser != null)
      {
         parser.addParserListener(m_parserListener);
         document = parser.parse(fileName, xml);
         if (document != null)
         {
            if (parser.getParserErrors() == 0)
            {
               documentElement = document.getDocumentElement();
               if (documentElement.getNodeName().equals("XwingML"))
               {
                  childNodes = documentElement.getChildNodes();
                  if (childNodes != null)
                  {
                     result = true;
                     for (i = 0; (i < childNodes.getLength()) && (result); i++)
                     {
                        node = childNodes.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE)
                        {
                           nodeName = node.getNodeName();
                           if (nodeName.equals("Defaults"))
                           {
                              result = handleDefaults(node);
                           }
                           else if (nodeName.equals("Classes"))
                           {
                              result = handleClasses(node);
                           }
                           else
                           {
                              xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
                           }
                           if (xmlObject != null)
                           {
                              if (xmlObject instanceof XwingMLComponent)
                              {
                                 if (parentFrame != null)
                                 {
                                    xmlObject.setParent(parentFrame);
                                 }
                                 else if (m_frame != null)
                                 {
                                    xmlObject.setParent(m_frame);
                                 }
                                 result = xmlObject.buildObject();
                                 if (result)
                                 {
                                    component = ((XwingMLComponent)xmlObject).getComponent();
                                    if ((component instanceof JFrame) || (component instanceof JDialog) || (component instanceof JWindow))
                                    {
                                       ((Window)component).addWindowListener(m_context);
                                    }
                                    else if (component instanceof JInternalFrame)
                                    {
                                       ((JInternalFrame)component).addInternalFrameListener(m_context);
                                    }
                                 }
                              }
                              else
                              {
                                 System.out.println("Unexpected component type in XML file");
                              }
                           }
                        }
                     }
                  }
                  else
                  {
                     System.out.println("No child nodes");
                  }
               }
               else
               {
                  System.out.println("Not a valid XwingML XML file");
               }
            }
         }
         else
         {
            System.out.println("Could not obtain document");
         }
      }
      else
      {
         System.out.println("Could not obtain parser");
      }
      return component;
   }

   /**
    * Method - createComponentFromXML - Create a Swing component from an XML string
    *
    * @param fileName XML file name (used by XML parser)
    * @param xml string containing XML
    * @return component component created by XwingML or null if component could not be created
    */

   public Component createComponentFromXML(String fileName, String xml)
   {
      return createComponentFromXML(fileName, xml, null);
   }

   /**
    * Method - createComponentFromXML - Create a Swing component from an XML string
    *
    * @param fileName XML file name
    * @param parentFrame frame to be assigned as parent of e.g. JDialog or JInternalFrame
    * @return component component created by XwingML or null if component could not be created
    */

   public Component createComponentFromXML(File xmlFile, JFrame parentFrame)
   {
      Component               component;
      int                     xmlBufferLength;
      byte                    xmlBuffer[];
      BufferedInputStream     xmlInputStream;


      component = null;
      if ((xmlFile.exists()) && (xmlFile.isFile()))
      {
         xmlBufferLength = (int)xmlFile.length();
         if (xmlBufferLength > 0)
         {
            xmlBuffer = new byte[xmlBufferLength];
            try
            {
               xmlInputStream = new BufferedInputStream(new FileInputStream(xmlFile));
               xmlInputStream.read(xmlBuffer, 0, xmlBufferLength);
               xmlInputStream.close();
               component = createComponentFromXML(xmlFile.getName(), new String(xmlBuffer), parentFrame);
            }
            catch (Throwable t)
            {
            }
         }
      }
      return component;
   }

   /**
    * Method - createComponentFromXML - Create a Swing component from an XML string
    *
    * @param fileName XML file name
    * @return component component created by XwingML or null if component could not be created
    */

   public Component createComponentFromXML(File xmlFile)
   {
      return createComponentFromXML(xmlFile, null);
   }

   /**
    * Method - handleDefaults - Handle Defaults tag of XwingML .xml file
    *
    * @param node DOM node containing Defaults tag
    * @return result true/false depending on whether the node could be handled successfully or not
    */

   protected boolean handleDefaults(Node node)
   {
      boolean                 result;
      NodeList                childNodes;
      NamedNodeMap            attributes;
      String                  path;
      int                     i;


      result = true;
      childNodes = node.getChildNodes();
      if (childNodes != null)
      {
         for (i = 0; i < childNodes.getLength(); i++)
         {
            node = childNodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE)
            {
               if (node.getNodeName().equals("ResourceDirectory"))
               {
                  attributes = node.getAttributes();
                  node = attributes.getNamedItem("path");
                  if (node != null)
                  {
                     path = node.getNodeValue();
                     if (path.length() > 0)
                     {
                        if (System.getProperty("file.separator").equals("/"))
                        {
                           if (path.length() >= 2)
                           {
                              if (path.charAt(1) == ':')
                              {
                                 path = path.substring(2);
                              }
                           }
                           path = path.replace('\\', '/');
                           if (!path.endsWith("/"))
                           {
                              path += '/';
                           }
                        }
                        else
                        {
                           path = path.replace('/', '\\');
                           if (!path.endsWith("\\"))
                           {
                              path += "\\";
                           }
                        }
                        m_context.addResourceDirectory(path);
                     }
                  }
               }
               else if (node.getNodeName().equals("XMLDirectory"))
               {
                  attributes = node.getAttributes();
                  node = attributes.getNamedItem("path");
                  if (node != null)
                  {
                     path = node.getNodeValue();
                     if (path.length() > 0)
                     {
                        if (System.getProperty("file.separator").equals("/"))
                        {
                           if (path.length() >= 2)
                           {
                              if (path.charAt(1) == ':')
                              {
                                 path = path.substring(2);
                              }
                           }
                           path = path.replace('\\', '/');
                           if (!path.endsWith("/"))
                           {
                              path += '/';
                           }
                        }
                        else
                        {
                           path = path.replace('/', '\\');
                           if (!path.endsWith("\\"))
                           {
                              path += "\\";
                           }
                        }
                        m_context.addXMLDirectory(path);
                     }
                  }
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - handleClasses - Handle Classes tag of XwingML .xml file
    *
    * @param node DOM node containing Classes tag
    * @return result true/false depending on whether the node could be handled successfully or not
    */

   protected boolean handleClasses(Node node)
   {
      boolean                 result;
      NodeList                childNodes;
      NamedNodeMap            attributes;
      String                  name;
      String                  className;
      Class                   instanceClass;
      Object                  instance;
      int                     i;


      result = true;
      childNodes = node.getChildNodes();
      if (childNodes != null)
      {
         for (i = 0; (i < childNodes.getLength()) && (result); i++)
         {
            node = childNodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE)
            {
               if (node.getNodeName().equals("Instance"))
               {
                  attributes = node.getAttributes();
                  node = attributes.getNamedItem("name");
                  if (node != null)
                  {
                     name = node.getNodeValue();
                     node = attributes.getNamedItem("className");
                     if (node != null)
                     {
                        className = node.getNodeValue();
                        try
                        {
                           instanceClass = Class.forName(className);
                           try
                           {
                              instance = instanceClass.newInstance();
                              if (instance instanceof XwingMLIPlugIn)
                              {
                                 ((XwingMLIPlugIn)instance).setContext(m_context);
                              }
                              m_context.addClassInstance(name, instance);
                           }
                           catch (Throwable t)
                           {
                              m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' could not be instantiated"));
                              result = false;
                           }
                        }
                        catch (ClassNotFoundException e)
                        {
                           m_context.fireXwingMLError(new XwingMLErrorEvent(node, "The class '" + className + "' was not found"));
                           result = false;
                        }
                     }
                     else
                     {
                        m_context.fireXwingMLError(new XwingMLErrorEvent(node, "Required 'className' attribute missing for Instance node"));
                        result = false;
                     }
                  }
                  else
                  {
                     m_context.fireXwingMLError(new XwingMLErrorEvent(node, "Required 'name' attribute missing for Instance node"));
                     result = false;
                  }
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - createDefaultFrame - Create default XwingML frame (the default frame is used as parent for a JDialog or JInternalFrame and is also
    * shown if no .xml file is passed in or if no component can be created from it).
    *
    * @return frame the default frame
    */

   public JFrame createDefaultFrame()
   {
      JFrame                  frame;
      Dimension               screenSize;


      screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      frame = new JFrame("Bluestone XwingML");
      frame.setIconImage(m_context.getImage("icon.gif"));
      frame.setJMenuBar(createDefaultMenuBar());
      frame.getContentPane().add(createDefaultToolBar(), BorderLayout.NORTH);
      m_defaultPanel = createDefaultPanel();
      frame.getContentPane().add(m_defaultPanel, BorderLayout.CENTER);
      frame.getContentPane().add(createDefaultMessageBar(), BorderLayout.SOUTH);
      frame.setLocation(new Point(screenSize.width / 10, screenSize.height / 10));
      frame.setSize(new Dimension((screenSize.width * 8) / 10, (screenSize.height * 8) / 10));
      return frame;
   }

   /**
    * Method - createDefaultMenuBar - Create default XwingML menu bar
    *
    * @return menuBar the default menu bar
    */

   public JMenuBar createDefaultMenuBar()
   {
      JMenuBar                menuBar;
      JMenu                   menu;
      JMenuItem               menuItem;


      menuBar = new JMenuBar();
      menu = new JMenu("File");
      menu.setMnemonic('F');
      menuItem = new JMenuItem("Open...", 'O');
      menuItem.addChangeListener(m_changeListener);
      menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_MASK));
      menuItem.setToolTipText("Open XwingML XML Document");
      menuItem.setActionCommand("file/open");
      menuItem.addActionListener(m_actionListener);
      menu.add(menuItem);
      menu.addSeparator();
      menuItem = new JMenuItem("Exit", 'x');
      menuItem.addChangeListener(m_changeListener);
      menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.CTRL_MASK));
      menuItem.setToolTipText("Exit XwingML");
      menuItem.setActionCommand("file/exit");
      menuItem.addActionListener(m_actionListener);
      menu.add(menuItem);
      menuBar.add(menu);
      menu = new JMenu("Tools");
      menu.setMnemonic('T');
      menuItem = new JMenuItem("Parse", 'P');
      menuItem.addChangeListener(m_changeListener);
      menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.CTRL_MASK));
      menuItem.setToolTipText("Open XwingML XML Document and execute GUI");
      menuItem.setActionCommand("tools/parse");
      menuItem.addActionListener(m_actionListener);
      menu.add(menuItem);
      menu.addSeparator();
      menuItem = new JMenuItem("Generate code", 'G');
      menuItem.addChangeListener(m_changeListener);
      menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, KeyEvent.CTRL_MASK));
      menuItem.setToolTipText("Generate Java source code from XwingML XML Document");
      menuItem.setActionCommand("tools/generate");
      menuItem.addActionListener(m_actionListener);
      menu.add(menuItem);
      menuBar.add(menu);
      menuBar.add(menu);
      menu = new JMenu("Help");
      menu.setMnemonic('H');
      menuItem = new JMenuItem("About XwingML...", 'A');
      menuItem.addChangeListener(m_changeListener);
      menuItem.setToolTipText("Show XwingML about box");
      menuItem.setActionCommand("help/about");
      menuItem.addActionListener(m_actionListener);
      menu.add(menuItem);
      menuBar.add(menu);
      return menuBar;
   }

   /**
    * Method - createDefaultToolBar - Create default XwingML tool bar
    *
    * @return toolBar the default tool bar
    */

   public JToolBar createDefaultToolBar()
   {
      JToolBar                toolBar;
      JButton                 button;


      toolBar = new JToolBar();
      toolBar.setFloatable(true);
      button = new JButton(m_context.getImageIcon("open.gif"));
      button.setActionCommand("file/open");
      button.setToolTipText("Open XwingML XML Document");
      button.addActionListener(m_actionListener);
      toolBar.add(button);
      button = new JButton(m_context.getImageIcon("parse.gif"));
      button.setActionCommand("tools/parse");
      button.setToolTipText("Open XwingML XML Document and execute GUI");
      button.addActionListener(m_actionListener);
      toolBar.add(button);
      button = new JButton(m_context.getImageIcon("generate.gif"));
      button.setActionCommand("tools/generate");
      button.setToolTipText("Generate Java source code from XwingML XML Document");
      button.addActionListener(m_actionListener);
      toolBar.add(button);
      toolBar.addSeparator();
      button = new JButton(m_context.getImageIcon("about.gif"));
      button.setActionCommand("help/about");
      button.setToolTipText("Show XwingML about box");
      button.addActionListener(m_actionListener);
      toolBar.add(button);
      return toolBar;
   }

   /**
    * Method - createDefaultPanel - Create default XwingML panel
    *
    * @return panel the default panel
    */

   public JPanel createDefaultPanel()
   {
      JPanel                  panel;
      JScrollPane             scrollPane;


      panel = new JPanel();
      panel.setBackground(Color.white);
      m_textArea = new JTextArea();
      m_textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
      m_textArea.setMargin(new Insets(8, 8, 8, 8));
      m_textArea.setLineWrap(false);
      m_textArea.setTabSize(3);
      m_textArea.setEditable(false);
      panel.setLayout(new BorderLayout());
      panel.add(new JScrollPane(m_textArea), BorderLayout.CENTER);
      return panel;
   }

   /**
    * Method - createDefaultMessageBar - Create default XwingML message bar
    *
    * @return messageBar the default message bar
    */

   public JToolBar createDefaultMessageBar()
   {
      JToolBar                messageBar;
      JLabel                  label;


      messageBar = new JToolBar();
      messageBar.setFloatable(false);
      label = new JLabel(" ");
      messageBar.add(label);
      m_changeListener.setLabel(label);
      return messageBar;
   }

   /**
    * Method - createDefaultContext - Create default XwingML context
    *
    * @return context the default XwingML context
    */

   public XwingMLIContext createDefaultContext()
   {
      return new XwingMLContext(this);
   }

   /**
    * Method - getContext - Get context
    *
    * @return context the XwingML context
    */

   public XwingMLIContext getContext()
   {
      return m_context;
   }

   /**
    * Class - XwingMLActionListener
    */

   class XwingMLActionListener implements ActionListener
   {
      /**
       * Method - actionPerformed - Action performed
       *
       * @param evt an ActionEvent instance
       */

      public void actionPerformed(ActionEvent evt)
      {
         String               actionCommand;
         JFileChooser         fileChooser;
         XwingMLFileFilter    fileFilter;
         File                 file;
         int                  option;
         int                  xmlBufferLength;
         byte                 xmlBuffer[];
         BufferedInputStream  xmlInputStream;
         String               xml;
         Component            component;
         JFrame               frame;
         JDialog              dialog;
         JInternalFrame       internalFrame;


         actionCommand = evt.getActionCommand();
         if (actionCommand.equals("file/open"))
         {
            fileChooser = new JFileChooser(System.getProperty("user.dir"));
            fileFilter = new XwingMLFileFilter();
            fileChooser.addChoosableFileFilter(fileFilter);
            fileChooser.setFileFilter(fileFilter);
            option = fileChooser.showOpenDialog(m_frame);
            if (option == JFileChooser.APPROVE_OPTION)
            {
               file = fileChooser.getSelectedFile();
               if (file.isFile())
               {
                  if (file.getName().endsWith(".xml"))
                  {
                     xmlBufferLength = (int)file.length();
                     if (xmlBufferLength > 0)
                     {
                        xmlBuffer = new byte[xmlBufferLength];
                        try
                        {
                           xmlInputStream = new BufferedInputStream(new FileInputStream(file));
                           xmlInputStream.read(xmlBuffer, 0, xmlBufferLength);
                           xmlInputStream.close();
                           m_fileName = file.getName();
                           m_frame.setTitle("Bluestone XwingML - " + m_fileName);
                           m_textArea.setText(new String(xmlBuffer));
                           if (!m_frame.getContentPane().isAncestorOf(m_defaultPanel))
                           {
                              if (m_component != null)
                              {
                                 m_frame.getContentPane().remove(m_component);
                                 m_component = null;
                              }
                              m_frame.getContentPane().add(m_defaultPanel, BorderLayout.CENTER);
                              m_frame.getContentPane().validate();
                           }
                        }
                        catch (Throwable t)
                        {
                        }
                     }
                     else
                     {
                        JOptionPane.showMessageDialog(m_frame, "The selected file is empty", "Empty file", JOptionPane.ERROR_MESSAGE);
                     }
                  }
                  else
                  {
                     JOptionPane.showMessageDialog(m_frame, "The selected file must be a .xml file", "Invalid file type", JOptionPane.ERROR_MESSAGE);
                  }
               }
               else
               {
                  JOptionPane.showMessageDialog(m_frame, "The selected file cannot be a directory", "Invalid file", JOptionPane.ERROR_MESSAGE);
               }
            }
         }
         else if (actionCommand.equals("file/exit"))
         {
            System.exit(0);
         }
         else if (actionCommand.equals("tools/parse"))
         {
            xml = m_textArea.getText();
            if (xml.length() > 0)
            {
               component = createComponentFromXML(m_fileName, xml);
               if (component != null)
               {
                  if (component instanceof JFrame)
                  {
                     frame = (JFrame)component;
                     frame.show();
                  }
                  else if (component instanceof JDialog)
                  {
                     dialog = (JDialog)component;
                     dialog.show();
                  }
                  else if (component instanceof JInternalFrame)
                  {
                     internalFrame = (JInternalFrame)component;
                     m_frame.getLayeredPane().add(internalFrame, JLayeredPane.MODAL_LAYER);
                     try
                     {
                        internalFrame.setSelected(true);
                     }
                     catch (Throwable t)
                     {
                     }
                  }
                  else if (component instanceof JComponent)
                  {
                     m_component = (JComponent)component;
                     m_frame.getContentPane().remove(m_defaultPanel);
                     m_frame.getContentPane().add(m_component, BorderLayout.CENTER);
                     m_frame.getContentPane().validate();
                  }
               }
            }
         }
         else if (actionCommand.equals("tools/generate"))
         {
            JOptionPane.showMessageDialog(m_frame, "Sorry.  The ability to generate Java code is not part of the freeware version of XwingML", "Not supported", JOptionPane.INFORMATION_MESSAGE);
         }
         else if (actionCommand.equals("help/about"))
         {
            m_aboutBox = new XwingMLAboutBox(m_frame);
            m_aboutBox.show();
         }
         else if (actionCommand.equals("about/ok"))
         {
            m_aboutBox.dispose();
         }
      }
   }

   /**
    * Class - XwingMLChangeListener
    */

   class XwingMLChangeListener implements ChangeListener
   {
      protected JLabel        m_label;


      /**
       * Constructor - XwingMLChangeListener
       */

      public XwingMLChangeListener()
      {
         setLabel(null);
      }

      /**
       * Method - setLabel - Set label to show messages in message bar
       */

      public void setLabel(JLabel label)
      {
         m_label = label;
      }

      /**
       * Method - stateChanged - State changed
       *
       * @param evt ChangeEvent instance
       */

      public void stateChanged(ChangeEvent evt)
      {
         Object               source;
         JMenuItem            menuItem;


         source = evt.getSource();
         if (source instanceof JMenuItem)
         {
            menuItem = (JMenuItem)source;
            if (menuItem.isArmed())
            {
               m_label.setText(menuItem.getToolTipText());
            }
            else
            {
               m_label.setText(" ");
            }
         }
      }
   }

   class XwingMLListener implements XwingMLIListener
   {
      public void warningEncountered(XwingMLEvent evt)
      {
         System.out.println("XwingML Warning: " + evt.getMessage());
      }

      public void errorEncountered(XwingMLEvent evt)
      {
         System.out.println("XwingML Error: " + evt.getMessage());
      }
   }

   class XwingMLParserListener implements XMLIParserListener
   {
      public void parserError(String message)
      {
         System.out.println("Parser Error: " + message);
      }

      public void parserWarning(String message)
      {
         System.out.println("Parser Warning: " + message);
      }
   }

   /**
    * Class - XwingMLWindowListener
    */

   class XwingMLWindowListener extends WindowAdapter
   {
      /**
       * Method - windowClosing - Window closing
       *
       * @param evt WindowEvent instance
       */

      public void windowClosing(WindowEvent evt)
      {
         Window               win;


         win = evt.getWindow();
         win.setVisible(false);
         win.dispose();
         System.exit(0);
      }
   }

   /**
    * Class - XwingMLFileFilter
    */

   class XwingMLFileFilter extends javax.swing.filechooser.FileFilter
   {
      /**
       * Constructor - XwingMLFileFilter
       */

      public XwingMLFileFilter()
      {
         super();
      }

      /**
       * Method - accept - Accept file ?
       *
       * @param file the file we're asked to accept/reject
       * @return result true/false depending on whether the file is acepted or not
       */

      public boolean accept(File file)
      {
         boolean              result;


         if (file.isFile())
         {
            result = file.getName().endsWith(".xml");
         }
         else
         {
            result = true;
         }
         return result;
      }

      /**
       * Method - getDescription - Get file filter description
       *
       * return description "XwingML XML Files"
       */

      public String getDescription()
      {
         return "XwingML XML Files";
      }
   }

   /**
    * Class - XwingMLAboutBox
    */

   class XwingMLAboutBox extends JDialog
   {
      protected JFrame        m_frame;


      /**
       * Constructor - XwingMLAboutBox
       *
       * @param frame parent frame
       */

      public XwingMLAboutBox(JFrame frame)
      {
         super(frame, "About XwingML");


         Box                  box;
         JPanel               panel;
         JPanel               imagePanel;
         JLabel               label;
         JButton              button;



         setModal(true);
         setResizable(false);
         box = new Box(BoxLayout.Y_AXIS);
         panel = new JPanel();
         panel.setLayout(new BorderLayout());
         panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
         label = new JLabel("Bluestone XwingML 1.0");
         label.setHorizontalAlignment(SwingConstants.CENTER);
         panel.add(label, BorderLayout.NORTH);
         imagePanel = new JPanel();
         imagePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
         label = new JLabel(m_context.getImageIcon("XwingML.gif"));
         label.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
         imagePanel.add(label);
         panel.add(imagePanel, BorderLayout.CENTER);
         label = new JLabel("The power of Swing with the ease of XML");
         label.setHorizontalAlignment(SwingConstants.CENTER);
         panel.add(label, BorderLayout.SOUTH);
         box.add(panel);
         panel = new JPanel();
         panel.setLayout(new BorderLayout());
         panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
         label = new JLabel("From the home of Enterprise Interaction Management");
         label.setHorizontalAlignment(SwingConstants.CENTER);
         panel.add(label, BorderLayout.NORTH);
         imagePanel = new JPanel();
         imagePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
         label = new JLabel(m_context.getImageIcon("eim.gif"));
         label.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
         imagePanel.add(label);
         panel.add(imagePanel, BorderLayout.CENTER);
         label = new JLabel("Copyright � 1999 Bluestone Software, Inc.");
         label.setHorizontalAlignment(SwingConstants.CENTER);
         panel.add(label, BorderLayout.SOUTH);
         box.add(panel);
         panel = new JPanel();
         panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
         panel.setLayout(new FlowLayout(FlowLayout.CENTER));
         button = new JButton("OK");
         button.setActionCommand("about/ok");
         button.addActionListener(m_actionListener);
         panel.add(button);
         box.add(panel);
         getContentPane().add(box, BorderLayout.CENTER);
         pack();
      }

      /**
       * Method - show - Show dialog
       */

      public void show()
      {
         Dimension            screenSize;
         Dimension            dialogSize;


         screenSize = Toolkit.getDefaultToolkit().getScreenSize();
         dialogSize = getSize();
         setLocation(new Point((screenSize.width - dialogSize.width) / 2, (screenSize.height - dialogSize.height) / 2));
         super.show();
      }
   }
}
