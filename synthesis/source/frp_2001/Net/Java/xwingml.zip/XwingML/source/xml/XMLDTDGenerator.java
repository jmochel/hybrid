

package com.bluestone.xml;

import com.bluestone.debug.*;

import org.w3c.dom.*;

import java.util.*;
import java.io.File;
import java.io.Serializable;

/**
 * Given a well-formed xml file, generate a DTD under which it will validate.
 * 
 */
public class XMLDTDGenerator
{
    /**
     * Create a DTD for the given document. The generated DTD will
     * validate this document instance and a class of similar documents,
     * but not necesarily all documents of the given DOCTYPE.
     *
     * @param   document to document to create a DTD string for.
     * @return  DTDString a string that can be used as a DTD to validate the
     *             given document.
     */
    public static String makeValidDTD( Document document )
    {
        String ret = null;
        
        if ( document != null )
        {
            Element docElement = document.getDocumentElement();
            if ( docElement != null )
            {
                HashMap map = new HashMap();
                StringBuffer outBuf = new StringBuffer();
                
                addNode( docElement, map );
                
                if ( map != null && map.size() > 0 )
                {
                    Iterator elementKeys = map.keySet().iterator();
                    while( elementKeys.hasNext() )
                    {
                        ElementDef nextEle = (ElementDef) map.get( elementKeys.next() );
                        if ( nextEle == null )
                        {
                            continue;
                        }
                        outBuf.append( "\n" + nextEle.toString() );
                    }
                    ret = outBuf.toString();
                }
                else
                    Debug.showInformation( "makeValidDTD: no elements found." );
            }
            else
                Debug.showError( "makeValidDTD: error: null document element." );
        }
        
        return ret;
    }
    
    /**
     * Add a node's definition to the element database, or modify an existing
     * nodes definition according to this node instance.
     *
     * @param docNode           a node in the document
     * @param elementsMap       the current element database.
     * @return a string representation of a valid DTD for this NODE and its children.
     */
    private static void addNode( Node docNode, HashMap elementsMap )
    {
        ElementDef curElement = (ElementDef)elementsMap.get( docNode.getNodeName() );
        if ( curElement == null )
        {
            curElement = new ElementDef();
            curElement.nodeName = docNode.getNodeName();
            curElement.nodeType = docNode.getNodeType();
            curElement.hasText  = false;
            elementsMap.put( curElement.nodeName, curElement );
        }

        // add attributes
        NamedNodeMap attributes = docNode.getAttributes();
        if ( attributes != null && attributes.getLength() > 0 )
        {
            if ( curElement.attributes == null )
                curElement.attributes = new TreeSet();
            
            for ( int i = 0 ; i < attributes.getLength(); i ++ )
            {
                curElement.attributes.add( attributes.item( i ).getNodeName() );
            }
        }
                
        // add children
        NodeList children = docNode.getChildNodes();
        if ( children != null && children.getLength() > 0 )
        {
            if ( curElement.children == null )
                curElement.children = new TreeSet();

            for ( int i = 0; i < children.getLength(); i++ )
            {
                Node child = children.item( i );
                if ( child.getNodeType() == Node.ELEMENT_NODE )
                    curElement.children.add( child.getNodeName() );
                else
                    curElement.hasText = true;
            }
            
            // process children
            for ( int i = 0; i < children.getLength(); i ++ )
            {
                Node child = children.item( i );
                if ( child.getNodeType() == Node.ELEMENT_NODE )
                    addNode( children.item( i ), elementsMap );
            }
        }
    }

    /**
     * An entry in the element database.
     */
    static class ElementDef implements Serializable
    {
        public String           nodeName;
        public int              nodeType;
        public Set              attributes;
        public Set              children;
        public boolean          hasText;
        
        public String toString()
        {
            String ret = getElementDef();
            if ( attributes != null )
            {
                ret += "\n" ;
                ret += getAttList();
            }
            return ret;
        }

        public String getAttList()
        {
            StringBuffer buf = null;
            
            if ( attributes != null )
            {
                buf = new StringBuffer();
                buf.append( "<!ATTLIST " );
                buf.append( nodeName );
                buf.append( " " );

                Iterator it = attributes.iterator();
                while ( it.hasNext() )
                {
                    buf.append( "\n\t" );
                    buf.append( it.next() );
                    buf.append( " CDATA #IMPLIED" );
                }
                buf.append( " >" );
            }

            return buf != null ? buf.toString() : null ;
        }

        public String getElementDef()
        {
            StringBuffer buf = new StringBuffer();
            
            buf.append( "<!ELEMENT " );
            buf.append( nodeName );
            buf.append( " " );

            if ( children != null )
            {
                buf.append( "( " );

                // handle mixed content
                if ( hasText )
                {
                    buf.append( " #PCDATA | " );
                }

                // add children, disregard order
                Iterator elements = children.iterator();
                while ( elements.hasNext() )
                {
                    buf.append( (String)elements.next() );
                    if ( elements.hasNext() )
                        buf.append( " | " );
                }
                buf.append( " )*" );
            }
            else
            {
                // handle text/only nodes
                if ( hasText )
                    buf.append( " ( #PCDATA ) " );
                else
                    buf.append( " EMPTY " );
            }
            
            buf.append( " >" );
            
            return buf.toString();
        }
    }

    /** 
     * Hmm, wonder what this does...
     */
    static class ParserListener implements XMLIParserListener
    {
        /**
         * Log a parse warning as an error.
         *
         */
        public void parserWarning( String message )
        {
            parserError( message );
        }
	
        /**
         * Log a parse error and signal to Workspace that errors were
         * encountered.
         */
        public void parserError( String message )
        {
            System.err.println( message );
            m_parseErrors.addElement( message );
        }

        /**
         * Return and clear the errors encountered parsing the current workspace document.  
         *
         * @return a Vector of string error messages.
         */
        public String getParseErrors()
        {
            String retval = null;
            if ( m_parseErrors.size() > 0 )
            {
                StringBuffer errBuffer = new StringBuffer();
                for ( int i = 0; i < m_parseErrors.size(); i++ )
                {
                    errBuffer.append( m_parseErrors.elementAt( i ) );
                    errBuffer.append( "\n" );
                }
                m_parseErrors = null;
                retval = errBuffer.toString();
            }
            return retval;
        }
        
        protected Vector			m_parseErrors	= new Vector(3);
    }

    
    /**
     * test method
     */
    public static void main( String[] args ) throws Exception
    {
        File            xmlFile;

        if ( args.length < 1 )
            System.exit( -1 );
        
        xmlFile = new File( args[ 0 ] );
        if ( ! xmlFile.canRead() )
            System.exit( -2 );

        XMLIParser          parser;
        XMLIParserListener  parserListener;
        Document            document;
        
        parser = XMLParserFactory.makeIParser();
        parserListener = new ParserListener();

        document = parser.parse( xmlFile );
        if ( document != null )
        {
            System.out.println( makeValidDTD( document ) );
        }
        else
            System.err.println( "run: error: null document" );
    }
}
