/*-------------------------------------------------------------------------------------------------

   XML Generator v1.0  99/05/27

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the XML Generator software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xml;

import java.io.*;
import java.util.*;
import org.w3c.dom.*;
import com.ibm.xml.parser.*;


/**
 * Class - XMLGenerator - XML Generator
 */

public class XMLGenerator
{
   protected DTD              m_dtd;
   protected boolean          m_valid;
   protected boolean          m_templateText;
   protected boolean          m_dataSites;
   protected int              m_minRecurseLevel;
   protected int              m_maxRecurseLevel;
   protected int              m_minZeroOrMore;
   protected int              m_maxZeroOrMore;
   protected int              m_minOneOrMore;
   protected int              m_maxOneOrMore;
   protected int              m_minAny;
   protected int              m_maxAny;
   protected boolean          m_docTypeInAny;
   protected Random           m_random;
   protected int              m_idCount;


   /**
    * Method - main - Main
    *
    * @param args array of String arguments
    */

   public static void main(String args[])
   {
      String                  fileName;
      String                  elementName;
      XMLGenerator            xmlGenerator;
      


      if (args.length == 2)
      {
         fileName = args[0];
         elementName = args[1];
         xmlGenerator = new XMLGenerator(fileName);
         if (xmlGenerator.isValid())
         {
            if (xmlGenerator.isElementDeclared(elementName))
            {
               System.out.println("XML:\n" + xmlGenerator.generateXML(elementName));
            }
            else
            {
               System.out.println("The element name '" + elementName + "' is not defined in the DTD");
            }
         }
         else
         {
            System.out.println("The supplied DTD is not valid");
         }
      }
      else
      {
         System.out.println("Usage: XMLGenerator <fileName> <elementName>");
      }
   }

   /**
    * Constructor - XMLGenerator
    *
    * @param dtd a DTD instance to generate XML from
    */

   public XMLGenerator(DTD dtd)
   {
      initializeDefaults();
      setDTD(dtd);
   }

   /**
    * Constructor - XMLGenerator
    *
    * @param file a File instance pointing to an external DTD
    */

   public XMLGenerator(File file)
   {
      DTD                     dtd;
      Parser                  parser;
      int                     errors;


      initializeDefaults();
      dtd = null;
      if (file != null)
      {
         if (file.exists())
         {
            if (file.canRead())
            {
               try
               {
                  parser = new Parser(file.getName());
                  dtd = parser.readDTDStream(new FileReader(file));
                  if (dtd != null)
                  {
                     errors = parser.getNumberOfErrors();
                     if (errors == 0)
                     {
                        dtd.setExternalID(new ExternalID("file:///" + file.getAbsolutePath().replace('\\', '/')));
                     }
                     else
                     {
                        dtd = null;
                     }
                  }
               }
               catch (IOException e)
               {
                  dtd = null;
               }
            }
         }
      }
      setDTD(dtd);
   }

   /**
    * Constructor - XMLGenerator
    *
    * @param fileName name of an external DTD file
    */

   public XMLGenerator(String fileName)
   {
      this(new File(fileName));
   }

   /**
    * Constructor - XMLGenerator
    */

   public XMLGenerator()
   {
      this((DTD)null);
   }

   /**
    * Method - initializeDefaults - Initialize defaults
    */

   protected void initializeDefaults()
   {
      setTemplateText(false);
      setDataSites(false);
      setRecurseLevel(2);      
      setZeroOrMore(1, 2);
      setOneOrMore(2);
      setAny(1);
      setDocTypeInAny(false);
      m_random = new Random();
      m_idCount = 1;
   }

   /**
    * Method - setTemplateText - Set template text
    *
    * @param templateText true/false depending on whether template text should be generated or not
    */

   public void setTemplateText(boolean templateText)
   {
      m_templateText = templateText;
      if (m_templateText)
      {
         setDataSites(false);
      }
   }

   /**
    * Method - getTemplateText - Get template text
    *
    * @return templateText true/false depending on whether template text should be generated or not
    */

   public boolean getTemplateText()
   {
      return m_templateText;
   }

   /**
    * Method - setDataSites - Set data sites
    *
    * @param dataSites true/false depending on whether Sapphire data sites should be generated or not
    */

   public void setDataSites(boolean dataSites)
   {
      m_dataSites = dataSites;
      if (m_dataSites)
      {
         setTemplateText(false);
      }
   }

   /**
    * Method - getDataSites - Get data sites
    *
    * @return dataSites true/false depending on whether Sapphire data sites should be generated or not
    */

   public boolean getDataSites()
   {
      return m_dataSites;
   }

   /**
    * Method - setRecurseLevel - Set recurse level
    *
    * @param minRecurseLevel minimum recurse level
    * @param maxRecurseLevel maximum recurse level
    */

   public void setRecurseLevel(int minRecurseLevel, int maxRecurseLevel)
   {
      if (minRecurseLevel >= 1)
      {
         if (maxRecurseLevel >= minRecurseLevel)
         {
            m_minRecurseLevel = minRecurseLevel;
            m_maxRecurseLevel = maxRecurseLevel;
         }
         else
         {
            throw new Error("maxRecurseLevel must be >= minRecurseLevel");
         }
      }
      else
      {
         throw new Error("minRecurseLevel must be at least 1");
      }
   }

   /**
    * Method - setRecurseLevel - Set recurse level
    *
    * @param minRecurseLevel minimum recurse level
    */

   public void setRecurseLevel(int minRecurseLevel)
   {
      setRecurseLevel(minRecurseLevel, minRecurseLevel);
   }

   /**
    * Method - setRecurseLevel - Set recurse level
    *
    * @return recurseLevel a recurse level >= min and <= max
    */

   public int getRecurseLevel()
   {
      int                     recurseLevel;


      recurseLevel = m_minRecurseLevel;
      if (m_maxRecurseLevel > m_minRecurseLevel)
      {
         recurseLevel += m_random.nextInt(m_maxRecurseLevel + 1 - m_minRecurseLevel);
      }
      return recurseLevel;
   }

   /**
    * Method - setZeroOrMore - Set zero-or-more
    *
    * @param minZeroOrMore - minimum zero-or-more
    * @param maxZeroOrMore - maximum zero-or-more
    */

   public void setZeroOrMore(int minZeroOrMore, int maxZeroOrMore)
   {
      if (minZeroOrMore >= 0)
      {
         if (maxZeroOrMore >= minZeroOrMore)
         {
            m_minZeroOrMore = minZeroOrMore;
            m_maxZeroOrMore = maxZeroOrMore;
         }
         else
         {
            throw new Error("maxZeroOrMore must be >= minZeroOrMore");
         }
      }
      else
      {
         throw new Error("minZeroOrMore must be at least 0");
      }
   }

   /**
    * Method - setZeroOrMore - Set zero-or-more
    *
    * @param minZeroOrMore - minimum zero-or-more
    */

   public void setZeroOrMore(int minZeroOrMore)
   {
      setZeroOrMore(minZeroOrMore, minZeroOrMore);
   }

   /**
    * Method - getZeroOrMore - Get zero-or-more
    *
    * @return zeroOrMore - zeroOrMore >= min and <= max
    */

   public int getZeroOrMore()
   {
      int                     zeroOrMore;


      zeroOrMore = m_minZeroOrMore;
      if (m_maxZeroOrMore > m_minZeroOrMore)
      {
         zeroOrMore += m_random.nextInt(m_maxZeroOrMore + 1 - m_minZeroOrMore);
      }
      return zeroOrMore;
   }

   /**
    * Method - setOneOrMore - Set one-or-more
    *
    * @param minOneOrMore - minimum one-or-more
    * @param maxOneOrMore - maximum one-or-more
    */

   public void setOneOrMore(int minOneOrMore, int maxOneOrMore)
   {
      if (minOneOrMore >= 1)
      {
         if (maxOneOrMore >= minOneOrMore)
         {
            m_minOneOrMore = minOneOrMore;
            m_maxOneOrMore = maxOneOrMore;
         }
         else
         {
            throw new Error("maxOneOrMore must be >= minOneOrMore");
         }
      }
      else
      {
         throw new Error("minOneOrMore must be at least 1");
      }
   }

   /**
    * Method - setOneOrMore - Set one-or-more
    *
    * @param minOneOrMore - minimum one-or-more
    */

   public void setOneOrMore(int minOneOrMore)
   {
      setOneOrMore(minOneOrMore, minOneOrMore);
   }

   /**
    * Method - getOneOrMore - Get one-or-more
    *
    * @return oneOrMore - one-or-more >= min and <= max
    */

   public int getOneOrMore()
   {
      int                     oneOrMore;


      oneOrMore = m_minOneOrMore;
      if (m_maxOneOrMore > m_minOneOrMore)
      {
         oneOrMore += m_random.nextInt(m_maxOneOrMore + 1 - m_minOneOrMore);
      }
      return oneOrMore;
   }

   /**
    * Method - setAny - Set any
    *
    * @param minAny - minimum any
    * @param maxAny - maximum any
    */

   public void setAny(int minAny, int maxAny)
   {
      if (minAny >= 0)
      {
         if (maxAny >= minAny)
         {
            m_minAny = minAny;
            m_maxAny = maxAny;
         }
         else
         {
            throw new Error("maxAny must be >= minAny");
         }
      }
      else
      {
         throw new Error("minAny must be at least 0");
      }
   }

   /**
    * Method - setAny - Set any
    *
    * @param minAny - minimum any
    */

   public void setAny(int minAny)
   {
      setAny(minAny, minAny);
   }

   /**
    * Method - getAny - Get any
    *
    * @return any - any >= min and <= max
    */

   public int getAny()
   {
      int                     any;


      any = m_minAny;
      if (m_maxAny > m_minAny)
      {
         any += m_random.nextInt(m_maxAny + 1 - m_minAny);
      }
      return any;
   }

   /**
    * Method - setDocTypeInAny - Set document type in any
    *
    * @param docTypeInAny true/false depending on whether or not the document type element may be used as an "ANY" element
    */

   public void setDocTypeInAny(boolean docTypeInAny)
   {
      m_docTypeInAny = docTypeInAny;
   }

   /**
    * Method - getDocTypeInAny - Get document type in any
    *
    * @param docTypeInAny true/false depending on whether or not the document type element may be used as an "ANY" element
    */

   public boolean getDocTypeInAny()
   {
      return m_docTypeInAny;
   }

   /**
    * Method - setDTD - Set DTD
    *
    * @param dtd the DTD instance
    */

   public void setDTD(DTD dtd)
   {
      Enumeration             enumeration;


      m_dtd = dtd;
      m_valid = false;
      if (m_dtd != null)
      {
         enumeration = m_dtd.getElementDeclarations();
         m_valid = enumeration.hasMoreElements();
      }
   }

   /**
    * Method - getDTD - Get DTD
    *
    * @return dtd the DTD instance
    */

   public DTD getDTD()
   {
      return m_dtd;
   }


   /**
    * Method - isValid - Is valid ?
    *
    * @return valid true/false depending on whether the DTD is valid or not
    */

   public boolean isValid()
   {
      return m_valid;
   }

   /**
    * Method - isElementDeclared - Is element declared ?
    *
    * @param elementName element name
    * @return result true/false depending on whether the element is declared or not
    */

   public boolean isElementDeclared(String elementName)
   {
      boolean                 result;


      result = false;
      if (isValid())
      {
         result = (m_dtd.isElementDeclared(elementName));
      }
      return result;
   }

   /**
    * Method - getElementDeclarations - Get element declarations
    *
    * @return elementDeclarations Vector of declared element names
    */

   public Vector getElementDeclarations()
   {
      Vector                  elementDeclarations;
      Enumeration             enumeration;
      ElementDecl             elementDecl;


      elementDeclarations = null;
      if (isValid())
      {
         elementDeclarations = new Vector();
         enumeration = m_dtd.getElementDeclarations();
         while (enumeration.hasMoreElements())
         {
            elementDecl = (ElementDecl)enumeration.nextElement();
            elementDeclarations.add(elementDecl.getName());
         }
      }
      return elementDeclarations;
   }

   /**
    * Method - generateXML - Generate XML
    *
    * @param elementName the name of the document type element
    * @return xml a String of XML or null if XML could not be generated
    */

   public String generateXML(String elementName)
   {
      String                  xml;
      TXDocument              document;
      Writer                  writer;



      xml = null;
      document = generateDocument(elementName);
      if (document != null)
      {
         try
         {
            writer = new StringWriter();
            document.printWithFormat(writer);
            xml = writer.toString();
         }
         catch (IOException e)
         {
            xml = null;
         }
      }
      return xml;
   }

   /**
    * Method - generateDocument - Generate DOM Document
    *
    * @param elementName the name of the document type element
    * @return document a Document instance or null if DOM could not be generated
    */

   public TXDocument generateDocument(String elementName)
   {
      TXDocument              document;
      ElementStack            stack;


      document = null;
      if (isValid())
      {
         if (!elementName.equals(m_dtd.getName()))
         {
            m_dtd.setName(elementName);
         }
         stack = new ElementStack();
         document = new TXDocument();
         document.setVersion("1.0");
         document.appendChild(document.createComment(" Document created by Bluestone Visual-XML "));
         document.appendChild(m_dtd);
         appendElement(document, document, stack, elementName);
      }
      return document;
   }

   /**
    * Method - appendElement - Append element
    *
    * @param document the DOM for which the element should be created
    * @param node the node to which the element should be added
    * @param stack stack maintaining level of elements
    * @param elementName name of element to add
    */

   protected void appendElement(TXDocument document, Node node, ElementStack stack, String elementName)
   {
      Element                 element;
      ElementDecl             elementDecl;
      Hashtable               table;
      Hashtable               insertableElements;
      InsertableElement       insertableElement;
      Text                    textNode;
      Node                    childNode;
      ContentModel            contentModel;
      CMNode                  cmNode;
      Enumeration             enumeration;
      Attr                    attr;
      AttDef                  attDef;
      int                     defaultType;


      if (!elementName.equals(DTD.CM_PCDATA))
      {
         if (stack.getRecurseLevel(elementName) < getRecurseLevel())
         {
            stack.push(elementName);
            element = document.createElement(elementName);
            node.appendChild(element);
            enumeration = m_dtd.getAttributeDeclarations(elementName);
            while (enumeration.hasMoreElements())
            {
               attr = null;
               attDef = (AttDef)enumeration.nextElement();
               defaultType = attDef.getDefaultType();
               switch (defaultType)
               {
                  case AttDef.REQUIRED:
                     attr = document.createAttribute(attDef.getName());
                     if (attDef.size() > 0)
                     {
                        attr.setValue(attDef.elementAt(m_random.nextInt(attDef.size())));
                     }
                     else
                     {
                        if (attDef.getDeclaredType() == AttDef.ID)
                        {
                           attr.setValue("DUMMY" + m_idCount++);
                        }
                        else
                        {
                           attr.setValue("DUMMY");
                        }
                     }
                     break;

                  case AttDef.IMPLIED:
                     break;

                  case AttDef.FIXED:
                  case AttDef.NOFIXED:
                     attr = document.createAttribute(attDef.getName());
                     attr.setValue(attDef.getDefaultStringValue());
                     break;
               }
               if (attr != null)
               {
                  element.setAttributeNode(attr);
               }
            }
            elementDecl = m_dtd.getElementDeclaration(elementName);
            if (elementDecl != null)   // Bug in IBM's parser ?
            {
               switch (elementDecl.getContentType())
               {
                  case ElementDecl.EMPTY:
                     break;

                  case ElementDecl.ANY:
                     appendAnyElement(document, element, stack);
                     break;

                  case ElementDecl.MODEL_GROUP:
                     contentModel = m_dtd.getContentModel(elementName);
                     if (contentModel != null)
                     {
                        cmNode = contentModel.getContentModelNode();
                        appendContentModelElements(document, element, stack, cmNode);
                     }
                     break;
               }
            }
            if ((getTemplateText()) ||(getDataSites()))
            {
               table = m_dtd.prepareTable(elementName);
               insertableElements = m_dtd.getInsertableElements(element, 0, table);
               if (insertableElements != null)
               {
                  insertableElement = (InsertableElement)insertableElements.get(DTD.CM_PCDATA);
                  if (insertableElement != null)
                  {
                     if (insertableElement.status == true)
                     {
                        if (getTemplateText())
                        {
                           textNode = document.createTextNode(elementName + "_Template_Text");
                        }
                        else
                        {
                           textNode = document.createTextNode("##Sa_" + elementName + "##");
                        }
                        if (element.hasChildNodes())
                        {
                           childNode = element.getFirstChild();
                           element.insertBefore(textNode, childNode);
                           element.insertBefore(document.createTextNode("\n", true), childNode);
                        }
                        else
                        {
                           element.appendChild(textNode);
                        }
                     }
                  }
               }
            }
            stack.pop();
         }
      }
   }

   /**
    * Method - appendAnyElement - Append any element
    *
    * @param document the DOM for which the element should be created
    * @param node the node to which the element should be added
    * @param stack stack maintaining level of elements
    */

   protected void appendAnyElement(TXDocument document, Node node, ElementStack stack)
   {
      Enumeration             enumeration;
      Vector                  elementDecls;
      ElementDecl             elementDecl;
      String                  elementName;
      int                     count;
      int                     i;


      enumeration = m_dtd.getElementDeclarations();
      elementDecls = new Vector();
      while (enumeration.hasMoreElements())
      {
         elementDecl = (ElementDecl)enumeration.nextElement();
         if ((!elementDecl.getName().equals(DTD.CM_PCDATA)) && ((getDocTypeInAny()) || (!m_dtd.getName().equals(elementDecl.getName()))))
         {
            elementDecls.add(elementDecl.getName());
         }
      }
      if (elementDecls.size() > 0)
      {
         count = getAny();
         for (i = 0; i < count; i++)
         {
            elementName = (String)elementDecls.elementAt(m_random.nextInt(elementDecls.size()));
            appendElement(document, node, stack, elementName);
         }
      }
   }

   /**
    * Method - appendContentModelElements - Append content model element(s)
    *
    * @param document the DOM for which the element should be created
    * @param node the node to which the element should be added
    * @param stack stack maintaining level of elements
    * @param cmNode content model node describe element(s) to be added
    */

   protected void appendContentModelElements(TXDocument document, Node node, ElementStack stack, CMNode cmNode)
   {
      CMLeaf                  leafNode;
      CM1op                   cm1Node;
      CM2op                   cm2Node;
      String                  elementName;
      GroupNodeVector         groupNodes;
      Object                  groupNode;
      int                     count;
      int                     i;
      

      if (cmNode instanceof CMLeaf)
      {
         leafNode = (CMLeaf)cmNode;
         elementName = leafNode.getName();
         if (elementName.equals("ANY"))
         {
            appendAnyElement(document, node, stack);
         }
         else
         {
            appendElement(document, node, stack, elementName);
         }
      }
      else if (cmNode instanceof CM1op)
      {
         cm1Node = (CM1op)cmNode;
         switch (cm1Node.getType())
         {
            case '*':
               count = getZeroOrMore();
               break;

            case '?':
               count = 1;
               break;

            case '+':
               count = getOneOrMore();
               break;

            default:
               count = 0;
               break;
         }
         for (i = 0; i < count; i++)
         {
            appendContentModelElements(document, node, stack, cm1Node.getNode());
         }
      }
      else if (cmNode instanceof CM2op)
      {
         cm2Node = (CM2op)cmNode;
         groupNodes = new GroupNodeVector(cm2Node.getType());
         buildGroupNodes(groupNodes, cm2Node);
         if (groupNodes.size() > 0)
         {
            processGroupNodes(document, node, stack, groupNodes);
         }
      }
      else
      {
         throw new Error("Unknown CM node type encountered");
      }
   }

   /**
    * Method - processGroupNodes - Process group nodes (from content model)
    *
    * @param document the DOM for which the element should be created
    * @param node the node to which the element should be added
    * @param stack stack maintaining level of elements
    * @param groupNodes Vector of nodes to process
    */

   protected void processGroupNodes(TXDocument document, Node node, ElementStack stack, GroupNodeVector groupNodes)
   {
      Object                  groupNode;
      int                     i;


      if (groupNodes.getType() == ',')
      {
         for (i = 0; i < groupNodes.size(); i++)
         {
            groupNode = groupNodes.elementAt(i);
            if (groupNode instanceof CMNode)
            {
               appendContentModelElements(document, node, stack, (CMNode)groupNode);
            }
            else if (groupNode instanceof GroupNodeVector)
            {
               processGroupNodes(document, node, stack, (GroupNodeVector)groupNode);
            }
         }
      }
      else
      {
         groupNode = groupNodes.elementAt(m_random.nextInt(groupNodes.size()));
         if (groupNode instanceof CMNode)
         {
            appendContentModelElements(document, node, stack, (CMNode)groupNode);
         }
         else if (groupNode instanceof GroupNodeVector)
         {
            processGroupNodes(document, node, stack, (GroupNodeVector)groupNode);
         }
      }
   }

   /**
    * Method - buildGroupNodes - Build group nodes
    *
    * @param groupNodes GroupNodeVector instance to add nodes to
    * @param cm2Node CM2op instance content model node to retrieve group nodes from
    */

   protected void buildGroupNodes(GroupNodeVector groupNodes, CM2op cm2Node)
   {
      CMNode                  cmNode;
      GroupNodeVector         subNodes;


      cmNode = cm2Node.getRight();
      if (cmNode instanceof CM2op)
      {
         subNodes = new GroupNodeVector(((CM2op)cmNode).getType());
         buildGroupNodes(subNodes, (CM2op)cmNode);
         groupNodes.insertElementAt(subNodes, 0);
      }
      else
      {
         groupNodes.insertElementAt(cmNode, 0);
      }
      cmNode = cm2Node.getLeft();
      if (cmNode instanceof CM2op)
      {
         if (cm2Node.getType() != ((CM2op)cmNode).getType())
         {
            subNodes = new GroupNodeVector(((CM2op)cmNode).getType());
            buildGroupNodes(subNodes, (CM2op)cmNode);
            groupNodes.insertElementAt(subNodes, 0);
         }
         else
         {
            buildGroupNodes(groupNodes, (CM2op)cmNode);
         }
      }
      else
      {
         groupNodes.insertElementAt(cmNode, 0);
      }
   }

   /**
    * Class - ElementStack - Element stack
    */

   class ElementStack extends Stack
   {
      /**
       * Constructor - ElementStack
       */

      public ElementStack()
      {
         super();
      }

      /**
       * Method - getRecurseLevel - Get recurse level
       *
       * @param elementName element name to retrieve recurse level from
       * @return recurseLevel level of recursion for the specified element
       */

      public int getRecurseLevel(String elementName)
      {
         int                  recurseLevel;
         int                  i;


         recurseLevel = 0;
         for (i = 0; i < size(); i++)
         {
            if (elementName.equals(elementAt(i)))
            {
               recurseLevel++;
            }
         }
         return recurseLevel;
      }
   }

   /**
    * Class - GroupNodeVector - Group node vector
    */

   class GroupNodeVector extends Vector
   {
      protected int           m_type;


      /**
       * Constructor - GroupNodeVector
       *
       * @param type the type of group (',' or '|')
       */

      public GroupNodeVector(int type)
      {
         super();
         if ((type == ',') || (type == '|'))
         {
            m_type = type;
         }
         else
         {
            throw new Error("Type must be ',' or '|'");
         }
      }

      /**
       * Method - getType - Get type
       *
       * @return type either ',' or '|'
       */

      public int getType()
      {
         return m_type;
      }
   }
}
