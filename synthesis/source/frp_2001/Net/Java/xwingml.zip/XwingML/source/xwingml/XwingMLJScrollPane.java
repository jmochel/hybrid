/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLJScrollPane - XwingML JScrollPane class
 */

public class XwingMLJScrollPane extends XwingMLJComponent
{
   /**
    * Constructor - XwingMLJScrollPane
    */

   public XwingMLJScrollPane()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLJScrollPane
    *
    * @param node the DOM node decsribing the scroll pane to build
    */

   public XwingMLJScrollPane(Node node)
   {
      super(node);
   }

   /**
    * Method - getJScrollPane - Get Swing scroll pane
    *
    * @return object the object typecasted to a JScrollPane
    */

   public JScrollPane getJScrollPane()
   {
      return (JScrollPane)m_object;
   }

   /**
    * Method - createObject - Create object
    *
    * @return result true/false depending on whether the object could be created or not
    */

   public boolean createObject()
   {
      m_object = createSwingComponent(JScrollPane.class);
      return (m_object != null);
   }

   /**
    * Method - handleAttributes - Handle attributes
    *
    * @return result true/false depending on whether the attributes could be handled successfully or not
    */

   public boolean handleAttributes()
   {
      boolean                 result;
      Node                    node;
      String                  nodeValue;
      JScrollPane             scrollPane;


      result = super.handleAttributes();
      if (result)
      {
         scrollPane = getJScrollPane();
         node = m_attributes.getNamedItem("vsbPolicy");
         if (node != null)
         {
            scrollPane.setVerticalScrollBarPolicy(getVerticalScrollBarPolicy(node));
         }
         node = m_attributes.getNamedItem("hsbPolicy");
         if (node != null)
         {
            scrollPane.setHorizontalScrollBarPolicy(getHorizontalScrollBarPolicy(node));
         }
      }
      return result;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      Node                    node;
      XwingMLIObject          xmlObject;
      XwingMLComponent        xmlComponent;
      Container               container;
      JScrollPane             scrollPane;
      int                     i;


      result = true;
      scrollPane = getJScrollPane();
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
            if (xmlObject != null)
            {
               xmlObject.setParent(scrollPane);
               result = xmlObject.buildObject();
               if (result)
               {
                  if (xmlObject instanceof XwingMLComponent)
                  {
                     xmlComponent = (XwingMLComponent)xmlObject;
                     scrollPane.setViewportView(xmlComponent.getComponent());
                  }
               }
            }
         }
      }
      return result;
   }

   /**
    * Method - getHorizontalScrollBarPolicy - Get horizontal scroll bar policy
    *
    * @param node the DOM node to obtain the horizontal scroll bar policy from
    * @return scroll bar policy
    */

   protected int getHorizontalScrollBarPolicy(Node node)
   {
      int                     hsbPolicy;
      String                  nodeValue;


      nodeValue = node.getNodeValue();
      hsbPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED;
      if (nodeValue.equals("HORIZONTAL_SCROLLBAR_AS_NEEDED"))
      {
         hsbPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED;
      }
      else if (nodeValue.equals("HORIZONTAL_SCROLLBAR_NEVER"))
      {
         hsbPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_NEVER;
      }
      else if (nodeValue.equals("HORIZONTAL_SCROLLBAR_ALWAYS"))
      {
         hsbPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The horizontal scrollbar policy '" + nodeValue + "' is unknown"));
      }
      return hsbPolicy;
   }

   /**
    * Method - getVerticalScrollBarPolicy - Get vertical scroll bar policy
    *
    * @param node the DOM node to obtain the vertical scroll bar policy from
    * @return scroll bar policy
    */

   protected int getVerticalScrollBarPolicy(Node node)
   {
      int                     vsbPolicy;
      String                  nodeValue;


      nodeValue = node.getNodeValue();
      vsbPolicy = JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED;
      if (nodeValue.equals("VERTICAL_SCROLLBAR_AS_NEEDED"))
      {
         vsbPolicy = JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED;
      }
      else if (nodeValue.equals("VERTICAL_SCROLLBAR_NEVER"))
      {
         vsbPolicy = JScrollPane.VERTICAL_SCROLLBAR_NEVER;
      }
      else if (nodeValue.equals("VERTICAL_SCROLLBAR_ALWAYS"))
      {
         vsbPolicy = JScrollPane.VERTICAL_SCROLLBAR_ALWAYS;
      }
      else
      {
         m_context.fireXwingMLWarning(new XwingMLWarningEvent(node, "The vertical scrollbar policy '" + nodeValue + "' is unknown"));
      }
      return vsbPolicy;
   }
}
