/*=============================================================================*/
/* Copyright � 1998-1999 by Bluestone Software, Inc. All rights Reserved.      */
/*=============================================================================*/
/*
$Archive:: $
$Revision:: $
$Date:: $ 02/22/1999
$Author:: $ Jay Hiremath
*/
/*=============================================================================*/

package com.bluestone.xml;
import java.util.EventListener;

/**
* Event Listener interface used in the Bluestone event model for
* DOM modifications.  Implement this interface and use it in 
* conjunction with othe XML DOM event related classes in 
* com.bluestone.xml.
*
* @see com.bluestone.xml.XMLDOMEvent
* @see com.bluestone.xml.XMLDOMEvent
* 
*/
public abstract interface XMLIDOMEventListener extends EventListener
{
   public abstract void handleEvent(XMLDOMEventObject evt);
}