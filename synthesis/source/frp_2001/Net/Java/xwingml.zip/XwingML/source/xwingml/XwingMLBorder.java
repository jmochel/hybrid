/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/


package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Class - XwingMLBorder - XwingML border super class for all borders
 */

public abstract class XwingMLBorder extends XwingMLObject
{
   protected XwingMLJComponent  m_xmlJComponent;


   /**
    * Constructor - XwingMLBorder
    */

   public XwingMLBorder()
   {
      this(null);
   }

   /**
    * Constructor - XwingMLBorder
    *
    * @param node the DOM node describing this border
    */

   public XwingMLBorder(Node node)
   {
      super(node);
      m_xmlJComponent = null;
   }

   /**
    * Method - getBorder - Get border
    *
    * @return object the object typecasted to Border
    */

   public Border getBorder()
   {
      return (Border)m_object;
   }

   /**
    * Method - getXwingMLJComponent - Get XwingML JComponent which has this border
    *
    * @return xmlJComponent the xmlJComponent which has this border or null if not set
    */

   public XwingMLJComponent getXMLJComponent()
   {
      return m_xmlJComponent;
   }

   /**
    * Method - handleChildNodes - Handle child nodes
    *
    * @return result true/false depending on whether the child nodes could be handled successfully or not
    */

   public boolean handleChildNodes()
   {
      boolean                 result;
      Node                    node;
      XwingMLIObject          xmlObject;
      int                     i;


      result = true;
      for (i = 0; (i < m_childNodes.getLength()) && (result); i++)
      {
         node = m_childNodes.item(i);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            xmlObject = XwingMLObjectFactory.createXMLObject(node, m_context);
            if (xmlObject != null)
            {
               if (xmlObject instanceof XwingMLJComponent)
               {
                  xmlObject.setParent(m_parent);
                  result = xmlObject.buildObject();
                  if (result)
                  {
                     m_xmlJComponent = (XwingMLJComponent)xmlObject;
                     m_xmlJComponent.getJComponent().setBorder(getBorder());
                  }
               }
            }
            else
            {
               result = false;
            }
         }
      }
      return result;
   }
}