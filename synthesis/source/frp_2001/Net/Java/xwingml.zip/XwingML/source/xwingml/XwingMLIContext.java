/*-------------------------------------------------------------------------------------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

-------------------------------------------------------------------------------------------------*/

package com.bluestone.xwingml;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
import javax.swing.*;
import javax.swing.event.*;
import org.w3c.dom.*;
import com.bluestone.xml.*;


/**
 * Interface - XwingMLIContext - The XwingML context interface
 */

public interface XwingMLIContext extends WindowListener, InternalFrameListener
{
   /**
    * Method - getXwingML - Get XwingML instance
    *
    * @return xwingml the XwingML instance
    */

   public XwingML getXwingML();

   /**
    * Method - getXMLIparser - Get XML parser interface (abstracted parser (e.g. IBM or Sun parser))
    *
    * @return parser the parser interface
    */

   public XMLIParser getParser();

   /**
    * Method - addXwingMLListener - Add XwingML listener
    *
    * @param listener the listener to add
    */

   public void addXwingMLListener(XwingMLIListener listener);

   /**
    * Method - removeXwingMLListener - Remove XwingML listener
    *
    * @param listener the listener to remove
    */

   public void removeXwingMLListener(XwingMLIListener listener);

   /**
    * Method - fireXwingMLWarning - Fire XwingML warning
    *
    * @param evt XwingMLEvent instance
    */

   public void fireXwingMLWarning(XwingMLEvent evt);

   /**
    * Method - fireXwingMLError - Fire XwingML error
    *
    * @param evt XwingMLEvent instance
    */

   public void fireXwingMLError(XwingMLEvent evt);

   /**
    * Method - addPropertyChangeListener - Add property change listener
    *
    * @param listener the listener to add
    */

   public void addPropertyChangeListener(PropertyChangeListener listener);

   /**
    * Method - removePropertyChangeListener - Remove property change listener
    *
    * @param listener the listener to remove
    */

   public void removePropertyChangeListener(PropertyChangeListener listener);

   /**
    * Method - setProperty - Set property
    *
    * @param key the property's key
    * @param value the property's value (may be null, in which case the property is removed)
    */

   public void setProperty(String key, Object value);

   /**
    * Method - getProperty - Get property
    *
    * @param key the property's key
    * @return value the property's value (or null if not found)
    */

   public Object getProperty(String key);

   /**
    * Method - removeProperty - Remove property
    *
    * @param key property's key
    */

   public void removeProperty(String key);

   /**
    * Method - hasPropertyKey - Has property key ?
    *
    * @param key property's key
    * @return result true/false depending on whether the context has the property key or not
    */

   public boolean hasPropertyKey(String key);

   /**
    * Method - hasPropertyValue - Has property value?
    *
    * @param value property's value
    * @return result true/false depending on whether the context has the property value or not
    */

   public boolean hasPropertyValue(Object value);

   /**
    * Method - propertyKeys - Get enumeration of property keys currently set
    *
    * @return propertyKeys enumration of property keys currently set
    */

   public Enumeration propertyKeys();

   /**
    * Method - propertyValues - Get enumeration of property values currently set
    *
    * @return propertyValues enumration of property values currently set
    */

   public Enumeration propertyValues();

   /**
    * Method - getImageIcon - Get image icon
    *
    * @param imageName name of image .gif or .jpg/.jpeg file
    * @return imageIcon the image icon or null if the file could not be found
    */

   public ImageIcon getImageIcon(String imageName);

   /**
    * Method - getImage - Get image
    *
    * @param imageName name of image .gif or .jpg/.jpeg file
    * @return image the image or null if the file could not be found
    */

   public Image getImage(String imageName);

   /**
    * Method - getXMLFile - Get XML file
    *
    * @param fileName the .xml file name
    * @return file the .xml file or null if it could not be found
    */

   public File getXMLFile(String fileName);

   /**
    * Method - getFrame - Get frame registered with XwingML
    *
    * @param name the name of the frame to retrieve
    * @return frame the requested frame or null if not found
    */

   public JFrame getFrame(String name);

   /**
    * Method - getDialog - Get dialog registered with XwingML
    *
    * @param name the name of the dialog to retrieve
    * @return dialog the requested dialog or null if not found
    */

   public JDialog getDialog(String name);

   /**
    * Method - getWindow - Get window registered with XwingML
    *
    * @param name the name of the window to retrieve
    * @return window the requested window or null if not found
    */

   public JWindow getWindow(String name);

   /**
    * Method - getInternalFrame - Get internal frame registered with XwingML
    *
    * @param name the name of the internal frame to retrieve
    * @return internalFrame the requested internal frame or null if not found
    */

   public JInternalFrame getInternalFrame(String name);

   /**
    * Method - findComponent - Find component belonging to a container (recurses through child containers)
    *
    * @param name name of component to find
    * @param container container to find component in
    * @return component the requested component or null if not found
    */

   public Component findComponent(String name, Container container);

   /**
    * Method - findJComponent - Find Swing component belonging to a container (recurses through child containers)
    *
    * @param name name of Swing component to find
    * @param container container to find component in
    * @return component the requested Swing component or null if not found
    */

   public JComponent findJComponent(String name, Container container);

   /**
    * Method - findJPanel - Find Swing panel belonging to a container (recurses through child containers)
    *
    * @param name name of Swing panel to find
    * @param container container to find panel in
    * @return panel the requested Swing panel or null if not found
    */

   public JPanel findJPanel(String name, Container container);

   /**
    * Method - findJScrollPane - Find Swing scroll pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing scroll pane to find
    * @param container container to find scroll pane in
    * @return scrollPane the requested Swing scroll pane or null if not found
    */

   public JScrollPane findJScrollPane(String name, Container container);

   /**
    * Method - findJSplitPane - Find Swing split pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing split pane to find
    * @param container container to find split pane in
    * @return splitPane the requested Swing split pane or null if not found
    */

   public JSplitPane findJSplitPane(String name, Container container);

   /**
    * Method - findJTabbedPane - Find Swing tabbed pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tabbed pane to find
    * @param container container to find tabbed pane in
    * @return tabbedPane the requested Swing tabbed pane or null if not found
    */

   public JTabbedPane findJTabbedPane(String name, Container container);

   /**
    * Method - findJButton - Find Swing button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing button to find
    * @param container container to find button in
    * @return button the requested Swing button or null if not found
    */

   public JButton findJButton(String name, Container container);

   /**
    * Method - findJToggleButton - Find Swing toggle button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing toggle button to find
    * @param container container to find toggle button in
    * @return toggleButton the requested Swing toggle button or null if not found
    */

   public JToggleButton findJToggleButton(String name, Container container);

   /**
    * Method - findJCheckBox - Find Swing check box belonging to a container (recurses through child containers)
    *
    * @param name name of Swing check box to find
    * @param container container to find check box in
    * @return checkBox the requested Swing check box or null if not found
    */

   public JCheckBox findJCheckBox(String name, Container container);

   /**
    * Method - findJRadioButton - Find Swing radio button belonging to a container (recurses through child containers)
    *
    * @param name name of Swing radio button to find
    * @param container container to find radio button in
    * @return radioButton the requested Swing radio button or null if not found
    */

   public JRadioButton findJRadioButton(String name, Container container);

   /**
    * Method - findJToolBar - Find Swing tool bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tool bar to find
    * @param container container to find tool bar in
    * @return toolBar the requested Swing tool bar or null if not found
    */

   public JToolBar findJToolBar(String name, Container container);

   /**
    * Method - findJLabel - Find Swing label belonging to a container (recurses through child containers)
    *
    * @param name name of Swing label to find
    * @param container container to find label in
    * @return label the requested Swing label or null if not found
    */

   public JLabel findJLabel(String name, Container container);

   /**
    * Method - findJTextField - Find Swing text field belonging to a container (recurses through child containers)
    *
    * @param name name of Swing text field to find
    * @param container container to find text field in
    * @return textField the requested Swing text field or null if not found
    */

   public JTextField findJTextField(String name, Container container);

   /**
    * Method - findJPasswordField - Find Swing password field belonging to a container (recurses through child containers)
    *
    * @param name name of Swing password field to find
    * @param container container to find password field in
    * @return textField the requested Swing password field or null if not found
    */

   public JPasswordField findJPasswordField(String name, Container container);

   /**
    * Method - findJTextArea - Find Swing text area belonging to a container (recurses through child containers)
    *
    * @param name name of Swing text area to find
    * @param container container to find text area in
    * @return textArea the requested Swing text area or null if not found
    */

   public JTextArea findJTextArea(String name, Container container);

   /**
    * Method - findJEditorPane - Find Swing editor pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing editor pane to find
    * @param container container to find editor pane in
    * @return editorPane the requested Swing editor pane or null if not found
    */

   public JEditorPane findJEditorPane(String name, Container container);

   /**
    * Method - findJTextPane - Find Swing text pane belonging to a container (recurses through child containers)
    *
    * @param name name of Swing editor pane to find
    * @param container container to find text pane in
    * @return textPane the requested Swing text pane or null if not found
    */

   public JTextPane findJTextPane(String name, Container container);

   /**
    * Method - findJComboBox - Find Swing combo box belonging to a container (recurses through child containers)
    *
    * @param name name of Swing combo box to find
    * @param container container to find combo box in
    * @return comboBox the requested Swing combo box or null if not found
    */

   public JComboBox findJComboBox(String name, Container container);

   /**
    * Method - findJList - Find Swing list belonging to a container (recurses through child containers)
    *
    * @param name name of Swing list to find
    * @param container container to find list in
    * @return list the requested Swing list or null if not found
    */

   public JList findJList(String name, Container container);

   /**
    * Method - findJTree - Find Swing tree belonging to a container (recurses through child containers)
    *
    * @param name name of Swing tree to find
    * @param container container to find tree in
    * @return tree the requested Swing tree or null if not found
    */

   public JTree findJTree(String name, Container container);

   /**
    * Method - findJTable - Find Swing table belonging to a container (recurses through child containers)
    *
    * @param name name of Swing table to find
    * @param container container to find table in
    * @return table the requested Swing table or null if not found
    */

   public JTable findJTable(String name, Container container);

   /**
    * Method - findJSlider - Find Swing slider belonging to a container (recurses through child containers)
    *
    * @param name name of Swing slider to find
    * @param container container to slider table in
    * @return slider the requested Swing slider or null if not found
    */

   public JSlider findJSlider(String name, Container container);

   /**
    * Method - findJProgessBar - Find Swing progress bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing progress bar to find
    * @param container container to progress bar table in
    * @return progressBar the requested Swing progress bar or null if not found
    */

   public JProgressBar findJProgressBar(String name, Container container);

   /**
    * Method - findJScrollBar - Find Swing scroll bar belonging to a container (recurses through child containers)
    *
    * @param name name of Swing scroll bar to find
    * @param container container to scroll bar table in
    * @return scrollBar the requested Swing scroll bar or null if not found
    */

   public JScrollBar findJScrollBar(String name, Container container);

   /**
    * Method - findJComponent - Find Swing component belonging to a container (recurses through child containers)
    *
    * @param name name of Swing component to find
    * @param container container to find component in
    * @param containerClass Java class of component to find
    * @return component the requested Swing component or null if not found
    */

   public Component findComponent(String name, Container container, Class componentClass);

   /**
    * Method - addResourceDirectory - Add resource directory (The XwingML context holds a list of directories in which
    * to look for resources (like .gif and .jpg/.jpeg files)).
    *
    * @param path the path of the resource directory to add
    */

   public void addResourceDirectory(String path);

   /**
    * Method - removeResourceDirectory - Remove resource directory
    *
    * @param path the path of the resource directory to remove
    */

   public void removeResourceDirectory(String path);

   /**
    * Method - getResourceDirectories - Get enumeration of resource directories
    *
    * @return resourceDirectories enumeration of resource directories currently added to the context
    */

   public Enumeration getResourceDirectories();

   /**
    * Method - addResourceJar - Add resource jar
    *
    * @param jarName name of jar to add
    */

   public void addResourceJar(String jarName);

      /**
    * Method - removeResourceJar - Remove resource jar
    *
    * @param jarName name of jar to remove
    */

   public void removeResourceJar(String jarName);

   /**
    * Method - getResourceJars - Get enumeration of resource jars
    *
    * @return resourceJars enumeration of resource jars currently added to the context
    */

   public Enumeration getResourceJars();

   /**
    * Method - addXMLDirectory - Add XML directory (The XwingML context holds a list of directories in which
    * to look for .xml files).
    *
    * @param path the path of the XML directory to add
    */

   public void addXMLDirectory(String path);

   /**
    * Method - removeXMLDirectory - Remove XML directory
    *
    * @param path the path of the XML directory to remove
    */

   public void removeXMLDirectory(String path);

   /**
    * Method - getXMLDirectories - Get enumeration of XML directories
    *
    * @return xmlDirectories enumeration of XML directories currently added to the context
    */

   public Enumeration getXMLDirectories();

   /**
    * Method - addClassInstance - Add class instance to context
    *
    * @param name name of class instance (arbitrary name which can be used to reference a particular instance)
    * @param instance instance of any class imaginable
    */

   public void addClassInstance(String name, Object instance);

   /**
    * Method - getClassInstance - get class instance from context
    *
    * @param name name of class instance 
    * @return instance the requested instance or null if not found
    */

   public Object getClassInstance(String name);

   /**
    * Method - removeClassInstance - remove class instance from context
    *
    * @param name name of class instance to remove
    */

   public void removeClassInstance(String name);
}