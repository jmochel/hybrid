   License agreement:
   ------------------

   XwingML v1.0  99/01/20

   Bluestone grants you ("Licensee") a non-exclusive, royalty free, license to use
   and modify the Xwing ML software ("Software") in source and binary code form in
   accordance with the terms of this Agreement, provided that (i) this copyright notice
   and license appear on all copies of the Software; (ii) Licensee does not utilize
   the Software in a manner which is disparaging to Bluestone, and (iii) Licensee posts
   all modifications to the Software onto the Bluestone web site.

   The Software is provided "AS IS," without a warranty of any kind.
   ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
   INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
   OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  BLUESTONE AND ITS LICENSORS SHALL NOT
   BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
   DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL BLUESTONE OR ITS LICENSORS
   BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
   CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF
   THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE,
   EVEN IF  BLUESTONE  HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

   The Software is not designed or intended for use in on-line control of aircraft, air traffic,
   aircraft navigation or aircraft communications; or in the design, construction, operation
   or maintenance of any nuclear facility. Licensee represents and warrants that it will
   not use the Software for such purposes. Licensee agrees not to export or re-export
   the Software, or any copy or adaptation, to any country currently in Country Groups
   Q, S, W, Y or Z (as defined by the US Department of Commerce) or the People's Republic of China,
   in violation of the US Export Administration regulations or other applicable regulations.

   The Software is provided as "restricted rights Software" (as defined by FAR Section 52.227-14 (a).
   The use, reproduction, or disclosure by the Department of Defense is governed by this license.
   The use, reproduction, or disclosure by any other Government department or agency is governed
   by the Restricted Rights Notice set forth in FAR Section 52.227014.

   Licensee agrees that it does not have any title or ownership of the Software.

   This is the entire agreement Bluestone and Licensee with respect to the licensing of
   the Software and supersedes all other proposals and agreements related to this licensing.
   This Agreement may be modified only by the prior written consent of both parties.
   This Agreement shall be governed by the laws of the state of Delaware without regard
   for its choice of law provisions.  All disputes arising under this Agreement shall be brought
   exclusively in a court of competent jurisdiction located in Wilmington, Delaware.

   � 1998-1999  Bluestone Software, Inc. All Rights Reserved.

	Bug fixes/Changes 02/19/99:
	---------------------------

	1. Changed the XwingML package name to com.bluestone.xwingml. Sorry about that folks, we're not trying to make life
		harder for anyone.  Unfortunately an internal Bluestone package name revision made it necessary.
	2. Added support for JComponent (usually in conjunction with the className="..." attribute); the Object factory didn't
		know how to build a JComponent - only extensions.
	3. Fixed a glitch with CardLayout.  Mr. Takanobu Tsuruno from Canon in Japan was kind enough to point out
		a couple of problems in the Container and CardLayout code. Thank you.
	4. Changed the -DResourceDirectories and -DXMLDirectories to -Dresource.path and -Dxml.path respectively.

	Installation:
   -------------

   XwingML requires Java JDK 1.2 or newer!

   The XwingML classes are all delivered in the xwingml.jar in the XwingML directory, created
   from the xwingml.zip archive.  The source for XwingML is available in XwingML/source.

   Before using XwingML, the xwingml.jar file must be added to the classpath; you may either
   set or update the CLASSPATH environment variable on your system to include the jar or specify
   the .jar file name using the -classpath option on the jvm.

   Windows:

   set CLASSPATH=%CLASSPATH%;<d:>\XwingML\xwingml.jar (<d:> is the drive where XwingML is installed)
   java com.bluestone.xml.swing.XwingML

   or

   java -classpath <d:>\XwingML\xwingml.jar com.bluestone.xml.swing.XwingML

   UNIX/Linux:

   export CLASSPATH=$CLASSPATH:/XwingML/xwingml.jar (or the equivalent for your preferred shell)

   or

   java -classpath /XwingML/xwingml.jar com.bluestone.xml.swing.XwingML

   (We have included convenient .bat files for Windows users to launch XwingML and the samples;
   similar shell scripts can easily be created for your favorite UNIX/Linux shell).

   Also, XwingML requires an XML parser in order to parse the .xml files and the xwingml.dtd.
   XwingML has been tested with two different parsers: Sun's early access release 2 and IBM's
   xml4j release 1.1.9; both freely downloadable.  IBM parser seems to perform a little bit
   better than Sun's and the error messages from IBM's parser are excellent, whereas the
   ones from Sun's parser seem relatively useless.   Bluestone has abstracted the vendor specific
   parser API and included that abstraction layer with XwingML.

   Download the parser of your choice and install it (you basically needs to add the parser's
   .jar file to the classpath or launch the jvm with the parser in its classpath - just like the
   xwingml.jar).

   By default, XwingML will want to use IBM's parser; if you want to use Sun's, you must define a jvm
   property named bluestone.xml.iparser; set it equal to the name of the parser abstraction you want to use,
   either Sun's or IBM's:

   java -Dbluestone.xml.iparser=com.bluestone.xml.XMLSunParser

   or

   java -Dbluestone.xml.iparser=com.bluestone.xml.XMLIBMParser   (the default)

   Both parsers come with the org.w3c.dom classes needed.

   Once XwingML and the parser of your choice have been installed, change directory to XwingML/bin and launch
   the xwingml.bat file (if you're on UNIX/Linux, create a similar shell script for your preferred shell and
   launch that).   This should bring up the XwingML frame and XML viewer through which you can load .xml
   files and "launch" them as XwingML GUI applications.  If you get any exceptions and/or error messages
   you haven't installed java/swing/XwingML/parser correctly.  If everything flies, you're good to go!

   Test:
   -----

   Before you run any of the samples, you must make sure that the XML files point correctly to the 
   XwingML dtd; it is delivered in XwingML/xml/xwingml.dtd and the .xml files you create must point
   to that location.  The sample .xml files delivered with XwingML all have the following DOCTYPE tag:

   <!DOCTYPE XwingML SYSTEM "file:///c:/XwingML/xml/xwingml.dtd">

   If you installed XwingML somewhere else and/or are on UNIX/Linux - change the file:/// URI to point to
   the xwingml.dtd file.

   The easiest test is to change directory to XwingML/samples/XMLPad and then launch XMLPad.bat (yeah,
   yeah, yeah! If you're on UNIX/Linux you've gotta hack a shell script first or type in the java command
   from the .bat file by hand!).

   If everything is installed correctly, you'll see a Swing incarnation of Notepad - a small text editor
   with a menu and a toolbar.  Go ahead and open a file or type in a new one and save it as text (you might
   even find it useful for creating the shell scripts we didn't supply!).

   Once XMLPad is up and running, you've verified that the required components are all working as expected
   and you're ready to start using XwingML.

   Resources and XML files:
   ------------------------

   The XwingML framework supports two jvm properties, resource.path and xml.path, through which
   you can specify a set of locations where e.g. .gif files and .xml files can be found.

   You can add further directories to either of the two lists through the <Defaults> tag, described in the
   dtd, or through the XwingMLContext methods addResourceDirectory and/or addXMLDirectory.

   The XwingML context will read the DOM produced from the .xml document and attempt to convert Windows
   style path's to UNIX/Linux ones and vice versa when the "wrong" type is used on the run-time system.
   Basically, all /'s are changed to \'s and any <d:> is removed from Windows style path's. e.g.
   c:\MyProject\resources will be changed to /MyProject/resources and /MyProject/resources will be changed
   to \MyProject\resources.

   Using XwingML:
   --------------

   So far, you've used XwingML by passing in the name of an XML file which (hopefully) conforms to the 
   XwingML DTD.  This is an easy way of getting started with the XwingML XML syntax; however, for more
   powerful applications, you'll probably want to use the XwingML classes and their API's to construct
   more complex and useful applications.

   We have supplied all the XwingML source - all with java docs, so feel free to get the necessary inspiration
   from those source files.  The Java-level integration basically happens at two points:

   1) All classes (such as listeners, renderers and component subclasses) specified in the .xml files,
      are checked to see if they implement the XwingMLIPlugIn interface; if they do, the XwingML context
      is passed to the instance using the setContext method.  Furthermore, all Swing components get the
      context through a client property named XwingML:context; it can be obtained and typecast to a
      XwingMLIContext.  Through the context, the XwingML instance can be obtained and used to generate
      more components from XML files.  (The XMLAbout.java from the XMLEdit sample describes this procedure).

   2) Applications can extend the XwingML class and control how .xml files are read and parsed.

   The XwingML frame and menu bar/tool bar are only shown when:

   1) you launch XwingML without any .xml file specified at the command line
   2) you launch XwingML with an .xml file which is syntactically incorrect
   3) you launch XwingML with an .xml file which yields a JDialog or JInternalFrame, in which case the
      XwingML frame is used as the parent.

   Since we, at Bluestone Software, use XwingML ourselves for our future products and tools, we are adding
   support for code generation:  feed in your .xml file and the tool will generate a .java source file.

   Performance:
   ------------

   Honestly, XwingML is pretty much a 400+ Mhz technology; you probably don't want to fiddle with this
   on any technology much older than six to nine months (although we do do demos on 266 Mhz Latitude Laptops
   from Dell).

   However, when this is said and done, the slowest part of XwingML is twofold:

   1) Loading all the Swing classes
   2) Loading all the parser and DOM classes

   Once the parser has created the first DOM and XwingML has built its first Frame or Dialog, things
   speed up significantly (We keep a reference to the parser (and thus the DOM classes) handy in the
   XwingML context, allowing you to create a component (e.g. a JDialog) in just a couple of lines of code.
   We consistently see - even complex - dialogs and frames being parsed, built and shown in less than a second
   on 400 Mhz hardware running NT. (Linux performs REALLY nice too!).

   Finally, if you think things are a bit slow:  go to www.dell.com and browse around in their on-line store
   (or call 1-800-WWW-DELL). XwingML was conceived, designed, built and tested on a 400 Mhz OptiPlex and
   a 450 Mhz Dimesion XPS - those people in Texas have some good stuff and it works every time!

   Feedback:
   ---------

   Questions, comments, ideas, requests and modifications are welcome at:

   xwingml-talk@bluestone.com


   Bluestone Software, Inc.
   1000 Briggs Road
   Mt. Laurel, NJ 08054
   (856) 727-4600

   www.bluestone.com
   info@bluestone.com