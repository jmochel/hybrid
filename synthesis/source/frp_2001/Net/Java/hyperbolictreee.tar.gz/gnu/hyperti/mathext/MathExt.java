/**************************************************************************
/* MathExt.java
/*
/* Copyright (c) 1999 Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/* Author: Vladimir Bulatov <bulatov@dots.physics.orst.edu> (HyperProf)
/* 
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/* 
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/* 
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330,
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti.mathext;

/**
  * A class containing some static methods which are useful in doing some mathematical calculations
  * <p><p>
  * Please send all bug reports, requests, and comments to
  * Andreas Hadjiprocopis (<a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>).
  *
  * @version 1.0.7
  *
  * @author Andreas Hadjiprocopis (<a href="http://www.soi.city.ac.uk/homes/livantes">http://www.soi.city.ac.uk/homes/livantes</a>, <a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>)
  * @author Vladimir Bulatov (<a href="mailto:bulatov@dots.physics.orst.edu">bulatov@dots.physics.orst.edu</a>)
  *
  */

public class MathExt{
/**
  * A constant equal to twice the value of Math.PI (3.14...)
  */
	public	static final	double	PI2 = 2.0 * Math.PI;
/**
  * A constant equal to three times the value of half Math.PI
  */
	public	static final	double	PI3d2 = 1.5 * Math.PI;
/**
  * A constant equal to half the value of Math.PI
  */
	public	static final	double	PId2 = 0.5 * Math.PI;
/**
  * An angle in radians when multiplied by this constant is converted to degrees
  */
	public	static double	rad2grad = 180.0/Math.PI;


/**
  * Return the hyperbolic tangent of number x
  * @param x a real number
  */
	public static double tanh(double x){
		x = Math.exp(x); 
		x *= x;
		return (x-1)/(x+1);
	}
/**
  * Return the hyperbolic cosine of number x
  * @param x a real number
  */
	public static double cosh(double x){
		double y = Math.exp(x);
		return (y+1./y)/2;
	}
/**
  * Return the hyperbolic sine of number x
  * @param x a real number
  */
	public static double sinh(double x){
		double y = Math.exp(x);
		return (y-1./y)/2;
	}
/**
  * Return the inverse hyperbolic tangent of x
  * @param x a number
  */
	public static double atanh(double x){
		return 0.5*Math.log((1+x)/(1-x));
	}
/**
  * Return the inverse hyperbolic cosine of x
  * @param x a number
  */
	public static double acosh(double x){
		return Math.log(x+Math.sqrt(x*x-1));
	}
/**
  * Return the square of x
  * @param x a number
  */
	public static double sqr(double x){
		return x*x;
	}
/**
  * Convert an angle from radians to degrees
  * @param radians an angle in radians
  */
	public static double toDegrees(double radians){
		return radians * 360.0 / PI2;
	}
/**
  * Return the argument of the point (x, y). The argument is the angle
  * formed between the line connecting the point to the origin and the positive x-axis
  * @param x the X-dimension of the point
  * @param x the Y-dimension of the point
  */
	public static double atan(double y, double x){
		// will do arctan(y/x) in the proper way
		if( Math.abs(x) < 1.0E-03 ){
			if( y > 0 ) return PId2;
			if( y < 0 ) return -PId2;
			return 0.0;
		}
		double	a = Math.atan(Math.abs(y/x));
		if( (x>0) && (y<0) ) return -a;
		if( (x<0) && (y<0) ) return (Math.PI+a);
		if( (x<0) && (y>0) ) return (Math.PI-a);
		return a;
	}
/**
  * Return Euclidean distance between two points represented by the two complex numbers z1 and z2
  * @param z1 a complex number
  * @param z2 a complex number
  */
	public static double EuclideanDistance(Complex z1, Complex z2){
		return Math.sqrt(sqr(z1.re-z2.re)+sqr(z1.im-z2.im));
	}
/**
  * Return Euclidean distance between two points represented by (x1,y1) and (x2,y2)
  * @param x1 a number
  * @param y1 a number
  * @param x2 a number
  * @param y2 a number
  */
	public static double EuclideanDistance(double x1, double y1, double x2, double y2){
		return Math.sqrt(sqr(x1-x2) + sqr(y1-y2));
	}
}
