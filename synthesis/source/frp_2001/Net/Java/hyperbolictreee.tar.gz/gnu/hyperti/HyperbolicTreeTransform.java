/**************************************************************************
/* HyperbolicTreeTransform.java
/*
/* Copyright (c) 1999 Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* Authors: Andreas Hadjiprocopis <livantes@soi.city.ac.uk> and
/*          Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published 
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to 
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330, 
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import java.awt.*;

import gnu.hyperti.graphi.*;
import gnu.hyperti.mathext.*;

public class HyperbolicTreeTransform {
	static Arc	arc = new Arc();
	static Complex	ccenter = new Complex(0.0, 0.0),
			c1 = new Complex(0.0, 0.0),
			c2 = new Complex(0.0, 0.0),
			c3 = new Complex(0.0, 0.0);

	public	static void	establishPositions(Graph graph){
		if( (graph == null) || (graph.getNumLevels() < 1) ) return;

		HyperbolicTreeNode	a_node;
		double	r;

		calculateAngles(graph, (HyperbolicTreeNode )graph.getHead());
		calculateAnglesRelativeToOrigin(graph);

		for(Enumeration e=graph.getNodes().elements(); e.hasMoreElements();){
			a_node = (HyperbolicTreeNode )(e.nextElement());
			if( a_node.getParents() == null ) r = 0.0; // the parent is on zero radius
			else r = BukowskiRadius(a_node.level, graph.getNumLevels());
			a_node.place(r * Math.cos(a_node.angle), r * Math.sin(a_node.angle));
		}
	}
	private static void	calculateAnglesRelativeToOrigin(Graph graph){
		HyperbolicTreeNode	a_node, dummy_node;
		double	sum_sines, sum_cosines;
		
		for(Enumeration e=graph.getNodes().elements();e.hasMoreElements();){
			dummy_node = a_node = (HyperbolicTreeNode )(e.nextElement());
			if( a_node.parents == null || a_node.parents.isEmpty() ) a_node.angleRelativeToOrigin = a_node.angle;
			else {
				sum_sines = sum_cosines = 0.0;
				while( (dummy_node != null) && (dummy_node.parents != null) ){
					sum_sines += Math.sin(dummy_node.angle);
					sum_cosines += Math.cos(dummy_node.angle);
					dummy_node = (HyperbolicTreeNode )(dummy_node.parents.elementAt(0));
				}
				// the angle relative to origin is atan(sum of sines / sum of cosines)
				a_node.angleRelativeToOrigin = MathExt.atan(sum_sines, sum_cosines);
			}
		}
	}
	private static void	calculateAngles(Graph graph, HyperbolicTreeNode n){
		Enumeration	e;
		if( (e=n.getParents()) == null ){
			n.angle = 0;
			n.allocatedAngularWidth = MathExt.PI2;
		} else {
			HyperbolicTreeNode	a_parent = (HyperbolicTreeNode )(e.nextElement());
			double	averageAngle;

			if( graph.getHead() == a_parent){
				averageAngle = a_parent.allocatedAngularWidth / a_parent.numChildren;
				n.angle = a_parent.angle - (a_parent.allocatedAngularWidth)/2.0 +
						(a_parent.allocatedAngularWidth / ((double )(a_parent.numChildren)))
						* ((double )(n.childInList));
				n.allocatedAngularWidth = a_parent.allocatedAngularWidth / ((double )(a_parent.numChildren+1));
			} else {
				if( a_parent.numChildren > 1 ){
					averageAngle = a_parent.allocatedAngularWidth / ((double )(a_parent.numChildren-1));
					n.angle = a_parent.angle - (a_parent.allocatedAngularWidth)/2.0 +
							(a_parent.allocatedAngularWidth / ((double )(a_parent.numChildren-1)))
							* ((double )(n.childInList));
					if( n.numChildren > 0 )
						n.allocatedAngularWidth = a_parent.allocatedAngularWidth / ((double )(a_parent.numChildren+1));
					else {
						n.allocatedAngularWidth = 0.0;
						return;
					}
				} else {
					n.angle = a_parent.angle;
					n.allocatedAngularWidth = a_parent.allocatedAngularWidth;
				}
			}
		}
		// do the children
		if( (e=n.getChildren()) != null )
			while( e.hasMoreElements() ) calculateAngles(graph, (HyperbolicTreeNode )(e.nextElement()));
	}
	public static double	BukowskiRadius(int level, int numLevels){
		// given the level of a node, it returns the distance from the origin. e.g. the radius of
		// the concentric circle it belongs to.
		return MathExt.tanh(((double )(level+3))/((double )numLevels));
	}
	public static void	drawGeodArc(Graphics g, Complex z1, Complex z2, int originX, int originY, double scaleX, double scaleY){
		drawArc(g, getArc(z1, z2), originX, originY, scaleX, scaleY);
	}
	public static void	drawArc(Graphics g, double x, double y, double radius, double start, double angle, int originX, int originY, double scaleX, double scaleY){
		int n = Arc.segmentsInArc(radius, angle, originX, originY, scaleX, scaleY);
		int x0,y0,x1,y1;
		x0 = x2screen(x+radius*Math.cos(start), originX, scaleX);
		y0 = y2screen(y+radius*Math.sin(start), originY, scaleY);
		for(int i=1;i<=n;i++){
			double fi = start + i*angle/n;
			x1 = x2screen(x+radius*Math.cos(fi), originX, scaleX);
			y1 = y2screen(y+radius*Math.sin(fi), originY, scaleY);
//			System.out.println("x0, y0: "+x0+","+y0+", x1, y1: "+x1+", "+y1);
			g.drawLine(x0,y0, x1,y1);
			x0 = x1; y0 = y1;
		}
	}
	public static void	drawArc(Graphics g, Arc arc, int originX, int originY, double scaleX, double scaleY){
//		System.out.println("Arc: "+arc);
		if(arc.r == 0.0) drawLine(g, arc.x,arc.y,arc.start,arc.angle, originX, originY, scaleX, scaleY);
		else drawArc(g, arc.x, arc.y, arc.r, arc.start, arc.angle, originX, originY, scaleX, scaleY);
	}
	public static void	drawLine(Graphics g, double x1, double y1, double x2, double y2, int originX, int originY, double scaleX, double scaleY){
		g.drawLine(x2screen(x1, originX, scaleX), y2screen(y1, originY, scaleY),
			   x2screen(x2, originX, scaleX), y2screen(y2, originY, scaleY));
	}
	public static int	x2screen(double x, int originX, double scaleX){
		return (int)(scaleX*x)+ originX;
	}
	public static int	y2screen(double y, int originY, double scaleY){
		return (int)(scaleY*y) + originY;
	}
	public static double	screen2x(int x, int originX, double scaleX){
		return ((x - originX) / scaleX);
	}
	public static double	screen2y(int y, int originY, double scaleY){
		return ((y - originY) / scaleY);
	}
	public static Arc	getArc(Complex z1, Complex z2){
		Arc	an_arc = new Arc();

		if(Arc.ParallelArc(z1,z2)){
			an_arc.r = 0.0;
			an_arc.x = z1.re;
			an_arc.y = z1.im;
			an_arc.start = z2.re;
			an_arc.angle = z2.im;
			return an_arc;
		}
		double s1 = 1 + z1.abs2(), s2 = 1 + z2.abs2();
		double norm = 1/(2*(z1.re*z2.im - z2.re*z1.im));			   
		ccenter.set((s1*z2.im-s2*z1.im)*norm,-(s1*z2.re-s2*z1.re)*norm);
		double cradius = MathExt.EuclideanDistance(ccenter,z2);

		double angle1, angle2, minang, angle;

		c1.set(z1); c1.sub(ccenter); angle1= c1.arg(); //Arg(z1-ccenter);
		c2.set(z2); c2.sub(ccenter); angle2= c2.arg(); //Arg(z2-ccenter);
		
		if(angle1 < 0.0) angle1 += 2.0*Math.PI;
		if(angle2 < 0.0) angle2 += 2.0*Math.PI;
		minang = angle1;//(angle1 < angle2) ? angle1 : angle2;
		angle = angle2 - angle1;//(angle1 > angle2) ? angle1-angle2 : angle2-angle1;
		if(angle > Math.PI)
			angle -= 2.0*Math.PI;
		else if(angle < -Math.PI){
			angle += 2.0*Math.PI;
		}
		an_arc.x = ccenter.re;
		an_arc.y = ccenter.im;
		an_arc.r = cradius;
		an_arc.start = minang;
		an_arc.angle = angle;
		return an_arc;
	}
	public static void	doTranslate(Complex z,Complex p){ // z = (z+p)/(1+(p*)*z)
	    if (z == null) {
		return;
	    }
		c1.add(z,p);
		c2.conj(p);
		c3.mul(c2,z);
		c3.add(1);
		z.div(c1,c3);
	}
	public static void doTransform(Complex z,HTransform t){ 
		// z = (z*teta+p)/(1+(p*)*z)
		c1.mul(z,t.teta);
		c1.add(t.p);
		c2.conj(t.p);
		c3.mul(c2,z);
		c3.add(1);
		z.div(c1,c3);
	}
	public static void	doTransform(HTransform t1,HTransform t2){
		c1.set(t2.p).conj().mul(t1.p).mul(t2.teta).add(1.0);

		c2.mul(t2.teta,t1.p).add(t2.p);
		c3.set(t1.p).conj().mul(t2.p).add(t2.teta).mul(t1.teta);

		t1.p.div(c2,c1);
		t2.teta.div(c3,c1);
		t2.teta.div(t2.teta.abs());
	}
	public static double HyperDistance(Complex z){
		return e2h(z.abs());
	}
	public static double e2h(double x){
		return 2.0*MathExt.atanh(x);
	}
	public static double h2e(double h){
		return MathExt.tanh(h*0.5);
	}
	public static void reflect(Complex p,Arc arc){
		if(arc.r == 0.0){ // strait line
			double qx = arc.x, qy = arc.y, px = arc.start, py = arc.angle;
			double denom = MathExt.sqr(qx-px)+ MathExt.sqr(qy-py);
			double t = py*(qx-p.re)-qy*(px-p.re)+p.im*(px-qx);
			p.set(p.re+2*(py-qy)*t, p.im+21*(px+qx)*t);
		} else {
			double denom = MathExt.sqr(p.re-arc.x) + MathExt.sqr(p.im-arc.y);
			double r2 = arc.r*arc.r;
			p.set(arc.x + r2*(p.re-arc.x)/denom, arc.y + r2*(p.im-arc.y)/denom);
		}
	}
	public static void drawPoly(Graphics g, Complex[] vert, int nvert, int originX, int originY, double scaleX, double scaleY){
		Complex c = vert[nvert-1];
		for(int i=0; i < nvert; i++){
			drawGeodArc(g,c,vert[i], originX, originY, scaleX, scaleY);
			c = vert[i];
		}
	}		
	public static void fillPoly(Graphics g, Complex[] vert, int nvert, int originX, int originY, double scaleX, double scaleY){
		Complex c = vert[nvert-1];
		Arc[] arc = new Arc[nvert];
		for(int i=0; i < nvert; i++){
			arc[i] = getArc(c,vert[i]);
			c = vert[i];
		}
		fillArcs(g, arc, originX, originY, scaleX, scaleY);
	}
	public static void fillArcs(Graphics g, Arc[] arc, int originX, int originY, double scaleX, double scaleY){
		int nvert = 0; // number of verteces
		for(int i=0; i < arc.length;i++){
			Arc a = arc[i];
			nvert += Arc.segmentsInArc(a.r, a.angle, originX, originY, scaleX, scaleY);
		}
		int[] x = new int[nvert];
		int[] y = new int[nvert];
		int n = 0;
		for(int i=0; i < arc.length;i++){
			Arc a = arc[i];
			int nv = Arc.segmentsInArc(a.r, a.angle, originX, originY, scaleX, scaleY);
			if(a.r == 0.0){	// strait line
				x[n] = x2screen(a.x, originX, scaleX);
				y[n] = y2screen(a.y, originY, scaleY);
				n++;
			} else {
				for(int j = 0; j < nv; j++){
					double fi = a.start + j*a.angle/nv;
					x[n] = x2screen(a.x+a.r*Math.cos(fi), originX, scaleX);
					y[n] = y2screen(a.y+a.r*Math.sin(fi), originY, scaleY);
					n++;
				}
			}
		}
		g.fillPolygon(x,y,nvert);
		g.drawPolygon(x,y,nvert);
	}
	public static void drawCircle(Graphics g, double x, double y, double radius, int originX, int originY, double scaleX, double scaleY){
//		g.drawOval(x2screen(x-radius, originX, scaleX),y2screen(y-radius, originY, scaleY), x2screen(2*radius, originX, scaleX),y2screen(2*radius, originY, scaleY));
		g.drawOval(x2screen(x-radius, originX, scaleX),y2screen(y-radius, originY, scaleY), (int )(2*radius*scaleX), (int )(2*radius*scaleY));
	}
	public static void fillCircle(Graphics g, double x, double y, double radius, int originX, int originY, double scaleX, double scaleY){
		g.fillOval(x2screen(x-radius, originX, scaleX),y2screen(y-radius, originY, scaleY), (int )(2*radius*scaleX), (int )(2*radius*scaleY));
//		System.out.println("Fill circle: scalex="+scaleX+", scaleY="+scaleY+", originX="+originX+", originY="+originY+"at x="+(x2screen(x-radius, originX, scaleX))+", "+(y2screen(y-radius, originY, scaleY)));
//		System.out.println("X="+x+", y="+y+", r="+radius+" real radius="+((int )(2*radius*scaleY)));
	}
}
