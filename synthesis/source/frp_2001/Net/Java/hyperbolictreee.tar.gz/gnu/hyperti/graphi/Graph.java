/**************************************************************************
/* Graph.java
/*
/* Copyright (c) 1999 Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* Author: Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* 
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/* 
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/* 
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330,
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti.graphi;

import	java.util.Vector;
import	java.util.Hashtable;
import	java.util.Enumeration;

/**
  * A class implementing a <b>basic unidirectional</b> graph consisting of nodes
  * which are connected with edges. The hyperbolic tree is a construction which
  * uses such a graph to represent its data. In order to create a graph, one has
  * to create the nodes first. Then chose one which will be the Head. All other
  * nodes are inserted into the graph by connecting them to already entered nodes.
  * Here is an example:
  *<P>
  *<pre><code>
  *  public Graph makeGraph(){
  *      // an array of nodes ...
  *      // MyHyperbolicNode extends the basic node class Node
  *      MyHyperbolicNode   nodes[];
  *      nodes = new MyHyperbolicNode[8];
  *      // this is the head of the tree:
  *      nodes[0] = new MyHyperbolicNode("Head");
  * 
  *      // create the other nodes too:
  *      for(int i=1;i<code><</code>nodes.length;i++)
  *        nodes[i] = new MyHyperbolicNode(""+i);
  * 
  *      // create the graph to hold the nodes by specifying the head
  *      Graph gr = new Graph(nodes[0]);
  *      // then add nodes to the graph by the method ``connect''
  *      // this means that you can not add nodes which are not directly or
  *      // indirectly connected to the head.
  *      gr.connect(nodes[0], nodes[1]);
  *      gr.connect(nodes[0], nodes[2]);
  *      gr.connect(nodes[0], nodes[3]);
  *      // Now 3 nodes are around the head
  *      // extend the tree by:
  *      gr.connect(nodes[3], nodes[4]);
  *      gr.connect(nodes[3], nodes[5]);
  *      gr.connect(nodes[1], nodes[6]);
  *      gr.connect(nodes[2], nodes[7]);
  * 
  *      // We are finished with this graph. Calculate positions etc:
  *      gr.calculate();
  *      return gr;
  *  }
  *</pre></code>
  *<P><P>
  * Please send all bug reports, requests, and comments to
  * Andreas Hadjiprocopis (<a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>).
  *
  * @version 1.0.7
  *
  * @author Andreas Hadjiprocopis (<a href="http://www.soi.city.ac.uk/homes/livantes">http://www.soi.city.ac.uk/homes/livantes</a>, <a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>) NetAesthetics & NoodleWoman Software
  *
  */

public class	Graph {
	private Node		head = null;
	private	Hashtable	nodes = null,
				edges = null;
	private int		numLevels = 0;
/**
  * Create a new graph and assign the head-node.
  * @param head the head-node. The head-node is displayed in the center of the canvas at start-up.
  */
	public Graph(Node head){
		this.head = head;
		this.head.graph = this;
	}
	// to be called whenever is needed to recalculate levels etc.
/**
  * After adding nodes to the graph, the programmer must force it to recalculate their positions.
  * This method does just that. Isn't that great?
  */
	public void	calculate(){
		Node	a_node;
		this.calculateLevels(head);

		if( this.numLevels == 0 || this.nodes == null || this.nodes.isEmpty()) return;
		//System.out.println(nodes);
		for(Enumeration e=this.nodes.elements();e.hasMoreElements();){
			a_node = (Node )(e.nextElement());
			a_node.calculateChildInList();
		}
	}
	private void	calculateLevels(Node n){
		Enumeration	parents = null,
				children = null;
		int	max_levels = -1;

		if( n == null ) return;

		if( (parents=n.getParents()) == null ){
			n.setLevel(0);
		} else {
			while(parents.hasMoreElements())
				max_levels = Math.max(max_levels, ((Node )(parents.nextElement())).level);
			n.setLevel(max_levels + 1);
		}
		this.numLevels = Math.max(this.numLevels, n.level+1);
		if( (children=n.getChildren()) != null ){
			max_levels = -1;
			while(children.hasMoreElements())
				this.calculateLevels((Node )(children.nextElement()));
		}
	}
/**
  * It returns the maximum distance (in nodes) of a node from the head.
  */
	public	int	getNumLevels(){
		return numLevels;
	}
	// make n1 parent and n2 child
/**
  * Connect node n2 to node n1. In other words, node n1 already exists in the graph, while
  * node n2 is now added. This is the only way to add nodes to the graph.
  * @param n1 a node already in the graph
  * @param n2 a node which will be connected on n1
  */
	public boolean	connect(Node n1, Node n2){
		String	eCode, n1Code, n2Code;
		n1Code = n1.hCode;
		n2Code = n2.hCode;
		eCode = n1.hCode+"."+n2.hCode;

		if( edges == null ) edges = new Hashtable();
		if( edges.get(eCode) != null ) return false;
		edges.put(eCode, new Edge(n1, n2));

		if( nodes == null ) nodes = new Hashtable();

		if( nodes.get(n1.hCode) == null ) nodes.put(n1Code, n1);
		if( nodes.get(n2.hCode) == null ) nodes.put(n2Code, n2);

		n2.addParent(n1);
		n1.addChild(n2);
		n2.graph = this;
		return true;
	}
	// removes the edge connecting n1 to n2 (and not vice versa)
	public boolean	disconnect(Node n1, Node n2){
	    System.out.println("Disconnecting edge connecting " + n1 + " and " + n2 );
	    if( (edges == null) || (nodes == null) ) return false;

		String	eCode, n1Code, n2Code, s;

		n1Code = n1.hCode;
		n2Code = n2.hCode;
		eCode = n1Code+"."+n2Code;
		if( edges.get(eCode) != null ){
		    boolean returnVal = (edges.remove(eCode) != null);
			// are the nodes used in other edges? or shall we delete them?
			boolean	n1NotFound = true;
			boolean	n2NotFound = true;
			for(Enumeration e=edges.keys();(e.hasMoreElements())&&(n1NotFound||n2NotFound);){
				s = (String )(e.nextElement());
				if( n1NotFound && (s.endsWith(n1Code) || (s.startsWith(n1Code))) ) n1NotFound = false;
				if( n2NotFound && (s.endsWith(n2Code) || (s.startsWith(n2Code))) ) n2NotFound = false;
			}
			// if nodes not used in any other edge, delete them 
			// else just tell the nodes, that this parent/child is not there any more
			System.out.println("n1NotFound: " + n1NotFound + " n2NotFound: " + n2NotFound);
			if( n1NotFound ) nodes.remove(n1Code);
			else n1.removeChild(n2);

			if( n2NotFound ) nodes.remove(n2Code);
			else n2.removeParent(n1);			

			// found the edge, delete it
			return returnVal;
		}
		return false;
	}
/**
  * Return all the nodes in this graph as a hashtable
  */
	public Hashtable	getNodes(){
		return nodes;
	}
/**
  * Return all the edges (a pair of connected nodes) in this graph as a hashtable
  */
	public Hashtable	getEdges(){
		return edges;
	}
/**
  * Return the head-node of this graph
  */
	public Node		getHead(){
		return head;
	}
/**
  * Return the contents of the graph as a string
  */
	public String	toString(){
		String	s = "Number of levels: "+numLevels+"\nList of nodes:\n";
		Node	a_node;
		Edge	an_edge;
		for(Enumeration e=nodes.keys();e.hasMoreElements();){			
			a_node = (Node )(nodes.get((String )(e.nextElement())));
			s += a_node.toString() + "\n";
		}
		s += "List of edges:\n";
		for(Enumeration e=edges.keys();e.hasMoreElements();){
			an_edge = (Edge )(edges.get((String )(e.nextElement())));
			s += "\t---------------------------\n"+an_edge.from.toString() + "\n\t ** connects to **\n"+ an_edge.to.toString()+"\n\t---------------------------\n";
		}
		return s;
	}
}
