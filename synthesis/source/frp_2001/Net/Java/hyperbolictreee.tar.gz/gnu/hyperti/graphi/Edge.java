/**************************************************************************
/* Edge.java
/*
/* Copyright (c) 1999 Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/* Authors: Vladimir Bulatov <bulatov@dots.physics.orst.edu> (HyperProf) and
/*          Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published 
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to 
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330, 
/* Boston, MA  02111-1307 USA
/**************************************************************************/


package gnu.hyperti.graphi;

public	class	Edge {
	public	Node	from = null,
			to = null;
	public	String	hCode = "";
	// constructor
	public	Edge(Node from, Node to){
		this.from = from;
		this.to = to;
		hCode = from.hCode+"."+to.hCode;
	}
	public String	toString(){
		return "\t"+from.hCode+"\n\t connects to \n"+to.hCode;
	}
}
