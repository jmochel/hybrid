/**************************************************************************
/* Complex.java
/*
/* Copyright (c) 1999 Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/* Author: Vladimir Bulatov <bulatov@dots.physics.orst.edu> (HyperProf)
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330,
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti.mathext;

/**
  * A class for the construction and manipulation of complex numbers.
  * <p><p>
  * Please send all bug reports, requests, and comments to
  * Andreas Hadjiprocopis (<a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>).
  *
  * @version 1.0.7
  *
  * @author Vladimir Bulatov (<a href="mailto:bulatov@dots.physics.orst.edu">bulatov@dots.physics.orst.edu</a>)
  *
  */

public class Complex {
/**
  * The real part of this complex number
  */
	public double re;
/**
  * The imaginary part of this complex number
  */
	public double im;
/**
  * Unity
  */
	static Complex i = new Complex(0.0, 1.0);


/**
  * Construct a complex number given the real and imaginary parts.
  * @param x the real part
  * @param y the imaginary part
  */
	public Complex(double x,double y){
		re = x;
		im = y;
	}
/**
  * Duplicate the given complex number
  * @param z the complex number to duplicate
  */
	public Complex(Complex z){
		this.re = z.re;
		this.im = z.im;
	}

/**
  * Add two complex numbers and return their sum as a new complex number
  * @param a a complex number
  * @param b a complex number to add to a
  */
	public Complex add(Complex a,Complex b){
	    if (a == null || b == null) {
		return null;
	    }
		re = a.re + b.re;
		im = a.im + b.im;
		return this;
	}
/**
  * Add a complex number to this complex number and return the result
  * @param a a complex number
  */
	public Complex add(Complex a){
	    if (a == null) {
		return null;
	    }
		re += a.re;
		im += a.im;
		return this;
	}
/**
  * Add real number a to the real component of this complex number
  * @param a a real number
  */
	public Complex add(double a){
		re += a;
		return this;
	}
/**
  * Add a to the real component and b to the imaginary component of this complex number
  * @param a a number to be added to the real part of this complex number
  * @param b a number to be added to the imaginary part of this complex number
  */
	public Complex add(double a,double b){
		re += a;
		im += b;
		return this;
	}
/**
  * Subtract a complex number from this complex number and return the result
  * @param a a complex number
  */
	public Complex sub(Complex a){
		re -= a.re;
		im -= a.im;
		return this;
	}
/**
  * Subtract two complex numbers and return their subtract as a new complex number
  * @param a a complex number
  * @param b a complex number to subtract from a
  */
	public Complex sub(Complex a, Complex b){
		re = a.re - b.re;
		im = a.im - b.im;
		return this;
	}
/**
  * Conjucate this complex number and return the result. Conjucate is when the imaginary part is negated.
  */
	public Complex conj(){
		im = -im;
		return this;
	}
/**
  * Return the conjucate of the specified complex number. Conjucate is when the imaginary part is negated.
  * @param a a complex number
  */
	public Complex conj(Complex a){
		re = a.re;
		im = -a.im;
		return this;
	}
/**
  * Negate this complex number and return the result. Negation is when both real and imaginary parts are negated (get their negative value, meaning if negative will yield positive and vice versa)
  */
	public Complex neg(){
		re = -re;
		im = -im;
		return this;
	}
/**
  * Negate the complex number a and return the result. Negation is when both real and imaginary parts are negated (get their negative value, meaning if negative will yield positive and vice versa)
  * @param a a complex number
  */
	public Complex neg(Complex a){
		re = -a.re;
		im = -a.im;
		return this;
	}
/**
  * Divide a over b and set this complex number equal to the (returned) result.
  * @param a a complex number
  * @param b a complex number
  */
	public Complex div(Complex a, Complex b){
		double d = b.re*b.re+b.im*b.im;
		re = (a.re*b.re+a.im*b.im)/d;
		im = (a.im*b.re-a.re*b.im)/d;
		return this;
	}
/**
  * Divide this complex number over a and set it equal to the (returned) result
  * @param a a complex number
  */
	public Complex div(Complex a){
		double d = a.re*a.re+a.im*a.im;
		double t = (re*a.re+im*a.im)/d;
		im = (im*a.re-re*a.im)/d;
		re = t;
		return this;
	}
/**
  * Divide this complex number over the scalar b
  * @param b a scalar
  */
	public Complex div(double b){
		im /= b;
		re /= b;
		return this;
	}
/**
  * Multiply a times b and set this complex number equal to the (returned) result.
  * @param a a complex number
  * @param b a complex number
  */
	public Complex mul(Complex a,Complex b){
	    if (a == null || b == null) {
		return null;
	    }
		re = a.re * b.re - a.im * b.im;
		im = a.re * b.im + a.im * b.re;
		return this;
	}
/**
  * Multiply a times a scalar b and set this complex number equal to the (returned) result.
  * @param a a complex number
  * @param b a scalar
  */
	public Complex mul(Complex a, double b){
	    if (a == null) {
		return null;
	    }
		im = a.im * b;
		re = a.re * b;
		return this;
	}
/**
  * Multiply this complex number times a complex b and set this complex number equal to the (returned) result.
  * @param b a complex number
  */
	public Complex mul(Complex b){
	    if (b == null) {
		return null;
	    }
		double t = re * b.re - im * b.im;
		im = re * b.im + im * b.re;
		re = t;
		return this;
	}
/**
  * Multiply this complex number times a scalar b
  * @param b a scalar
  */
	public Complex mul(double b){
		im *= b;
		re *= b;
		return this;
	}
/**
  * Set this complex number equal to a
  * @param a a complex number
  */
	public Complex set(Complex a){
		re = a.re;
		im = a.im;
		return this;
	}
/**
  * Set the real part of this complex number to x and its imaginary part to y
  * @param x a scalar
  * @param y a scalar
  */
	public Complex set(double x, double y){
		re = x;
		im = y;
		return this;
	}
/**
  * Returns the square of the distance of the point representing this complex number from the origin (0,0)
  */
	public double abs2(){
		return re*re+im*im;
	}
/**
  * Returns the distance of the point representing this complex number from the origin (0,0)
  */
	public double abs(){
		return Math.sqrt(abs2());
	}
/**
  * Returns the angle (argument) in radians that the line joining the origin (0,0) to this complex number forms with the positive horizontal axis
  */
	public double arg(){
		return Math.atan2(im,re);
	}
/**
  * Normalisation of a complex number consists of translating it so that its distance from the origin (0,0) is unit.
  */
	public Complex normalize(){
		double r = abs();
		re /= r;
		im /= r;
		return this;
	}
/**
  * Return a string representation of this complex number
  */
	public String toString(){
		return "("+ String.valueOf(re) + "," + String.valueOf(im) + ")";
	}
}
