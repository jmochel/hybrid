import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.*;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;


import	gnu.hyperti.HyperbolicTree;
import	gnu.hyperti.HyperbolicTreeNode;
import	gnu.hyperti.graphi.Graph;
 
public	class Paroutis extends Applet {
	static HyperbolicTree	ht;
	static Graph		cg;
	static Graph		g;

	public static void	main(String args[]){
		Frame	f = new Frame("Hyperbolic Tree");
		f.setSize(500,500);
		f.setLayout(new BorderLayout());
		Main(args);
		f.add("Center", ht);
		f.addWindowListener(new WindowListener() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
			public	void windowDeiconified(WindowEvent e){}
			public	void windowIconified(WindowEvent e){}
			public	void windowDeactivated(WindowEvent e){}
			public	void windowOpened(WindowEvent e){}
			public	void windowClosed(WindowEvent e){}
			public	void windowActivated(WindowEvent e){}
		});

		f.show();
	}

	public static void	Main(String args[]){
		MyHyperbolicNode	head, n[];
		n = new MyHyperbolicNode[27];
		head = new MyHyperbolicNode("Head");
		for(int i=0;i<n.length;i++) n[i] = new MyHyperbolicNode("n"+(i+1));

		ht = new HyperbolicTree(head, 500,500);
		ht.connect(head, n[0]);
		ht.connect(head, n[1]);
		ht.connect(head, n[2]);

		ht.connect(n[0], n[3]);
		ht.connect(n[0], n[4]);

		ht.connect(n[1], n[5]);
		ht.connect(n[1], n[6]);
		ht.connect(n[1], n[7]);

		ht.connect(n[2], n[8]);
		ht.connect(n[2], n[9]);
		ht.connect(n[2], n[25]);
		ht.connect(n[2], n[26]);

		ht.connect(n[3], n[10]);
		ht.connect(n[3], n[11]);
		ht.connect(n[3], n[12]);

		ht.connect(n[4], n[13]);
		ht.connect(n[4], n[14]);
		ht.connect(n[4], n[15]);
		ht.connect(n[4], n[16]);

		ht.connect(n[5], n[17]);

		ht.connect(n[7], n[18]);
		ht.connect(n[7], n[19]);
		ht.connect(n[7], n[20]);

		ht.connect(n[9], n[21]);
		ht.connect(n[9], n[22]);
		ht.connect(n[9], n[23]);
		ht.connect(n[9], n[24]);

//		g.calculate();

	}

	public	void	init(){
		BorderLayout	borderLayout = new BorderLayout();
//		setSize(100,100);
		setLayout(borderLayout);

		Main((String [])null);
		add("Center", ht);
//		System.out.println(ht);
	}
}

class	MyHyperbolicNode extends HyperbolicTreeNode {
	String	contents = "";

	public	MyHyperbolicNode(String contents){
		super();
		this.contents = contents;
	}
	public	String	toString(){
		return "\tname: "+contents+"\n"+super.toString();
	}
	public void draw(Graphics g, int originX, int originY, double scaleX, double scaleY){
//		super.draw(g, originX, originY, scaleX, scaleY);
		fill(Color.red, g, originX, originY, scaleX, scaleY);
		outline(Color.black, g, originX, originY, scaleX, scaleY);
		drawEdge(Color.blue, g, originX, originY, scaleX, scaleY);
		// and now print its name (contents) or anything else you wish
		g.setColor(Color.black);
		g.drawString(contents, originX+(int )(ecenterx*scaleX), originY+(int )(ecentery*scaleY));
	}
	public void clicked(int x, int y){
		super.clicked(x, y);
		System.out.println("I ("+contents+") was clicked. The mouse was at ("+x+" ,"+y+")");
	}
}
