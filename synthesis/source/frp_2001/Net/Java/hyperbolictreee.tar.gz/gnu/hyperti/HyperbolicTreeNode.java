/**************************************************************************
/* HyperbolicTreeNode.java
/*
/* Copyright (c) 1999 Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* Authors: Andreas Hadjiprocopis <livantes@soi.city.ac.uk> and
/*          Vladimir Bulatov <bulatov@dots.physics.orst.edu> (HyperProf)
/*          
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published 
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to 
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330, 
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti;

import	java.util.Vector;
import	java.util.Enumeration;
import	java.awt.Color;
import	java.awt.Graphics;

import	gnu.hyperti.mathext.*;
import	gnu.hyperti.graphi.*;

/**************************************************************************/
/**
   * This is a class implementing a basic node for a hyperbolic tree.
  * More complex nodes which might be made so as to accomodate user data and
  * painted according to user's specifications may be constructed by
  * extending this basic class.
  * <P>
  * This is an example of how you can add the following enhancements:
  * <i>HyperbolicTreeNode</i> class in the following way:
  * * <b>Firstly</b>, add an object (String contents) which will hold the name of the node.
  * * <b>Secondly</b>, overwrite the <i>draw</i> method of the <i>HyperbolicTreeNode</i> so
  * * that a node is drawn in red color with a black outline, the edge connecting the node to its
  * * parent is drawn in a blue color and the name of the node is drawn in black color.
  * * <b>Thirdly</b>, overwrite the <i>clicked</i> method of the <i>HyperbolicTreeNode</i> so
  * * that, when a node is clicked we get a notification (just a println) as well as the default
  * * reaction which is to call the method <i>onFocus()</i> and move the node in the center
  * * of the canvas.
  *<p>
  * <pre><code>
  *  import gnu.hyperti.HyperbolicTreeNode;
  *  import  java.awt.*;
  * class MyHyperbolicNode extends HyperbolicTreeNode {
  *     String    contents = "";
  * 
  *     public    MyHyperbolicNode(String contents){
  *         super();
  *         this.contents = contents;
  *     }
  *     public    String    toString(){
  *         return "\tname: "+contents+"\n"+super.toString();
  *     }
  *     public void draw(Graphics g, int originX, int originY, double scaleX, double scaleY){
  *         fill(Color.red, g, originX, originY, scaleX, scaleY);
  *         outline(Color.black, g, originX, originY, scaleX, scaleY);
  *         drawEdge(Color.blue, g, originX, originY, scaleX, scaleY);
  *         // and now print its name (contents) or anything else you wish
  *         g.setColor(Color.black);
  *         g.drawString(contents, originX+(int )(ecenterx*scaleX), originY+(int )(ecentery*scaleY));
  *     }
  *     public void clicked(int x, int y){
  *         super.clicked(x, y);
  *         System.out.println("I ("+contents+") was clicked. The mouse was at ("+x+" ,"+y+")");
  *     }
  * }
  * </code></pre>
  *<P><P>
  * Please send all bug reports, requests, and comments to
  * Andreas Hadjiprocopis (<a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>).
  *
  * @version 1.0.7
  *
  * @author Andreas Hadjiprocopis (<a href="http://www.soi.city.ac.uk/homes/livantes">http://www.soi.city.ac.uk/homes/livantes</a>, <a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>) NetAesthetics & NoodleWoman Software
  * @author Vladimir Bulatov (<a href="mailto:bulatov@dots.physics.orst.edu">bulatov@dots.physics.orst.edu</a>)
  *
  */

public class HyperbolicTreeNode extends Node {
/** The angle specified by the positive X-axis and the line joining the node and the origin. <b>Internal use only!</b>.
  */
	public  double  angleRelativeToOrigin = 0.0;
/** The angle of the node relative to its parent's angle. <b>Internal use only!</b>.
  */
	public	double	angle = 0.0;
/** The angle span the children of this node are allowed to have. <b>Internal use only!</b>.
  */
	public  double	allocatedAngularWidth = 0.0;
/**
  * The position of this node on the hyperbolic plane is represented by this complex number
  */
	public	Complex	z;
/**
  * The radius of this node on the hyperbolic plane increases or decreases depending on the distance of the node from the center of the display
  */
	public	double radius;
/**
  * The radius of this node on the euclidean plane -- this is fixed and independent of the position of the node
  */
	public	double eradius; // euclidean radius
/**
  * The position of the node in the euclidean plane -- X-coordinate.
  */
	public	double ecenterx;// euclidean positions
/**
  * The position of the node in the euclidean plane -- X-coordinate.
  */
	public	double ecentery;// euclidean positions
	// constructor
/**
  * The constructor for a hyperbolic tree node. The node's position is not yet set,
  * while raius is set to default value.
  */
	public	HyperbolicTreeNode(){
		super();
		this.z = null;
		this.radius = 0.2;
	}
/**
  * The node has been clicked. The mouse pointer was at screen coordinates (x,y) when this happened.
  * Overwrite this method if you want to get notification when a node is clicked. By default,
  * this method moves the node to the center of the display -- in focus.
  * @param x the X-coordinate of the mouse pointer when the click happened
  * @param y the Y-coordinate of the mouse pointer when the click happened
  */
	public void	clicked(int x, int y){
		onFocus();
	}
/**
  * Move all the nodes so that this node is in the center/focus of the display.
  */
	public	void	onFocus(){
		((HyperbolicTreeNode )(graph.getHead())).doTranslate(new Complex(-z.re, -z.im));
	}
/**
  * Place the node at a specified location.
  * This method is not intended to be used by users. Its scope
  * is internal.
  * @param x the x-location
  * @param y the y_location
  */
	public void place(double x, double y){
		if( z == null ) z = new Complex(x, y);
		else z.set(x,y);
		this.recalculate();
	}
/**
  * Translate the node by the amount specified by the real and imaginary parts of the complex number p.
  * This method is not intended to be used by users. Its scope
  * is internal.
  * @param p a complex number (imagine it like java's Dimension).
  */
	public void doTranslate(Complex p){
		HyperbolicTreeTransform.doTranslate(z,p);
		this.recalculate();
		if( children == null || children.isEmpty() ) {
		    return;
		}
		for(int i=0; i<children.size(); i++)
		    ((HyperbolicTreeNode )(children.elementAt(i))).doTranslate(p);
	}
/**
  * Rotate the node by an angle which is specified by the real and imaginary parts of the complex number p.
  * This method is not intended to be used by users. Its scope
  * is internal.
  * @param p a complex number (imagine it like java's Dimension). The tangent of the angle (also known as the argument of the
  * number) is the ratio of the real over the imaginary parts of p
  */
	public void doRotate(Complex teta){
		z.mul(teta);
		this.recalculate();
		if( children != null )
			for(int i=0; i<children.size(); i++)
				((HyperbolicTreeNode )(children.elementAt(i))).doRotate(teta);
	}
/**
  * Apply a transform to this node. A transform consists of a series of rotations and translations
  * This method is not intended to be used by users. Its scope
  * is internal.
  * @param t is the transform
  */
	public void doTransform(HTransform t){
		HyperbolicTreeTransform.doTransform(z,t);
		this.recalculate();
	}
/**
  * Reflect the node about the specified arc. In euclidean geometry, the reflection of a node (a point)
  * is about a line.
  * This method is not intended to be used by users. Its scope
  * is internal.
  * @param arc specifies an arc
  */
	public void reflect(Arc arc){
		HyperbolicTreeTransform.reflect(z,arc);		 
		this.recalculate();
	}


	// temporary variables
	private static Complex z1 = new Complex(0.0, 0.0), z2 = new Complex(0.0, 0.0);
/**
  * This method is called whenever a transform is applied on the node or its position or size
  * somehow changes.
  */
	public void recalculate(){
		// euclidean radius 
		double erad = MathExt.tanh(0.5*radius);
		if (z == null) {
		    return;
		}
		double zlen = z.abs();
		// move cyrcle in place
		if(zlen != 0.0){
			z1.set(erad*z.re/zlen,erad*z.im/zlen);	
			z2.set(-erad*z.re/zlen,-erad*z.im/zlen);
			HyperbolicTreeTransform.doTranslate(z1,z);
			HyperbolicTreeTransform.doTranslate(z2,z);
			z1.add(z2); z1.mul(0.5); 
			z2.sub(z1);
			// euclidean radius of moved cyrcle
			eradius = z2.abs();
			ecenterx = z1.re;
			ecentery = z1.im;
		} else {
			eradius = erad;
			ecenterx = z.re;
			ecentery = z.im;
		}
	}
/**
  * This method is responsible for drawing the node onto the canvas as a circle filled with red color.
  * When this basic node class is extended, this method may be overwritten
  * in order to supply greater functionality and flexibility. For example, a node may or may not
  * be visible, or some text should be rendered near the node, the edge and node color may change etc.
  * @param g the Graphic context
  * @param originX the X-component of the origin of the coordinate system
  * @param originY the Y-component of the origin of the coordinate system
  * @param scaleX the amount of scaling in the X-dimension so as the graph to fit onto the canvas
  * @param scaleY the amount of scaling in the Y-dimension so as the graph to fit onto the canvas
  */
	public void draw(Graphics g, int originX, int originY, double scaleX, double scaleY){
		drawEdge(Color.blue, g, originX, originY, scaleX, scaleY);
		fill(Color.red, g, originX, originY, scaleX, scaleY);
	}
/**
  * This method will draw a geodesic arc connecting this node with its parent node. In other words,
  * this method draws the edges connecting the node and its parent
  * @param color the color of the edge to draw
  * @param g the Graphic context
  * @param originX the X-component of the origin of the coordinate system
  * @param originY the Y-component of the origin of the coordinate system
  * @param scaleX the amount of scaling in the X-dimension so as the graph to fit onto the canvas
  * @param scaleY the amount of scaling in the Y-dimension so as the graph to fit onto the canvas
  */
	public void drawEdge(Color color, Graphics g, int originX, int originY, double scaleX, double scaleY){
                // draw the edge connecting this node to its *parent*
		if( parents == null || parents.isEmpty()) return;
		g.setColor(color);
		HyperbolicTreeTransform.drawGeodArc(g, ((HyperbolicTreeNode )(parents.elementAt(0))).z, z, originX, originY, scaleX, scaleY);
	}

/**
  * This method should be used in conjuction with the draw method. It represents the node as a
  * circle and fills it with the node's current background color.
  * @param color the color of the node to fill
  * @param g the Graphic context
  * @param originX the X-component of the origin of the coordinate system
  * @param originY the Y-component of the origin of the coordinate system
  * @param scaleX the amount of scaling in the X-dimension so as the graph to fit onto the canvas
  * @param scaleY the amount of scaling in the Y-dimension so as the graph to fit onto the canvas
  */
	public	void fill(Color color, Graphics g, int originX, int originY, double scaleX, double scaleY){
		g.setColor(color);
		HyperbolicTreeTransform.fillCircle(g, ecenterx, ecentery, eradius, originX, originY, scaleX, scaleY);
	}
/**
  * This method should be used in conjuction with the draw method. It represents the node as a
  * circle -- no filling.
  * @param color the color of the node outline
  * @param g the Graphic context
  * @param originX the X-component of the origin of the coordinate system
  * @param originY the Y-component of the origin of the coordinate system
  * @param scaleX the amount of scaling in the X-dimension so as the graph to fit onto the canvas
  * @param scaleY the amount of scaling in the Y-dimension so as the graph to fit onto the canvas
  */
	public	void outline(Color color, Graphics g, int originX, int originY, double scaleX, double scaleY){
		g.setColor(color);
		HyperbolicTreeTransform.drawCircle(g, ecenterx, ecentery, eradius, originX, originY, scaleX, scaleY);
	}
/**
  * Given the cartesian position of the node (ex, ey), this method will return the nearest node or
  * null if there is no node in the vincinity of this point. This method is used to find the
  * node when the user clicks with the mouse.
  * @param ex is the X-component of the cartesian point (as given by the MouseEvent.getX() method)
  * @param ey is the Y-component of the cartesian point (as given by the MouseEvent.getY() method)
  * @param originX the X-component of the origin of the coordinate system
  * @param originY the Y-component of the origin of the coordinate system
  * @param scaleX the amount of scaling in the X-dimension so as the graph to fit onto the canvas
  * @param scaleY the amount of scaling in the Y-dimension so as the graph to fit onto the canvas
  */
	public	HyperbolicTreeNode	findNode(int ex, int ey, int originX, int originY, double scaleX, double scaleY){
		// given euclidean point ex, ey, compare it with euclidean
		// center ecenterx=z.re, ecentery=z.im and see if they match within the radius of the node (eradius)
		HyperbolicTreeNode	n;

		double			d = MathExt.EuclideanDistance(	HyperbolicTreeTransform.screen2x(ex, originX, scaleX),
									HyperbolicTreeTransform.screen2y(ey, originY, scaleY),
									z.re, z.im );
		if( d <= eradius )  return this;
		if(children != null)
			for(int i=0; i < children.size(); i++)
				if( (n=((HyperbolicTreeNode)(children.elementAt(i))).findNode(ex, ey, originX, originY, scaleX, scaleY)) != null ) return n;

		return (HyperbolicTreeNode )null;
	}
}
