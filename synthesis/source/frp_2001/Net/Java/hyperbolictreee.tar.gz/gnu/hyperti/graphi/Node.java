/**************************************************************************
/* Node.java
/*
/* Copyright (c) 1999 Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* Author: Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* 
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/* 
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/* 
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330,
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti.graphi;

import	java.util.Vector;
import	java.util.Enumeration;

import	gnu.hyperti.mathext.*;

// java.util.Vector: Note
// since jdk/1.2 the .addElement Method and .removeElement Method
// have been replaced by .add and .remove, respectively.
// note that while add returns boolean, the addElement returns void

public class Node {
	public		Vector	parents = null;
	public		Vector	children = null;
	public	int	level = -1, // starting from the top parent, which level child are we?
			numParents = 0,		// how many parents we have?
			numChildren = 0,	// how many children
			childInList = 0;	// what number are we in our first parent's children list?
	public	Graph	graph = null;

	public	String	hCode = "";
	// constructor
	public	Node(){
		super();
		hCode = this.hashCode()+"";
	}
	public	void	setLevel(int level){
		this.level = level;
	}
	public	boolean	addParent(Node parent){
		if( parent == null ) return false;
		if( this.parents == null ) this.parents = new Vector();
		this.numParents++;
		this.parents.addElement(parent);
		return true;
	}
	public	boolean	removeParent(Node parent){
		if( (parent == null) || (this.parents == null) ) return false;
		this.numParents--;
		return this.parents.removeElement(parent);
	}
	// convenience method for the ``addParent''
	public boolean	addParents(Vector parents){
		if( parents == null ) return false;
		for(Enumeration e=parents.elements();e.hasMoreElements();){
			if( !this.addParent((Node )(e.nextElement())) ) return false;
			this.numParents++;
		}
		return true;
	}
	public boolean	addChild(Node child){
		if( child == null ) return false;
		if( this.children == null ) this.children = new Vector();
		this.numChildren++;
		this.children.addElement(child);
		return true;
	}
	public	boolean	removeChild(Node child){
		if( (child == null) || (this.children == null) ) return false;
		this.numChildren--;
		return this.children.removeElement(child);
	}
	// convenience method for the ``addChild''
	public boolean	addChildren(Vector children){
		if( children == null ) return false;
		for(Enumeration e=children.elements();e.hasMoreElements();){
			if( !this.addChild((Node )(e.nextElement())) ) return false;
			this.numChildren++;
		}
		return true;
	}
	public	Enumeration getParents(){
		if( this.parents == null ) return (Enumeration )null;
		return this.parents.elements();
	}
	public	Enumeration	getChildren(){
		if( this.children == null ) return (Enumeration )null;
		return this.children.elements();
	}
	public	void	calculateChildInList(){
		if( parents == null || parents.isEmpty()) return;
		Node	a_parent = (Node )(parents.elementAt(0));
		int	i;
		for(i=0;i<a_parent.children.size();i++)
			if( a_parent.children.elementAt(i) == this ){
				this.childInList = i;
				break;
			}
		return;
	}


	// will remove this node and tell to our parents that
	// we are no longer child but, instead, our children
	// are added to their list of children now.
	// Notification goes to our children too.
	public	boolean	remove(){
		Node	a_node;

		// notify our children about the change, now they have new parents: our parents
		if( this.children != null )
			for(Enumeration e=this.children.elements();e.hasMoreElements();){
				a_node = (Node )(e.nextElement());
				// tell this child to add our parents to its parents' list
				if( !a_node.addParents(this.parents) ) return false;
				// tell this child to remove us from its parents' list
				if( !a_node.parents.removeElement(this) ) return false;
			}
				
		// notify our parents
		if( this.parents != null )
			for(Enumeration e=this.parents.elements();e.hasMoreElements();){
				a_node = (Node )(e.nextElement());
				// tell this parent to add our children to its children's list
				if( !a_node.addChildren(this.children) ) return false;
				// tell this parent to remove us from its children's list
				if( !a_node.children.removeElement(this) ) return false;
			}
		return ( (this.parents!=null) || (this.children!=null) );
	}
	public String	toString(){
		String	s = "\txxxxxxxxxxxxxxxxxx\n\thash code: "+this.hCode+"\n\tchild in list: "+childInList+"\n\tparents:";

		if( this.parents != null )
			for(Enumeration e=this.parents.elements();e.hasMoreElements();)
				s += " "+((Node )(e.nextElement())).hCode;
		s += "\n\tchildren:";
		if( this.children != null )
			for(Enumeration e=this.children.elements();e.hasMoreElements();)
				s += " "+((Node )(e.nextElement())).hCode;
		return s+"\n\txxxxxxxxxxxxxxxxxx\n";
	}
}
