/**************************************************************************
/* Arc.java
/*
/* Copyright (c) 1999 Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/* Author: Vladimir Bulatov <bulatov@dots.physics.orst.edu> (HyperProf)
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published 
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to 
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330, 
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package	gnu.hyperti;

import gnu.hyperti.mathext.*;

/**
  Arc of Cyrcle r with center at x,y and 
  begins at start 
  and is of anlgle wide.
  angles in radians
  if(r == 0.)
  it is segment of line
  from (x,y) to (start, angle)
 */

public class Arc {
	public	double	x, y, r,
			start, angle;
	static final double EPS = 1.e-4;

	static boolean		ParallelArc(Complex z1, Complex z2){
		double ab1 = z1.abs2(),ab2 = z2.abs2();
		double ar1 = z1.arg(),ar2 = z2.arg();
		return	((ab1 < EPS || ab2 < EPS) ||
			((ab1 >= EPS && ab2 >= EPS) &&
			((Math.abs(ar1-ar2) < EPS || (Math.abs(ar1-ar2-Math.PI) < EPS) ||
			(Math.abs(ar1-ar2+Math.PI) < EPS)))));
	}
	public static int	segmentsInArc(double radius, double angle, int originX, int originY, double scaleX, double scaleY){
		// number of grad in segment
		if(radius == 0.0)
			return 1;
		int n1 = (int)Math.ceil(Math.abs(angle*MathExt.rad2grad/5));
		//number of 5 pixel segments in cyrcle
		int n2 = Math.abs(HyperbolicTreeTransform.x2screen(radius, originX, scaleX))+1;
		return  Math.min(n1,n2);
	}
	public String	toString(){
		return "================\nx= "+x+"\ny= "+y+"\nradius= "+r+"\nstart: "+start+"\nangle: "+angle;
	}
}
