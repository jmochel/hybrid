/**************************************************************************
/* HyperbolicTree.java
/*
/* Copyright (c) 1999 Andreas Hadjiprocopis <livantes@soi.city.ac.uk>
/* Authors: Andreas Hadjiprocopis <livantes@soi.city.ac.uk> and
/*          Vladimir Bulatov <bulatov@dots.physics.orst.edu>
/*
/* This program is free software; you can redistribute it and/or modify
/* it under the terms of the GNU Library General Public License as published 
/* by  the Free Software Foundation; either version 2 of the License or
/* (at your option) any later version.
/*
/* This program is distributed in the hope that it will be useful, but
/* WITHOUT ANY WARRANTY; without even the implied warranty of
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/* GNU Library General Public License for more details.
/*
/* You should have received a copy of the GNU Library General Public License
/* along with this program; see the file COPYING.LIB.  If not, write to 
/* the Free Software Foundation Inc., 59 Temple Place - Suite 330, 
/* Boston, MA  02111-1307 USA
/**************************************************************************/

package gnu.hyperti;

import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.util.*;
import java.io.*;

import gnu.hyperti.graphi.*;
import gnu.hyperti.mathext.*;

/**************************************************************************/

/**
  * This is a Java implementation of a ``Hyperbolic Tree'' (HT). An HT is another way of presenting (or
  * visualising) a normal tree structure using non-euclidean geometry -- instead the hyperbolic
  * geometry is used. Simply put, in such a geometry, lengths (sizes) are dependent on the position of an
  * object (its distance from the center, the focusing point). To get the picture, remember the view you get
  * when you look at a chrome spehere, like those used on Christmas tree decorations. The center is big,
  * the sides much smaller, but, everything fits in the sphere (the whole room behind you). 
  * <P>
  * Where is such a construction useful? 
  * <P>
  * An HT is useful in situations where you have a lot of data and you want it <b>all</b> displayed on screen. In
  * normal euclidean geometry display, all nodes will have to be scaled so as to fit within the display
  * area. In a hyperbolic geometry display, the nodes near the center of focus will be scaled with a
  * different factor than those in the sides (outside the center/focus). When you change the focus, those
  * nodes that are now in the focus are more prominent and those nodes outside the focus are scaled
  * down <b>without</b> disappearing. 
  * <P>
  * How to use this <b>basic</b> hyperbolic tree implementation? 
  * Here is an example java program which will display the hyperbolic tree:
  * <p>
  * <pre><code>
  * import java.applet.Applet;
  * import java.applet.AppletContext;
  * import java.awt.*;
  * import java.awt.event.WindowListener;
  * import java.awt.event.WindowEvent;
  * 
  * 
  * import gnu.hyperti.HyperbolicTree;
  * import gnu.hyperti.HyperbolicTreeNode;
  * import gnu.hyperti.graphi.Graph;
  *  
  * <p>
  * // In order to enhance the functionality of the node we will extend the basic
  * // <i>HyperbolicTreeNode</i> class in the following way:
  * // * <b>Firstly</b>, add an object (String contents) which will hold the name of the node.
  * // * <b>Secondly</b>, overwrite the <i>draw</i> method of the <i>HyperbolicTreeNode</i> so
  * // * that a node is drawn in red color with a black outline, the edge connecting the node to its
  * // * parent is drawn in a blue color and the name of the node is drawn in black color.
  * // * <b>Thirdly</b>, overwrite the <i>clicked</i> method of the <i>HyperbolicTreeNode</i> so
  * // * that, when a node is clicked we get a notification (just a println) as well as the default
  * // * reaction which is to call the method <i>onFocus()</i> and move the node in the center
  * // * of the canvas.
  *<p>
  * class MyHyperbolicNode extends HyperbolicTreeNode {
  *     String    contents = "";
  * 
  *     public    MyHyperbolicNode(String contents){
  *         super();
  *         this.contents = contents;
  *     }
  *     public    String    toString(){
  *         return "\tname: "+contents+"\n"+super.toString();
  *     }
  *     public void draw(Graphics g, int originX, int originY, double scaleX, double scaleY){
  *         fill(Color.red, g, originX, originY, scaleX, scaleY);
  *         outline(Color.black, g, originX, originY, scaleX, scaleY);
  *         drawEdge(Color.blue, g, originX, originY, scaleX, scaleY);
  *         // and now print its name (contents) or anything else you wish
  *         g.setColor(Color.black);
  *         g.drawString(contents, originX+(int )(ecenterx*scaleX), originY+(int )(ecentery*scaleY));
  *     }
  *     public void clicked(int x, int y){
  *         super.clicked(x, y);
  *         System.out.println("I ("+contents+") was clicked. The mouse was at ("+x+" ,"+y+")");
  *     }
  * }
  *<p><p>
  * // This is the main class
  * public class Paroutis extends Applet {
  *     static HyperbolicTree    ht;
  * <p>
  *     public static void main(String args[]){
  *         Frame    f = new Frame("Hyperbolic Tree");
  *         f.setSize(500,500);
  *         f.setLayout(new BorderLayout());
  *         Main(args);
  *         f.add("Center", ht);
  *         f.addWindowListener(new WindowListener() {
  *             public void windowClosing(WindowEvent e) {
  *                 System.exit(0);
  *             }
  *             public void windowDeiconified(WindowEvent e){}
  *             public void windowIconified(WindowEvent e){}
  *             public void windowDeactivated(WindowEvent e){}
  *             public void windowOpened(WindowEvent e){}
  *             public void windowClosed(WindowEvent e){}
  *             public void windowActivated(WindowEvent e){}
  *         });
  * 
  *         f.show();
  *     }
  * <P>
  *     public static void Main(String args[]){
  *         MyHyperbolicNode head, n[];
  *         // This tree will contain 27 nodes and the <i>head</i>
  *         n = new MyHyperbolicNode[27];
  *         // initialise the head
  *         head = new MyHyperbolicNode("Head");
  *         // initialise the nodes
  *         for(int i=0;i<code><</code>n.length;i++) n[i] = new MyHyperbolicNode("n"+(i+1));
  * 
  *         ht = new HyperbolicTree(head, 500,500);
  *         ht.connect(head, n[0]);
  *         ht.connect(head, n[1]);
  *         ht.connect(head, n[2]);
  * 
  *         ht.connect(n[0], n[3]);
  *         ht.connect(n[0], n[4]);
  * 
  *         ht.connect(n[1], n[5]);
  *         ht.connect(n[1], n[6]);
  *         ht.connect(n[1], n[7]);
  * 
  *         ht.connect(n[2], n[8]);
  *         ht.connect(n[2], n[9]);
  *         ht.connect(n[2], n[25]);
  *         ht.connect(n[2], n[26]);
  * 
  *         ht.connect(n[3], n[10]);
  *         ht.connect(n[3], n[11]);
  *         ht.connect(n[3], n[12]);
  * 
  *         ht.connect(n[4], n[13]);
  *         ht.connect(n[4], n[14]);
  *         ht.connect(n[4], n[15]);
  *         ht.connect(n[4], n[16]);
  * 
  *         ht.connect(n[5], n[17]);
  * 
  *         ht.connect(n[7], n[18]);
  *         ht.connect(n[7], n[19]);
  *         ht.connect(n[7], n[20]);
  * 
  *         ht.connect(n[9], n[21]);
  *         ht.connect(n[9], n[22]);
  *         ht.connect(n[9], n[23]);
  *         ht.connect(n[9], n[24]);
  * 
  * 
  *     }
  * <P>
  *     public void init(){
  *         BorderLayout borderLayout = new BorderLayout();
  *         setLayout(borderLayout);
  * 
  *         Main((String [])null);
  *         add("Center", ht);
  *     }
  * }
  * 
  *</code></pre>
  *<P>
  * Interaction with the hyperbolic tree graph is minimum and consists of three possibilities:
  * <DL COMPACT>
  * <DT>i.<DD>Mouse is dragged: the graph moves, following mouse movement,
  * <DT>ii.<DD>Mouse is clicked on top of a node: that node moves to the center of the canvas, rearranging the graph geometry appropriately,
  * <DT>iii.<DD>Mouse is clicked on canvas (not node): the head-node comes in the focus /center of display
  * <DT>iv.<DD>Mouse is clicked with SHIFT KEY pressed: the graph rotates,
  * </DL>
  * <p><p>
  * Please send all bug reports, requests, and comments to
  * Andreas Hadjiprocopis (<a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>).
  *
  * @version 1.0.7
  *
  * @author Andreas Hadjiprocopis (<a href="http://www.soi.city.ac.uk/homes/livantes">http://www.soi.city.ac.uk/homes/livantes</a>, <a href="mailto:livantes@soi.city.ac.uk">livantes@soi.city.ac.uk</a>) NetAesthetics & NoodleWoman Software
  * @author Chidi Iweha (<a href="mailto:chidi_1@yahoo.com">livantes@soi.city.ac.uk</a>) WebHouse Software
  * @author Vladimir Bulatov (<a href="mailto:bulatov@dots.physics.orst.edu">bulatov@dots.physics.orst.edu</a>)
  *
  */

public class HyperbolicTree extends Canvas implements MouseListener, MouseMotionListener {

/**************************************************************************/

/**
  * @serial
  */
	private	Graph			graph;
	private	static final int 	NOTHING = 0,
					ROTATION=1,
					TRANSLATION = 2;
/**
  * @serial
  */
	private	Dimension 		canvasSize = null;
/**
  * @serial
  */
	private	int			originX, originY;
/**
  * @serial
  */
	private	double			scaleX = 1.0,
					scaleY = 1.0;
/**
  * @serial
  */
	private	Complex			lastp = new Complex(0.0, 0.0),
					newp = new Complex(0.0, 0.0),
					teta = new Complex(0.0, 0.0),
					center = new Complex(0,0);
/**
  * @serial
  */
	private	Color			backgroundColor = Color.white;
/**
  * @serial
  */
	private	HyperbolicTreeNode	head;
/**
  * @serial
  */
	private	boolean			wasmoved = false;
/**
  * @serial
  */
	private	int			dragMode = NOTHING;
/**
  * @serial
  */
	private	boolean			fullRedraw = true;
/**
  * @serial
  */
	private	Image			frameBuffer = null;
/**
  * @serial
  */
	private	Graphics		frameBufferGraphics = null;

    private ArrayList listeners;

    /**
     *Allows you do define a listener that is triggered when the mouse goes over a node, or clicks on the node.  Takes a NodeEvent
     */

    public interface Listener {
	public void nodeClicked(NodeEvent evt);
	public void nodeMouseOver(NodeEvent evt);
    }

    /**
     *The corresponding adapter for the aforementioned listener class
     */
    public class Adapter implements Listener {
	public void nodeClicked(NodeEvent evt) {}
	public void nodeMouseOver(NodeEvent evt){}
    }

    /**
     *  Stores potentially important information about the Event: the node itself, 
     * the x and y coordinates of the action, and the Graphics object
     */
    public static class NodeEvent {
	private HyperbolicTreeNode node;
	private int x;
	private int y;
	private Graphics g;

	public NodeEvent(HyperbolicTreeNode node, int x, int y, Graphics g) {
	    this.node = node;
	    this.x = x;
	    this.y = y;
	    this.g = g;
	}

	public int getX() {
	    return x;
	}

	public int getY() {
	    return y;
	}

	public Graphics getGraphics() {
	    return g;
	}

	public HyperbolicTreeNode getNode() {
	    return node;
	}

    }

/*
 * Constructors
 */
/**
  * Construct a hyperbolic tree object given an interconnection Graph and the width and height of the canvas.
  * @param Graph is an interconnection graph
  * @param width is an integer representing the width of the canvas
  * @param height is an integer representing the height of the canvas
  */
	public HyperbolicTree(Graph graph, int width, int height){
		this.graph = graph;
		this.canvasSize = new Dimension(Math.min(width,height), Math.min(width,height));
		this.setSize(canvasSize);
		this.originX = this.canvasSize.width / 2;
		this.originY = this.canvasSize.height / 2;
		this.scaleX = 0.47 * this.canvasSize.width;
		this.scaleY = 0.47 * this.canvasSize.height;
		this.listeners = new ArrayList();

		HyperbolicTreeTransform.establishPositions(graph);
		head = (HyperbolicTreeNode )(graph.getHead());
		addMouseListener(this);
		addMouseMotionListener(this);
	}
/**
  * Construct a hyperbolic tree object given a node which will be the head-node of the graph
  * and the width and height of the canvas. Use the method <i>connect</i> to connect nodes
  * to this head node and subsequent nodes.
  * @param head the head node
  * @param width is an integer representing the width of the canvas
  * @param height is an integer representing the height of the canvas
  */
	public HyperbolicTree(HyperbolicTreeNode head, int width, int height){
		this.graph = new Graph(head);
		this.canvasSize = new Dimension(Math.min(width,height), Math.min(width,height));
		this.setSize(canvasSize);
		this.originX = this.canvasSize.width / 2;
		this.originY = this.canvasSize.height / 2;
		this.scaleX = 0.47 * this.canvasSize.width;
		this.scaleY = 0.47 * this.canvasSize.height;

		HyperbolicTreeTransform.establishPositions(graph);
		this.head = head;
		addMouseListener(this);
		addMouseMotionListener(this);
	}
/**
  * Connect node n2 to node n1. In other words, node n1 already exists in the graph, while
  * node n2 is now added. This is the only way to add nodes to the graph.
  * @param n1 a node already in the graph
  * @param n2 a node which will be connected on n1
  */
	public	void	connect(Node n1, Node n2){
		graph.connect(n1, n2);
		graph.calculate();
		HyperbolicTreeTransform.establishPositions(graph);
		if( frameBuffer != null ){
			paintOntoFrameBuffer();
			repaint();
		}
	}

    public void addListener(Listener listener) {
	listeners.add(listener);
    }
/**
  * Set the background color to bc and <b>repaint</B>
  * @param bc the color to set the background to
  */
	public	void	setBackgroundColor(Color bc){
		this.backgroundColor = bc;
		this.paintOntoFrameBuffer();
 		this.repaint();
	}
/**
  * Set the focus to the Head node. This is the positioning of the nodes corresponding to startup
  */
	public	void	setInTheMiddle(){
		// centre the tree, root node in the middle
		head.doTranslate(new Complex(-head.z.re, -head.z.im));
		this.paintOntoFrameBuffer();
		this.repaint();
	}

/*
 * Privates
 */
	private	void	paintOntoFrameBuffer(){
		HyperbolicTreeNode	a_node;

		// erase all
		frameBufferGraphics.setColor(this.backgroundColor);
		frameBufferGraphics.fillRect(0,0,canvasSize.width,canvasSize.height);

		// draw the nodes
		frameBufferGraphics.setColor(Color.red);
		
		if ( graph.getNodes() == null || graph.getNodes().isEmpty()) {
		    return;
		}
		
		for(Enumeration e=graph.getNodes().elements();e.hasMoreElements();)
			((HyperbolicTreeNode )(e.nextElement())).draw(frameBufferGraphics, originX, originY, scaleX, scaleY);
	}

	public void	paint(Graphics g){
		Dimension newSize = this.getSize();

		if( (canvasSize.width != newSize.width) || (canvasSize.height != newSize.height) || (frameBuffer==null) ){
			canvasSize.width = Math.min(newSize.width, newSize.height);
			canvasSize.height = Math.min(newSize.width, newSize.height);
			this.setSize(canvasSize);
			this.originX = this.canvasSize.width / 2;
			this.originY = this.canvasSize.height / 2;
			this.scaleX = 0.47 * this.canvasSize.width;
			this.scaleY = 0.47 * this.canvasSize.height;

			this.frameBuffer = null; this.frameBuffer = this.createImage(canvasSize.width, canvasSize.height);
			this.frameBufferGraphics = null; this.frameBufferGraphics = frameBuffer.getGraphics();

			HyperbolicTreeTransform.establishPositions(graph);
			this.paintOntoFrameBuffer();
		}
		g.drawImage(frameBuffer, 0, 0, this);
	}
	public void	update(Graphics g){
	    Rectangle	r = g.getClipBounds();

		g.clipRect(r.x,r.y,r.width,r.height);
		g.drawImage(frameBuffer, 0, 0, this);
	}
	// mouse listener events
	public  void    mouseClicked(MouseEvent e) {
		HyperbolicTreeNode	n;

		if( (n=head.findNode(e.getX(), e.getY(), originX, originY, scaleX, scaleY)) != null ){
//			System.out.println(n);
//			head.doTranslate(new Complex(-n.z.re, -n.z.im));
			n.clicked(e.getX(), e.getY());
			Iterator i = listeners.iterator();
			Listener current = null;
			while( i.hasNext() ) { 
			    current = (Listener)i.next();
			    current.nodeClicked(new NodeEvent(n,e.getX(),e.getY(),this.getGraphics()));
			}
		} else this.setInTheMiddle();

		this.paintOntoFrameBuffer();
		this.repaint();
	}
	public  void    mousePressed(MouseEvent e) {
		// if you press the mouse and press SHIFT key then the tree rotates, else you can move it.
		if((e.getModifiers() & Event.SHIFT_MASK) != 0) dragMode = ROTATION;
                else dragMode = TRANSLATION;

		lastp.set(HyperbolicTreeTransform.screen2x(e.getX(), originX, scaleX),
			HyperbolicTreeTransform.screen2y(e.getY(), originY, scaleY));
	}
	public  void    mouseReleased(MouseEvent e) {
		dragMode = NOTHING;
	}
	public  void    mouseEntered(MouseEvent e) {}
	public  void    mouseExited(MouseEvent e) {}
	public void	mouseMoved(MouseEvent e) {
	    HyperbolicTreeNode	n;
	    if( (n=head.findNode(e.getX(), e.getY(), originX, originY, scaleX, scaleY)) != null ){
		//System.out.println(n);
		//			head.doTranslate(new Complex(-n.z.re, -n.z.im));
		n.clicked(e.getX(), e.getY());
		Iterator i = listeners.iterator();
		Listener current = null;
		while( i.hasNext() ) { 
		    current = (Listener)i.next();
		    current.nodeMouseOver(new NodeEvent(n,e.getX(),e.getY(),this.getGraphics()));
		}
	    }
	}

	public void	mouseDragged(MouseEvent e){
		if( dragMode == TRANSLATION ){
			newp.set(HyperbolicTreeTransform.screen2x(e.getX(), originX, scaleX),
				HyperbolicTreeTransform.screen2y(e.getY(), originY, scaleY));
			this.translate();
			this.paintOntoFrameBuffer();
			this.repaint();
			lastp.set(newp);
			return;
		}
		if( dragMode == ROTATION ){
			newp.set(HyperbolicTreeTransform.screen2x(e.getX(), originX, scaleX),
				HyperbolicTreeTransform.screen2y(e.getY(), originY, scaleY));
			this.rotate();
			this.paintOntoFrameBuffer();
			this.repaint();
			lastp.set(newp);
			return;
		}
	}
	private void	rotate(){
		teta.div(newp.sub(center),lastp.sub(center));
		teta.normalize();
		head.doTranslate(center.neg());
		head.doRotate(teta);
		head.doTranslate(center.neg());
		newp.add(center);
	}
	private void	translate(){
		lastp.neg();
		head.doTranslate(lastp);
		head.doTranslate(newp);
	}
}
