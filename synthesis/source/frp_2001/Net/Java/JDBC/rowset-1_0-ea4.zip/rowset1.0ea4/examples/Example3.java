import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;


public class Example3 {

    public static void main(String args[])
    {                
        Example3 crs = new Example3();
        try {
            crs.setup();
            crs.go(false);        
            crs.go(true);
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
    }

    private void go(boolean populated) throws SQLException {
        CachedRowSet crs;

        // create a new row set
        crs = new CachedRowSet();

        // set some properties of the rowset
        crs.setUrl("jdbc:oracle:thin:@machine:1521:db");
        crs.setUsername("username");
        crs.setPassword("password");
        crs.setCommand("select col1, col2 from test_table order by 1");
        crs.setTableName("test_table");

        crs.execute();

        if (populated == false) {
            // insert into the rowset
            populateRowset(crs);
            System.err.println("Rowset populated");
            
            System.out.println("RowSet populated.");
            
            System.err.println("Transfering changes to database...");
            crs.acceptChanges();
            System.err.println("Changes transfered.");
        } else {
            scrollCursor(crs);
        }

    }


    private void setup() throws SQLException {

        Connection conn = getConn();
        Statement stmt = conn.createStatement();
        
        try {
            stmt.execute("drop table test_table");
        } catch (SQLException ex) {
            System.err.println("Caught drop table.");
        }
        
        // create the test table
        stmt.execute("Create table test_table (col1 int, col2 float)");
        System.out.println("Table created.");

        // disconnect
        stmt.close();
        System.err.println("stmt closed.");
        conn.commit();
        conn.close();
        System.err.println("conn closed.");
    }    

    private Connection getConn() {

        // Register the driver.
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("ClassNotFoundException: " +
                               ex.getMessage());
        }

        // Connect to the database.
        try {
            return (DriverManager.getConnection
                ("jdbc:oracle:thin:jje/ellis@anybodys:1521:demo"));
        } catch (SQLException ex) {
            System.err.println("getConnection failed: " + ex.getMessage());
        }
        return null;
    }

    private void scrollCursor(CachedRowSet crs) throws SQLException {
        System.out.println("Fetching from RowSet...");
        
        String v1;
        float v2;
        
        while (crs.next()) {

            v1 = crs.getString(1);
            if (crs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = crs.getFloat("col2");
            if (crs.wasNull() == false) {
                System.out.println("v2 is " + v2);
            } else {
                System.out.println("v2 is null");
            }    
              
        } 

        if (crs.isAfterLast() == true) {
            System.out.println("We have reached the end");
            System.out.println("This is row: " + crs.getRow());
        }
        
        System.out.println("And now backwards...");
        
        while (crs.previous()) {

            v1 = crs.getString("col1");
            if (crs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = crs.getFloat(2);
            if (crs.wasNull() == false) {
                System.out.println("v2 is " + v2);
            } else {
                System.out.println("v2 is null");
            }    
            
        }
        
        if (crs.isBeforeFirst() == true) {
            System.out.println("We have made it back to the start!");
        }
        
        crs.first();
        if (crs.isFirst() == true)
            System.out.println("We have moved to first");

        System.out.println("This is row: " + crs.getRow());

        if (crs.isBeforeFirst() == false)
            System.out.println("We aren't before the first row.");

        crs.last();
        if (crs.isLast() == true)
            System.out.println("...and now we have moved to the last");

        System.out.println("This is row: " + crs.getRow());

        if (crs.isAfterLast() == false)
            System.out.println("we aren't after the last.");
    }
    
    private void populateRowset(CachedRowSet crs) throws SQLException {
        int i;

        for (i=0; i < 10 ; i++) {
            crs.moveToInsertRow();
            crs.updateInt(1,i);
            crs.updateFloat(2, ((((float)i) * 100) + i));
            crs.insertRow();
            crs.moveToCurrentRow();
        }

    }

}

