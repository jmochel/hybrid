import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;

public class Example5 {
    Connection conn = null;
    Statement stmt = null;
    JdbcRowSet jrs = null;

    public static void main(String Args[])
    {                
        Example5 rs = new Example5();
        rs.setup();
        rs.go();        
    }

    public void go() {
        try {
	    EchoListener echo = new EchoListener();

	    jrs = new JdbcRowSet();
	    jrs.addRowSetListener(echo);
	    jrs.setUrl("jdbc:odbc:DSN");
	    jrs.setUsername("user");
	    jrs.setPassword("pass");
	    jrs.setCommand("select col1, col2 from test_table");
	    jrs.execute();
	
            // a scroll in the park...
            scrollCursor(jrs);

	    jrs.close();
        } 
        catch (SQLException ex) {
            System.err.println("SQLException:  " + ex.getMessage());
        }
    }


    public void setup() {
	getConn();
	
        try {
            stmt = conn.createStatement();
        } catch (SQLException ex) {
            System.err.println("Unable to get connection: " + ex.getMessage());
        }
        
        try {
            stmt.execute("drop table stuffit");
        }
        catch (SQLException ex) {
            System.err.println("Caught drop table: " + ex.getMessage());
        }
        try {
            stmt.execute("Create table stuffit (col1 char(10), col2 int)");
            System.out.println("Table created.");
            stmt.execute("insert into stuffit values ('0', 0)");
            stmt.execute("insert into stuffit values ('1', 1)");
            stmt.execute("insert into stuffit values ('2', 2)");
            stmt.execute("insert into stuffit values (null,null)");
            stmt.execute("insert into stuffit values ('Fish', 0)");
            System.out.println("Rows inserted");

        } catch (SQLException ex) {
            System.err.println("Died: " + ex.getMessage());
        }
    }    

    public void getConn() {

        // Register the driver.
        try {
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }

        // Connect to the database.
        try {
            conn = DriverManager.getConnection(
		"jdbc:odbc:DSN", "user", "pass");
           
        } catch (SQLException ex) {
            System.err.println("getConnection failed: " + ex.getMessage());
        }
    }




    public void scrollCursor(JdbcRowSet crs) throws SQLException {
        System.out.println("Fetching from RowSet...");
        
        String v1;
        int v2;
        try {        
	    while (crs.next()) {
		try {
		    v1 = crs.getString(1);
		    if (crs.wasNull() == false)
			System.out.println("v1 is " + v1);
		    else
			System.out.println("v1 is null");
		} catch (SQLException ex) {
		    System.err.println("Unable to get: " + ex.getMessage());
		}
		v2 = crs.getInt(2);
		if (crs.wasNull() == false)
		    System.out.println("v2 is " + v2);
		else 
		    System.out.println("v2 is null");
	    } 
	} catch (SQLException ex) {
	    ex.printStackTrace();
	}
    }
}

