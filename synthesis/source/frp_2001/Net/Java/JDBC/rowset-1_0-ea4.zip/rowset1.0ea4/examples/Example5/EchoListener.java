import javax.sql.*;
import java.io.*;

public class EchoListener implements RowSetListener {

    public void rowSetChanged(RowSetEvent event) {
        System.out.println("The rowset changed");
    }
    
    public void rowChanged(RowSetEvent event) {
        System.out.println("Row changed");
    }
    
    public void cursorMoved(RowSetEvent event) {
        System.out.println("Rowset cursor moved");
    }
}
