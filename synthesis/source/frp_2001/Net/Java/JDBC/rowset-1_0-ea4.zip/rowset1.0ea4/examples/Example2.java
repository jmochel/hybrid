import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;


public class Example2 {

    public static void main(String args[])
    {                
        Example2 crs = new Example2();
        try {
            crs.setup();
            crs.go();        
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
    }

    private void go() throws SQLException {
        CachedRowSet crs;

        // create a new row set
        crs = new CachedRowSet();

        // set some properties of the rowset
        crs.setUrl("jdbc:oracle:thin:@machine:1521:db");
        crs.setUsername("username");
        crs.setPassword("password");
        crs.setCommand("select col1, col2 from test_table where col2 > ?");
        // supply value for the parameter marker
        crs.setInt(1,1);
        // populate the rowset.
        crs.execute();
        System.out.println("RowSet populated.");
        
        // scroll this rowsets cursor
        scrollCursor(crs);            
    }


    private void setup() throws SQLException {

        Connection conn = getConn();
        Statement stmt = conn.createStatement();
        
        try {
            stmt.execute("drop table test_table");
        } catch (SQLException ex) {
            System.err.println("Caught drop table.");
        }
        
        // create the test table
        stmt.execute("Create table test_table (col1 char(10), col2 int)");
        System.out.println("Table created.");
        
        // insert some test data
        stmt.execute("insert into test_table values ('zero', 0)");
        stmt.execute("insert into test_table values ('one', 1)");
        stmt.execute("insert into test_table values ('two', 2)");
        stmt.execute("insert into test_table values (null,null)");
        stmt.execute("insert into test_table values ('three', 3)");
        System.out.println("Rows inserted");

        // disconnect
        stmt.close();
        System.err.println("stmt closed.");
        conn.commit();
        conn.close();
        System.err.println("conn closed.");
    }    

    private Connection getConn() {

        // Register the driver.
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("ClassNotFoundException: " +
                               ex.getMessage());
        }

        // Connect to the database.
        try {
            return (DriverManager.getConnection
                ("jdbc:oracle:thin:jje/ellis@anybodys:1521:demo"));
        } catch (SQLException ex) {
            System.err.println("getConnection failed: " + ex.getMessage());
        }
        return null;
    }

    private void scrollCursor(CachedRowSet crs) throws SQLException {
        System.out.println("Fetching from RowSet...");
        
        String v1;
        float v2;
        
        while (crs.next()) {

            v1 = crs.getString(1);
            if (crs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = crs.getFloat("col2");
            if (crs.wasNull() == false) {
                System.out.println("v2 is " + v2);
            } else {
                System.out.println("v2 is null");
            }    
              
        } 

        if (crs.isAfterLast() == true) {
            System.out.println("We have reached the end");
            System.out.println("This is row: " + crs.getRow());
        }
        
        System.out.println("And now backwards...");
        
        while (crs.previous()) {

            v1 = crs.getString("col1");
            if (crs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = crs.getFloat(2);
            if (crs.wasNull() == false) {
                System.out.println("v2 is " + v2);
            } else {
                System.out.println("v2 is null");
            }    
            
        }
        
        if (crs.isBeforeFirst() == true) {
            System.out.println("We have made it back to the start!");
        }
        
        crs.first();
        if (crs.isFirst() == true)
            System.out.println("We have moved to first");

        System.out.println("This is row: " + crs.getRow());

        if (crs.isBeforeFirst() == false)
            System.out.println("We aren't before the first row.");

        crs.last();
        if (crs.isLast() == true)
            System.out.println("...and now we have moved to the last");

        System.out.println("This is row: " + crs.getRow());

        if (crs.isAfterLast() == false)
            System.out.println("we aren't after the last.");
    }
}

