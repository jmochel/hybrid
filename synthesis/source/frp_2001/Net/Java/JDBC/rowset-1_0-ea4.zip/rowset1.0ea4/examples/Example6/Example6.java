import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;
import java.io.*;


public class Example6 {

    public static void main(String args[])
    {                
        Example6 rs = new Example6();
        try {
            rs.setup();
            rs.go();        
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
    }

    private void go() throws SQLException {
        WebRowSet wrs;

        // create a new row set
        wrs = new WebRowSet();

        // set some properties of the rowset
        wrs.setUrl("jdbc:odbc:DSN");
        wrs.setUsername("user");
        wrs.setPassword("pass");

        wrs.setCommand("select col1, col2 from test_table");
        wrs.setTransactionIsolation(java.sql.Connection.TRANSACTION_READ_UNCOMMITTED);
        
	// populate the rowset.
        wrs.execute();
        System.out.println("RowSet populated.");
	int k[] = {1,2};
	wrs.setKeyColumns(k);
        try {
            java.io.FileWriter FW = new java.io.FileWriter("Example6.xml");
            
            scrollCursor(wrs);
            wrs.writeXml(FW);

            java.io.FileReader FR = new java.io.FileReader("Example6.xml");
            
            WebRowSet wrs2 = new WebRowSet();
            wrs2.readXml(FR);

            java.io.FileWriter FW2 = new java.io.FileWriter("Example6_2.xml");
            
            wrs2.writeXml(FW2);     

        } catch (Throwable ex) {
            System.out.println(ex.getMessage());
        }
    }


    private void setup() throws SQLException {

        Connection conn = getConn();
	conn.setAutoCommit(false);
	conn.setAutoCommit(false);
        Statement stmt = conn.createStatement();
        
        try {
            stmt.execute("drop table test_table");
        } catch (SQLException ex) {
            System.err.println("Caught drop table.");
        }
        
        // create the test table
        stmt.execute("Create table test_table (col1 char(10), col2 int)");
        System.out.println("Table created.");
        
        // insert some test data
        stmt.execute("insert into test_table values ('zero', 0)");
        stmt.execute("insert into test_table values ('one', 1)");
        stmt.execute("insert into test_table values ('two', 2)");
        stmt.execute("insert into test_table values (null,null)");
        stmt.execute("insert into test_table values ('three', 3)");
        System.out.println("Rows inserted");

        // disconnect
        stmt.close();
        System.err.println("stmt closed.");
        conn.commit();
        conn.close();
        System.err.println("conn closed.");
    }    

    private Connection getConn() {

        // Register the driver.
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }

        // Connect to the database.
        try {
            return DriverManager.getConnection(
        		"jdbc:odbc:DSN", "user","pass");
	} catch (SQLException ex) {
            System.err.println("getConnection failed: " + ex.getMessage());
        }
        return null;
    }

    private void scrollCursor(WebRowSet wrs) throws SQLException {
        System.out.println("Fetching from RowSet...");
        
        String v1;
        int v2;

        wrs.beforeFirst();
        
        while (wrs.next()) {

            v1 = wrs.getString(1);
            if (wrs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = wrs.getInt("col2");
            if (wrs.wasNull() == false) {
                System.out.println("v2 is " + v2);
		if (v2 == 2) {
			System.out.println("Updating!");
			wrs.updateInt("col2", 9999);
			wrs.updateString("col1", "Big Number");
			wrs.updateRow();
			wrs.deleteRow();

			wrs.moveToInsertRow();
			wrs.updateInt("col2", 5);
			wrs.updateString("col1", "go");
			wrs.insertRow();
			wrs.moveToCurrentRow();
			wrs.next();
			wrs.updateString("col1", "five");
			wrs.updateRow();
			wrs.previous();
		}
            } else {
                System.out.println("v2 is null");
            }    
              
        } 

        if (wrs.isAfterLast() == true) {
            System.out.println("We have reached the end");
            System.out.println("This is row: " + wrs.getRow());
        }
        
        System.out.println("And now backwards...");
        
        while (wrs.previous()) {

            v1 = wrs.getString("col1");
            if (wrs.wasNull() == false) {
                System.out.println("v1 is " + v1);
            } else {
                System.out.println("v1 is null");
            }

            v2 = wrs.getInt(2);
            if (wrs.wasNull() == false) {
                System.out.println("v2 is " + v2);
            } else {
                System.out.println("v2 is null");
            }    
            
        }
        
        if (wrs.isBeforeFirst() == true) {
            System.out.println("We have made it back to the start!");
        }
        
        wrs.first();
        if (wrs.isFirst() == true)
            System.out.println("We have moved to first");

        System.out.println("This is row: " + wrs.getRow());

        if (wrs.isBeforeFirst() == false)
            System.out.println("We aren't before the first row.");

        wrs.last();
        if (wrs.isLast() == true)
            System.out.println("...and now we have moved to the last");

        System.out.println("This is row: " + wrs.getRow());

        if (wrs.isAfterLast() == false)
            System.out.println("we aren't after the last.");
    }
}

