package example4;

import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;
import javax.naming.*;
import javax.ejb.*;

public class CoffeesBean implements SessionBean {

    private SessionContext sc = null;
    private Context ctx = null;
    private DataSource ds = null;
    
    public CoffeesBean () {}
    
    public void ejbCreate() throws CreateException {

        try {
            ctx = new InitialContext();
            ds = (DataSource)ctx.lookup("jdbc/CoffeesDB");
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            throw new CreateException();
        }
    }

    public RowSet getCoffees() throws SQLException {
        
        Connection con = null;
	ResultSet rs;
        CachedRowSet crs;

        try {
            con = ds.getConnection("webCustomer", "webPassword");
            Statement stmt = con.createStatement();
            rs =  stmt.executeQuery("select * from coffees");
            
            crs = new CachedRowSet();
            crs.populate(rs);
            // the writer needs this because JDBC drivers
            // don't provide this meta-data.
            crs.setTableName("coffees");
            
            rs.close();
            stmt.close();
        } finally {
            if (con != null) 
                con.close();
        }
        return rset;
    }
    
    public updateCoffees(RowSet rs) throws SQLException {

        Connection con = null;

        try {
            CachedRowSet crs = (CachedRowSet)rs;
            con = ds.getConnection("webCustomer", "webPassword");
            // moves the changes back to the database
            crs.acceptChanges(con);
        } finally {
            if (con != null) 
                con.close();
        }
    }

    //
    // Methods inherited from SessionBean
    //
    
    public void setSessionContext(SessionContext sc) {
        this.sc = sc;
    }
    
    public void ejbRemove() {}
    public void ejbPassivate() {}
    public void ejbActivate() {}

    
}
