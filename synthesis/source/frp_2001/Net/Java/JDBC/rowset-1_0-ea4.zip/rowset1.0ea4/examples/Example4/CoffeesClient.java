package example4;

import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;
import javax.naming.*;
import javax.ejb.*;
import javax.rmi.*;

class CoffeesClient {

    public static void main(String[] args) {

        try {
            // init the bean
            Context ctx = new InitialContext();
            Object obj = ctx.lookup("ejb/Coffees");
            CoffeesHome coffeesHome = (CoffeesHome)
                PortableRemoteObject.narrow(obj, CoffeesHome.class);
            Coffees coffees = coffeesHome.create();
            
            // get the rowset from the bean
            CachedRowSet rset = (CachedRowSet)coffees.getCoffees();

            // find the Columbian coffee
            while (rset.next()) {
                String coffeeName = rset.getString("COF_NAME");
                if (coffeeName.equalsIgnoreCase(new String("Columbian"))) {
                    // columbian coffee has gone up 10%
                    rset.updateFloat("PRICE", 
                                     (float)(rset.getFloat("PRICE") * 1.10));
                    rset.updateRow();
                }
            }

            // finally send the updated back to the bean...
            System.out.println("Calling update method");
            coffees.updateCoffees((RowSet)rset);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

