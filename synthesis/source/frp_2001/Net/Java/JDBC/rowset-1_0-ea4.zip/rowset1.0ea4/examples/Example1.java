import java.sql.*;
import javax.sql.*;
import sun.jdbc.rowset.*;

public class Example1
{
    public static void main(String args[])
    {
        Connection conn; // Hold the connection to the database
        Statement stmt;
        ResultSet rs;
        
        // Register the driver.
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("ClassNotFoundException: " + 
                               ex.getMessage());
        }
        
        /*
         * Connect to the database.
         *
         * NOTE: this will *not* work as is. You will need to
         * supply userid, password, machine and database in the
         * appropiate place before you can connect
         */
        try {
            conn = DriverManager.getConnection(
               "jdbc:oracle:thin:username/password@machine:1521:db");
            
            stmt = conn.createStatement();
            
            // clean up previous runs
            try {
                stmt.execute("drop table test_table");
            }
            catch (SQLException ex) {
                System.err.println("Caught drop table: " + ex.getMessage());
            }
            
            // create our test table
            stmt.execute("Create table test_table (col1 char(10), col2 int)");
            System.out.println("Table created.");

            // insert some test rows
            stmt.execute("insert into test_table values ('value0', 0)");
            stmt.execute("insert into test_table values ('value1', 1)");
            stmt.execute("insert into test_table values ('value2', 2)");
            stmt.execute("insert into test_table values (null,null)");
            stmt.execute("insert into test_table values ('value3', 3)");
            System.out.println("Rows inserted");

            // commit everything
            conn.commit();

            /*
             * now create the resultset that we will use to populate
             * the rowset.
             */
            rs = stmt.executeQuery("select col1, col2 from test_table");
            System.out.println("Query executed");
            
            // create a new rowset and populate it...
            CachedRowSet crs = new CachedRowSet();
            crs.populate(rs);                
            System.out.println("RowSet populated.");

            /*
             * Now that the rowset has been populated we can
             * close the connection to the database.
             */
            stmt.close();
            System.err.println("stmt closed.");
            conn.close();
            System.err.println("conn closed.");
            
            /*
             * From this point on we are fetching from the rowset
             */
            System.out.println("Fetching from RowSet...");
                
            String v1;
            int v2;
            
            while (crs.next()) {

                v1 = crs.getString(1);
                if (crs.wasNull() == false) {
                    System.out.println("v1 is " + v1);
                } else {
                        System.out.println("v1 is null");
                }
                
                v2 = crs.getInt("col2");
                if (crs.wasNull() == false) {
                    System.out.println("v2 is " + v2);
                } else {
                    System.out.println("v2 is null");
                }    
                
            } 
            
            if (crs.isAfterLast() == true) {
                System.out.println("We have reached the end");
                System.out.println("This is row: " + crs.getRow());
            }
            
            System.out.println("And now backwards...");
            
            while (crs.previous()) {

                v1 = crs.getString("col1");
                if (crs.wasNull() == false) {
                    System.out.println("v1 is " + v1);
                } else {
                    System.out.println("v1 is null");
                }
                
                v2 = crs.getInt(2);
                if (crs.wasNull() == false) {
                    System.out.println("v2 is " + v2);
                } else {
                  System.out.println("v2 is null");
                }    
                
            }
            
            if (crs.isBeforeFirst() == true) 
                System.out.println("We have reached the start");
            
            crs.first();
            if (crs.isFirst() == true)
                System.out.println("We have moved to first");

            System.out.println("This is row: " + crs.getRow());

            if (crs.isBeforeFirst() == false)
                System.out.println("We aren't before the first row.");

            crs.last();
            if (crs.isLast() == true)
                System.out.println("...and now we have moved to the last");

            System.out.println("This is row: " + crs.getRow());

            if (crs.isAfterLast() == false)
                System.out.println("we aren't after the last.");
        } 
        catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
        
    }
}

