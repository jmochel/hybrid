package com.tivoli.jmx.tutorial.server;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;

public class LogFile {
	private java.lang.String name;
	private java.io.File logfile;
	private java.io.OutputStream logstream;
	private static LogFile logFileInstance;

public LogFile(String name) {
	this.name = name;
}

public void close() throws IOException {
	logstream.close();
}

public long getLastModified() {
	return logfile.lastModified();
}

public java.io.OutputStream getOutputStream() {
	return logstream;
}

public long getSize() {
	return logfile.length();
}

public void open() throws IOException {
	logfile = new File(name);
	logstream = new java.io.FileOutputStream(logfile);
}

public synchronized void rollOver() throws IOException {

	try {
		logstream.close();
		logfile.renameTo(new File(name + ".backup"));
	} catch (IOException x) {
		System.err.println("Can't create a backup: " + x);
	}
	logstream = new FileOutputStream(logfile);
}
}
