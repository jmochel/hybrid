package com.tivoli.jmx.tutorial.managedserver;

public interface ListenerMBean {

int getPort();

long getRequests();

boolean isListening();

void setPort(int port);

void startListening();

void stopListening();
}
