package com.tivoli.jmx.tutorial.server;

import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.SortedSet;

public class Listener extends Thread {
	private int port = 10240;
	private boolean listening = true;
	private java.util.SortedSet queue;

public Listener(SortedSet queue) {
	this.queue = queue;
}

public Listener(SortedSet queue, int port) {
	this.queue = queue;
	this.port = port;
}

public synchronized boolean isListening() {
	return listening;
}

public void run() {
	try {
		ServerSocket ss = new ServerSocket(this.port);

		while (listening) {
			Socket s = ss.accept();
			Request r = new Request(System.currentTimeMillis(), s);
			synchronized (queue) {
				queue.add(r);
				queue.notify();
			}
		}
	} catch (IOException x) {
		System.out.println(x);
	}
}
}
