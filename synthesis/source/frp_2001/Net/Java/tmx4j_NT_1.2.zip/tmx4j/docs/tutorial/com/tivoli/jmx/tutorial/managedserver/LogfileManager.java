package com.tivoli.jmx.tutorial.managedserver;

import javax.management.ObjectName;
import javax.management.MBeanServer;
import javax.management.Notification;

public class LogfileManager implements javax.management.NotificationListener {
	public static class Filter implements javax.management.NotificationFilter {
		private String type;
		
		public Filter(String type) {
			this.type = type;
		}

		public boolean isNotificationEnabled(Notification notification) {
			return (type.compareToIgnoreCase(notification.getType()) == 0);
		}
	}
	private javax.management.MBeanServer mbs;
	private javax.management.ObjectName logfile;

public LogfileManager(MBeanServer mbs, ObjectName logfile) {
	this.logfile = logfile;
	this.mbs = mbs;
}

public void handleNotification(javax.management.Notification notification, Object handBack) {
	try {
		mbs.invoke(logfile, "rollOver", null, null);
	} catch (Exception x) {
		System.err.println("Can't roll over logfile" + x);
	}
}
}
