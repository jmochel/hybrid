package com.tivoli.jmx.tutorial.server;

import java.util.Iterator;
import java.util.HashSet;

public class HandlerPool {
	private java.util.Set handlers;
	private int size;

public HandlerPool() {
	this.handlers = new HashSet();
	this.size = 8;
	fill();
}

public HandlerPool(int size) {
	this.size = size;
	fill();
}

private void fill() {
	for (int i = 0; i < this.size; i++) {
		Handler h = new Handler(this);
		h.start();
		handlers.add(h);
	}
}

public void release(Handler handler) {
	synchronized (handlers) {
		handlers.add(handler);
		handlers.notify();
	}
}

public Handler reserve() {
	Handler h = null;
	
	synchronized (handlers) {
		while (handlers.isEmpty()) {
			try { handlers.wait(); } catch (InterruptedException x) {}
		}
		Iterator i = handlers.iterator();
		h = (Handler) i.next();
		handlers.remove(h);
	}
	
	return h;
}
}
