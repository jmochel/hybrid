package com.tivoli.jmx.tutorial.managedserver;

public interface HandlerPoolMBean {

int getSize();

void refill();

void setSize(int size);
}
