package com.tivoli.jmx.tutorial.managedserver;

import java.io.IOException;

public interface LogFileMBean {

long getLastModified();

long getSize();

void rollOver() throws IOException;
}
