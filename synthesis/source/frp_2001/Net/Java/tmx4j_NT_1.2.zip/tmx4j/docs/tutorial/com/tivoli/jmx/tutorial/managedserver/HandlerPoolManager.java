package com.tivoli.jmx.tutorial.managedserver;

import javax.management.MBeanServer;
import javax.management.Attribute;
import javax.management.Notification;
import javax.management.ObjectName;

public class HandlerPoolManager implements javax.management.NotificationListener {
	public static class Filter implements javax.management.NotificationFilter {
		private String type;
		
		public Filter(String type) {
			this.type = type;
		}
		
		public boolean isNotificationEnabled(Notification notification) {
			return (type.compareToIgnoreCase(notification.getType()) == 0);
		}
	}
	private javax.management.ObjectName handlerPool;
	private javax.management.MBeanServer mbs;

public HandlerPoolManager(MBeanServer mbs, ObjectName handlerPool) {
	this.handlerPool = handlerPool;
	this.mbs = mbs;
}

public void handleNotification(javax.management.Notification notification, Object handBack) {
	try {
		int size = ((Integer) mbs.getAttribute(handlerPool, "Size")).intValue();
		Attribute nextSize = new Attribute("Size", new Integer((int) (size * 1.25)));
		mbs.setAttribute(handlerPool, nextSize);
	} catch (Exception x) {
		System.err.println("Can't get handler pool size");
	}
}
}
