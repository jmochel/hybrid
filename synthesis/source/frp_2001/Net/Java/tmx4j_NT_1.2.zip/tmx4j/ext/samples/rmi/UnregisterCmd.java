/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 16 1.2 ext/src/samples/rmi/UnregisterCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:10 $

package samples.rmi;

import java.rmi.RemoteException;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
/**
 * Instances of UnregisterCmd represent command-lines
 * that contain the '--unregister' switch.
 */
public class UnregisterCmd extends Tmx4jCommand {
    private javax.management.ObjectName oname;
    /**
     * Create a new UnregisterCmd instance.
     */
    public UnregisterCmd() {
	super();
    }
    /**
     * Unregister the specified object name via the RMI
     * MBeanServerConnection.
     */
    public void doIt() {
	try {
	    connection.unregisterMBean(oname);
	} catch (RemoteException x) {
	    System.err.println("Can't unregister: " + x);
	    System.exit(-1);
	}
    }
    /**
     * Initialize the UnregisterCmd from the command-line arguments
     */
    public void init(String[] args) throws IllegalArgumentException {
	try {
	    oname = new ObjectName(args[1]);
	} catch (MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
}
