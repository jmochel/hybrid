/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 25 1.2 ext/src/samples/mbeans/MBean_Standard.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:33 $

package samples.mbeans;

import javax.management.*;
import java.util.*;

/*******************************************************************************
 *
 * MBeanStandard.java
 *
 * @author Raimondo Castino, Eliseba Costantini
 * @version 1.2
 *
 ******************************************************************************/
public class MBean_Standard implements MBean_StandardMBean {
  private String  diskSpace = "100.0 MB";
  private String  paperLeft = "80 sheets";
  private Integer type = new Integer(10);
	
  // Public constructor. 

  public MBean_Standard( Integer type ) {
   	this.type = type;
  }
    
  public MBean_Standard() {
 	  this.type = new Integer(1);
  }

  // Getter method for diskSpace attribute
  public String getdiskSpace() {
	  return diskSpace;
  }

  // Getter method for paperLeft attribute
  public String getpaperLeft() {
	  return paperLeft;
  }

  // Getter method for type attribute

  public Integer gettype() {
	  return type;
  }

  // Setter method for diskSpace attribute
  public void setdiskSpace( String space ) {
   	//System.out.println("---> setdiskSpace");
	  diskSpace = space;
  }

  // Setter method for paperLeft attribute
  public void setpaperLeft( String paper ) {
	  paperLeft = paper;
  }

  public Integer reset() {
    diskSpace = "0.0 MB";
    paperLeft = "0 sheets";
    return new Integer(0);
  }

  public int ping( String host, float f) {
    //System.out.println("---> ping(" + host + ", " + f);
    return 34;
  }

} // end class MBeanStandard
