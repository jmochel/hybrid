/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 06 1.5 ext/src/samples/ManagedResourcePoint.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:43 $

package samples;

import javax.management.modelmbean.*;
import javax.management.*;

/*******************************************************************************
 * ManagedResourcePoint.java
 *
 * The managed resource described by the reference to an instance
 * of Point class, and by the ModelMBeanInfo object relative.
 * 
 * @author Eliseba Costantini 
 * @author Massimo Tarquini 
 * @author Max Parlione
 *
 * @version 1.5
 ******************************************************************************/
public class ManagedResourcePoint {

  private Object reference;
  private ModelMBeanInfo mmbi;

  
  /**
   * Construct a managed resource for an instance of Point class
   */
  public ManagedResourcePoint(MBeanInfo default_mmbi) {
    reference = new Point();
    mmbi = createModelMBeanInfo(default_mmbi);
  }

  /**
   * Return the reference to an instance of the Point class
   */
  public Object getReference() {
    return reference;
  } // end getReference

  /**
   * Return the ModelMBeanInfo that will describe that managed resource
   */
  public ModelMBeanInfo getResourceInfos() {
    return mmbi;
  } // end getResourceInfos

  /**
   * Creates a ModelMBeanInfo instance with the metadata objects  
   */
  private ModelMBeanInfo createModelMBeanInfo(MBeanInfo default_mmbi) {
        
    // append constructor infos to the already built ones
    ModelMBeanConstructorInfo[] defaultConstructorInfos = 
                   (ModelMBeanConstructorInfo[]) default_mmbi.getConstructors();
    ModelMBeanConstructorInfo[] resourceConstructorInfos = createConstructors();
    ModelMBeanConstructorInfo[] finalConstructorInfos = 
                  new ModelMBeanConstructorInfo[defaultConstructorInfos.length + 
                                               resourceConstructorInfos.length];            
    System.arraycopy(defaultConstructorInfos,
                     0,
                     finalConstructorInfos,
                     0,  
                     defaultConstructorInfos.length);
                     
    System.arraycopy(resourceConstructorInfos,
                     0,
                     finalConstructorInfos, 
                     defaultConstructorInfos.length,
                     resourceConstructorInfos.length);                                     
                  
     // append operation infos to the already built ones
     ModelMBeanOperationInfo[] defaultOperationInfos = 
                  (ModelMBeanOperationInfo[]) default_mmbi.getOperations();
     ModelMBeanOperationInfo[] resourceOperationInfos = createOperations(); 
                               
     ModelMBeanOperationInfo[] finalOperationInfos = 
                      new ModelMBeanOperationInfo[defaultOperationInfos.length +
                                                 resourceOperationInfos.length];            
     System.arraycopy(defaultOperationInfos, 
                      0,
                      finalOperationInfos,
                      0, 
                      defaultOperationInfos.length);
     System.arraycopy(resourceOperationInfos, 
                      0,
                      finalOperationInfos, 
                      defaultOperationInfos.length,
                      resourceOperationInfos.length);
                         
     // append attribute infos to the already built ones
     ModelMBeanAttributeInfo[] defaultAttributeInfos = 
                       (ModelMBeanAttributeInfo[]) default_mmbi.getAttributes();
     ModelMBeanAttributeInfo[] resourceAttributeInfos = createAttributes();
                                
     ModelMBeanAttributeInfo[] finalAttributeInfos = 
                      new ModelMBeanAttributeInfo[defaultOperationInfos.length +
                                                 resourceAttributeInfos.length];            
     System.arraycopy(defaultAttributeInfos, 
                      0, 
                      finalAttributeInfos,
                      0, 
                      defaultAttributeInfos.length);
     System.arraycopy(resourceAttributeInfos, 
                      0, 
                      finalAttributeInfos, 
                      defaultAttributeInfos.length, 
                      resourceAttributeInfos.length);  
   
     return new ModelMBeanInfoSupport("javax.management.modelmbean." + 
                                      "RequiredModelMBean",
                                      "Manages a point (x, y)",
                                      finalAttributeInfos, 
                                      finalConstructorInfos,
                                      finalOperationInfos, 
                                      null, 
                                      mBeanDes());                                      
                                     
  } // end createModelMBeanInfo

  /**
   * Create the mbean descriptor
   */
  private Descriptor mBeanDes() {
    String[] fieldNames = new String[2];
    Object[] fieldValues = new Object[2];
    fieldNames[0] = "name";
    fieldValues[0] = "javax.management.modelmbean.RequiredModelMBean";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "mbean";
    return new DescriptorSupport(fieldNames, fieldValues);
  } // end mBeanDes

  /**
   * Configure two readable attributes X and Y (coordinate space).
   */
  private ModelMBeanAttributeInfo[] createAttributes() {
    ModelMBeanAttributeInfo[] mmbai = new ModelMBeanAttributeInfo[2];
    String[] fieldNames = new String[3];
    Object[] fieldValues = new Object[3];
    fieldNames[0] = "name";
    fieldValues[0] = "X";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "attribute";
    fieldNames[2] = "getMethod";
    fieldValues[2] = "getX";
    mmbai[0]= new ModelMBeanAttributeInfo("X", "double", "Readable attribute",
                                          true, false, false, 
                                          new DescriptorSupport(
                                                    fieldNames, fieldValues));
    fieldNames[0] = "name";
    fieldValues[0] = "Y";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "attribute";
    fieldNames[2] = "getMethod";
    fieldValues[2] = "getY";
    mmbai[1]= new ModelMBeanAttributeInfo("Y", "double", "Readable attribute",
                                          true, false, false, 
                                          new DescriptorSupport(
                                                    fieldNames, fieldValues));
    return mmbai;
  } // end createAttributes

  /**
   * Configures an operation matching the translate(int, int) method of Point.
   */
  private ModelMBeanOperationInfo[] createOperations() {
    ModelMBeanOperationInfo[] mmboi = new ModelMBeanOperationInfo[3];

    String[] fieldNames = new String[3];
    Object[] fieldValues = new Object[3];
    fieldNames[0] = "name";
    fieldValues[0] = "translate";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "operation";
    fieldNames[2] = "role";
    fieldValues[2] = "operation";

    MBeanParameterInfo[] params = new MBeanParameterInfo[2];
    params[0] = new MBeanParameterInfo("dx", "int",
                            "the distance to move this point along the x axis");
    params[1] = new MBeanParameterInfo("dy", "int",
                            "the distance to move this point along the y axis");

    mmboi[0] = new ModelMBeanOperationInfo("translate", "Translates the point",
                                          params, "void", 
                                          MBeanOperationInfo.ACTION, 
                                          new DescriptorSupport(
                                                     fieldNames, fieldValues));
    
    // X getter 
    fieldNames[0] = "name";
    fieldValues[0] = "getX";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "operation";
    fieldNames[2] = "role";
    fieldValues[2] = "getter";

    params = new MBeanParameterInfo[0];
    
    mmboi[1]= new ModelMBeanOperationInfo("getX", "Gets the X",
                                          params, "double", 
                                          MBeanOperationInfo.INFO, 
                                          new DescriptorSupport(
                                                     fieldNames, fieldValues));
    
    // Y getter 
    fieldNames[0] = "name";
    fieldValues[0] = "getY";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "operation";
    fieldNames[2] = "role";
    fieldValues[2] = "getter";

    params = new MBeanParameterInfo[0];
    
    mmboi[2]= new ModelMBeanOperationInfo("getY", "Gets the Y",
                                          params, "double", 
                                          MBeanOperationInfo.INFO, 
                                          new DescriptorSupport(
                                                     fieldNames, fieldValues));
     
    return mmboi;
  } // end createOperations

  /**
   * Configure a constructor matching the Point() constructor of Point.
   */
  private ModelMBeanConstructorInfo[] createConstructors() {

    String[] fieldNames = new String[3];
    Object[] fieldValues = new Object[3];
    fieldNames[0] = "name";
    fieldValues[0] = "javax.management.modelmbean.RequiredModelMBean";
    fieldNames[1] = "descriptorType";
    fieldValues[1] = "operation";
    fieldNames[2] = "role";
    fieldValues[2] = "constructor";
    ModelMBeanConstructorInfo[] mmbci = new ModelMBeanConstructorInfo[1];
    mmbci[0]= new ModelMBeanConstructorInfo(
                               "javax.management.modelmbean.RequiredModelMBean",
                               "initializes a point at the origin (0, 0)", null,
                                new DescriptorSupport(fieldNames, fieldValues));
    return mmbci;
  } // end createConstructors
} // end class ManagedResourcePoint
