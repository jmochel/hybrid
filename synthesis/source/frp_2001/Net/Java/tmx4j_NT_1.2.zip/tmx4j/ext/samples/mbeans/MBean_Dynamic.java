/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 16 1.4 ext/src/samples/mbeans/MBean_Dynamic.java, jmx_daemon, jmx_dev, 2001Jan5 01/01/04 13:41:46 $

package samples.mbeans;

import javax.management.*;

/*******************************************************************************
 *
 * MBeanDynamic.java
 *
 * This is a sample MBean, of the Dynamic type.
 * This same class serves two different types of resources: hard disk and 
 * printer. It impersonates one or the other depending on the "type" Integer 
 * paramenter of the constructor.
 * 
 * @author Raimondo Castino, Eliseba Costantini, Alessio Menale
 * @version 1.4
 *
 ******************************************************************************/
 
public class MBean_Dynamic implements DynamicMBean {

private String  diskSpace = "100.0 MB";
protected String  paperLeft = "80 sheets";
protected Integer type = new Integer(90);

  /*
   * Public constructor. The Integer "type" lets this object impersonate
   * one of several different Resources.
   */
  public MBean_Dynamic( Integer type ) {
	  this.type = type;
  }

  public MBean_Dynamic() {
	  this.type = new Integer(1);
  }

  public MBeanInfo getMBeanInfo() {
	  MBeanAttributeInfo[] attributes = new MBeanAttributeInfo[3];
	  /* MBeanAttributeInfo args: String name, String type, String description
                         boolean isReadable, boolean isWritable, boolean isIs */
	  attributes[0] = new MBeanAttributeInfo
               ("diskSpace", "java.lang.String", "Disk space", true,true,false);
  	attributes[1] = new MBeanAttributeInfo
               ("paperLeft", "java.lang.String", "Paper left",true,true,false);
  	attributes[2] = new MBeanAttributeInfo
               ("type", "java.lang.Integer", "",true,false,false);

	  MBeanParameterInfo[] parameters1 = new MBeanParameterInfo[1];
	  // MBeanParameterInfo args: String name, String type, String description
	  parameters1[0] = new MBeanParameterInfo("type","java.lang.Integer","");

	  MBeanConstructorInfo[] constructors = new MBeanConstructorInfo[2];
	  /* MBeanConstructorInfo args: String name, 
                          String description, MBeanParameterInfo[] signature */
	  constructors[0] = new MBeanConstructorInfo
                                 ("MBeanDynamic","",new MBeanParameterInfo[0]);
  	constructors[1] = new MBeanConstructorInfo("MBeanDynamic","",parameters1);

  	MBeanOperationInfo[] operations = new MBeanOperationInfo[1];
	  /* MBeanOperationInfo args: String name, String description, 
                MBeanParameterInfo[] signature, String returnType, int impact */
	  operations[0] = new MBeanOperationInfo("reset","Reset",
                                              new MBeanParameterInfo[0],
                                              "java.lang.Integer",
                                              MBeanOperationInfo.ACTION);
    /* MBeanInfo args: String className, String description,
           MBeanAttributeInfo[] attributes, MBeanConstructorInfo[] constructors,
      MBeanOperationInfo[] operations, MBeanNotificationInfo[] notifications) */
	  MBeanInfo mbi = new MBeanInfo(MBean_Dynamic.class.getName(),
                                    "An easy dynamic MBean",attributes,
                                          constructors,operations,null);
	  return mbi;
  } // end getMBeanInfo()


  /*
   * Lets a management application get the value of one attribute by name.
   */
  public Object getAttribute( String name ) {
	  if (name.equals("type")) {
		  return (type);
    }

	  if (name.equals("diskSpace")) {
		  return (diskSpace);
	  }

	  if (name.equals("paperLeft")) {
		  return (paperLeft);
	  }

	  return null;
  }



  public AttributeList getAttributes( String[] attributes ) {
	  AttributeList attributeList = new AttributeList();
	  for( int i = 0; i < attributes.length; i++ ) {
		  attributeList.add( new Attribute(attributes[i], 
                             getAttribute(attributes[i])) ); 
	  }

    return attributeList;
  }


  public void setAttribute( Attribute attribute ) 
                        throws AttributeNotFoundException {
    if( attribute.getName().equals("paperLeft") ) {
		  paperLeft = (String)attribute.getValue();
	  } else if(attribute.getName().equals("diskSpace")) {
		  diskSpace = (String)attribute.getValue();
	  } else {
		  // An invalid attribute is requested: throw an exception
		  throw( new AttributeNotFoundException() );
	  }
  } // end setAttribute()


  public AttributeList setAttributes(AttributeList attributeList) {
	  try {
		  for( int i = 0; i < attributeList.size(); i++ ) {
			  setAttribute( (Attribute)(attributeList.get(i)) );
		  }
	  } 
	  catch ( Exception e ) {
		  // Do nothing!
	  }

	  return attributeList;
  }

  public Object invoke( String actionName, 
                        Object[] params, String[] signature ) {
	  if(actionName.equals("reset"))
		  return reset();
	  else 
		  return null;
  } // end invoke()


  public Integer reset() {
  	diskSpace = "0.0 MB";
	  paperLeft = "0 sheets";
	  return new Integer(0);
  }
    
} // end class
