/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 23 1.2 ext/src/samples/mbeans/MBean_Relation.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:28 $

package samples.mbeans;

import javax.management.*;
import javax.management.monitor.*;

/*******************************************************************************
 * MBean_Relation.java
 *
 * @author Cosimo Vampo
 * @version 1.2
 *
 * A simple MBean that wraps three attributes suitable for a CounterMonitor,
 * a StringMonitor and a GaugeMonitor.
 * 
 * The initial value of the counter (firstAttribute) is set to zero by the
 * constructor.
 * At each observation the counter value is displayed and then increased by
 * one (this is a trick to simplify the example's structure).
 * When the counter reaches the current threshold a notification is sent and
 * a simple message is displayed.
 ******************************************************************************/
public class MBean_Relation implements MBean_RelationMBean,
                                      NotificationListener
{
    private Integer firstAttribute;
    private Integer  secondAttribute;
    private Integer thirdAttribute;

    // Gauge Monitor accessories
    private int delta = 1;


    public MBean_Relation()
    {
      this.firstAttribute = new Integer(0);
      this.secondAttribute = new Integer(0);
      this.thirdAttribute = new Integer(0);
    }

    public Integer getFirstAttribute()
    {
        Integer old_value = new Integer(firstAttribute.intValue());
        System.out.println("Observed Attribute: " + old_value);
        
        firstAttribute = new Integer(firstAttribute.intValue() + 1);
        return old_value;
    }

    public Integer getSecondAttribute()
    {
        Integer old_value = new Integer(secondAttribute.intValue());
        System.out.println("Observed Attribute: " + old_value);
        
        secondAttribute = new Integer(secondAttribute.intValue() + 1);
        return old_value;
    }
    

    public Integer getThirdAttribute()
    {
      Integer old = new Integer(thirdAttribute.intValue());
      System.out.println("Observed Attribute: " + old);
        
      int int_attr = thirdAttribute.intValue() + delta;
      if ((int_attr > 10 && delta == 1) ||
          (int_attr < 5  && delta == -1))
              delta = -delta;
            
      thirdAttribute = new Integer(int_attr);
        
      return old;
    }


    public void handleNotification(Notification notif, Object handback)
    {
        System.out.println("Notification Received!");
        System.out.println(" Message: " + notif.getMessage());
        System.out.println(" Notification Type: " + notif.getType());
    }

} // class MBean_Relation
