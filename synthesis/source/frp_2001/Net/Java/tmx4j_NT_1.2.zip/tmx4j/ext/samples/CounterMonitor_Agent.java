/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 02 1.3 ext/src/samples/CounterMonitor_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:04 $

package samples;

import samples.mbeans.MBean_Monitor;
import javax.management.*;
import javax.management.monitor.*;

/* This is a simple class that shows the usage of a CounterMonitor.
 *
 * First, it instantiates both an MBean server and the MBean (that wraps a
 * simple counter).
 * Second, it registers a CounterMonitor in the MBean server and sets all the
 * attributes (static fields constants) needed for the monitoring.
 * Third, the same MBean that wraps the counter is added as listener to the
 * monitor.
 * Finally the monitor is started. The observation time is twenty seconds.
 * When the observed attribute reaches the threshold a notification is
 * sent and a simple message is displayed.
 *
 * @author Alfredo Cappariello, Marco De Gregorio
 * @version 1.3
 */
 
public class CounterMonitor_Agent {

    MBeanServer mBS;
    CounterMonitor monitor;
    
    ObjectName on_mbean, on_monitor;
    ObjectInstance oi_mbean, oi_monitor;
    MBean_Monitor mbeanTest;
    
    static final String attribute = new String("FirstAttribute");
    static final int    GranularityPeriod = 1000,
                        InitialThreshold = 5,
                        Offset = 3;


    public CounterMonitor_Agent()
    {
        System.out.println("*** begin CounterMonitor_Agent ***");
        
        try {
        
            // Instantiates the MBean server
        
            mBS = MBeanServerFactory.createMBeanServer();
            System.out.println(">> Istantiated: MBeanServer");                                
                        
            // Instantiates and registers an MBean in the MBean server

            mbeanTest = new MBean_Monitor();
            on_mbean = new ObjectName("Domain:description=myMBean");
            oi_mbean = mBS.registerMBean(mbeanTest, on_mbean);
            System.out.println(">> Registered: MBean_Monitor");
            
            
            
            // Instantiates and registers a CounterMonitor in the MBean server
            
            monitor = new CounterMonitor();
            on_monitor = new ObjectName("MyDomain:description=myMonitor");
            monitor.setObservedObject(on_mbean);
            monitor.setObservedAttribute(attribute);
            monitor.setGranularityPeriod(GranularityPeriod);
            monitor.setThreshold(new Integer(InitialThreshold));
            monitor.setOffset(new Integer(Offset));
            monitor.setNotify(true);
            System.out.println(">> Istantiated: CounterMonitor");                        
        
        
            // The MBean is added as listener to the Monitor
        
            monitor.addNotificationListener(
              mbeanTest,
              null,
              new String("myHandback"));
            oi_monitor = mBS.registerMBean(monitor, on_monitor);

            System.out.println(">> Registered: Monitor");
        }
        catch (Exception e) {
            e.printStackTrace();
            
            System.exit(1);
        }

    }
    
    public void run() {
    
      try {
        // Starts the monitor
        monitor.start();
        
        // Waits 20 sec.
        Thread.sleep(20000);
        
        // ...and then stops it
        monitor.stop();
      }
      catch (Exception e) {
        e.printStackTrace();
        System.exit(1);
      }
    }

    public static void main(String args[])
    {
        CounterMonitor_Agent agent = new CounterMonitor_Agent();
        agent.run();
        
        System.out.println("***  end CounterMonitorExample  ***");
        System.exit(0);
    }
    
} // end class CounterMonitor_Agent
