/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 14 1.2 ext/src/samples/mbeans/MBean_Broadcaster.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:12 $

package samples.mbeans;

import javax.management.*;
import java.util.*;

/*******************************************************************************
 *
 * MBean_Broadcaster.javaa
 *
 * @author Eliseba Costantini, Alessio Menale
 * @version 1.2
 *
 ******************************************************************************/
public class MBean_Broadcaster 
      extends NotificationBroadcasterSupport implements MBean_BroadcasterMBean {
  private String Status;
  private boolean ready;
  private Integer numberDocs;
  private int[] Priority = {0, 0};
  private long timeOfActivity;
  private long typeStamp = 100000;
  
  public MBean_Broadcaster() {
    Status = "on";
    ready = true;
    System.out.println("\n Printer>> Printer status is 'ON' --> 'ready'");
    numberDocs = new Integer(0);
    timeOfActivity = System.currentTimeMillis();
  }

  public String getStatus() {
    return Status;
  } // end getStatus()

  public void switchOff() throws Exception {
      Status = "off";
      //notificare change!
      AttributeChangeNotification acn;
      typeStamp = typeStamp + 10;
      acn = new AttributeChangeNotification(new ObjectName(":broadcaster=FVT"),
                                            0,typeStamp, "printer off","Status",  
                                            "java.lang.String", "on", "off");
      sendNotification(acn);
      System.out.println("\n Printer>> Notified change of 'Status' "+
                                            "attribute (setted to 0FF)");
  
      long tStart = timeOfActivity;
      long tStop = System.currentTimeMillis();
      timeOfActivity = (tStop - tStart);
      //notificare change!
      typeStamp = typeStamp + 10;
      acn = new AttributeChangeNotification(new ObjectName(":broadcaster=FVT"),
                                            0, typeStamp, "time of activity", 
                                            "timeOfActivity", "long", 
                                            new Long(tStart), new Long(tStop));
      sendNotification(acn);
      System.out.println("\n Printer>> Notified evaluation of 'timeOfActivity'"
                                              +" attribute: " + timeOfActivity);
  } // end switchOff()

  public void clearQueue()  throws Exception {
    int n = numberDocs.intValue();
    if (n != 0) {
        numberDocs = new Integer(0);
        //notificare change!
        AttributeChangeNotification acn;
        typeStamp = typeStamp + 10;
        acn = new AttributeChangeNotification
                  (new ObjectName(":broadcaster=FVT"), 0, typeStamp, 
                                  "cleaned queue", "numberDocs", 
                                  "java.lang.Integer", new Integer(n), 
                                  new Integer(0));
        sendNotification(acn);
        System.out.println("\n Printer>> Notified change of 'numberDocs' " + 
                                                    "attribute (setted to 0)");
    }
  } // end clearQueue()

  public void print(String message) throws Exception {
      int n = numberDocs.intValue();
      numberDocs = new Integer( n+1 );
      //notificare change!
      AttributeChangeNotification acn;
      typeStamp = typeStamp + 10;
      acn = new AttributeChangeNotification
                (new ObjectName(":broadcaster=FVT"),0, typeStamp, 
                                "added doc to queue", "numberDocs", 
                                "java.lang.Integer", new Integer(n),
                                numberDocs);
      sendNotification(acn);
      System.out.println("\n Printer>> Notified change of "+
                                     "'numberDocs' attribute");
    
      boolean oldReady = ready;
      ready = false;
      if (oldReady != ready) {
        //notificare change!
        typeStamp = typeStamp + 10;
        acn = new AttributeChangeNotification
                  (new ObjectName(":broadcaster=FVT"), 0, typeStamp, 
                                  "not ready", "ready", "boolean", 
                                  new Boolean(oldReady), new Boolean(ready));
        sendNotification(acn);
        System.out.println("\n Printer>> Status isn't 'ready' (printing!), "+
                                                           "notified change!");
      }

      System.out.println("\n\n Printer>> Printing message '" + message + "'");
 
      System.out.println("\n Printer>> Print completed");
      ready = true;
      //notificare change!
      typeStamp = typeStamp + 10;
      acn = new AttributeChangeNotification
                (new ObjectName(":broadcaster=FVT"), 0, typeStamp, "ready", 
                                "ready", "boolean", new Boolean(false), 
                                new Boolean(ready));
      sendNotification(acn);
      System.out.println("\n Printer>> Status is 'ready' now "+
                          "(print completed!), notified change!");
  } // end print()

  public void setPriority(int i) throws Exception {
      int oldPriority = Priority[1];
      if (oldPriority != i) {     
        Priority[1] = i;
        //notificare change!
        AttributeChangeNotification acn;
        typeStamp = typeStamp + 10;
        acn = new AttributeChangeNotification
                  (new ObjectName(":broadcaster=FVT"), 0, typeStamp, 
                                  "changed priority", "Priority", "int", 
                                  new Integer(oldPriority), 
                                  new Integer(Priority[1]));
        sendNotification(acn);
        System.out.println("\n>> Priority of client is changed, "+
                                  "notified change! Priority: " + i);
      }
  } // setPriority

  public boolean isready() {
    return ready;
  }
  public Integer numberDocs() {
    return numberDocs;
  }
  public long gettimeOfActivity() {
    return timeOfActivity;
  }


} // end class MBean_Broadcaster


