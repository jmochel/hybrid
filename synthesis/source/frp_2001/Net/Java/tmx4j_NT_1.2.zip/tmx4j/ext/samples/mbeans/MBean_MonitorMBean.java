/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 22 1.2 ext/src/samples/mbeans/MBean_MonitorMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:26 $

package samples.mbeans;

/*******************************************************************************
 *
 *  MBean_MonitorMBean.java
 *
 * @author Marco De Gregorio
 * @version 1.2
 *
 ******************************************************************************/
public interface MBean_MonitorMBean
{
  public Integer getFirstAttribute();
  public void    setFirstAttribute(Integer n);

  public String  getSecondAttribute();
  public void    setSecondAttribute(String s);

  public Integer getThirdAttribute();
  public void    setThirdAttribute(Integer n);
}
