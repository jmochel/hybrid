/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 15 1.2 ext/src/samples/mbeans/MBean_BroadcasterMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:15 $

package samples.mbeans;

/*******************************************************************************
 *
 * MBean_BroadcasterMBeans.java
 *
 * @author Eliseba Costantini, Alessio Menale
 * @version 1.2
 *
 ******************************************************************************/
public interface MBean_BroadcasterMBean {
    
  public String getStatus();
  public void switchOff() throws Exception ;
  public void clearQueue() throws Exception ;
  public void print(String message) throws Exception ;
  public void setPriority(int i) throws Exception ;
  public boolean isready();
  public Integer numberDocs();
  public long gettimeOfActivity();
}
