/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 10 1.2 ext/src/samples/rmi/InvokeCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:59 $

package samples.rmi;

import java.rmi.RemoteException;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
/**
 * Instance of InvokeCmd represent command-lines
 * that contain the '--invoke' switch
 */
public class InvokeCmd extends Tmx4jCommand {
    private javax.management.ObjectName oname;
    private java.lang.String method;
    private java.lang.Object[] params;
    private java.lang.String[] sig;
    private final static int OBJECT_NAME = 1;
    private final static int METHOD = 2;
    private final static int PARAMETERS = 3;
    /**
     * Create a new InvokeCmd instance.
     */
    public InvokeCmd() {
	super();
    }
    /**
     * Invoke the the specified method against the given object name 
     * via the RMI MBeanServerConnection.
     */
    public void doIt() {
	try {
	    Object result = connection.invoke(oname, method, params, sig);
	    result = (result == null) ? "" : result;
	    System.out.println(result);
	} catch (RemoteException x) {
	    System.err.println("Can't invoke: " + x);
	}
    }
    /**
     * Initialize the InvokeCmd instance from the give args list.
     */
    public void init(String[] args) throws IllegalArgumentException {
	if (args.length < PARAMETERS) throw new IllegalArgumentException();
	try {
	    oname = new ObjectName(args[OBJECT_NAME]);
	    method = args[METHOD];
	    params = new Object[args.length - PARAMETERS];
	    sig = new String[args.length - PARAMETERS];
	    for (int i = PARAMETERS; i < args.length; i++) {
		CmdParam cp = new CmdParam(args[i]);
		params[i-PARAMETERS] = cp.getValue();
		sig[i-PARAMETERS] = cp.getType();
	    }
	} catch (MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}	
    }
}
