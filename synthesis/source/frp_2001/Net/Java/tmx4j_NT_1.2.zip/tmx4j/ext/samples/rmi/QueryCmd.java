/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 12 1.2 ext/src/samples/rmi/QueryCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:01 $

package samples.rmi;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.Set;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import javax.management.ObjectName;
/**
 * Instances of QueryCmd represent command-lines
 * that contain the '--query' switch
 */
class QueryCmd extends Tmx4jCommand {
    private ObjectName oname;
    /**
     * Create a new QueryCmd instance.
     */
    public QueryCmd() {
	super();
    }
    /**
     * Execute the 'queryNames' method with the specified object name pattern
     * via the RMI MBeanServerConnection.
     */
    public void doIt() {
	try {
	    Set onames = connection.queryNames(oname, null);
	    if (onames != null) {
		Iterator nmiter = onames.iterator();
		while (nmiter.hasNext()) {
		    System.out.println(((ObjectName)
					nmiter.next()).toString());
		}
	    }
	} catch (RemoteException x) {
	    System.err.println("Can't query: " + x);
	    System.exit(-1);
	}
    }
    /**
     * Use the command-line arguments to initialize
     * the query command.
     */
    public void init(String[] args) throws IllegalArgumentException {
	if (args.length < 2) throw new IllegalArgumentException();
	try {
	    oname = new ObjectName(args[1]);
	} catch (javax.management.MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
}
