/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 04 1.3 ext/src/samples/RmiDaemon.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/13 17:17:30 $

package samples;

import javax.management.*;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;

import com.tivoli.jmx.connector.ConnectorServer;

public class RmiDaemon {
    private static final String CSDOMAIN = "connectors:";
    private static final String CSKEYS =
	"type=ConnectorServer,connection=//localhost/MBeanServerConnection";
    private static final String CSCLASS =
	"com.tivoli.jmx.connector.RmiConnectorServer";

    public static void main(String[] args)
	  throws Exception {
	    MBeanServer mbs = MBeanServerFactory.createMBeanServer();
	    ConnectorServer cs = ConnectorServer.newInstance(CSCLASS);
	    ObjectName csName = new ObjectName(CSDOMAIN + CSKEYS);
	    mbs.registerMBean(cs, csName);
      System.out.println("RMI daemon started successfully.");
      try {
        mbs.invoke(csName, "start", null, null);
      } catch (ReflectionException re) {
        re.getTargetException().printStackTrace();        
      } catch (MBeanException mbe) {
        mbe.getTargetException().printStackTrace();        
      } catch (RuntimeOperationsException roe) {
        roe.getTargetException().printStackTrace();        
      } catch (RuntimeMBeanException rmbe) {
        rmbe.getTargetException().printStackTrace();        
      } catch (Exception e) {
        e.printStackTrace();        
      } // end try
      
    }
}
