/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 05 1.2 ext/src/samples/HTTPAdaptor_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:10 $

package samples;

import javax.management.ObjectName;
import javax.management.MBeanServer;
import com.tivoli.jmx.http_pa.Utilities;
import com.tivoli.jmx.http_pa.Listener;

/*******************************************************************************
 *
 * HTTPAdaptor_Agent.java
 *
 * Instantiates an MBeanServer and starts the HTTP_Adaptor.
 *
 * @author Kenneth Barron
 *
 * @version 1.2
 *
 ******************************************************************************/
public class HTTPAdaptor_Agent {
  
  public static void main (String[] args)  {
    try {
      // Instantiate the MBeanServer with a null Agent ID
      MBeanServer mbs = Utilities.getMBeanServer(null);

      // Create and Register the HTTP_Adaptor MBean
      Listener myListener = new Listener();
      ObjectName objNameListener = new ObjectName(":type=HTTP_Adaptor");
      mbs.registerMBean(myListener, objNameListener);
      System.out.println(
        "Adaptor registered with ObjectName of 'DefaultDomain:type=HTTP_Adaptor'");
    
      mbs.invoke(objNameListener,"startListener", null, null);
      System.out.println("Adaptor startListener invoked");
    } catch (Exception ex) {
      System.out.println("*** Error - unable to start Daemon ***");
      ex.printStackTrace();
    }
  }
}
