/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 18 1.2 ext/src/samples/mbeans/MBean_ListenerMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:22 $
 
package samples.mbeans;

/*******************************************************************************
 *
 * MBean_ListenerMBean.java
 *
 * @author Alfredo Cappariello, Marco De Gregorio, Alessio Menale
 * @version 1.2
 *
 ******************************************************************************/
public interface MBean_ListenerMBean {
  public void setMBeanModule(int mod);
  public int getMBeanModule();
  public void setCounter(int count);
  public int getCounter();
  public void setCounterDiffMode(int count);
  public int getCounterDiffMode();
  public void setCounterGet(int count);
  public int getCounterGet();
  public void setIncrementalValue(int value);
  public int getIncrementalValue();
  public void reset();
} // end interface S_MBeanS1MBean
