/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 20 1.2 ext/src/samples/rmitest/PersonMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:18 $

package samples.rmitest;

/**
 * Insert the type's description here.
 */
public interface PersonMBean {
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:16:57 PM)
 * @param meal java.lang.String
 * @param place java.lang.String
 */
void eat(String meal, String place);
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:13:15 PM)
 * @return byte
 */
byte getAge();
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:15:36 PM)
 * @return int
 */
int getHeight();
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:14:00 PM)
 * @return int
 */
int getWeight();
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:13:37 PM)
 * @param age byte
 */
void setAge(byte age);
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:14:23 PM)
 * @param weight int
 */
void setWeight(int weight);
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:17:42 PM)
 * @param hours int
 */
void sleep(int hours);
/**
 * Insert the method's description here.
 * Creation date: (9/8/00 5:18:05 PM)
 * @return int
 * @param hours int
 */
int work(int hours);
}
