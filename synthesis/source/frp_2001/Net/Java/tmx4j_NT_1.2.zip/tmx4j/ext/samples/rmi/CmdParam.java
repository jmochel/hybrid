/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 07 1.2 ext/src/samples/rmi/CmdParam.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:52 $

package samples.rmi;

import java.lang.reflect.Constructor;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
/**
 * Instances of CmdParam represent a command-line
 * parameter, i.e., a string of the form:
 * <value>:<type>.
 */
class CmdParam {
    private Object value;
    private String type;
    /**
     * Create a new CmdParameter instance from
     * a string with the form: <value>:<type>.
     * @param spec the parameter specification
     */
    public CmdParam(String spec) {
	StringTokenizer st = new StringTokenizer(spec, ":");
	try {
	    String vs = st.nextToken();
	    type = st.nextToken();
	    value = valueFromString(vs, type);
	} catch (NoSuchElementException x) {
	    throw new IllegalArgumentException(x.getMessage());
	} catch (Exception x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
    /**
     * Return the the <type> portion of the parameter
     * Creation date: (11/27/00 3:32:43 PM)
     * @return the parameter type
     */
    public String getType() {
	return type;
    }
    /**
     * Return the <value> portion of the parameter.
     * Creation date: (11/27/00 3:32:24 PM)
     * @return the parameter value
     */
    public Object getValue() {
	return value;
    }
    /**
     * Determine whether or not a string is
     * a proper parameter specification
     * Creation date: (11/27/00 4:17:12 PM)
     * @return true if the string is a parameter specification
     * @param spec a potential parameter specification string
     */
    public static boolean isParamSpec(String spec) {
	return (spec.indexOf(':') != -1);
    }
    /**
     * Turn a string representation of a value into
     * a value of the specified type. Note, assumes
     * that the type has a string constructor
     * Creation date: (11/27/00 3:46:08 PM)
     * @return value of the specified type corresponding to valstr
     * @param valstr string representation of the value
     * @param type the value's type
     */
    private Object valueFromString(String valstr, String type)
	throws Exception {
	if (type.compareTo("int") == 0) {
	    return new Integer(valstr);
	} else if (type.compareTo("byte") == 0) {
	    return new Byte(valstr);
	} else if (type.compareTo("long") == 0) {
	    return new Long(valstr);
	} else if (type.compareTo("float") == 0) {
	    return new Float(valstr);
	} else if (type.compareTo("double") == 0) {
	    return new Double(valstr);
	} else {
	    Class k = Class.forName(type);
	    Class[] params = {String.class};
	    Constructor ctor = k.getConstructor(params);
	    Object[] args = {valstr};
	    return ctor.newInstance(args);
	}
    }
}
