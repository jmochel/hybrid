/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 07 1.3 ext/src/samples/MLet_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:45 $

package samples;

import com.tivoli.jmx.*;
import javax.management.*;
import java.io.*;
import java.util.*;
import java.util.jar.*;
import java.lang.reflect.*;
import java.net.*;

/*******************************************************************************
 *
 * MLet_Agent.java
 *
 * @author Roberto Longobardi, Attilio Mattiocco
 * @version 1.3
 *
 ******************************************************************************/
public class MLet_Agent extends Thread {

  private boolean debug = true;
  private static String BASE_PATH = null;
  private MBeanServer mBeanServer;
  private ObjectName objName;
  private int successes = 0;
  private int expected_successes = 1;
  public  boolean allOK = true;

  public MLet_Agent() {
  }

  public void run() {

    ObjectName mBean1ObjName = null;
    
    // Getting path to server
    try {
      if ( debug ) System.out.println( "\n# getting path to server");
      ResourceBundle resources = ResourceBundle.getBundle("mlet");
      BASE_PATH = resources.getString("ServerPath1");
      if ( debug ) System.out.println( "\n# ServerPath retrieved: "+BASE_PATH);
    }
    catch(MissingResourceException x){
      if ( debug ) System.out.println( "\n# failed: check mlet.properties");
      System.exit(1);
    }
    
    if ( debug ) System.out.println( "\n# Creating MBeanServer" );
    mBeanServer = MBeanServerFactory.createMBeanServer("DomainForFVT");

    /**************************************************************************/
    try {
      /* Register MLet Service */
      Object[] params1 = new Object[1];
      String[] signature1 = new String[1];

      java.net.URL urls[] = new java.net.URL[1];
      // Dummy URL. Necessary for the constructor.
      urls[0] = new java.net.URL("file:/c:/");   
      
      if (debug) System.out.println( "\n# registering MLet Service" );
      
      params1[0] = urls;
      signature1[0] = new String(java.net.URL[].class.getName());
      ObjectInstance mlet = mBeanServer.createMBean(
            "javax.management.loading.MLet", new ObjectName(":type=MLet"),
            null, params1, signature1 );
            
      if (debug) System.out.println( "\n# done" );

      /* Loads and registers an MBean with the M-Let service, using an M-Let text file */
      Object[] params = new Object[1];
      String[] signature = new String[1];
      Set mbeans = null;

      ClassLoader cl = ClassLoader.getSystemClassLoader();
      
      params[0] = BASE_PATH+"Sample_MLet.xml";
      signature[0] = "java.lang.String";

      try {
        // Register the MBean. The resulting Set will either contain the 
        // ObjectInstance or a Throwable object.
        
        if (debug) System.out.println("\n# registering MBean from URL: "
                                      +params[0] );
        
        mbeans = (Set) mBeanServer.invoke( new ObjectName(":type=MLet"),
                                          "getMBeansFromURL", 
                                          params, 
                                          signature );
      
        if (debug) System.out.println( "\n# done" );
      
      } catch ( RuntimeException re ) {
        String msg = "Exception: "+re.getClass()+"->"+re.getMessage();
        if (debug) re.printStackTrace();
        Exception temp = re;
        while ( temp instanceof javax.management.RuntimeMBeanException ) {
          temp = ((javax.management.RuntimeMBeanException) 
                    temp).getTargetException();
          msg += "\n   >>> Nested Exception:"+temp.getClass()+":"+
                  temp.getMessage();
          if (debug) temp.printStackTrace();
        }
        while ( temp instanceof javax.management.RuntimeOperationsException ) {
          temp = ((javax.management.RuntimeOperationsException) 
                    temp).getTargetException();
          msg += "\n   >>> Nested Exception:"+temp.getClass()+":"+
                  temp.getMessage();
          if (debug) temp.printStackTrace();
        }
        if (debug) System.out.println ("MLet_Agent - run - Exception: "+msg);
      } catch ( Error err ) {
        if (debug) System.out.println ("MLet_Agent - run - Error: "+
                                      err.getClass()+":"+err.getMessage());
        if (debug) err.printStackTrace();
      } catch ( Exception e ) {
        if (debug) System.out.println ("MLet_Agent - run - Exception: "+
                                      e.getClass()+":"+e.getMessage());
        if (debug) e.printStackTrace();
      }

      // Print results
      if (debug) System.out.println(
                  "\n\n    >>>>>    Registration results     <<<<<");
      Iterator it = mbeans.iterator();
    
      int ii = 1;
      while ( it.hasNext() ) {
        Object nextMBean = it.next();
        if ( nextMBean instanceof Exception ) {
          Exception e = (Exception) nextMBean;
          if (debug) System.out.println("\n"+ (ii++) +") Exception: "+
                                        e.getClass()+"->"+e.getMessage());
        } else {
          if ( nextMBean instanceof Error ) {
            Error err = (Error) nextMBean;
            if (debug) System.out.println("\n"+ (ii++) +") Exception: "+
                                          err.getClass()+"->"+err.getMessage());
          } else {
            if ( nextMBean instanceof ObjectInstance ) {
              successes++;
              ObjectInstance oi = (ObjectInstance) nextMBean;
              if (debug) System.out.println("\n"+ (ii++) +") MBean: class="+
                  oi.getClassName()+", name="+oi.getObjectName().toString());
            }
          }
        }
      }
      
      if (debug) System.out.println(
                  "\n    >>>>> End of registration results <<<<<\n");

      if (successes != expected_successes) {
        allOK = false;
      }
    } catch ( Error err ) {
      allOK = false;
      // Catch all errors that could be thrown
      if ( debug ) System.out.println("Error: "+err.getMessage());
      err.printStackTrace();
    } catch ( Exception e ) {
      allOK = false;
      // Catch all exceptions that could be thrown
      if ( debug ) System.out.println("Exception: "+e.getClass()+"->"+
                                      e.getMessage());
      if ( e instanceof ReflectionException ) {
        ReflectionException re = (ReflectionException) e;
        Exception ne = re.getTargetException();
        if ( debug ) System.out.println("    >> Nested Exception: "+
                                        ne.getClass()+"->"+ne.getMessage());
        ne.printStackTrace();
      }
      e.printStackTrace();
    }

    if ( allOK ) {
      if ( debug ) System.out.println("\n\n****************************************************");
      if ( debug ) System.out.println(    "************* Registration successful !!! **********");
      if ( debug ) System.out.println(    "****************************************************\n\n");
      System.exit (0);
    } else {
      if ( debug ) System.out.println("\n\n****************************************************");
      if ( debug ) System.out.println(    "***************** Registration FAILED !!! **********");
      if ( debug ) System.out.println(    "****************************************************\n\n");
      System.exit (1);
    }
  } // end run


  public static void main(String[] args) {
    MLet_Agent tc = new MLet_Agent();
    new Thread(tc).start();
  } // end main
}
