/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 13 1.2 ext/src/samples/rmi/ShowCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:03 $

package samples.rmi;

import javax.management.MBeanInfo;
import java.rmi.RemoteException;
import javax.management.ObjectName;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.MalformedObjectNameException;
/**
 * Instances of ShowCmd represent command-lines that
 * contain the '--show' switch.
 */
class ShowCmd extends Tmx4jCommand {
    private javax.management.ObjectName oname;
    /**
     * Create a new ShowCmd instance.
     */
    public ShowCmd() {
	super();
    }
    /**
     * Get the specified object name's MBeanInfo and display it
     * on System.out.
     */
    public void doIt() {
	try {
	    MBeanInfo mbi = connection.getMBeanInfo(oname);
	    showMBeanInfo(mbi);
	} catch (RemoteException x) {
	    System.err.println("Can't show: " + x);
	    System.exit(-1);
	}
    }
    /**
     * Use the command-line arguments to initialize the
     * ShowCmd instance.
     */
    public void init(String[] args) throws IllegalArgumentException {
	if (args.length < 2) throw new IllegalArgumentException();
	try {
	    oname = new ObjectName(args[1]);
	} catch (MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
    /**
     * Insert the method's description here.
     * Creation date: (11/28/00 2:46:05 PM)
     * @param mbi javax.management.MBeanInfo
     */
    private String showAttributes(MBeanInfo mbi) {
	MBeanAttributeInfo[] attrs = mbi.getAttributes();
	StringBuffer sb = new StringBuffer();
	if (attrs == null || attrs.length == 0) {
	    sb.append("\tnone\n");
	} else {
	    for (int i = 0; i < attrs.length; i++) {
		sb.append("\t");
			
		if (attrs[i].isIs()) sb.append("i");
		else sb.append("-");
		if (attrs[i].isReadable()) sb.append("r");
		else sb.append("-");
		if (attrs[i].isWritable()) sb.append("w");
		else sb.append("-");
			
		sb.append("\t" + attrs[i].getType() +
			  "\t" + attrs[i].getName());

		try {
		    Object attr =
			connection.getAttribute(oname, attrs[i].getName());
		    sb.append("\t" + attr.toString());
		} catch (RemoteException x) {
		    sb.append("\tunavailable");
		}
		sb.append("\n");
	    }
	}
	return sb.toString();
    }
    /**
     * Insert the method's description here.
     * Creation date: (11/28/00 2:44:42 PM)
     * @param mbi javax.management.MBeanInfo
     */
    private String showConstructors(MBeanInfo mbi) {
	MBeanConstructorInfo[] ctors = mbi.getConstructors();
	StringBuffer sb = new StringBuffer();
	if (ctors == null || ctors.length == 0) {
	    sb.append("\tnone\n");
	} else {
	    for (int i = 0; i < ctors.length; i++) {
		sb.append("\t");
		sb.append(ctors[i].getName() + "(");
		MBeanParameterInfo[] params = ctors[i].getSignature();
		if (params != null && params.length > 0) {
		    for (int j = 0; j < params.length; j++) {
			sb.append(params[j].getType() + " " +
				  params[j].getName());
			if (params.length > (j+1)) sb.append(", ");
		    }
		}
		sb.append(")\n");
	    }
	}
	return sb.toString();
    }
    /**
     * Insert the method's description here.
     * Creation date: (11/28/00 2:40:25 PM)
     * @param mbi javax.management.MBeanInfo
     */
    private void showMBeanInfo(MBeanInfo mbi) {
	System.out.println("Object Name\n\t" + oname.toString());
	System.out.print("Constructors\n" + showConstructors(mbi));
	System.out.print("Operations\n" + showOperations(mbi));
	System.out.print("Attriubtes\n" + showAttributes(mbi));
	System.out.print("Notifications\n" + showNotifications(mbi));
    }
    /**
     * Insert the method's description here.
     * Creation date: (11/28/00 2:46:28 PM)
     * @param mbi javax.management.MBeanInfo
     */
    private String showNotifications(MBeanInfo mbi) {
	MBeanNotificationInfo[] notifs = mbi.getNotifications();
	StringBuffer sb = new StringBuffer();
	if (notifs == null || notifs.length == 0) {
	    sb.append("\tnone\n");
	} else {
	    for (int i = 0; i < notifs.length; i++) {
		sb.append("\t");
		sb.append(notifs[i].getName() + "\n");
		String[] ntypes = notifs[i].getNotifTypes();
		for (int j = 0; (ntypes != null) && (j < ntypes.length); j++) {
		    sb.append("\t\t" + ntypes[j] + "\n");
		}
	    }
	}
	return sb.toString();
    }
    /**
     * Insert the method's description here.
     * Creation date: (11/28/00 2:45:33 PM)
     * @param mbi javax.management.MBeanInfo
     */
    private String showOperations(MBeanInfo mbi) {
	MBeanOperationInfo[] ops = mbi.getOperations();
	StringBuffer sb = new StringBuffer();
	if (ops == null || ops.length == 0) {
	    sb.append("\tnone\n");
	} else {
	    for (int i = 0; i < ops.length; i++) {
		sb.append("\t");
		sb.append(ops[i].getReturnType() + " " +
			  ops[i].getName() + "(");
		MBeanParameterInfo[] params = ops[i].getSignature();
		if (params != null && params.length > 0) {
		    for (int j = 0; j < params.length; j++) {
			sb.append(params[j].getType() + " " +
				  params[j].getName());
			if (params.length > (j+1)) sb.append(", ");
		    }
		}
		sb.append(")\n");
	    }
	}
	return sb.toString();
    }
}

