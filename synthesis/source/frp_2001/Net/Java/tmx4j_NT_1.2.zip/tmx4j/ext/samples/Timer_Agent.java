/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 12 1.3 ext/src/samples/Timer_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:27 $

package samples;

import javax.management.*;
import javax.management.timer.Timer;
import java.io.*;
import java.util.*;
import samples.mbeans.MBean_Timer;

/*******************************************************************************
 * Timer_Agent.java
 * 
 * The timer service sends only one notification to the
 * MBean that is registered as listener
 * 
 * @author Marco Melillo
 * @version 1.3
 *
 ******************************************************************************/
public class Timer_Agent 
{
  /**MBeanServer*/
  private static MBeanServer mBeanServer;
  
  /**Timer_Agent body*/
  public static void run() {
    //The main will sleep for tMain time; in milliseconds
    int tMain=3000;
    //Timer's ObjectName
    ObjectName objTimer=null;
    //MBean_Timer's ObjectName
    ObjectName objSL=null;
    //ObjectName temporate objTmp
    ObjectName objTmp=null;
    
    Set s=null;
    Iterator i=null;
    Timer timer=null;
    
    samples.mbeans.MBean_Timer sl=null;
    
    try {
      objTimer=new ObjectName(":type=Timer");
      
      //Registers Timer
      timer=new Timer();
      mBeanServer.registerMBean(timer, objTimer);
            
      //Registers simple listener MBean_Timer
      objSL=new ObjectName(":type=MBean_Timer");
      sl=new MBean_Timer(mBeanServer, objTimer);
      mBeanServer.registerMBean(sl, objSL);
            
      //MBeans queries
      s=mBeanServer.queryNames(null,null);
      
      //It prints how many MBeans have been registered
      System.out.println("MBean registered:");
      i=s.iterator();
      while (i.hasNext()) {
          objTmp=(ObjectName)i.next();
        System.out.println(objTmp.getCanonicalName());
      }
      System.out.println();
      
      //I'm starting timer service
      mBeanServer.invoke(objTimer,"start", new Object[0], new String[0]);
      
      //I need to sleep for the tMain time
      Thread.currentThread().sleep(tMain);
    }catch(Exception e) {
      e.printStackTrace();
    } 
  }

  /**Main method*/
  public static void main(String[] args) {
    System.out.println("*** Timer_Agent");
    System.out.println("*** begin");
    
    //I'm creating MBeanServer
    mBeanServer = MBeanServerFactory.createMBeanServer();
    
    //It invokes the run method, it contains the class's body test
    System.out.println();         
    run();
    System.out.println();         
    
    System.out.println("*** Timer_Agent");
    System.out.println("*** end");    
  }
}
