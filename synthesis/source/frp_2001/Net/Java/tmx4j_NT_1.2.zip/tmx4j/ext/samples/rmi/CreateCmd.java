/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 08 1.2 ext/src/samples/rmi/CreateCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:54 $

package samples.rmi;

import java.rmi.RemoteException;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
/**
 * Instances of CreateCmd represent command-lines that
 * specify the '--create' switch
 */
class CreateCmd extends Tmx4jCommand {
    private final static int CLASS = 1;
    private final static int OBJECT_NAME = 2;
    private final static int OPTIONS = 3;
    private String clazz;
    private javax.management.ObjectName oname;
    private javax.management.ObjectName ldrname;
    private java.lang.Object[] params;
    private java.lang.String[] sig;
    /**
     * Create a new CreateCmd instance
     */
    public CreateCmd() {
	super();
    }
    /**
     * Create a new MBean via the RMI MBeanServerConnection.
     */
    public void doIt() {
	try {
	    connection.createMBean(clazz, oname);
	} catch (RemoteException x) {
	    System.err.println("Can't create: " + x);
	    System.exit(-1);
	}
    }
    /**
     * Initialize the CreateCmd from the specified arguments list.
     */
    public void init(String[] args) throws IllegalArgumentException {
	if (args.length <= OBJECT_NAME) throw new IllegalArgumentException();
	try {
	    int fp = OPTIONS;
	    clazz = args[CLASS];
	    oname = new ObjectName(args[OBJECT_NAME]);
	    if (args.length > OPTIONS) {
		if (CmdParam.isParamSpec(args[OPTIONS]) == false) {
		    ldrname = new ObjectName(args[OPTIONS]);
		    fp++;
		}
		for (int i = fp; i < args.length; i++) {
		    CmdParam cp = new CmdParam(args[i]);
		    params[i - fp] = cp.getValue();
		    sig[i - fp] = cp.getType();
		}
	    }
	} catch (MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
}

