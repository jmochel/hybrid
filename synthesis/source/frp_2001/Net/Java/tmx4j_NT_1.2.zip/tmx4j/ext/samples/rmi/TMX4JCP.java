/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 15 1.2 ext/src/samples/rmi/TMX4JCP.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:08 $

package samples.rmi;

/**
 * Instances of TMX4JCP, the TMX4J Control
 * Program, are the core of a command-line
 * utility that provides remote JMX Agent
 * access via the RMI MBeanServerConnection.
 */
public class TMX4JCP {
    private Tmx4jCommand command;
    /**
     * Create a new TMX4JCP instance. Each TMX4JCP is a
     * command whose doIt() method executes the action
     * specified by the command-line arguments.
     * @param args the array of command-line arguments
     */
    public TMX4JCP(String[] args) {
	command = Tmx4jCommand.cmdFromArgs(args);
    }
    /**
     * Delegate to the Tmx4jCommand contained in
     * command.
     * Creation date: (11/24/00 4:35:51 PM)
     */
    public void doIt() {
	command.doIt();
    }
    /**
     * A simple control program that accesses a JMX
     * agent running an RMI ConnectorServer. The syntax
     * of the command is:<pre>
     * 	java TMX4JCP <command> <arguments>
     * The commands are:
     * 	--query <objectname>
     * 	--create <class> <objectname> [loader] [parameters]
     *	--show <objectname>
     * 	--invoke <objectname> <method> [parameters]
     * 	--update <objectname> <attribute> <value>
     * 	--unregister <objectname>
     * 	--help
     * Parameters are specified by strings with the
     * following format:
     * 	<value>:<type>
     * </pre>
     * @param args an array of command-line arguments
     */
    public static void main(java.lang.String[] args) {
	TMX4JCP cp = new TMX4JCP(args);
	cp.doIt();
    }
}
