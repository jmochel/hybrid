/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 27 1.3 ext/src/samples/mbeans/MBean_Timer.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:38 $

package samples.mbeans;

import javax.management.*;
import com.tivoli.jmx.timer.*;
import java.util.*;

/*******************************************************************************
 *  MBean_Timer.java
 *
 * @author Marco Melillo
 * @version 1.3
 *
 ******************************************************************************/
public class MBean_Timer implements MBean_TimerMBean, NotificationListener
{
  ObjectName objTimer=null;
  MBeanServer mBeanServer=null;
  String name="MBean_Timer";
  
  TimerNotificationFilter myFilter=null;
  Integer myId=null;
  
  /**Constructor*/  
  public MBean_Timer(MBeanServer mbs, ObjectName ot) throws Exception {
    mBeanServer=mbs;
    objTimer=ot;
    //'date' is the time of notification
    //The time is now plus one second
    Date date=new Date((new Date()).getTime()+1000);
      
    //It adds notification on timer object using method invoke on MBeanServer
    Object[] objs=new Object[4];
    objs[0]=name;
    objs[1]="message";
    objs[2]=null;//user's Object
    objs[3]=date;
    String[] pars=new String[4];
    pars[0]="java.lang.String";
    pars[1]="java.lang.String";
    pars[2]="java.lang.Object";
    pars[3]="java.util.Date";
    Object objInt=mBeanServer.invoke(ot, "addNotification", objs, pars);
    myId=(Integer)objInt;
      
    //It creates the filter
    myFilter=new TimerNotificationFilter();
    myFilter.setIdentifier(myId);

    //It sets this object like listener on MBeanServer 
    //using filter and timer's ObjectName   
    mBeanServer.addNotificationListener(objTimer, this, myFilter, null);
  }
    
  /**MBean method*/
  public String getName() {
    return name;
  }
  
  /**It manages the notification received from the Timer*/  
  public void handleNotification(Notification notif, Object handback) {          
    System.out.println(name+"---> Notification Received <---");
  }
}

