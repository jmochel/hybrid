/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 17 1.2 ext/src/samples/mbeans/MBean_Listener.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:19 $
 
package samples.mbeans;

import javax.management.*;

/*******************************************************************************
 *
 * MBean_Listener.java
 *
 * This is a dummy Listener MBean, which can be used to listen for Notifications
 * on any MBean.
 *
 * @author Alfredo Cappariello, Marco De Gregorio, Alessio Menale
 * @version 1.2
 *
 ******************************************************************************/
 
public class MBean_Listener 
                    implements MBean_ListenerMBean, NotificationListener {
  
  static private int notificationCounter = 0;
  private int counter;
  private int counterDiffMode;
  private int counterGet;
  private int incrementalValue;
  private int mBeanModule;

  public MBean_Listener() {
    counter = 0;
    counterGet = 0;
    incrementalValue = 0;
	  mBeanModule = 0;
  } // end constructor 

  public void setCounter(int count) {
    counter = count;
  } // end setCounter()

  public int getCounter() {
    counterGet++;
    System.err.println("counter: " + counter + 
                       "       N. notification: " + notificationCounter);
  	counter += incrementalValue;
  	return (counter-incrementalValue);
  } // end getCounter()

	public void setCounterDiffMode(int countdiff) {
    if (countdiff >= mBeanModule) {
      counterDiffMode = countdiff%mBeanModule;
    }
	  else
	    counterDiffMode = countdiff;
  } // end setCounterDiffMode()

  public int getCounterDiffMode() {
    counterGet++;
    System.err.println("counterDiffMode: " + counterDiffMode + 
                       "       N. notification: " + notificationCounter);
	  if (mBeanModule != 0 && counterDiffMode >= mBeanModule)	{
      counterDiffMode = counterDiffMode%mBeanModule;
    	return counterDiffMode;
	  }
  	else
  	  counterDiffMode += incrementalValue;
  	return (counterDiffMode-incrementalValue);
  } // end getCounterDifMode()

  public void setCounterGet(int count) {
    counterGet = count;
  } // end setCounterGet()

  public int getCounterGet() {
    return counterGet;
  } // end getCounterGet()

  public void setMBeanModule(int mod) {
    mBeanModule = mod;
  } // end setMBeanModule()

  public int getMBeanModule() {
    return mBeanModule;
  } // end getMBeanModule()

  public void setIncrementalValue(int value) {
    incrementalValue = value;
  } // end setIncrementalValue()

  public int getIncrementalValue() {
    return incrementalValue;
  } // end getIncrementalValue()

  public void reset() {
    counter = 0;
    counterDiffMode = 0;
    counterGet = 0;
    incrementalValue = 0;
    notificationCounter = 0;
  } // end reset() 

  public void handleNotification(Notification notif, Object handback) {
    notificationCounter++;
    System.out.println("Notification #" + notificationCounter);    
  } // end handleNotification()

  public int getNotificationCounter() {
    return notificationCounter;
  } // end getNotificationCounter()

} // end class MBean_Listener
