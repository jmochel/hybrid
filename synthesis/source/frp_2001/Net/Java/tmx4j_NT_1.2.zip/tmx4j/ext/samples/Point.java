/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 66 1.2 ext/src/samples/Point.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:49 $

package samples;

/**
 * Point class 
 * 
 * used for samples
 *
 * @author Massimo Tarquini
 * @version 1.2
 */
public class Point {
  
  private double x;
  private double y;
  
  /*
   * Constructor
   */
  public Point(int x, int y) {
    this.x = x;
    this.y = y;
  }
  
  /*
   * Constructor
   */
  public Point() {
    this.x = 0;
    this.y = 0;
  }
  
  /*
   * Getter method
   */
  public double getX() {
    return this.x;
  }
  
  /*
   * Getter method
   */
  public double getY() {
    return this.y;
  }
  
  /*
   * Setter method
   */
  public void setX(double x) {
    this.x = x;
  }
  
  /*
   * Setter method
   */
  public void setY(double y) {
    this.y = y;
  }
  
  /*
   * Setter method
   */
  public void translate(int x, int y) {
    this.x = x;
    this.y = y;
  }
}
