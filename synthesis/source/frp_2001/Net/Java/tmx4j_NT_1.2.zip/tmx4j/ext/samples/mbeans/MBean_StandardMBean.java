/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 26 1.2 ext/src/samples/mbeans/MBean_StandardMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:36 $

package samples.mbeans;

/*******************************************************************************
 *
 * MBeanStandardMBean.java
 *
 * @author Raimondo Castino, Eliseba Costantini, Alessio Menale
 * @version 1.2
 *
 ******************************************************************************/
public interface MBean_StandardMBean {
 	public String getdiskSpace();
 	public String getpaperLeft();
	public Integer gettype();

	public void setdiskSpace( String space );
	public void setpaperLeft( String paper );

 	public Integer reset();
	public int ping( String host, float f);
}
