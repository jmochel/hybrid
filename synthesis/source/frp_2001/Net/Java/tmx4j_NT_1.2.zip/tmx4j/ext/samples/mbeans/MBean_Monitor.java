/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 21 1.3 ext/src/samples/mbeans/MBean_Monitor.java, jmx_daemon, jmx_dev, 2001Jan5 01/01/04 12:06:00 $

package samples.mbeans;

import javax.management.*;
import javax.management.monitor.*;

/*******************************************************************************
 * MBean_Monitor.java
 *
 * @author Marco De Gregorio, Alfredo Cappariello, Massimo Tarquini
 * 
 * A simple MBean that wraps three attributes suitable for a CounterMonitor,
 * a StringMonitor and a GaugeMonitor.
 * 
 * The initial value of the counter (firstAttribute) is set to zero by the
 * constructor.
 * At each observation the counter value is displayed and then increased by
 * one (this is a trick to simplify the example's structure).
 * When the counter reaches the current threshold a notification is sent and
 * a simple message is displayed.
 ******************************************************************************/
public class MBean_Monitor implements MBean_MonitorMBean,
                                      NotificationListener
{
    private Integer firstAttribute;
    private String  secondAttribute;
    private Integer thirdAttribute;

    // String Monitor accessories
    private String obs_str;
    private String str_toObserve[];
    private String toCompare;
    private int vect_size, current_index;
    public boolean stop_flag;

    // Gauge Monitor accessories
    private int delta = 1;

    // Constructor (for Counter and Gauge Monitors)
    public MBean_Monitor()
    {
      this.firstAttribute = new Integer(0);
      this.secondAttribute = new String("");
      this.thirdAttribute = new Integer(0);
    }

    // Constructor (for String Monitor)
    public MBean_Monitor(String toCompare, String toObserve[])
    {
      this.obs_str = null;
      this.toCompare = toCompare;
      this.str_toObserve = toObserve;
      this.vect_size = toObserve.length;
      this.current_index = 0;
      this.stop_flag = false;
    }

    public Integer getFirstAttribute()
    {
      Integer old_value = new Integer(firstAttribute.intValue());
      System.out.println("Observed Attribute: " + old_value);
        
      firstAttribute = new Integer(firstAttribute.intValue() + 1);
      return old_value;
    }
    
    public void setFirstAttribute(Integer n)
    {
      this.firstAttribute = n;
    }

    public String getSecondAttribute()
    {       
      System.out.println("Observed String: " + secondAttribute);
      String old_str = new String(secondAttribute);
        
      current_index++;
      if (current_index == vect_size) {
        current_index = 0;
        stop_flag = true;
      }
      if (str_toObserve != null)
        secondAttribute = str_toObserve[current_index];
      
      return old_str;
    }
    
    public void setSecondAttribute(String s)
    {
      this.secondAttribute = s;
    }
    
    public Integer getThirdAttribute()
    {
      Integer old = new Integer(thirdAttribute.intValue());
      System.out.println("Observed Attribute: " + old);
        
      int int_attr = thirdAttribute.intValue() + delta;
      if ((int_attr > 10 && delta == 1) ||
          (int_attr < 5  && delta == -1))
            delta = -delta;
            
      thirdAttribute = new Integer(int_attr);
        
      return old;
    }

    public void setThirdAttribute(Integer n)
    {
      this.thirdAttribute = n;
    }
    
    public void handleNotification(Notification notif, Object handback)
    {
        System.out.println("Notification Received!");
        System.out.println(" Message: " + notif.getMessage());
        System.out.println(" Notification Type: " + notif.getType());
    }
    
} // class MBean_Monitor
