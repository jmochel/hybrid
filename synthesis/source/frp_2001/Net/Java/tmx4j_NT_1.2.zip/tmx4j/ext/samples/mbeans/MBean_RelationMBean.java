/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 24 1.2 ext/src/samples/mbeans/MBean_RelationMBean.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:31 $

package samples.mbeans;

/*******************************************************************************
 * MBean_RelationMBean.java
 *
 * @author Cosimo Vampo
 * @version 1.2
 *
 ******************************************************************************/
public interface MBean_RelationMBean
{
  public Integer getFirstAttribute();

  public Integer  getSecondAttribute();

  public Integer getThirdAttribute();
}
