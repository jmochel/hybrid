/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 08 1.3 ext/src/samples/ModelMBean_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:47 $

package samples;

import javax.management.*;
import javax.management.modelmbean.*;

/*******************************************************************************
 * ModelMBean_Agent.java
 *
 * An agent that registers a ModelMBean and invokes
 * the 'getAttribute' and 'invoke' methods over this ModelMBean.
 * 
 * @author Eliseba Costantini, Max Parlione
 * @version 1.3
 ******************************************************************************/
public class ModelMBean_Agent {

  public static void main(String[] args) {
    try {
      // MBeanServer inizialization
      MBeanServer mBeanServer = MBeanServerFactory.createMBeanServer();
      System.out.println("MBeanServer created.");

      ObjectName modelMBeanName = new ObjectName("MyDomain:number=1");
      mBeanServer.createMBean(RequiredModelMBean.class.getName(), 
                                                                modelMBeanName);
      System.out.println("ModelMBean registered.");
      
      // gets the default modelmbeaninfo 
      MBeanInfo default_mmbi = (MBeanInfo) mBeanServer.getMBeanInfo(
                                                                modelMBeanName);

      ManagedResourcePoint managedResource = new ManagedResourcePoint(
                                                                  default_mmbi);

      // gets the modelmbeaninfo describing the modelmbean and the resource
      ModelMBeanInfo mmbi = managedResource.getResourceInfos();
      
      // sets the managed resource
      mBeanServer.invoke(modelMBeanName, "setModelMBeanInfo",
                   new Object[] {mmbi},
                   new String[] {ModelMBeanInfo.class.getName()});
      System.out.println("ModelMBeanInfo set...");                                           
      
      // sets the managed resource
      Object resourceReference = managedResource.getReference();
      mBeanServer.invoke(modelMBeanName, "setManagedResource",
                         new Object[] {resourceReference ,"ObjectReference"},
                         new String[] {"java.lang.Object", "java.lang.String"}
                        );
      System.out.println("managed resorce set...");                        

      // gets the attribute values
      System.out.println("getAttribute X and Y ...");
      double x = ((Double) mBeanServer.getAttribute(
                    modelMBeanName, "X")).doubleValue();
      double y = ((Double) mBeanServer.getAttribute(
                    modelMBeanName, "Y")).doubleValue();
      System.out.println("This point represents a location in (" 
                                                          + x + ", " + y + ")");

      System.out.println("Invoking the 'translate' method...");
      Object[] params =  {new Integer(50), new Integer(30)};
      String[] signature =  {"int", "int"};
      mBeanServer.invoke(modelMBeanName, "translate", params, signature);

      System.out.println("Verify the new location of this point...");
      double X = ((Double)mBeanServer.invoke(modelMBeanName, 
                                                  "getX", 
                                                  new Object[0],
                                                  new String[0])).doubleValue();                                                         
      double Y = ((Double)mBeanServer.invoke(modelMBeanName, 
                                                  "getY", 
                                                  new Object[0], 
                                                  new String[0])).doubleValue();                                                         
      System.out.println("This point has been translated in (" 
                                                           + X + ", " + Y + ")");
              
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
      //e.getTargetException()
      e.printStackTrace();
      System.out.println("Unespected error");
    }
  } // end main

} // end class ModelMBean_Agent
