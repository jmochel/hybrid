/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 03 1.3 ext/src/samples/DynamicMBean_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 01/01/04 13:39:31 $

package samples;

import javax.management.ObjectInstance;
import javax.management.ObjectName;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.Attribute;

/*******************************************************************************
 *
 * DynamicMBean_Agent.java
 *
 * Makes use of the MBean_Dynamic sample Dynamic mbean.
 * Instantiates an MBeanServer and performs simple operations on the MBean.
 *
 * @author Attilio Mattiocco, Massimo Tarquini, Alessio Menale
 *
 * @version 1.3
 *
 ******************************************************************************/
public class DynamicMBean_Agent {
  
  public DynamicMBean_Agent() {
  }

  public static void main (String[] args)  {
  
   ObjectName name1 = null;
   MBeanServer MBS = MBeanServerFactory.createMBeanServer();
   Object testMBean = null;
   ObjectInstance instance;
   Object obj;
   
   try  {
      name1 = new ObjectName("MyDomain:Value=1");

      System.out.println("Instantiate the MBean");
      testMBean = MBS.instantiate("samples.mbeans.MBean_Dynamic", null);
    
      System.out.println("Register the MBean");
      instance = MBS.registerMBean(testMBean, name1);
    
      System.out.println("Invoke the operation");
      obj = MBS.invoke(name1, "reset", null, null);  

      System.out.println("Get an attribute");
      obj = MBS.getAttribute(name1, "diskSpace");  

      System.out.println("Set an attribute");
      Attribute attr = new Attribute("diskSpace", "finish");
      MBS.setAttribute(name1, attr);  

   }
   catch (Exception e)  {
     System.out.println("failure, exiting...");
     e.printStackTrace();
   } //end try-catch
  }// end main
  
}
