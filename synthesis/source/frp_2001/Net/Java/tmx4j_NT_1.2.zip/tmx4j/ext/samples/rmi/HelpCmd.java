/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 09 1.2 ext/src/samples/rmi/HelpCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:11:56 $

package samples.rmi;

/**
 * Instances of HelpCmd represent command-lines
 * that use the '--help' switch or that contain
 * an unknown switch.
 */
public class HelpCmd extends Tmx4jCommand {
/**
 * Create a new HelpCmd instance.
 */
public HelpCmd() {
	super();
}
/**
 * Print the TMX4JCP usage message on System.out.
 */
public void doIt() {
	String help = 
	"Usage: java -Dtmx4j.connector=<MBeanConnection> samples.rmi.TMX4J --<command> args\n" +
	"where <command> <args> is one of:\n" +
	"\tquery <object name>\n" +
	"\tcreate <class name> <object name>\n" +
	"\tshow <object name>\n" +
	"\tinvoke <object name> <method> [parameters]\n" +
	"\tupdate <object name> <attribute> <value>\n" +
	"\tunregister <object name>\n" +
	"\thelp\n" +
	"parameters are specified as <value>:<type>";
	System.out.println(help);
}
/**
 * Initialize the HelpCmd from the given args list.
 */
public void init(String[] args) throws IllegalArgumentException {}
}
