/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 14 1.3 ext/src/samples/rmi/Tmx4jCommand.java, jmx_daemon, jmx_dev, 2001Jan5 01/01/04 14:31:27 $

package samples.rmi;

import com.tivoli.jmx.connector.rmi.*;

/**
 * Base class for all of the TMX4JCP commands.
 */
abstract class Tmx4jCommand {
	protected MBeanServerConnection connection;
  /**
   * Create a new Tmx4jCommand instance.
   * Creation date: (11/27/00 2:46:18 PM)
   */
  public Tmx4jCommand() {
    String cp = null;
    try {
      cp = System.getProperty("tmx4j.connection");
    } catch (SecurityException x) {
      System.err.println("Can't access tmx4j.connection property: " + x);
      System.exit(-1);
    } catch (NullPointerException x) {
      System.err.println("Null tmx4j.connection property");
      System.exit(-1);
    } catch (IllegalArgumentException x) {
      System.err.println("Empty key");
      System.exit(-1);
    }
    
    try {
      connection = (MBeanServerConnection) java.rmi.Naming.lookup(cp);
    } catch (Exception x) {
      System.err.println("Can't connect to " + cp);
      System.exit(-1);
    }
  }
  /**
   * Creates an instance of the command subtype
   * appropriate for the command-line arguments.
   * Any error in the command-line results in the
   * creation of a "help" command.
   * Creation date: (11/24/00 4:50:42 PM)
   * @return samples.rmi.Tmx4jCommand
   * @param args java.lang.String
   */
  public static Tmx4jCommand cmdFromArgs(String[] args) {
    Tmx4jCommand cmd = null;
    
    if (args == null || args.length == 0){
      return new HelpCmd();
    }
    
    try {
      cmd = cmdFromSwitch(args[0]);
      cmd.init(args);
    } catch (RuntimeException x) {
      cmd = new HelpCmd();
    } finally {
      return cmd;
    }
  }
  /**
   * Create the type of command indicated by the command
   * switch argument.
   * Creation date: (11/24/00 5:22:48 PM)
   * @return samples.rmi.Tmx4jCommand
   * @exception java.lang.IllegalArgumentException The exception description.
   */
  private static Tmx4jCommand cmdFromSwitch(String cmdSwitch) 
                                     throws IllegalArgumentException {
    Tmx4jCommand cmd = null;
    String cs = parseCmdSwitch(cmdSwitch);
    if (cs.compareToIgnoreCase("query") == 0) {
      cmd = new QueryCmd();
    } else if (cs.compareToIgnoreCase("create") == 0) {
      cmd = new CreateCmd();
    } else if (cs.compareToIgnoreCase("show") == 0) {
      cmd = new ShowCmd();
    } else if (cs.compareToIgnoreCase("invoke") == 0) {
      cmd = new InvokeCmd();
    } else if (cs.compareToIgnoreCase("update") == 0) {
      cmd = new UpdateCmd();
    } else if (cs.compareToIgnoreCase("unregister") == 0) {
      cmd = new UnregisterCmd();
    } else {
      cmd = new HelpCmd();
    }
    return cmd;
  }
  /**
   * Execute the command.
   * Creation date: (11/24/00 4:38:10 PM)
   */
  public abstract void doIt();
  /**
   * Initialize the command from the command-line arguments.
   * Creation date: (11/24/00 5:47:03 PM)
   * @param args java.lang.String[]
   * @exception java.lang.IllegalArgumentException The exception description.
   */
  public abstract void init(String[] args) throws IllegalArgumentException;
  /**
   * Strips the leading "--" off the command switch
   * and returns the command string. Throws an
   * IllegalArgumentException if the "--" prefix
   * isn't there.
   * Creation date: (11/24/00 5:37:42 PM)
   * @return java.lang.String
   * @param cmdSwitch java.lang.String
   */
  private static String parseCmdSwitch(String cmdSwitch) {
    if (cmdSwitch.startsWith("--") == false) {
      throw new IllegalArgumentException();
    }
    return cmdSwitch.substring(2);
  }
}
