/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 11 1.3 ext/src/samples/StringMonitor_Agent.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:24 $

package samples;

import samples.mbeans.MBean_Monitor;
import javax.management.*;
import javax.management.monitor.*;
import java.util.*;

/**
 *  StringMonitor_Agent.java
 *
 * @author Marco De Gregorio
 * @version 1.3
 */
public class StringMonitor_Agent {

    MBeanServer mBS;
    StringMonitor monitor;
    ObjectName on_mbean, on_monitor;
    ObjectInstance oi_mbean, oi_monitor;
    MBean_Monitor mbeanTest;

    public StringMonitor_Agent(long GP, String toCompare, String toObserve[])
    {   
        try {
            // Instantiates the MBean server
        
            mBS = MBeanServerFactory.createMBeanServer();
            System.out.println(">> Istantiated: MBeanServer");
        
            // Vector params[] contains the strings to compare with the
            // observed attribute.
            
                        
            // Instantiates and registers an MBean in the MBean server.

            mbeanTest = new MBean_Monitor(toCompare, toObserve);
            mbeanTest.setSecondAttribute(toObserve[0]);
            on_mbean = new ObjectName("Domain:description=myMBean");
            oi_mbean = mBS.registerMBean(mbeanTest, on_mbean);
            System.out.println(">> Registered: MBean_Monitor");
            
            // Instantiates and registers a StringMonitor in the MBean server
            
            monitor = new StringMonitor();
            on_monitor = new ObjectName("MdGDomain:description=myMonitor");
            monitor.setObservedObject(on_mbean);
            monitor.setObservedAttribute("SecondAttribute");
            monitor.setGranularityPeriod(GP);
            monitor.setNotifyMatch(true);
            monitor.setNotifyDiffer(true);
            monitor.setStringToCompare(toCompare);
            System.out.println(">> Istantiated: Monitor");
        
            // The tm MBean is added as listener to the Monitor
        
            monitor.addNotificationListener(mbeanTest, null, new String("myHandback"));
            
            oi_monitor = mBS.registerMBean(monitor, on_monitor);
            System.out.println(">> Registered: Monitor");
        }
        catch (Exception e) {
            e.printStackTrace();
            
            System.exit(1);
        }
    }
    
    public void run() {
    
      try {
        // Starts the monitor
        monitor.start();
        
        // Waits until mbean's stop_flag = true
        do {
          Thread.sleep(1000);
        } while (!mbeanTest.stop_flag);
        
        // ...and then stops the monitor
        monitor.stop();
      }
      catch (Exception e) {
        e.printStackTrace();
        System.exit(1);
      }
    }

    public static void main(String args[])
    {
        long GP = 5000;
        String toCompare = "ciao";
        String toObserve[] = {
            "ciao",
            "bye",
            "ciao"
        };

        StringMonitor_Agent agent =
                        new StringMonitor_Agent(GP, toCompare, toObserve);
        agent.run();
        
        System.out.println("***  end StringMonitorExample  ***");
        System.exit(0);
    }
}
