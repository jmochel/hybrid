/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 17 1.2 ext/src/samples/rmi/UpdateCmd.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:13 $

package samples.rmi;

import java.rmi.RemoteException;
import javax.management.Attribute;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
/**
 * Instances of UpdateCmd represent command-lines that
 * contain the '--update' switch.
 */
public class UpdateCmd extends Tmx4jCommand {
    private final static int OBJECT_NAME = 1;
    private final static int ATTRIBUTE = 2;
    private final static int VALUE = 3;
    private javax.management.ObjectName oname;
    private java.lang.String attrName;
    private java.lang.Object attrValue;
    /**
     * Create a new UpdateCmd instance.
     */
    public UpdateCmd() {
	super();
    }
    /**
     * Set the attribute specified by the UpdateCmd to the
     * given value.
     */
    public void doIt() {
	try {
	    connection.setAttribute(oname, new Attribute(attrName, attrValue));
	} catch (RemoteException x) {
	    System.err.println("Can't update: " + x);
	    System.exit(-1);
	}
    }
    /**
     * Initialize the UpdateCmd from the command-line arguments.
     */
    public void init(String[] args) throws IllegalArgumentException {
	if (args.length <= VALUE) throw new IllegalArgumentException();
	try {
	    oname = new ObjectName(args[OBJECT_NAME]);
	    attrName = args[ATTRIBUTE];
	    attrValue = (new CmdParam(args[VALUE])).getValue();
	} catch (MalformedObjectNameException x) {
	    throw new IllegalArgumentException(x.getMessage());
	}
    }
}
