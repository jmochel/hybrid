/*---------------------------------------------------------------------------*\
|                                                                             |
| COPYRIGHT:                                                                  |
|   Tivoli Management Extensions for Java V1.1                                |
|                                                                             |
|   Licensed Materials - Property of IBM                                      |
|   (C) Copyright IBM Corporation 2000                                        |
|   All Rights Reserved                                                       |
|   US Government Users Restricted Rights - Use, duplication, or              |
|   disclosure restricted by GSA ADP Schedule Contract with IBM Corp.         |
|                                                                             |
\*---------------------------------------------------------------------------*/

// $Revision: @(#) 09 1.3 ext/src/samples/Relation_Sample.java, jmx_daemon, jmx_dev, 2001Jan5 00/12/12 19:12:20 $

package samples;

import samples.mbeans.*;
import javax.management.*;
import javax.management.monitor.*;
import javax.management.relation.*;

import java.util.*;

/*******************************************************************************
 *
 * Relation_Sample.java
 *
 * This is a sample use of the relation package.
 * Three attributes of an mbean are observed by three Monitors; two of them by 
 * two CounterMonitors, the third one by a GaugeMonitor. Two Relations are 
 * created for the mbean: the first with the CounterMonitors, the second with 
 * the GaugeMonitor.
 * In this case the Relations are, respectively, internal and external Relations.
 * 
 * @author Cosimo Vampo, Maurizio Simeoni
 * @version 1.3
 *
 ******************************************************************************/
class Relation_Sample {

  MBeanServer mbs;
  ObjectName relServiceObjName;
  MBean_Relation mbeanTest;

  //ObjectName on_mbean, on_monitor;
  ObjectName observedObjName,
             counter1ObjName,
             counter2ObjName,
             gaugeObjName;


  /**
   * Constructor
   */
  public Relation_Sample() throws Exception {
    
    initialize();
    makeRelationTypes();
    makeRelations();
  }

  private void initialize() throws Exception {
   
    mbs = MBeanServerFactory.createMBeanServer();
    System.out.println(">> Istantiated: MBeanServer");   
    
    RelationService relationService = new RelationService(true);

    relServiceObjName = new ObjectName("MyDomain:description=RelationService");
    mbs.registerMBean(relationService, relServiceObjName); 
    System.out.println(">> Registered: Relation Service");                        

    registerObservedMBean();
    counter1ObjName = new ObjectName("MyDomain:description=myMonitorFirst");
    counter2ObjName = new ObjectName("MyDomain:description=myMonitorSecond");
    registerCounterMonitor(counter1ObjName, "FirstAttribute");
    registerCounterMonitor(counter2ObjName, "SecondAttribute");
    registerGaugeMonitor();
  }

  private void registerObservedMBean() throws Exception {

    mbeanTest = new MBean_Relation();
    observedObjName = new ObjectName("MyDomain:description=myMBean");
    mbs.registerMBean(mbeanTest, observedObjName);
    System.out.println(">> Registered: Observed MBean");                        
  }

  private void registerCounterMonitor(ObjectName objectName, String attribute) 
                               throws Exception {

   int    GranularityPeriod = 1000,
          InitialThreshold = 5,
          Offset = 3;
    CounterMonitor monitor = new CounterMonitor();
    monitor.setObservedObject(objectName);
    monitor.setObservedAttribute(attribute);
    monitor.setGranularityPeriod(GranularityPeriod);
    monitor.setThreshold(new Integer(InitialThreshold));
    monitor.setOffset(new Integer(Offset));
    monitor.setNotify(true);

    // The MBean is added as listener to the Monitor

    monitor.addNotificationListener(
      mbeanTest,
      null,
      new String("myHandback"));
    mbs.registerMBean(monitor, objectName);
    System.out.println(">> Registered: Counter Monitor");
    // Starts the monitor    
    monitor.start();
  }

  private void registerGaugeMonitor() throws Exception{
    
    GaugeMonitor monitor = new GaugeMonitor();
    gaugeObjName = new ObjectName("MyDomain:description=myMonitorThird");
    
    monitor.setObservedObject(gaugeObjName);
    monitor.setObservedAttribute("ThirdAttribute");
    monitor.setGranularityPeriod(300);
    monitor.setThresholds(new Integer(10), new Integer(5));
    monitor.setNotifyHigh(true);
    monitor.setNotifyLow(true);
    
    // The tm MBean is added as listener to the Monitor
    
    monitor.addNotificationListener(mbeanTest, null, new String("myHandback"));
    
    mbs.registerMBean(monitor, gaugeObjName);
    System.out.println(">> Registered: Gauge Monitor");
    // Starts the monitor and then sleeps for twenty seconds
    monitor.start();
  }

  private void makeRelationTypes() throws Exception {
    
    RoleInfo[] roleInfos = new RoleInfo[2];
    roleInfos[0] = new RoleInfo("Monitors", 
                                "javax.management.monitor.CounterMonitor", 
                                true, true, 1, 2, "");
    roleInfos[1] = new RoleInfo("Observed", 
                                "samples.mbeans.MBean_Relation", 
                                true, true, 1, 1, "");
    String typeName = "CounterObservation";
    String[] signature = {"java.lang.String", 
                          javax.management.relation.RoleInfo[].class.getName()};
    Object[] params = {typeName, roleInfos};
    mbs.invoke(relServiceObjName, "createRelationType", params, signature);

    System.out.println(">> Created: Relation type " + typeName);

    roleInfos[0] = new RoleInfo("Monitors", 
                                "javax.management.monitor.GaugeMonitor", 
                                true, true, 1, 2, "");
    roleInfos[1] = new RoleInfo("Observed", 
                                "samples.mbeans.MBean_Relation", 
                                true, true, 1, 1, "");
    typeName = "GaugeObservation";
    params[0] = typeName;
    mbs.invoke(relServiceObjName, "createRelationType", params, signature);

    System.out.println(">> Created: Relation type " + typeName);
  }

  private void makeRelations() throws Exception {
    
    //make the counter relation (internal)
    String relId = "CounterRelation";
    String relTypeName = "CounterObservation";
    RoleList roleList = new RoleList();

    ArrayList monitorList = new ArrayList();
    monitorList.add(counter1ObjName);
    monitorList.add(counter2ObjName);
    Role monitorsRole = new Role("Monitors", monitorList);
    roleList.add(monitorsRole);

    ArrayList observedList = new ArrayList();
    observedList.add(observedObjName);
    Role observedRole = new Role("Observed", observedList);
    roleList.add(observedRole);

    String[] signature = {"java.lang.String", "java.lang.String", 
                          "javax.management.relation.RoleList"};
    Object[] params = {relId, relTypeName, roleList};
    mbs.invoke(relServiceObjName, "createRelation", params, signature);
    System.out.println(">> Created: Relation " + relId);

    //make the gauge relation (external)
    relId = "GaugeRelation";
    relTypeName = "GaugeObservation";
    roleList = new RoleList();

    monitorList = new ArrayList();
    monitorList.add(gaugeObjName);
    monitorsRole = new Role("Monitors", monitorList);
    roleList.add(monitorsRole);
    roleList.add(observedRole);

    RelationSupport gaugeRelation = new RelationSupport(relId, 
                                                        relServiceObjName, 
                                                        mbs, 
                                                        relTypeName,
                                                        roleList);
    ObjectName gaugeRelationObjName;
    gaugeRelationObjName = new ObjectName("MyDomain:description=Relation");
    mbs.registerMBean(gaugeRelation, gaugeRelationObjName);

    mbs.invoke(relServiceObjName, "addRelation", 
                new Object[] {gaugeRelationObjName},
                new String[] {"javax.management.ObjectName"});
    System.out.println(">> Added: Relation " + relId);
  }

  private void print(Map map) {
    Set keys = map.keySet();
    Iterator iter = keys.iterator();
    System.out.println(
      "follow the monitor object names' associated to the observed mbean:");
    while(iter.hasNext()){
      System.out.println(iter.next().toString());
    }
  }

	public static void main(String[] args) throws Exception{

    Relation_Sample sample = new Relation_Sample();
    String[] signature = {"javax.management.ObjectName",
                          "java.lang.String",
                          "java.lang.String"};
    Object[] params = {sample.observedObjName, null, null};
    Map map = (Map)sample.mbs.invoke(sample.relServiceObjName,
                                     "findAssociatedMBeans", 
                                     params, signature);
    sample.print(map);
	}
}
