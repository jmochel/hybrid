package PVS.Utils;

public class DoubleR extends Object{
  public double value;
  public DoubleR(){this.value = 0.0;}
  public DoubleR(double value){
    this.value = value;
  }
  public String toString(){return Double.toString(value);}
}
