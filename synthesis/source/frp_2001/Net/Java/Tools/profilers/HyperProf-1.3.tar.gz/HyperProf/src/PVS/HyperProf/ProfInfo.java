package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import PVS.Utils.Comparator;
import PVS.Utils.QSort;

class ProfInfo extends Object{

  Hashtable table = new Hashtable();

  PackageTable packages = new PackageTable();
  
  Vector entries = new Vector();
  static int total_time = 0;
  static int current_time = 0;
  Main mainframe;
  ProfInfo(Main mainframe){
    total_time = 0;
    this.mainframe = mainframe;
  }

  Enumeration getMethods(){
    return entries.elements();
  }

  void addElement(ProfLine entry){

    ProfEntry callee = (ProfEntry)table.get(entry.calleeName);
    if(callee == null){
      callee = new ProfEntry(entry.calleeName,mainframe);
      table.put(entry.calleeName,callee);
      entries.addElement(callee);
    }	

    ProfEntry caller = (ProfEntry)table.get(entry.callerName);
    if(caller == null){
      caller = new ProfEntry(entry.callerName,mainframe);
      table.put(entry.callerName,caller);
      entries.addElement(caller);
    }	

    callee.addCaller(new CallerEntry(caller,entry.time,entry.calls,mainframe));
    caller.addCallee(new CallerEntry(callee,entry.time,entry.calls,mainframe));

    packages.add(callee);
    packages.add(caller);

        
    //total_time += entry.time;
  }

  void initTime(){
    total_time = 0;
    for(int i=0;i < entries.size();i++){
      int time = ((ProfEntry)entries.elementAt(i)).time;
      // not all entries are presented as a callee
      // and therefore some (?.? for example) have negative time 
      if(time > 0) 
	total_time += time;
    }
    System.out.println("\ntotal time: "+total_time+"ms");
  }

  void sort(){    
    // ProfEntry can be a comparator for ProfEntry 
    Comparator comp = (Comparator)entries.elementAt(0);
    QSort.quickSort(entries,0,entries.size()-1,comp);
    for(int i=0;i<entries.size();i++){
      ProfEntry entry = (ProfEntry)entries.elementAt(i);
      if(entry.callerList.size() > 0)
	QSort.quickSort(entry.callerList,0,entry.callerList.size()-1,
			(Comparator)entry.callerList.elementAt(0));
      if(entry.calleeList.size() > 0)
	QSort.quickSort(entry.calleeList,0,entry.calleeList.size()-1,
			(Comparator)entry.calleeList.elementAt(0));
    }
  }
}
