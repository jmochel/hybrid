package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.util.Hashtable;
import java.util.Enumeration;
import java.io.PrintStream;

class PackageTable {

  Hashtable packages = new Hashtable();
  boolean modified = false;
  int numMethods=0, numPackages=0, numClasses=0;
  ProfEntry sEntry = new ProfEntry("?.?", null); // '?.?' entry

  PackageTable(){
  }
  
  void add(ProfEntry entry){
    modified = true;
    if(entry.name.methodName.equals("?.?")){ 
      // special entry 
      sEntry = entry;
      return;
    }
    PackageEntry pe = (PackageEntry)packages.get(entry.name.packageName);
    if(pe == null){
      pe = new PackageEntry(entry.name.packageName);
      packages.put(entry.name.packageName,pe);
    }
    pe.addClass(entry);     
  }   
  

  int countMethods(){
    if(modified){
      countAll();
    }
    return numMethods;     
  }

  int countPackages(){
    if(modified){
      countAll();
    }
    return numPackages;         
  }

  int countClasses(){
    if(modified){
      countAll();
    }
    return numClasses;  
  }

  void countAll(){
    numPackages = 0;
    numClasses = 0;
    numMethods = 0;
    for(Enumeration pack = packages.elements(); pack.hasMoreElements();){
      PackageEntry pe = (PackageEntry)pack.nextElement();
      numPackages++;
      for(Enumeration cle = pe.classes.elements(); cle.hasMoreElements();){
	ClassEntry cl = (ClassEntry)cle.nextElement();
	numClasses++;
	for(Enumeration me = cl.methods.elements(); me.hasMoreElements();){
	  ProfEntry e = (ProfEntry)me.nextElement();
	  numMethods++;
	}
      }
    }
    modified = false;
  }

  void print(PrintStream p){
    for(Enumeration pack = packages.elements(); pack.hasMoreElements();){
      PackageEntry pe = (PackageEntry)pack.nextElement();
      p.println("|"+pe.name+"|");
      for(Enumeration cle = pe.classes.elements(); cle.hasMoreElements();){
	ClassEntry cl = (ClassEntry)cle.nextElement();
	p.println("  |"+cl.name+"|");
	for(Enumeration me = cl.methods.elements(); me.hasMoreElements();){
	  ProfEntry e = (ProfEntry)me.nextElement();
	  p.println("    |"+e.name.methodName+"|");
	}
      }
    }
  }
}       	

