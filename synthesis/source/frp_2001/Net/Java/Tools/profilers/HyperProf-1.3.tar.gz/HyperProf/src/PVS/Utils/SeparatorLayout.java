package PVS.Utils;
/**
 * A layout manager for container splitted into two 
 *   resizable component with separator
 *   container should contain exactly 3 component
 *   first and last are "real" component
 *   middle component is separator
 *
 * @version 1.0, 12/14/95
 * @author V.Bulatov
 */

import java.awt.*;


public class SeparatorLayout implements LayoutManager {
  public static final int VERTICAL = 0; // separator is horizontal
  public static final int HORIZONTAL = 1;// separator is vertical
  
  int direction;

  private double weight=0.5; // weight of first component

  public SeparatorLayout() {
    this(HORIZONTAL);
  }
  
  public SeparatorLayout(int direction) {
    this(direction,0.5);
  }

  public SeparatorLayout(int direction, double weight) {
    this.direction = direction;    
    if(weight >1.0 || weight < 0.0)
      throw new 
	IllegalArgumentException("wrong weight:" + weight);
    this.weight = weight;
  }
  
  /**
   * required by interface
   */
  public void addLayoutComponent(String name, Component comp) {
  }
  
  /**
   * required by interface
   */
  public void removeLayoutComponent(Component comp) {
  }

  /** 
   * Returns the preferred dimensions for this layout given the components
   * in the specified container.
   * @param parent the component which needs to be laid out 
   * @see #minimumLayoutSize
   */
  public Dimension preferredLayoutSize(Container parent) {
    int ncomponents = parent.countComponents();
    if(ncomponents != 3 ){
      throw new 
	IllegalArgumentException("wrong number of component ["+
				 ncomponents+"] for SeparatorLayout");
    }

    return getSize(parent,
		   parent.getComponent(0).preferredSize(),
		   parent.getComponent(1).preferredSize(),
		   parent.getComponent(2).preferredSize());
  }

  /** 
   * Returns the minimum dimensions for this layout given the components
   * in the specified container.
   * @param parent the component which needs to be laid out 
   * @see #minimumLayoutSize
   */
  public Dimension minimumLayoutSize(Container parent) {
    int ncomponents = parent.countComponents();
    if(ncomponents != 3 ){
      throw new 
	IllegalArgumentException("wrong number of component for SeparatorLayout");
    }

    return getSize(parent,
		   parent.getComponent(0).minimumSize(),
		   parent.getComponent(1).minimumSize(),
		   parent.getComponent(2).minimumSize());
  }
  
  /**
    just calculates width and height of columns
   */

  Dimension getSize(Container parent,Dimension d0, Dimension d1, Dimension d2){
    int width, height;
    switch(direction){
    default:
    case HORIZONTAL:
      width = d0.width;
      if(width < d1.width)
	width = d1.width;
      if(width < d2.width)
	width = d2.width;
      height = d0.height+d1.height+d2.height;
      break;
    case VERTICAL:
      height = d0.height;
      if(height < d1.height)
	height = d1.height;
      if(height < d2.height)
	height = d2.height;
      width= d0.width+d1.width+d2.width;
      break;
    }
    
    Insets insets = parent.insets();
    return new Dimension(insets.left + insets.right+width,
			 insets.top + insets.bottom + height);
  }
  
  /** 
   * Lays out the container in the specified panel.  
   * @param parent the specified component being laid out
   * @see Container
   */
  public void layoutContainer(Container parent) {
    Insets insets = parent.insets();

    int ncomponents = parent.countComponents();
    if(ncomponents != 3 )
      return;

    Component comp0 = parent.getComponent(0);
    Component sep = parent.getComponent(1);
    Component comp1 = parent.getComponent(2);

    int w = parent.size().width - (insets.left + insets.right);
    int h = parent.size().height - (insets.top + insets.bottom);

    
    switch(direction){
    default:
    case HORIZONTAL:
      int hs = sep.minimumSize().height;
      int h1 = (int)((h-hs)*weight);
      comp0.reshape(0, 0, w, h1);
      sep.reshape(0, h1, w, hs);
      comp1.reshape(0, h1+hs, w, h - h1 - hs);
      break;
    case VERTICAL:
      int ws = sep.minimumSize().width;
      int w1 = (int)((w-ws)*weight);
      comp0.reshape(0, 0, w1, h);
      sep.reshape(w1, 0, ws, h);
      comp1.reshape(w1+ws, 0, w - w1 - ws,h );
      break;      
    }

    comp0.validate();
    comp1.validate();
  }

  /** 
   * moves separator of in this Container and setup 
   * current proportion of division of the Container
   */
  public void moveSeparator(Container parent, int x, int y){
    if(parent.getLayout() != this){
      throw new 
	IllegalArgumentException
	  ("layout of container is not this SeparatorLayout");
    }

    Insets insets = parent.insets();

    int ncomponents = parent.countComponents();
    if(ncomponents != 3 )
      return;

    Component comp0 = parent.getComponent(0);
    Component sep = parent.getComponent(1);
    Component comp1 = parent.getComponent(2);

    int w = parent.size().width - (insets.left + insets.right);
    int h = parent.size().height - (insets.top + insets.bottom);

    switch(direction){
    default:
    case HORIZONTAL:
      int hs = sep.minimumSize().height;
      if(y < 0)
	y = 0;
      else if (y > h - hs)
	y = h - hs;
      weight = (double)y/(h-hs);
      break;
    case VERTICAL:
      int ws = sep.minimumSize().width;
      if(x < 0)
	x = 0;
      else if(x > w - ws)
	x = w-ws;
      weight = (double)x/(w-ws);
      break;      
    }   
    parent.invalidate();

    parent.validate();
  }

  public void setWeight(double weight){
    if(weight >1.0 || weight < 0.0)
      throw new 
	IllegalArgumentException("wrong weight:" + weight);
    this.weight = weight;
  }
  
  /**
   * Returns the String representation of this SeparatorLayout's values.
   */
  public String toString() {
    return getClass().getName() + "[direction = "
      +((direction == HORIZONTAL)?"HORIZONTAL":"VERTICAL")+
	", weight = "+weight+"]";
  }

}
