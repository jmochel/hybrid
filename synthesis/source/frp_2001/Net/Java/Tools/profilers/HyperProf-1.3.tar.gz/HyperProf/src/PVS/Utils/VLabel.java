package PVS.Utils;

import java.awt.*;

public class VLabel extends Panel
{
  static public final int WEST_EAST = 0, SOUTH_NORTH = 1;

  String label;
  int alignment;
  int direction;
  
  public VLabel() {
    this("");
  }

  public VLabel(String label) {
    this(label,Label.LEFT);
  }

  public VLabel(String label, int alignment) {
    this(label,alignment,WEST_EAST);
  }

  public VLabel(String label, int alignment, int direction) {
    this.label = label;
    this.direction = direction;
    this.alignment = alignment;
  }
    
  public void setText(String label){
    if (label != this.label && (this.label == null || !this.label.equals(label))) {
      this.label = label;
      memImage = null;
      invalidate();
      validate();
    }
  }
  
  public Dimension minimumSize() {
    
    //setFont(new Font(getFont().getName(),getFont().getStyle(),getFont().getSize()));
    if (label != null) {
      FontMetrics labelMetrics = getFontMetrics(getFont());      
      
      int labelWidth = labelMetrics.stringWidth(label);
      int labelHeight = labelMetrics.getAscent()+labelMetrics.getDescent();
            
      if(direction == WEST_EAST)
	return (new Dimension (labelWidth,labelHeight));
      else if(direction == SOUTH_NORTH)
	return (new Dimension (labelHeight,labelWidth));
    } 
    return new Dimension (0,0);
  }

  public Dimension preferredSize() {
    return minimumSize();
  }
  
  public void update(Graphics g){
    paint(g);
  }


  Image memImage; // image of this label in memory

  public void paint (Graphics g) {
    if(memImage == null)
      makeMemImage();
    g.drawImage(memImage,0,0,null);
  }       

  void makeMemImage(){
    Dimension dim = size();
    int width, height;
    switch(direction){
    default:
    case WEST_EAST:
      width = dim.width; height = dim.height;
      break;
    case SOUTH_NORTH:      
      width = dim.height; height = dim.width;
      break;
    }

    memImage = this.createImage(width,height); 
    Graphics memG = memImage.getGraphics();

    memG.setColor(getBackground());
    memG.fillRect(0,0,width,height);

    memG.setFont(getFont());    
    FontMetrics fm = getFontMetrics(getFont());
    memG.setColor(getForeground());
    memG.drawString (label, 0, fm.getAscent());
    memG.dispose();

    if(direction == SOUTH_NORTH){
      memImage = ImageUtils.rotateImage(memImage,90);
    }    
  }

  /*
  public void paint(Graphics g) {
    LabelPeer peer = (LabelPeer)this.getPeer();
    //peer.paint
    System.out.println("vlabel:paint");
    g.setColor(Color.blue);
    //g.fillRect(0,0,size().width,size().height);
    //super.paint(g);
  }
  */
}
