package PVS.Utils;

import java.awt.*;

public class DestroyableFrame extends Frame {
  public DestroyableFrame(String title) { 
    super(title); 
  }
  public boolean handleEvent(Event evt) {
    switch (evt.id) {
    case Event.WINDOW_DESTROY: 
      this.hide();  
      this.dispose();
      //if(getParent()==null)
      // System.exit(0);
      return true;      
    }
    return false; 
  }
}
