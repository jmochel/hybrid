package PVS.Hyperbolic;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.


import java.awt.Color;
import PVS.Utils.MathExt;

public class HyperCyrcle extends Object implements HyperObject,Cloneable{

  public Color color = Color.black;
  public Complex z;
  public double radius;
  public boolean hollow = false;
  public double eradius; // euclidean radius
  public double ecenterx, ecentery;// euclidean positions
  
  boolean wasMoved = true;

  public HyperCyrcle(){
    z = new Complex();
  }

  public HyperCyrcle(Complex z, double radius, Color color){
    this(z, radius, color, true);
  }

  public HyperCyrcle(Complex z, double radius, Color color, boolean hollow){
    this.z = new Complex(z);
    this.color = color;
    this.radius = radius;
    this.hollow = hollow;
  }

  public void place(double x, double y){
    z.set(x,y);
    wasMoved = true;
  }

  public void doTranslate(Complex p){
    Hyperbolic.doTranslate(z,p);
    wasMoved = true;
  }
  
  public void doRotate(Complex teta){
    z.mul(teta);
    wasMoved = true;
  }

  public void doTransform(HTransform t){
    Hyperbolic.doTransform(z,t);
    wasMoved = true;
  }

  public void reflect(Arc arc){
    Hyperbolic.reflect(z,arc);     
    wasMoved = true;
  }

  // temporary variables
  private static Complex z1 = new Complex(), z2 = new Complex();

  public void draw(Graphics2d g){
    if(wasMoved){
      // euclidean radius 
      double erad = MathExt.tanh(0.5*radius);  
      double zlen = z.abs();
      // move cyrcle in place
      if(zlen != 0.0){
	z1.set(erad*z.re/zlen,erad*z.im/zlen);  
	z2.set(-erad*z.re/zlen,-erad*z.im/zlen);
	Hyperbolic.doTranslate(z1,z);
	Hyperbolic.doTranslate(z2,z);
	z1.add(z2); z1.mul(0.5); 
	z2.sub(z1);
	// euclidean radius of moved cyrcle
	eradius = z2.abs();
	ecenterx = z1.re;
	ecentery = z1.im;
      } else {
	eradius = erad;
	ecenterx = z.re;
	ecentery = z.im;
      }
      wasMoved = false;
    }
    g.setColor(color);
    if(hollow)      
      g.drawCyrcle(ecenterx,ecentery,eradius);
    else 
      g.fillCyrcle(ecenterx,ecentery,eradius);
  }

  public HyperObject getCopy(){
    return new HyperCyrcle(z,radius,color);
  }

}

