package PVS.Utils;
/*
  File: QSort.java

  Taken by V.Bulatov@ic.ac.uk from Dynarray.java

  Originally written by Doug Lea and released into the public domain. 
  Thanks for the assistance and support of Sun Microsystems Labs, Agorics 
  Inc, Loral, and everyone contributing, testing, and using this code.

  History:
  Date     Who                What
  2Oct95  dl@cs.oswego.edu   refactored from DASeq.java
  13Oct95  dl                 Changed protection statuses

  06Jun96  V.Bulatov          sorting part extracted and example test written

*/
  
//package collections;


/**
 *
 * quick sort algorithm
 * 
 *
**/

import java.util.Vector;

public class QSort { 

/**
 * An implementation of Quicksort using medians of 3 for partitions.
 * @param s, the array to sort
 * @param lo, the least index to sort from
 * @param hi, the greatest index
 * @param cmp, the comparator to use for comparing elements
**/

  public static void quickSort(Object s[], int lo, int hi, Comparator cmp) {
    
    if (lo >= hi) return;
    
    /* 
       Use median-of-three(lo, mid, hi) to pick a partition. 
       Also swap them into relative order while we are at it.
    */
  
    int mid = (lo + hi) / 2;
  
    if (cmp.compare(s[lo], s[mid]) > 0) {
      Object tmp = s[lo]; s[lo] = s[mid]; s[mid] = tmp; // swap
    }
    
    if (cmp.compare(s[mid], s[hi]) > 0) {
      Object tmp = s[mid]; s[mid] = s[hi]; s[hi] = tmp; // swap 
      
      if (cmp.compare(s[lo], s[mid]) > 0) {
        Object tmp2 = s[lo]; s[lo] = s[mid]; s[mid] = tmp2; // swap
      }
      
    }
    
    int left = lo+1;           // start one past lo since already handled lo
    int right = hi-1;          // similarly
    if (left >= right) return; // if three or fewer we are done
    
    Object partition = s[mid];
    
    for (;;) {
      
      while (cmp.compare(s[right], partition) > 0) --right;
      
      while (left < right && cmp.compare(s[left], partition) <= 0) ++left;
      
      if (left < right) {
        Object tmp = s[left]; s[left] = s[right]; s[right] = tmp; // swap
        --right;
      }
      else break;
    }
    
    quickSort(s, lo, left, cmp);
    quickSort(s, left+1, hi, cmp);    
  }

  public static void quickSort(Vector v, int lo, int hi, Comparator cmp) {
    
    if (lo >= hi) return;
    
    /* 
       Use median-of-three(lo, mid, hi) to pick a partition. 
       Also swap them into relative order while we are at it.
    */
  
    int mid = (lo + hi) / 2;
  
    if (cmp.compare(v.elementAt(lo), v.elementAt(mid)) > 0) {
      Object tmp = v.elementAt(lo); 
      v.setElementAt(v.elementAt(mid),lo); 
      v.setElementAt(tmp,mid); // swap
    }
    
    if (cmp.compare(v.elementAt(mid), v.elementAt(hi)) > 0) {
      Object tmp = v.elementAt(mid); 
      v.setElementAt(v.elementAt(hi),mid);
      v.setElementAt(tmp,hi);// swap 
      
      if (cmp.compare(v.elementAt(lo), v.elementAt(mid)) > 0) {
        Object tmp2 = v.elementAt(lo); 
	v.setElementAt(v.elementAt(mid),lo); 
	v.setElementAt(tmp2,mid); // swap
      }
      
    }
    
    int left = lo+1;           // start one past lo since already handled lo
    int right = hi-1;          // similarly
    if (left >= right) return; // if three or fewer we are done
    
    Object partition = v.elementAt(mid);
    
    for (;;) {
      
      while (cmp.compare(v.elementAt(right), partition) > 0) --right;
      
      while (left < right && 
	     cmp.compare(v.elementAt(left), partition) <= 0) ++left;
      
      if (left < right) {
        Object tmp = v.elementAt(left); 
	v.setElementAt(v.elementAt(right),left);
	v.setElementAt(tmp,right);
        --right;
      }
      else break;
    }
    
    quickSort(v, lo, left, cmp);
    quickSort(v, left+1, hi, cmp);    
  }

  public static void main(String[] args){
    int n = 1000;
    if(args.length == 0){
      System.out.println("usage: java QSort <amount to sort>");
    } else{
      n = Integer.parseInt(args[0]);
    }
    Double[] array = new Double[n];
    for(int i=0; i<n; i++){
      array[i] = new Double(Math.random());
    }
    Comparator cmp = new DoubleComparator();
    long start = System.currentTimeMillis();
    
    quickSort(array,0,n-1,cmp);
    long delta = System.currentTimeMillis() - start;
    System.out.println(""+n+ " numbers was sorted in " +delta +" milliseconds");
  }
}

