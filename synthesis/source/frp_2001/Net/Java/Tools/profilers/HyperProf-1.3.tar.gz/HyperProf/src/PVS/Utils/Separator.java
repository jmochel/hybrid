package PVS.Utils;

/**
 Separator
 A separator to help SeparatorLayout manage window divided into 2 parts 
*/

import java.awt.*;
import java.awt.peer.ComponentPeer;
import java.util.Vector;

public class Separator extends BorderPanel
{

  int direction;

  public Separator() {
    this(SeparatorLayout.HORIZONTAL);
  }

  public Separator(int direction) {
    super(BorderPanel.RECESSED);
    this.direction = direction;

  }

  public void update(Graphics g){
    paint(g);
  }

  public Dimension preferredSize(){
    return new Dimension(5,5);
  }
  public Dimension minimumSize(){
    return new Dimension(5,5);
  }
  
  public boolean mouseEnter(Event e, int x, int y){
    WindowUtils.getMainWindow(this).setCursor(Frame.CROSSHAIR_CURSOR);
    return false;
  }

  public boolean mouseExit(Event e, int x, int y){
    WindowUtils.getMainWindow(this).setCursor(Frame.DEFAULT_CURSOR);
    return false;
  }

  int xdown, ydown,xold,yold;
  boolean firstLine;
  Rectangle r;
  public boolean mouseDown(Event e, int x, int y){
    r = this.bounds();
    xdown = x; ydown = y;
    firstLine = true;
    return false;
  }

  public boolean mouseDrag(Event e, int x, int y){
    if(!firstLine)
      drawLine(getParent(),xold+r.x,yold+r.y);    
    drawLine(getParent(),x+r.x,y+r.y);
    firstLine = false;
    yold = y;
    xold = x;
    return false;
  }

  public boolean mouseUp(Event e, int x, int y){
    drawLine(getParent(),xold+r.x,yold+r.y);    

    ((SeparatorLayout)getParent().getLayout()).
      moveSeparator(getParent(),x-xdown + r.x, y-ydown + r.y);
    return false;
  }

  void drawLine(Component c, int x,int y){
    //System.out.println(c);
    //try{ // Windows 95 JDK 1.0 limitation
    //if(c instanceof Canvas) {// Windows 95 JDK 1.0 limitation
      ComponentPeer peer = c.getPeer();
      
      Graphics g = peer.getGraphics();
      g.setXORMode(Color.black);
      g.setColor(c.getBackground());
      if(direction == SeparatorLayout.HORIZONTAL)
	g.drawRect(0,y,size().width,1);
      else 
	g.drawRect(x,0,1,size().height);
      
      g.dispose();       
      //} catch(Exception e){ // lets kill complainings 
      //(it doesn't catches exceptions here)
    //}
    if(c instanceof Container){
      Component[] comp = ((Container)c).getComponents();
      for(int i=0; i < comp.length; i++){
	Rectangle r = comp[i].bounds();
	drawLine(comp[i],x-r.x,y-r.y);
      }
    }
  }


  public static void main(String[] args) {

    Separator separator1 = new  Separator(SeparatorLayout.VERTICAL);
    Separator separator2 = new  Separator(SeparatorLayout.HORIZONTAL);

    Panel panel_bottom = new BorderPanel();
    panel_bottom.setLayout(new SeparatorLayout(SeparatorLayout.HORIZONTAL));

    panel_bottom.add(new TextArea("Area2"));
    panel_bottom.add(separator2);
    panel_bottom.add(new TextArea("Area3"));

    
    Panel panel = new Panel(); 
    panel.setLayout(new SeparatorLayout(SeparatorLayout.VERTICAL));

    panel.add(new TextArea("Area1"));
    panel.add(separator1);
    panel.add(panel_bottom);

    Frame frame = new Frame("SeparatorLayout test");
    frame.add("Center", panel);
    frame.pack();
    frame.resize(600, 400);
    frame.show();
  }
}
