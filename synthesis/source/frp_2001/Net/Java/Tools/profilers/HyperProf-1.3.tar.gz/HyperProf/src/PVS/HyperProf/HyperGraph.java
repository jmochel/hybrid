package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.awt.*;
import java.applet.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import java.io.*;

import PVS.Hyperbolic.*;
import PVS.Utils.Fmt;
import PVS.Utils.Comparator;
import PVS.Utils.QSort;
import PVS.Utils.MathExt;

class HNode extends HyperCyrcle{

  String name, typename;
  ProfEntry entry;
  Vector children = null;
  HNode parent = null;
  double time;

  HNode(Complex center, double radius, Color color, 
	String name,  String typename, HNode parent, double time){
    super(center, radius, color, false);
    this.name = name;
    this.typename = typename;
    this.entry = null;
    this.parent = parent;
    this.time = time;
    //System.out.println(this+"<init>("+center+")");
  }

  HNode(Complex center, double radius, Color color, 
	ProfEntry entry, String typename, HNode parent, double time){
    this(center, radius, color, entry.name.methodName, typename, parent,time);
    this.entry = entry;
  }

  static Font fonts[] = new Font[10];

  static {
    for(int i=0;i<10;i++)
      fonts[i] = new Font("Helvetica",Font.PLAIN,i+1);
  }

  void addChild(HNode node){
    if(children == null)
      children = new Vector(1);
    children.addElement(node);
    //System.out.println(this+": addChild("+node+")");
  }

  void setCapacity(int size){
    if(children == null)
      children = new Vector(size);
    children.setSize(size);
  }

  HNode findNode(double x, double y){
    double d = distance2(x,y);
    HNode node = this;
    if(children != null){
      for(int i=0; i < children.size(); i++){
	HNode n1 = ((HNode)children.elementAt(i)).findNode(x,y);
	double d1 = n1.distance2(x,y);
	if(d1 < d){
	  node = n1;
	  d = d1;
	}
      }
    }
    return node;
  }

  HNode findNode(ProfEntry e){
    if(e == entry)
      return this;
    if(children != null){
      for(int i=0; i < children.size(); i++){
	HNode node = ((HNode)children.elementAt(i)).findNode(e);
	if(node != null)
	  return node;
      }
    }
    return null;
  }

  /**
    returns vector of all children, which have entry != null 
   */
  Vector getNodesWithEntry(Vector v){
    if(v == null)
      v = new Vector();
    if(children != null){
      // there are children
      for(int i=0; i < children.size(); i++){
	// recursive call for each child 
	((HNode)children.elementAt(i)).getNodesWithEntry(v);      
      }
    } else if(entry != null){
      // this is last child
      v.addElement(this);
    }    
    return v;
  }

  double distance2(double x, double y){
    return MathExt.sqr(z.re - x) +   MathExt.sqr(z.im - y);    
  } 

  public String toString(){
    if(children != null)
      return name+" : "+children.size(); 
    else 
      return name+z;
  }

  public void draw(Graphics2d g2){
    //System.out.println(this+": draw");
    if(parent != null){
      g2.setColor(color);
      Hyperbolic.drawGeodArc(g2,parent.z,z);      
    }
    if(children != null){
      for(int i=0; i < children.size(); i++){
	((HNode)children.elementAt(i)).draw(g2);
      } 
    }
    super.draw(g2);
    if(!Hyperbolic.fastLines){ 
      // draw caption 
      Graphics g = g2.getGraphics();
      g.setColor(Color.black);
      int fn = g2.x2screen(eradius)/3;
      if(fn >= 3){
	fn = Math.min(fonts.length-1,fn);
	g.setFont(fonts[fn]);
	FontMetrics fm = g.getFontMetrics();
	int h = fm.getHeight()+fm.getMaxDecent();
	int w = fm.stringWidth(name);
	g.drawString(name,
		     g2.x2screen(ecenterx) - w/2,
		     g2.x2screen(ecentery) + h/2);
      }
    }
  } 
  
  public void doTranslate(Complex t){
    //System.out.println(this+": doTranslate("+t.re+","+t.im+")");
    super.doTranslate(t);
    if(children != null){
      for(int i=0; i < children.size(); i++){
	((HNode)children.elementAt(i)).doTranslate(t);
      } 
    }
  }

  public void doRotate(Complex t){
    //System.out.println(this+": doRotate("+t.re+","+t.im+")");
    super.doRotate(t);
    if(children != null){
      for(int i=0; i < children.size(); i++){
	((HNode)children.elementAt(i)).doRotate(t);
      } 
    }      
  }

  /**
    rotate only this node, childrens are not affected
   */
  public void doRotateSingle(Complex t){
    super.doRotate(t);
  }

  public void reflect(Arc arc){
    super.reflect(arc);
    if(children != null){
      for(int i=0; i < children.size(); i++){
	((HNode)children.elementAt(i)).reflect(arc);
      } 
    }               
  }
}

class HBound implements HyperObject{

  HNode node1, node2;
  Color color;

  HBound(HNode node1, HNode node2,Color color){
    this.node1 = node1;
    this.node2 = node2;
    this.color = color;
  }

  public void doTranslate(Complex p){}
  public void doRotate(Complex teta){}
  public void doTransform(HTransform m){}
  public void reflect(Arc arc){}

  public void draw(Graphics2d g){
    g.setColor(color);
    if (node1 != null && node2 != null) 
      Hyperbolic.drawGeodArc(g,node1.z,node2.z);
  }

  public HyperObject getCopy(){
    return new HBound(node1, node2, color);
  }   
}

public class HyperGraph extends Canvas {

  HNode root;  // root of methods tree
  Vector bounds = new Vector(); // caller-callee bounds

  static final int ROTATION=1, TRANSLATION = 2;

  Dimension dim = new Dimension(0,0);
  Image memImage;
  Graphics memG;
  Complex lastp = new Complex();
  Complex newp = new Complex();
  Complex teta = new Complex();
  Complex center = new Complex(0,0);
  boolean wasmoved = false;
  double radius;
  int dragMode;

  Label statusBar = null;

  PackageTable ptable;
  static Color colorMethod = new Color(255,128,128);
  static Color colorClass = new Color(30,255,30);
  static Color colorPackage = new Color(128,128,255);
  static Color colorBranch = new Color(128,128,128);
  static Color colorCaller = new Color(255,255,60);
  static Color colorCallee = new Color(255,255,255);
  static Color colorSuper  = new Color(255,128,128);

  // storage of all methods, classes and packages
  HNode methods[], packages[], classes[];

  Component parent; // our parent which we will inform about selections

  /**
    HyperGraph constructor
   */

  public HyperGraph(PackageTable ptable, Component parent) {
    
    this.ptable = ptable;
    this.parent = parent;
    setBackground(new Color(192,192,192));

    double rmethod,rclass,rpackage;
    int nmethods = ptable.countMethods();
    int npackages = ptable.countPackages();
    int nclasses = ptable.countClasses();    
    int nnodes = (nmethods+npackages+nclasses);
    double crad = 0.25;
    // length of methods cyrcle
    double len = nnodes*2*crad;
    double pilen = 2*Math.PI/(len);
    rmethod = Math.sqrt(pilen*pilen+1)-pilen;
    rclass = Hyperbolic.h2e(0.66*Hyperbolic.e2h(rmethod));
    rpackage = Hyperbolic.h2e(0.33*Hyperbolic.e2h(rmethod));

    // angle between method's nodes
    double dfi = 2*Math.PI/nnodes;
    // start angle of first node
    double fi = -Math.PI/2;

    int current = 0;

    Complex cp = new Complex(0,0), // package center
    cc = new Complex(0,0),         // class center
    cm = new Complex(0,0);         // method center
    
    String package_name = new String("package");
    String class_name = new String("class");
    String method_name = new String("method");
    // special '?.?' node
    root = new HNode(cp,crad,colorSuper,ptable.sEntry,method_name,null, 0.);
    //root.setCapacity(ptable.packages.size());

    // minimal angle between class cyrcles
    double dfic = Math.atan2(crad*(1-rclass*rclass),rclass);
    // minimal angle between package cyrcles
    double dfip = Math.atan2(crad*(1-rpackage*rpackage),rpackage);
    // place to store temporary packages and classes 
    packages = new HNode[npackages]; 
    classes = new HNode[nclasses];
    methods = new HNode[nmethods];
    // counters
    int curmethod = 0,curpackage = 0, curclass = 0;

    // sorted packages
    Vector pkgs = new Vector(); 
    for(Enumeration pack = ptable.packages.elements();pack.hasMoreElements();){
      PackageEntry pe = (PackageEntry)pack.nextElement();
      pkgs.addElement(pe);
    }
    QSort.quickSort(pkgs,0,pkgs.size()-1,(Comparator)pkgs.elementAt(0)); 

    for(int i=0;i<pkgs.size();i++){
      // packages
      PackageEntry pe = (PackageEntry)pkgs.elementAt(i);
      int nmp = pe.countMethods(); // number of methods in the package
      double fip = fi + 0.5*dfi*(nmp-1); // average angle of all methods      
      cp.set(rpackage*Math.cos(fip),rpackage*Math.sin(fip));
      HNode hpackage = new HNode(cp, crad,colorPackage,
				 pe.name,package_name,root, 
				 pe.getTotalTime()/1000.0);
      root.addChild(hpackage);
      //hpackage.setCapacity(pe.classes.size());

      packages[curpackage++] = hpackage;

      // sorted classes
      Vector clss = new Vector(); 
      for(Enumeration cle = pe.classes.elements(); cle.hasMoreElements();){
	ClassEntry cl = (ClassEntry)cle.nextElement();
	clss.addElement(cl);
      }
      QSort.quickSort(clss,0,clss.size()-1,(Comparator)clss.elementAt(0)); 

      for(int j = 0;j<clss.size();j++){
	// classes
	ClassEntry cl = (ClassEntry)clss.elementAt(j);
	int nmc = cl.countMethods();// number of methods in the class
	double fic = fi + 0.5*dfi*(nmc-1);

	cc.set(rclass*Math.cos(fic), rclass*Math.sin(fic));
	HNode hclass = new HNode(cc, crad,colorClass,
				 cl.name,class_name,hpackage,
				 cl.getTotalTime()/1000.0);
	hpackage.addChild(hclass);
	//hclass.setCapacity(cl.methods.size());
	classes[curclass++] = hclass;
	
	// sorted methods
	Vector mtds = new Vector(); 
	for(Enumeration me = cl.methods.elements(); me.hasMoreElements();){
	  ProfEntry e = (ProfEntry)me.nextElement();
	  mtds.addElement(e);
	}
	QSort.quickSort(mtds,0,mtds.size()-1,(Comparator)mtds.elementAt(0));

	for(int k = 0; k < mtds.size(); k++){
	  // methods
	  ProfEntry e = (ProfEntry)mtds.elementAt(k);
	  cm.set(rmethod*Math.cos(fi), rmethod*Math.sin(fi));
	  HNode hmethod = new HNode(cm, crad,colorMethod,
				    e, method_name,hclass,
				    e.time/1000.0);
	  hclass.addChild(hmethod);
	  methods[curmethod++] = hmethod;
	  fi+= dfi;	  
	}
	fi += dfi; // increment at the end of class
      }
      fi += dfi; // increment at the end of package
    }

    adjustPositions(packages, dfip);
    adjustPositions(classes, dfic);

    //createBounds();

  }

  /**
    moves nodes to avoid overlap    
    dfi - minimal angle between nodes
   */
  void adjustPositions(HNode[] nodes, double dfi){
    Complex c = new Complex();
    for(int j = 0; j < 100; j++){ // do 100 iterations to adjust
      boolean wasmoved = false;
      for(int i=0;i < nodes.length; i++){
	int i1 = (i+1)%nodes.length;
	double dfi1 = c.div(nodes[i1].z,nodes[i].z).arg();
	if(dfi1 < dfi){
	  double df2 = (dfi-dfi1)/2+1.e-5;
	  c.set(Math.cos(df2),Math.sin(df2));
	  nodes[i1].doRotateSingle(c);
	  c.conj();
	  nodes[i].doRotateSingle(c);       
	  wasmoved = true;
	}
      }    
      if(!wasmoved)
	break;
    }     
  }

  /**
    makes all caller - callee bounds.
    looks too messy
   */
  void createBounds(){
    bounds.setSize(0);
    for(int i=0; i < methods.length; i++){
      HNode node = methods[i];
      ProfEntry e = node.entry;
      if(e == null)
	continue;
      int ncallee = e.calleeList.size();
      if(ncallee > 0){
	for(int j=0;j < ncallee; j++){
	  HNode fnode = 
	    findNode(((CallerEntry)e.calleeList.elementAt(j)).entry);
	  HBound hb = new HBound(node,fnode, colorCaller);
	  bounds.addElement(hb);
	}
      }
    }
  }

  
  boolean fullRedraw = true;

  public void paint(Graphics g) {
    Dimension d = size();
    if(d.width != dim.width || d.height != dim.height || memImage == null){
      dim = d;
      radius = (0.47*Math.min(dim.width,dim.height));
      memImage = this.createImage(dim.width,dim.height);      
      memG = memImage.getGraphics();
      memG.translate(dim.width/2,dim.height/2);
      fullRedraw = true;
    }

    if(fullRedraw){      
      Graphics2d g2 = new Graphics2d(memG);
      g2.setScale(radius);    
      memG.setColor(getBackground());
      memG.fillRect(-dim.width/2,-dim.height/2,dim.width,dim.height);
      memG.setColor(Color.black);
      g2.drawCyrcle(0.,0.,1.);
      root.draw(g2);
      //g.setColor(Color.red);
      //g.fillOval((int)(radius*center.re)-2,(int)(radius*center.im)-2,4,4);
      //g.drawOval((int)(radius*center.re)-5,(int)(radius*center.im)-5,10,10);
      fullRedraw = false;
    }

    g.drawImage(memImage,0,0,null);

    // draw bounds
    Graphics2d g2 = new Graphics2d(g);
    g.translate(dim.width/2,dim.height/2);
    g2.setScale(radius);        
    for(int i=0;i < bounds.size();i++){
      HyperObject o = (HyperObject)bounds.elementAt(i);
      o.draw(g2);
    }
    
  }

  public void update(Graphics g) {

    if(wasmoved){ // we are moving it now, not im mouseDrag
      switch(dragMode){
      case TRANSLATION:
	lastp.neg();

	//HTransform tr1 = new HTransform(lastp.neg(),new Complex(1.));
	//Hyperbolic.doTransform(tr1,new HTransform(newp,new Complex(1.)));
	//root.doTransform(tr1);

	root.doTranslate(lastp);
	root.doTranslate(newp);
	break;

      case ROTATION:
	teta.div(newp.sub(center),lastp.sub(center));	
	teta.normalize();

	//Complex c1 = new Complex(1.);
	//HTransform tr2 = new HTransform(center.neg(),c1);
	//Hyperbolic.doTransform(tr2, new HTransform(new Complex(0.),teta));
	//Hyperbolic.doTransform(tr2, new HTransform(center.neg(),c1));
	//root.doTransform(tr2);

	root.doTranslate(center.neg());
	root.doRotate(teta);
	root.doTranslate(center.neg());
	
	newp.add(center); // return point back
      }
      lastp.set(newp);
      wasmoved = false;
      fullRedraw = true;
    }
    paint(g);
  }
  
  public boolean mouseDown(Event ev, int x, int y) {
    if((ev.modifiers & Event.META_MASK) != 0){
      dragMode = ROTATION;
    } else {
      dragMode = TRANSLATION;      
    }

    lastp.set((x-dim.width/2)/radius,(y-dim.height/2)/radius);
    return true;
  }

  HNode selected = null;

  HNode findNode(int x, int y){
    double xw = x2w(x);
    double yw = y2w(y);
    return root.findNode(xw, yw);
  }

  HNode findNode(ProfEntry e){
    return root.findNode(e);
  }

  public boolean mouseMove(Event ev, int x, int y) {
    HNode node = findNode(x,y);
    if(node != null && node != selected){
      if(statusBar != null){
	if(node.entry == null)
	  statusBar.setText(node.typename+":"+node.name +
			    " ("+Fmt.fmt(node.time,5,4)+"sec)");
	else 
	  statusBar.setText(node.typename+":"+node.entry.name.shortName+
			    " ("+Fmt.fmt(node.time,5,4)+") seconds");
      }
      selected = node;
    }
    return true;
  }

  boolean wasDragged = false;

  public boolean mouseDrag(Event ev, int x, int y) {
    wasmoved = true;
    newp.set((x-dim.width/2)/radius,(y-dim.height/2)/radius);
    Hyperbolic.fastLines = true; // to speedup line drawing
    wasDragged = true;         
    repaint();     
    return true;
  }

  public boolean mouseUp(Event ev, int x, int y) {
    Hyperbolic.fastLines = false; // let we have nicer static picture
    if(!wasDragged){ // new entry was selected
      // new selected entry with callers and callee
      HNode node = findNode(x,y);
      if(node != null){ 
	if(node.entry != null){ // methods entry
	  ProfEntry entry = node.entry;
	  if(parent != null){ // inform our parent about selection
	    parent.postEvent(new Event(this,Event.ACTION_EVENT,entry));  
	  }
	  selectEntry(entry);
	} else {
	  Vector nodes = node.getNodesWithEntry(null);
	  selectNodes(nodes);
	}
      }
    } else { 
      // picture just was moved
      // we had fast repaint and want to return hight quality image
      wasDragged = false; 
      fullRedraw = true; // to force full repaint
      repaint();
    }
    return true;
  }

  /**
    creates connections of this node to all other nodes, which
    have caller-callee relationship to this node
   */
  void selectEntry(ProfEntry e, HNode node){

    int ncallee = e.calleeList.size();
    int ncaller = e.callerList.size();
    bounds.setSize(ncallee+ncaller);

    if(ncallee > 0){
      for(int i=0;i < ncallee; i++){
	HNode fnode = 
	  findNode(((CallerEntry)e.calleeList.elementAt(i)).entry);
	HBound line = new HBound(node,fnode, colorCallee);
	bounds.setElementAt(line,i);
      }
    }

    if(ncaller > 0){
      for(int i=0;i < ncaller; i++){
	HNode fnode = 
	  findNode(((CallerEntry)e.callerList.elementAt(i)).entry);
	HBound line = new HBound(node,fnode, colorCaller);
	bounds.setElementAt(line,ncallee+i);
      }	
    }
   repaint(); 
  }

  /**
    creates connection of all nodes in this list, if they have 
    caller-callee relationship
   */
  void selectNodes(Vector nodes){

    bounds.setSize(0);
    for(int i=0; i < nodes.size(); i++){
      HNode node = (HNode)nodes.elementAt(i);
      ProfEntry e = node.entry;
      int ncaller = e.callerList.size();
      if(ncaller > 0){
	for(int j=0;j < ncaller; j++){
	  HNode fnode = 
	    findNode(((CallerEntry)e.callerList.elementAt(j)).entry);
	  HBound hb = new HBound(node,fnode, colorCaller);
	  bounds.addElement(hb);
	}
      }
    }
    for(int i=0; i < nodes.size(); i++){
      HNode node = (HNode)nodes.elementAt(i);
      ProfEntry e = node.entry;
      int ncallee = e.calleeList.size();
      if(ncallee > 0){
	for(int j=0;j < ncallee; j++){
	  HNode fnode = 
	    findNode(((CallerEntry)e.calleeList.elementAt(j)).entry);
	  HBound hb = new HBound(node,fnode, colorCallee);
	  bounds.addElement(hb);
	}
      }
    }
   repaint(); 
  }

  void selectEntry(ProfEntry e){
    selectEntry(e,findNode(e));
  }

  double x2w(int x){
    return (x-dim.width/2)/radius;
  }

  double y2w(int y){
    return (y-dim.height/2)/radius;
  }
}
