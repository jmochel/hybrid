package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.util.StringTokenizer;

class ProfLine extends Object {
  String calleeName;
  String callerName;
  int time, calls;
  ProfLine(String s){
    try{ 
      StringTokenizer tok = new StringTokenizer(s," \t\r\n");
      calls = Integer.parseInt(tok.nextToken());
      calleeName = tok.nextToken();
      if (calleeName.equals("<unknown"))
        calleeName += tok.nextToken();
      callerName = tok.nextToken();
      if (callerName.equals("<unknown"))
        callerName += tok.nextToken();
      time = Integer.parseInt(tok.nextToken());      
    } catch (Exception e){
      calleeName = "";
      callerName = "";
      time = 0;
      calls = 0;
      System.out.println("\nwrong input\n expected: 'ncalls callee_name caller_name time'"
		       + "\n but got: '"+s+"'");
      e.printStackTrace(System.out);      
    }    
  }  
}

