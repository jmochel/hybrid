package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.util.StringTokenizer;
import PVS.Utils.Comparator;
import PVS.Utils.Fmt;


class MemoryEntry extends Object implements Comparator{

  static boolean shortOutput = true;
  String type="",shortType = "";
  int count,bytes;
  Main mainframe;

  MemoryEntry(String s,Main mainframe){
    this.mainframe = mainframe;
    try{ //"()"+File.separator 
      StringTokenizer tok = new StringTokenizer(s," \t\r\n");
      type = tok.nextToken();
      count = Integer.parseInt(tok.nextToken());
      bytes = Integer.parseInt(tok.nextToken());      
      switch(type.charAt(0)){
      case '[': // primitive type
	switch(type.charAt(1)){
	case 'I':
	  shortType = "int"; break;
	case 'F':
	  shortType = "float"; break;
	case 'D':
	  shortType = "double"; break;
	case 'B':
	  shortType = "byte"; break;
	case 'S':
	  shortType = "short"; break;
	case 'C':
	  shortType = "char"; break;
	case 'Z':
	  shortType = "boolean"; break;
	case 'J':
	  shortType = "long"; break;
	case 'L':
	  shortType = makeShortType(type); break;
	default:
	  shortType = "unknown type"; break;
	}
	break;
      case 'L':
	shortType = makeShortType(type); break;
      }
    } catch (Exception e){
      e.printStackTrace(System.out);
    }
  }


  String makeShortType(String type){    
    int l = type.lastIndexOf('/');
    if(l>0)
      return type.substring(l+1);
    else 
      return type;	
  }

  String getType(){
    return type;
  }

  public int compare(Object fst, Object snd){
    if(mainframe.sortType == Main.SORT_BY_TIME)
      return  ((MemoryEntry)snd).bytes - ((MemoryEntry)fst).bytes;
    else if(mainframe.sortType == Main.SORT_BY_NAME)
      return ((MemoryEntry)fst).shortType.
	compareTo(((MemoryEntry)snd).shortType);	
    return 0;
  }

  public String toString(){
    if(shortOutput)
      return ""+
	((mainframe.units == Main.ABSOLUTE_UNITS)?
	 Fmt.fmt(bytes,7):
	 Fmt.fmt((100.*bytes/mainframe.memoryInfo.total_bytes),5,2)+"% ")+
		 "/"+Fmt.fmt(count,6,Fmt.LJ)+shortType;
    else 
      return "" +
	((mainframe.units == Main.ABSOLUTE_UNITS)?
	 Fmt.fmt(bytes,7):
	 Fmt.fmt((100.*bytes/mainframe.memoryInfo.total_bytes),5,2)+"% ")+
	   "/"+Fmt.fmt(count,6,Fmt.LJ)+type;
  }
}

