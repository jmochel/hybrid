package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import PVS.Utils.Comparator;
import PVS.Utils.Fmt;
import java.util.Vector;

class ProfEntry extends Object implements Comparator{

  SplittedName name;

  Vector calleeList = new Vector();
  Vector callerList = new Vector();
  int calls, time, callee_time,caller_time;
  Main mainframe;

  ProfEntry(String  name,Main mainframe){
    this.calls = 0;
    this.caller_time = 0;
    this.callee_time = 0;
    this.time = 0;
    this.mainframe = mainframe;
    this.name = ParseName(name);
  }

  public void addCaller(CallerEntry entry){
    callerList.addElement(entry);
    this.caller_time += entry.time;
    if(entry.entry != this){ // recursive call
      this.time += entry.time;
      this.calls += entry.calls;
    }
  }

  public void addCallee(CallerEntry entry){
    calleeList.addElement(entry);
    if(entry.entry != this){ // recursive call
      this.callee_time += entry.time;   // this time is counted by callee
      this.time -= entry.time;
    }
  }
  
  public int compare(Object fst, Object snd){
    if(mainframe.sortType == Main.SORT_BY_TIME)
      return  ((ProfEntry)snd).time - ((ProfEntry)fst).time;
    else if(mainframe.sortType == Main.SORT_BY_NAME)
      return  ((ProfEntry)fst).
	name.shortName.compareTo(((ProfEntry)snd).name.shortName);
    return 0;
  }
  
  static SplittedName ParseName(String fullname){

    String packageName = "";
    String className = "";
    String methodName = fullname;
    int br1 = fullname.lastIndexOf('(');
    int br2 = fullname.lastIndexOf(')');
    if(br1 < 0) // strange
      return new SplittedName(packageName,className,methodName);
    String name = fullname.substring(0,br1);
    int cl = name.lastIndexOf('/');
    if(cl > 0){
      packageName = name.substring(0,cl+1); // '/' is included
      int m = name.lastIndexOf('.');
      className = name.substring(cl+1,m+1); // '.' including
      methodName = name.substring(m+1);
    } else { // "?.?" name 
      int m = name.lastIndexOf('.');
      className = name.substring(0,m+1); // '.' including
      methodName = name.substring(m+1);
    }

    String args;
    if(br2-br1 > 1){
      args = fullname.substring(br1+1,br2);
      args = parseArgs(args);
    } else {
      args = "";
    }

    methodName =  methodName+"("+args+")";
    
    return new SplittedName(packageName,className,methodName);
  }

  static String parseArgs(String args){
    StringBuffer result = new StringBuffer();
    int i=0;
    int arrCount = 0;
    while(i < args.length()){
      if(result.length() > 0) // add comma before argument, except first
	result.append(", ");
      switch(args.charAt(i)){
      default:
	i++; break;
      case '[':
	while(args.charAt(i) == '['){
	  arrCount++; i++;
	}
	break;
      case 'I':
	result.append("int"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'F':
	result.append("float"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'D':
	result.append("double"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'C':
	result.append("char"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'S':
	result.append("short"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'B':
	result.append("byte"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'Z':
	result.append("boolean"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'J':
	result.append("long"); i++; 
	while(arrCount-- > 0)
	  result.append("[]");
	arrCount = 0;
	break;
      case 'L': // Class reference
	int end = args.indexOf(';',i);
	if(end > 0){
	  String s = args.substring(i+1,end);
	  int l = s.lastIndexOf('/');
	  if(l>0){
	    result.append(s.substring(l+1));
	  } else {
	    result.append(s);
	  }
	  i = end+1;
	  while(arrCount-- > 0)
	    result.append("[]");	  
	  arrCount = 0;
	} else { // strange ...
	  i++;
	}
	break;	
      }      
    }
    return new String(result);
  }

  public String toString(){
    if(mainframe.shortOutput)
      return ""+
	((mainframe.units == Main.ABSOLUTE_UNITS)?
	 //(Fmt.fmt(time,7)+(Fmt.fmt(ProfInfo.current_time,7))):
	 (Fmt.fmt(time,7)+(Fmt.fmt(caller_time,7))):

	 (Fmt.fmt((100.*time/ProfInfo.total_time),5,3)+"% "+
	 //Fmt.fmt((100.*ProfInfo.current_time/ProfInfo.total_time),5,3)+"% "))+
	 Fmt.fmt((100.*caller_time/ProfInfo.total_time),5,3)+"% "))+
	   "/"+Fmt.fmt(calls,6,Fmt.LJ)+name.className+name.methodName;  
    else 
      return ""+
	((mainframe.units == Main.ABSOLUTE_UNITS)?
	 (Fmt.fmt(time,7)+(Fmt.fmt(ProfInfo.current_time,7))):
	 //(Fmt.fmt(time,7)+(Fmt.fmt(caller_time,7))):

	 (Fmt.fmt((100.*time/ProfInfo.total_time),5,3)+"% "+
	 Fmt.fmt((100.*ProfInfo.current_time/ProfInfo.total_time),5,3)+"% "))+
	 //Fmt.fmt((100.*caller_time/ProfInfo.total_time),5,3)+"% "))+
 	   "/"+Fmt.fmt(calls,7,Fmt.LJ) +
	     name.packageName+name.className+name.methodName;    
  }

}
