package PVS.Hyperbolic;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.awt.*;
import java.awt.image.*;

public class Graphics2d extends Object {

  Graphics g;
  double scalex=1,scaley=1,x0=0,y0=0;

  // Constructor.
  public Graphics2d() {
  }

  public Graphics2d(Graphics g) {
    this.g = g;
  }

  public void setGraphics(Graphics g){
    this.g = g;
  }

  public Graphics getGraphics(){
    return g;
  }

  public void setScale(double scale){
    this.scalex = scale;
    this.scaley = scale;
  }

  public void setOrigin(double x0, double y0){
    this.x0 = x0;
    this.y0 = y0;
  }

  public int x2screen(double x){
    return (int)(scalex*(x+x0));
  }

  public int y2screen(double x){
    return (int)(scaley*(x+y0));
  }

  static double rad2grad = 180./Math.PI;

  public void drawCyrcle(double x, double y, double radius){
    g.drawOval(x2screen(x-radius),y2screen(y-radius),
	       x2screen(2*radius),y2screen(2*radius));
  }

  public void fillCyrcle(double x, double y, double radius){
    g.fillOval(x2screen(x-radius),y2screen(y-radius),
	       x2screen(2*radius),y2screen(2*radius));
  }

  private int segmentsInArc(double radius, double angle){
    // number of grad in segment
    if(radius == 0.0)
      return 1;
    int n1 = (int)Math.ceil(Math.abs(angle*rad2grad/5));
    //number of 5 pixel segments in cyrcle
    int n2 = Math.abs(x2screen(radius))+1;
    return  Math.min(n1,n2);
  }

  /*
  static double sine[] = new double[360];
  static double cosine[] = new double[360];
  static {
    for(int i=0;i<360;i++){
      sine[i] = Math.sin(i/rad2grad);
      cosine[i] = Math.cos(i/rad2grad);
    }
  }
  */
  public void drawArc(double x, double y, double radius,
		      double start, double angle){
    
    int n = segmentsInArc(radius,angle);
    int x0,y0,x1,y1;
    x0 = x2screen(x+radius*Math.cos(start));
    y0 = y2screen(y+radius*Math.sin(start)); 
    for(int i=1;i <= n;i++){
      double fi = start + i*angle/n;
      x1 = x2screen(x+radius*Math.cos(fi));
      y1 = y2screen(y+radius*Math.sin(fi));
      g.drawLine(x0,y0, x1,y1);
      x0 = x1; y0 = y1;
    }
  }

  public void drawArc(Arc arc){
    if(arc.r == 0.0){
      drawLine(arc.x,arc.y,arc.start,arc.angle);
      return;
    } else {
      drawArc(arc.x, arc.y, arc.r, arc.start, arc.angle);
    }
  }

  public void fillArcs(Arc[] arc){
    int nvert = 0; // number of verteces
    for(int i=0; i < arc.length;i++){
      Arc a = arc[i];
      nvert += segmentsInArc(a.r, a.angle);
    }      
    int[] x = new int[nvert];
    int[] y = new int[nvert];
    int n = 0;
    for(int i=0; i < arc.length;i++){
      Arc a = arc[i];
      int nv = segmentsInArc(a.r, a.angle);
      if(a.r == 0.0){  // strait line
	x[n] = x2screen(a.x);
	y[n] = y2screen(a.y);	
	n++;
      } else {
	for(int j = 0; j < nv; j++){
	  double fi = a.start + j*a.angle/nv;
	  x[n] = x2screen(a.x+a.r*Math.cos(fi));
	  y[n] = y2screen(a.y+a.r*Math.sin(fi));
	  n++;
	}
      }
    } 
    g.fillPolygon(x,y,nvert);
    g.drawPolygon(x,y,nvert);
  }

  public void drawArc1(double x, double y, double radius,
		      double start, double angle){

    int iangle, istart; 
    if(angle > 0){
      istart = (int)Math.ceil(rad2grad*start);
      iangle = (int)(Math.floor(rad2grad*(angle+start)))-istart;
    } else { // angle <= 0
      istart = (int)Math.floor(rad2grad*start);
      iangle = (int)(Math.ceil(rad2grad*(angle+start)))-istart;
    }
    //drawTinySegment(x,y,radius,start,start+angle);
    g.drawArc(x2screen(x-radius),y2screen(y-radius),
    	      x2screen(2*radius), y2screen(2*radius), istart,iangle);
    drawTinySegment(x,y,radius,start,istart/rad2grad);
    drawTinySegment(x,y,radius,(istart+iangle)/rad2grad,start+angle);
    //System.out.println("start: "+(int)(rad2grad*minang)+
    //		       ", angle: "+(int)(rad2grad*angle));
  }

  void drawTinySegment(double x,double y,double radius,
		       double start,double end){
    g.drawLine(x2screen(x+radius*Math.cos(start)),
	       y2screen(y-radius*Math.sin(start)), 
	       x2screen(x+radius*Math.cos(end)),
	       y2screen(y-radius*Math.sin(end)));
  }

  public void drawLine( double x1, double  y1, double x2, double y2 ) {
    g.drawLine(x2screen(x1),y2screen(y1), x2screen(x2),y2screen(y2));
  }   

  public void setColor(Color color){
    g.setColor(color);
  }
  
  public void fillRect(double x, double y, double width, double height){
    g.fillRect(x2screen(x),y2screen(y),x2screen(width),y2screen(height));
  }  
}

