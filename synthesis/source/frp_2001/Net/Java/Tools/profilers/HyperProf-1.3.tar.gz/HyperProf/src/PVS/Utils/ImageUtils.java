package PVS.Utils;

import java.awt.*;
import java.io.*;
import java.awt.image.*;

public class ImageUtils {

  /**
    rotateImage

    for now it does 90 degree counterclockwise rotation only
   */

  static Image rotateImage(Image imgsrc, double grad){
    
    int srcwidth = imgsrc.getWidth(null);
    int srcheight = imgsrc.getHeight(null);
    
    int reswidth = srcheight, resheight = srcwidth;
    
    int[] srcbuf = new int[srcwidth*srcheight];

    PixelGrabber pg = new PixelGrabber(imgsrc,0,0,srcwidth,srcheight,
				       srcbuf,0,srcwidth);
    try{
      pg.grabPixels(1000); 
    }catch(InterruptedException e){ // who can interupt us ?
      System.err.println("interrupted waiting for pixels!");
      return null;
    }    


    int[] resbuf = new int[reswidth*resheight];

    for(int j=0;j < resheight;j++){
      int rs = j*reswidth;
      int ss = srcwidth - j - 1;
      for(int i=0,ii=0;i < reswidth;i++){
	resbuf[rs+i] = srcbuf[ss + ii];
	ii+= srcwidth;
      }
    }

    ImageProducer ip = new MemoryImageSource(reswidth,resheight,resbuf,0,reswidth);
    Image imgres = Toolkit.getDefaultToolkit().createImage(ip);
    return imgres;
  }
}





