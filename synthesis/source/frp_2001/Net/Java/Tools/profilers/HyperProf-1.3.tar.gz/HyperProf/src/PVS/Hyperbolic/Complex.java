package PVS.Hyperbolic;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

public class Complex {
  public double re,im;

  static Complex i = new Complex(0.,1.);

  public Complex(double x,double y){
    re = x;
    im = y;
  }

  public Complex(Complex z){
    this.re = z.re;
    this.im = z.im;
  }

  public Complex(double x){
    this.re = x;
    this.im = 0.;
  }

  public Complex(){
    this(0,0);
  }

  public Complex add(Complex a,Complex b){
    re = a.re + b.re;
    im = a.im + b.im;
    return this;
  }

  public Complex add(Complex a){
    re += a.re;
    im += a.im;
    return this;
  }

  public Complex add(double a){
    re += a;
    return this;
  }

  public Complex add(double a,double b){
    re += a;
    im += b;
    return this;
  }

  public Complex sub(Complex a){
    re -= a.re;
    im -= a.im;
    return this;
  }

  public Complex sub(Complex a, Complex b){
    re = a.re - b.re;
    im = a.im - b.im;
    return this;
  }

  public Complex conj(){
    im = -im;
    return this;
  }

  public Complex conj(Complex a){
    re = a.re;
    im = -a.im;
    return this;
  }

  public Complex neg(){
    re = -re;
    im = -im;
    return this;
  }

  public Complex neg(Complex a){
    re = -a.re;
    im = -a.im;
    return this;
  }

  public Complex div(Complex a, Complex b){
    double d = b.re*b.re+b.im*b.im;
    re = (a.re*b.re+a.im*b.im)/d;
    im = (a.im*b.re-a.re*b.im)/d;
    return this;
  }

  public Complex div(Complex a){
    double d = a.re*a.re+a.im*a.im;
    double t = (re*a.re+im*a.im)/d;
    im = (im*a.re-re*a.im)/d;
    re = t;
    return this;
  }

  public Complex div(double b){
    im /= b;
    re /= b;
    return this;
  }

  public Complex mul(Complex a,Complex b){
    re = a.re * b.re - a.im * b.im;
    im = a.re * b.im + a.im * b.re;
    return this;
  }

  public Complex mul(Complex a, double b){
    im = a.im * b;
    re = a.re * b;
    return this;
  }

  public Complex mul(Complex b){
    double t = re * b.re - im * b.im;
    im = re * b.im + im * b.re;
    re = t;
    return this;
  }

  public Complex mul(double b){
    im *= b;
    re *= b;
    return this;
  }

  public Complex set(Complex a){
    re = a.re;
    im = a.im;
    return this;
  }

  public Complex set(double x, double y){
    re = x;
    im = y;
    return this;
  }

  public double abs2(){
    return re*re+im*im;
  }

  public double abs(){
    return Math.sqrt(abs2());
  }

  public double arg(){
    return Math.atan2(im,re);
  }

  public Complex normalize(){
    double r = abs();
    re /= r;
    im /= r;
    return this;
  }

  public String toString(){
    return "("+ String.valueOf(re) + "," + String.valueOf(im) + ")";
  }

}
