package PVS.HyperProf;

// Main.java - HyperProf main class 
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.awt.*;
import java.io.File;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Hashtable;

import PVS.Utils.Comparator;
import PVS.Utils.QSort;
import PVS.Utils.Separator;
import PVS.Utils.SeparatorLayout;
import PVS.Utils.WindowUtils;
import PVS.Utils.Fmt;
import PVS.Utils.VLabel;
import PVS.Utils.DestroyableFrame;

public class Main extends Frame{
  
  static final int ABSOLUTE_UNITS = 1,RELATIVE_UNITS = 2;
  static final int SORT_BY_TIME = 0,SORT_BY_NAME = 1;

  int sortType = SORT_BY_TIME;
  int units = RELATIVE_UNITS;
  boolean shortOutput = true;
  
  // interface
  List methodList = new List();
  List callerList = new List();
  List calleeList = new List();
  List memoryList = new List();
  Label statusLine = new Label();
  Label labelMethods = new Label();
  Label labelMemoryHeader = new Label();

  CheckboxMenuItem menuSortByTime = new CheckboxMenuItem("by time");
  CheckboxMenuItem menuSortByName = new CheckboxMenuItem("by name");
  CheckboxMenuItem menuAbsoluteNumbers = 
    new CheckboxMenuItem("absolute numbers");
  CheckboxMenuItem menuRelativeNumbers = 
    new CheckboxMenuItem("relative numbers");


  // real data
  ProfInfo profInfo;
  MemoryInfo memoryInfo;
  MemoryUsed memoryUsed;


  Frame hyperFrame;    // frame for showing graph in hyperbolic space
  HyperGraph hyperGraph;

  public Main(String name) {
    super(name);
    init();
  }
  
  public Dimension preferredSize(){
    return new Dimension(640,480);
  }

  void init(){

    Font font = new Font("Courier",Font.PLAIN,14);
    setBackground(new Color(192,192,192));
    methodList.setFont(font);
    callerList.setFont(font);
    calleeList.setFont(font);    
    memoryList.setFont(font);    

    MenuBar menubar = new MenuBar();

    Menu file = new Menu("File", true);
    file.add("Load...");
    file.add("New profiler");
    file.add("Show Graph");
    file.add("Quit");
    //file.add("Close");

    Menu help = new Menu("Help", true);
    help.add("About...");

    Menu sort = new Menu("Sort", true);
    sort.add(menuSortByTime);
    sort.add(menuSortByName);
    menuSortByTime.setState(true);
    menuSortByName.setState(false);

    Menu options = new Menu("Options", true);
    options.add(menuAbsoluteNumbers);
    options.add(menuRelativeNumbers);
    menuAbsoluteNumbers.setState(false);
    menuRelativeNumbers.setState(true);

    menubar.add(file);
    menubar.add(sort);
    menubar.add(options);
    menubar.add(help);

    WindowUtils.getMainWindow(this).setMenuBar(menubar);

    Separator separator1 = new  Separator();
    Separator separator2 = new  Separator();
    Separator separator3 = new  Separator();

    GridBagLayout gridbag = new GridBagLayout();
    Panel panel_1 = new Panel();panel_1.setLayout(gridbag);
    labelMethods.setFont(font);
    VLabel methodsLabel = new VLabel("Methods",Label.RIGHT,VLabel.SOUTH_NORTH);
    //Label methodsLabel = new Label("Methods");

    WindowUtils.constrain(panel_1,methodsLabel,
			  0,0,1,3, GridBagConstraints.NONE,
			  GridBagConstraints.CENTER,0.,0.);
    WindowUtils.constrain(panel_1,labelMethods,1,0,1,1,
			  GridBagConstraints.HORIZONTAL,
			  GridBagConstraints.CENTER,1.,0.);
    WindowUtils.constrain(panel_1,methodList,1,1,1,1,
			  GridBagConstraints.BOTH,
			  GridBagConstraints.CENTER,1.,1.);
    WindowUtils.constrain(panel_1,statusLine,1,2,1,1,
			  GridBagConstraints.HORIZONTAL,
			  GridBagConstraints.CENTER,1.,0.);

    Panel panel_2 = new Panel();panel_2.setLayout(gridbag);
    VLabel labelCaller = new VLabel("Caller",Label.RIGHT,VLabel.SOUTH_NORTH);
    //Label labelCaller = new Label("Caller");
    WindowUtils.constrain(panel_2,labelCaller,0,0,1,1, GridBagConstraints.NONE,
			  GridBagConstraints.CENTER,0.,0.);
    WindowUtils.constrain(panel_2,callerList,1,0,1,1, GridBagConstraints.BOTH,
			  GridBagConstraints.CENTER,1.,1.);

    Panel panel_3 = new Panel();panel_3.setLayout(gridbag);
    VLabel labelCallee = new VLabel("Callee",Label.RIGHT,VLabel.SOUTH_NORTH);
    //Label labelCallee = new Label("Callee");
    WindowUtils.constrain(panel_3,labelCallee,0,0,1,1, GridBagConstraints.NONE,
			  GridBagConstraints.CENTER,0.,0.);
    WindowUtils.constrain(panel_3,calleeList,1,0,1,1, GridBagConstraints.BOTH,
			  GridBagConstraints.CENTER,1.,1.);

    Panel panel_4 = new Panel();panel_4.setLayout(gridbag);
    VLabel labelMemory = new VLabel("Memory",Label.RIGHT,VLabel.SOUTH_NORTH);
    //Label labelMemory = new Label("Memory");    
    WindowUtils.constrain(panel_4,labelMemory,0,0,1,2,
			  GridBagConstraints.NONE,
			  GridBagConstraints.CENTER,0.,0.);
			  
    labelMemoryHeader.setFont(font);
    WindowUtils.constrain(panel_4,labelMemoryHeader,1,0,1,1, 
			  GridBagConstraints.HORIZONTAL,
			  GridBagConstraints.CENTER,1.,0.);
    WindowUtils.constrain(panel_4,memoryList,1,1,1,1, GridBagConstraints.BOTH,
			  GridBagConstraints.CENTER,1.,1.);
                                                                                
    Panel panel_23 = new Panel();
    panel_23.setLayout(new SeparatorLayout(SeparatorLayout.HORIZONTAL,0.5));
    Panel panel_123 = new Panel();
    panel_123.setLayout(new SeparatorLayout(SeparatorLayout.HORIZONTAL,0.5));
    Panel panel_all = new Panel();
    panel_all.setLayout(new SeparatorLayout(SeparatorLayout.HORIZONTAL,0.75));

    panel_23.add(panel_2);
    panel_23.add(new Separator());
    panel_23.add(panel_3);

    panel_123.add(panel_1);
    panel_123.add(new Separator());
    panel_123.add(panel_23);

    panel_all.add(panel_123);
    panel_all.add(new Separator());
    panel_all.add(panel_4);

    this.add("Center",panel_all);

  }

  public boolean action(Event e,Object what){
    if(e.target == menuSortByName){
      if(sortType != SORT_BY_NAME){
	sortType = SORT_BY_NAME;
	menuSortByName.setState(true);
	menuSortByTime.setState(false);
	initMethodList();	
      }     
      return true;
    } else if(e.target == menuSortByTime){
      if(sortType != SORT_BY_TIME){
	sortType = SORT_BY_TIME;
	menuSortByName.setState(false);
	menuSortByTime.setState(true);
	initMethodList();	
      }
      return true;
    } else if(e.target == menuAbsoluteNumbers){
      if(units != ABSOLUTE_UNITS){
	units = ABSOLUTE_UNITS;
	menuAbsoluteNumbers.setState(true);
	menuRelativeNumbers.setState(false);
	menuSortByTime.setState(true);
	initMethodList();	
      }
      return true;
    } else if(e.target == menuRelativeNumbers){
      if(units != RELATIVE_UNITS){
	units = RELATIVE_UNITS;
	menuAbsoluteNumbers.setState(false);
	menuRelativeNumbers.setState(true);
	menuSortByTime.setState(true);
	initMethodList();	
      }
      return true;
    } else if(e.target == hyperGraph){

      int n = findEntry((ProfEntry)what);
      methodList.select(n);
      methodList.makeVisible(n);
      selectEntry((ProfEntry)what);
      return true;

    } else if(e.target == calleeList){

      int index = methodList.getSelectedIndex();
      if(index < 0)
	return true;
      ProfEntry entry = (ProfEntry)profInfo.entries.elementAt(index);
      int index_c = calleeList.getSelectedIndex();
      ProfEntry entry_c = 
	((CallerEntry)entry.calleeList.elementAt(index_c)).entry;
      int index_m = profInfo.entries.indexOf(entry_c);
      methodList.select(index_m);
      methodList.makeVisible(index_m);
      selectEntry(entry_c);
      if(hyperGraph != null){
	hyperGraph.selectEntry(entry_c);
      }
      return true;

    } else if(e.target == callerList){

      int index = methodList.getSelectedIndex();
      if(index < 0)
	return true;
      ProfEntry entry = (ProfEntry)profInfo.entries.elementAt(index);
      int index_c = callerList.getSelectedIndex();
      ProfEntry entry_c = 
	((CallerEntry)entry.callerList.elementAt(index_c)).entry;
      int index_m = profInfo.entries.indexOf(entry_c);
      methodList.select(index_m);
      methodList.makeVisible(index_m);
      selectEntry(entry_c);
      if(hyperGraph != null){
	hyperGraph.selectEntry(entry_c);
      }
      return true;

    }

    if(what instanceof String){ //we are expecting menu's name
      if(what.equals("Load...")){
        doLoad();
      } else if(what.equals("New profiler")){
	doNewProfiler();
      } else if(what.equals("Quit")){
	System.exit(0);
      } else if(what.equals("Close")){
	this.hide();
	this.dispose();  // segmentation fault on Linux
      } else if(what.equals("Show Graph")){
	doShowHyperGraph();
      } else if(what.equals("About...")){
	doAbout();
      }
    }
    return true;
  }

  public boolean handleEvent(Event e){   
    if(e.id == Event.WINDOW_DESTROY)
      System.exit(0);
    if(e.target == methodList){
      switch(e.id){
      case Event.LIST_SELECT:
	ProfEntry entry = 
	  (ProfEntry)profInfo.entries.elementAt(((Integer)e.arg).intValue());
    	selectEntry(entry);
	if(hyperGraph != null){
	  hyperGraph.selectEntry(entry);
	}
        break;
      default:
	break;
      }
    }
    return super.handleEvent(e); // to pass event to action()
  }

  /**
    unsuccessfull experiment with usual graph
   */
  void doShowGraph(){
    Frame frame = new Frame("Graph");
    Graph graph = new Graph();
    frame.add("Center",graph);
    frame.reshape(0,0,600,600);
    StringBuffer buf = new StringBuffer();
    for(Enumeration names =profInfo.getMethods();true; ){
      ProfEntry entry = (ProfEntry)names.nextElement();
      for(int j=0; j < entry.callerList.size(); j++){
	CallerEntry centry = (CallerEntry)entry.callerList.elementAt(j);
	buf.append(centry.entry.name.shortName);
	buf.append("-");
	buf.append(entry.name.shortName);
	buf.append("/100"); // length of edge
	buf.append(",");
	//System.out.println(centry.entry.shortName+"-"+entry.shortName);
      }
      if(!names.hasMoreElements())
	break;
    }
    graph.setGraph(new String(buf));
    frame.show();    
  }

  void doShowHyperGraph(){
    
    hyperFrame = new DestroyableFrame("Graph");
    hyperGraph = new HyperGraph(profInfo.packages,this);
    Label label = new Label();
    hyperGraph.statusBar = label;
    hyperFrame.add("South",label);
    hyperFrame.add("Center",hyperGraph);
    hyperFrame.resize(600,600);
    hyperFrame.show();    
  }

  static Main doNewProfiler(){
    Main frame = new Main("HyperProf");
    frame.resize(600,400);
    frame.pack();
    frame.show();
    Toolkit.getDefaultToolkit().sync();    
    return frame;
  }

  FileDialog file_load_dialog;

  void doLoad(){
    if(file_load_dialog == null){
      file_load_dialog = new FileDialog(WindowUtils.getMainWindow(this), 
                                        "Load profile", FileDialog.LOAD);
    }
    file_load_dialog.pack();
    file_load_dialog.show(); 
    
    String fname = file_load_dialog.getFile();
    String fpath = file_load_dialog.getDirectory();
    String path = fpath+fname;
    
    if(fname != null && fpath != null){  // user had selected something
      readFile(new File(fpath,fname));
    }
  }
  
  public void doAbout(){
    AboutDialog d = new AboutDialog(this,"About HyperProf",true);
    d.pack();
    d.show();
  }

  int findEntry(ProfEntry entry){
    for(int i=0;i < profInfo.entries.size();i++){
      if(profInfo.entries.elementAt(i) == entry)
	return i;
    }
    return -1;
  }

  void selectEntry(ProfEntry entry){
    if(callerList.countItems() > 0)
      callerList.clear();
    
    ProfInfo.current_time = 0; // to start time counter
    for(int i=0; i < entry.callerList.size(); i++){
      CallerEntry centry = (CallerEntry)entry.callerList.elementAt(i);
      profInfo.current_time += centry.time;
      callerList.addItem(centry.toString());
    }

    if(calleeList.countItems() > 0)
      calleeList.clear();

    ProfInfo.current_time = 0; // to start time counter
    for(int i=0; i < entry.calleeList.size(); i++){
      CallerEntry centry = (CallerEntry)entry.calleeList.elementAt(i);
      profInfo.current_time += centry.time;
      calleeList.addItem(centry.toString());
    }
    statusLine.setText(entry.name.packageName + entry.name.shortName);   
  }


  void readFile(File file){

    try{
       read(new FileInputStream(file));
     } catch(FileNotFoundException e){
       e.printStackTrace(System.out);
       return;
     }
    this.setTitle("HyperProf [" +file.getName() +"]");
  }

  void read(InputStream inp){

    WindowUtils.getMainWindow(this).setCursor(Frame.WAIT_CURSOR);
    Toolkit.getDefaultToolkit().sync();

    DataInputStream input = new DataInputStream (new BufferedInputStream(inp));
    profInfo = new ProfInfo(this);
    memoryInfo = new MemoryInfo();    
    try{
      String s;
      int section = 0;
      int count = 0;
      boolean started = false; 
      System.out.print("parsing");System.out.flush();
      while((s = input.readLine())!= null){
	char c = s.charAt(0);
	if(c == '#' || !started){ // in JDK 1.02 '#' is absent in first line
	  started = true;
	  section++;   // is it always in this order?
	  continue;
	}
        // in JDK-1.1 '#' is absend always
	if(c == 'h') {// handles_used
	  section = 2; // forget about it
	  continue;   
	}
	else if(c == 's') {// sig count bytes indx
	  section = 3;
	  continue;
	} else if(c == '*'){ // *** tab[]
	  break;
	}
	switch(section){
	case 1:
	  profInfo.addElement(new ProfLine(s));break;
	case 2:
	  memoryUsed = new MemoryUsed(s);break;
	case 3:
	  memoryInfo.addElement(new MemoryEntry(s,this));break;
	}
	if((++count) % 10 == 0){
	  System.out.print(".");System.out.flush();
	  Thread.yield();
	}
      }
    } catch (IOException e){ 
      e.printStackTrace(System.out);
    }
    
    profInfo.initTime();

    //profInfo.packages.print(System.out);

    initMethodList();
    labelMethods.setText("   time  cumult/calls name (100% = "+
			      Fmt.fmt((profInfo.total_time/1000.),5,4) +
			      " seconds)");
    labelMemoryHeader.setText(" bytes  /cnt  type (100% = "+
			      memoryInfo.total_bytes + " bytes)");
    WindowUtils.getMainWindow(this).setCursor(Frame.DEFAULT_CURSOR);
  }
  
  void initMethodList(){
    System.out.println("\nsorting...");System.out.flush();
    
    WindowUtils.getMainWindow(this).setCursor(Frame.WAIT_CURSOR);
    Toolkit.getDefaultToolkit().sync();
    
    
    profInfo.sort();
    profInfo.current_time = 0;

    if(methodList.countItems() > 0)
      methodList.clear();
    if(calleeList.countItems() > 0)
      calleeList.clear();
    if(callerList.countItems() > 0)
      callerList.clear();
    if(memoryList.countItems() > 0)
      memoryList.clear();


    System.out.println("\ninitializing...");System.out.flush();
    for(Enumeration names =profInfo.getMethods();names.hasMoreElements();){
      ProfEntry entry = (ProfEntry)names.nextElement();
      profInfo.current_time += entry.time;
      methodList.addItem(entry.toString());
    }
    
    memoryInfo.sort();
    for(Enumeration names = memoryInfo.getElements();
	names.hasMoreElements();){
      memoryList.addItem(((MemoryEntry)names.nextElement()).toString());
    }
    
    System.out.println("\nready");System.out.flush();
    WindowUtils.getMainWindow(this).setCursor(Frame.DEFAULT_CURSOR);
  }
  
  public static void main(String[] args){
    Main frame = doNewProfiler();
    if(args.length>0)
      frame.readFile(new File(args[0]));   
  }
}

