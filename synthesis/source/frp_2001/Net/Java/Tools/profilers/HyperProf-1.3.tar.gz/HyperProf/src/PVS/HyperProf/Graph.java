package PVS.HyperProf;
//
// Copyright (C) 1996 by Vladimir Bulatov <V.Bulatov@ic.ac.uk>.  
//        All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.

import java.util.*;
import java.awt.*;
import java.applet.Applet;

import PVS.Utils.*;

class Node {
  double x;
  double y;
  
  double dx;
  double dy;
  
  boolean fixed;
  boolean visible;  // is this node visible?
  int charge; // number_of_out_edges - number_of_in_edges
  String lbl;
}

class Edge {
  Node from;
  Node to;

  boolean visible; // is this edge visible?
  double len;
}

class GraphPanel extends Panel implements Runnable {
  Graph graph;
  int nnodes;
  Node nodes[] = new Node[1000];
  
  int nedges;
  Edge edges[] = new Edge[2000];
  
  Thread relaxer;
  boolean stress;
  boolean random;
  int cutoff = 200;
  
  static final int DIRECTIONAL = 1,REPULSION = 2,BOUNDS = 4,CHARGE=8;
  int relax_algorithm=/*DIRECTIONAL | REPULSION | BOUNDS |*/ CHARGE;

  DoubleR directional_force = new DoubleR(100);
  DoubleR repulsion_force = new DoubleR(0);
  DoubleR bound_force = new DoubleR(0);
  DoubleR charge_force = new DoubleR(0);

  GraphPanel(Graph graph) {
    this.graph = graph;
  }
  
  Node findNode(String lbl) {
    for (int i = 0 ; i < nnodes ; i++) {
      if (nodes[i].lbl.equals(lbl)) {
	return nodes[i];
      }
    }
    return addNode(lbl);
  }

  Node addNode(String lbl) {
    Node n = new Node();
    n.x = 10 + 380*Math.random();
    n.y = 10 + 380*Math.random();
    n.lbl = lbl;
    n.visible = true;
    nodes[nnodes] = n;
    nnodes++;
    return n;
  }

  void addEdge(String from, String to, int len) {
    Edge e = new Edge();
    e.from = findNode(from);
    e.to = findNode(to);
    e.len = len;
    e.visible = true;
    edges[nedges++] = e;
    e.from.charge++;
    e.to.charge--;
  }

  void hideNode(Node node){
    node.visible = false;
    for (int i = 0 ; i < nedges ; i++) {
      Edge e = edges[i];
      if(e.from == node || e.to == node)
	e.visible = false;
    }    
  }

  public void run() {
    while (true) {
      relax();
      if (random && (Math.random() < 0.03)) {
	Node n = nodes[(int)(Math.random() * nnodes)];
	if (!n.fixed && n.visible) {
	  n.x += 100*Math.random() - 50;
	  n.y += 100*Math.random() - 50;
	}
      }
      try {
	Thread.sleep(100);
      } catch (InterruptedException e) {
	break;
      }
    }
  }
  
  synchronized void relax() {
    if((relax_algorithm & DIRECTIONAL) != 0)
      computeDirectionalForces();
    if((relax_algorithm & BOUNDS) != 0)
      computeBoundForces();
    if((relax_algorithm & REPULSION) != 0)
      computeRepulsionForces();
    if((relax_algorithm & CHARGE) != 0)
      computeChargeForces();
    moveNodes();
    repaint();
  }

  void computeChargeForces(){
    for (int i = 0 ; i < nnodes ; i++) {
      nodes[i].dy -= charge_force.value*nodes[i].charge;
    }    
  }

  void computeDirectionalForces(){
    for (int i = 0 ; i < nedges ; i++) {
      Edge e = edges[i];
      if(!e.visible)
	continue;
      double dy = e.to.y - e.from.y;
      double dx = e.to.x - e.from.x;
      double len = Math.sqrt(dx*dx+dy*dy);
      if(len != 0.){
	double fx,fy;
	// we assume that potential energy of edge is proportional to 
	// cos(angle between y axis and this edge)
	// Energy = force*(1-cos(fi)) = force*(1-dy/sqrt(dx*dx+dy*dy));
	fx = directional_force.value*(-dy*dx/(len*len*len)); 
	fy = directional_force.value*(dx*dx)/(len*len*len);
	//System.out.println("force: "+ fx +","+fy);
	e.to.dy += fy;
	e.from.dy -=fy;	
	e.to.dx += fx;
	e.from.dx -=fx;	
	
      }
    }    
  }

  void computeBoundForces(){
    for (int i = 0 ; i < nedges ; i++) {
      Edge e = edges[i];
      if(!e.visible)
	continue;
      double vx = e.to.x - e.from.x;
      double vy = e.to.y - e.from.y;
      double len = Math.sqrt(vx * vx + vy * vy);
      double f = bound_force.value*(edges[i].len - len) / (len * 3) ;
      double dx = f * vx;
      double dy = f * vy;
      
      e.to.dx += dx;
      e.to.dy += dy;
      e.from.dx += -dx;
      e.from.dy += -dy;
    }
  }

  void computeRepulsionForces(){
    for (int i = 0 ; i < nnodes ; i++) {
      Node n1 = nodes[i];
      if(!n1.visible)
	continue;
      double dx = 0;
      double dy = 0;
      
      for (int j = 0 ; j < nnodes ; j++) {
	if (i == j) {
	  continue;
	}
	Node n2 = nodes[j];
	double vx = n1.x - n2.x;
	double vy = n1.y - n2.y;
	double len = vx * vx + vy * vy;
	if (len == 0) {
	  dx += Math.random();
	  dy += Math.random();
	} else if (len < cutoff*cutoff) {
	  dx += vx / len;
	  dy += vy / len;
	}
      }
      double dlen = dx * dx + dy * dy;
      if (dlen > 0) {
	dlen = Math.sqrt(dlen) / 2;
	n1.dx += repulsion_force.value*dx / dlen;
	n1.dy += repulsion_force.value*dy / dlen;
      }
    }
    
  }  

  void moveNodes(){
    
    Dimension d = size();
    for (int i = 0 ; i < nnodes ; i++) {
      Node n = nodes[i];
      if(!n.visible)
	continue;
      if (!n.fixed) {
	n.x += Math.max(-5, Math.min(5, n.dx));
	n.y += Math.max(-5, Math.min(5, n.dy));
	//System.out.println("v= " + n.dx + "," + n.dy);
	if (n.x < 0) {
	  n.x = 0;
	} else if (n.x > d.width) {
	  n.x = d.width;
	}
	if (n.y < 0) {
	  n.y = 0;
	} else if (n.y > d.height) {
	  n.y = d.height;
	}
      }
      n.dx /= 2;
      n.dy /= 2;
    }
  }

  Node pick;
  boolean pickfixed;
  Image offscreen;
  Dimension offscreensize;
  Graphics offgraphics;
  
  
  final Color fixedColor = Color.red;
  final Color selectColor = Color.pink;
  final Color edgeColor = Color.black;
  final Color nodeColor = new Color(250, 220, 100);
  final Color stressColor = Color.gray;
  final Color arcColor1 = Color.black;
  final Color arcColor2 = Color.pink;
  final Color arcColor3 = Color.red;
  
  public void paintNode(Graphics g, Node n, FontMetrics fm) {
    int x = (int)n.x;
    int y = (int)n.y;
    g.setColor((n == pick) ? selectColor : (n.fixed ? fixedColor : nodeColor));
    int h = fm.getHeight() + 4;
    //int w = fm.stringWidth(n.lbl) + 10;
    int w = h;
    g.fillRect(x - w/2, y - h / 2, w, h);
    g.setColor(Color.black);
    g.drawRect(x - w/2, y - h / 2, w-1, h-1);
    //g.drawString(n.lbl, x - (w-10)/2, (y - (h-4)/2) + fm.getAscent());
  }
  
  public synchronized void update(Graphics g) {
    Dimension d = size();
    if ((offscreen == null) || (d.width != offscreensize.width) || (d.height != offscreensize.height)) {
      offscreen = createImage(d.width, d.height);
      offscreensize = d;
      offgraphics = offscreen.getGraphics();
      offgraphics.setFont(getFont());
    }
    
    offgraphics.setColor(getBackground());
    offgraphics.fillRect(0, 0, d.width, d.height);
    offgraphics.setColor(arcColor1);
    for (int i = 0 ; i < nedges ; i++) {
      Edge e = edges[i];
      if(!e.visible)
	continue;
      int x1 = (int)e.from.x;
      int y1 = (int)e.from.y;
      int x2 = (int)e.to.x;
      int y2 = (int)e.to.y;
      int len = (int)Math.abs(Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) - e.len);
      //offgraphics.setColor((len < 10) ? arcColor1 : (len < 20 ? arcColor2 : arcColor3)) ;
      drawArrow(offgraphics,x1, y1, x2, y2);
      if (stress) {
	String lbl = String.valueOf(len);
	offgraphics.setColor(stressColor);
	offgraphics.drawString(lbl, x1 + (x2-x1)/2, y1 + (y2-y1)/2);
	offgraphics.setColor(edgeColor);
      }
    }
    
    FontMetrics fm = offgraphics.getFontMetrics();
    for (int i = 0 ; i < nnodes ; i++) {
      Node node = nodes[i];
      if(node.visible)
	paintNode(offgraphics, nodes[i], fm);
    }
    g.drawImage(offscreen, 0, 0, null);
  }

  static int x[] = new int[3],y[] = new int[3];
  static int arrlen = 10;
  void drawArrow(Graphics g, int x1,int y1,int x2,int y2){
    g.drawLine(x1, y1, x2, y2);

    double dx = x2-x1, dy = y2-y1, len = Math.sqrt(dx*dx+dy*dy);
    x[0] = (int)(x1+dx/2); 
    y[0] = (int)(y1+dy/2);
    x[1] = (int)(x1+dx/2+(-dx+ dy/3)/len*arrlen);
    y[1] = (int)(y1+dy/2+(-dy- dx/3)/len*arrlen);
    x[2] = (int)(x1+dx/2+(-dx- dy/3)/len*arrlen);
    y[2] = (int)(y1+dy/2+(-dy+ dx/3)/len*arrlen);
    g.fillPolygon(x,y,3);
  }

  
  public synchronized boolean mouseDown(Event evt, int x, int y) {
    double bestdist = Double.MAX_VALUE;
    for (int i = 0 ; i < nnodes ; i++) {
      Node n = nodes[i];
      double dist = (n.x - x) * (n.x - x) + (n.y - y) * (n.y - y);
      if (dist < bestdist) {
	pick = n;
	bestdist = dist;
      }
    }
    pickfixed = pick.fixed;
    pick.fixed = true;
    pick.x = x;
    pick.y = y;
    
    repaint();
    return true;
  }
  
  public synchronized boolean mouseDrag(Event evt, int x, int y) {
    if(pick != null){
      pick.x = x;
      pick.y = y;
      repaint();
    }
    return true;
  }
  
  public synchronized boolean mouseUp(Event evt, int x, int y) {
    System.out.println(pick.lbl);

    pick.x = x;
    pick.y = y;
    pick.fixed = pickfixed;

    if((evt.modifiers & Event.META_MASK) != 0){ // right button
      pick.fixed = ((pick.fixed)? false:true);
      pick = null;
    } else if((evt.modifiers & Event.CTRL_MASK) != 0){      
      hideNode(pick);
      pick = null;      
    } else {      
      pick = null;      
    }
    repaint();
    return true;
  }
  
  public void start() {
    relaxer = new Thread(this);
    relaxer.start();
  }
  public void stop() {
    relaxer.stop();
  }
}

public class Graph extends Panel {
  
  GraphPanel panel;
  
  public Graph(){
    
    setLayout(new BorderLayout());
    
    panel = new GraphPanel(this);

    add("Center", panel);
    Panel p = new BorderPanel();
    add("South", p);
    p.setLayout(new GridBagLayout());
    WindowUtils.constrain(p,new Button("Scramble"),0,0,1,1);
    WindowUtils.constrain(p,new Button("Shake"),0,1,1,1);
    WindowUtils.constrain(p,new Checkbox("Stress"),1,0,1,1);
    WindowUtils.constrain(p,new Checkbox("Random"),1,1,1,1);

    WindowUtils.constrain(p,new Button("Start"),2,0,1,1);
    WindowUtils.constrain(p,new Button("Stop"),2,1,1,1);
    WindowUtils.constrain(p,new Button("Dismiss"),2,2,1,1);

    WindowUtils.constrain(p,new DoubleField("directional",panel.directional_force),3,0,1,1);
    WindowUtils.constrain(p,new DoubleField("repulsion",panel.repulsion_force),3,1,1,1);

    WindowUtils.constrain(p,new DoubleField("bound",panel.bound_force),4,0,1,1);
    WindowUtils.constrain(p,new DoubleField("charge",panel.charge_force),4,1,1,1);
  }
  
  void setGraph(String edges){
    
    for (StringTokenizer t = new StringTokenizer(edges, ",") ; t.hasMoreTokens() ; ) {
      String str = t.nextToken();
      int i = str.indexOf('-');
      if (i > 0) {
	int len = 50;
	int j = str.indexOf('/');
	if (j > 0) {
	  len = Integer.valueOf(str.substring(j+1)).intValue();
	  str = str.substring(0, j);
	}
	panel.addEdge(str.substring(0,i), str.substring(i+1), len);
      }
    }
    
    /*
       Dimension d = size();
       String center = getParameter("center");
       if (center != null){
       Node n = panel.nodes[panel.findNode(center)];
       n.x = d.width / 2;
       n.y = d.height / 2;
       n.fixed = true;
       }
       */
    start();
  }
  
  public void start() {
    panel.start();
  }
  
  public void stop() {
    panel.stop();
  }
  
  public boolean action(Event evt, Object arg) {
    if (arg instanceof Boolean) {
      if (((Checkbox)evt.target).getLabel().equals("Stress")) {
	panel.stress = ((Boolean)arg).booleanValue();
      } else {
	panel.random = ((Boolean)arg).booleanValue();
      }
      return true;
    } 
    if ("Scramble".equals(arg)) {
      Dimension d = size();
      for (int i = 0 ; i < panel.nnodes ; i++) {
	Node n = panel.nodes[i];
	if (!n.fixed) {
	  n.x = 10 + (d.width-20)*Math.random();
	  n.y = 10 + (d.height-20)*Math.random();
	}
      }
      return true;
    }
    if ("Shake".equals(arg)) {
      Dimension d = size();
      for (int i = 0 ; i < panel.nnodes ; i++) {
	Node n = panel.nodes[i];
	if (!n.fixed) {
	  n.x += 80*Math.random() - 40;
	  n.y += 80*Math.random() - 40;
	}
      }
      return true;
    }
    if ("Stop".equals(arg)){
      panel.stop();
      return true;
    }
    if ("Start".equals(arg)){
      panel.start();
      return true;
    }
    if ("Dismiss".equals(arg)){
      panel.stop();
      Component p = getParent();
      if(p instanceof Frame){
	((Frame)p).hide();
	((Frame)p).dispose();
      }
      return true;
    }
    return false;
  }
  
  public static void main(String[] argv){
    Frame frame = new Frame("Graph");
    Graph graph = new Graph();
    frame.add("Center",graph);
    frame.reshape(0,0,400,400);
    
    if(argv.length >0)
      graph.setGraph(argv[0]);
    else 
      graph.setGraph("a1-a2,a2-a3,a3-a4,a4-a5,a5-a6,b1-b2,b2-b3,b3-b4,b4-b5,b5-b6,c1-c2,c2-c3,c3-c4,c4-c5,c5-c6,x-a1,x-b1,x-c1,x-a6,x-b6,x-c6");
    
    frame.show();
  }
}
