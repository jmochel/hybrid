
class TestProfiler {
  
  static void test1(int n){
    for(int i=0;i < n;i++){
      double x = Math.log(i);
    }
  }

  static void test2(int n){
    for(int i=0;i < n;i++){
      double y = test3(i);
    }
  }

  static double test3(double x){
    return Math.sin(x);
  }

  static double test4(double x,int i){
    if(i > 0)
      return Math.sin(test5(x,i-1));
    else 
      return x;
  }

  static double test5(double x,int i){
    if(i > 0)
	return Math.sin(test4(x,i-1));
    else 
      return x;
  }

  public static void main(String[] args){
    long t1 = System.currentTimeMillis();
    test1(10000);
    long t2 = System.currentTimeMillis();
    test2(10000);
    long t3 = System.currentTimeMillis();
    int [] mem = new int[100000];
    long t4 = System.currentTimeMillis();
    double x = test4(1.,2000);
    long t41 = System.currentTimeMillis();
    System.out.println("test1: "+(t2-t1)+" millis\n test2: "+(t3-t2)+" millis\n"+
		       "test4: "+(t41-t4)+" millis");    

    System.exit(-1);
  }
}

