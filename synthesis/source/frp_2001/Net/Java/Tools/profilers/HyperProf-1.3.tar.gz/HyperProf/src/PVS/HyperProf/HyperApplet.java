package PVS.HyperProf;

import java.awt.*;
import java.applet.*;
import java.io.InputStream;
import java.net.URL;

public class HyperApplet extends Applet{

  Main frame;

  public void init(){
    String filename = getParameter("filename");
    frame = Main.doNewProfiler(); 
    try {
      URL url = new URL(getDocumentBase(), filename);
      frame.setTitle("HyperProf [" + url +"]");    
      InputStream inp = url.openStream();
      frame.read(inp);
    } catch (Exception e) {
      e.printStackTrace(System.out);
    }    
  }
  
  public void start(){ 
    frame.show();
  }
  
  public void stop(){ 
    frame.hide();
  }
 
}
