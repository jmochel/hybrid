IntelliJ Renamer - README

Thank you for downloading IntelliJ Renamer!

IntelliJ Renamer is a multi-platform Java source code management tool.
Analyze dependencies, find usages, rename and move packages, classes, methods and class variables.
Find all places in your project where particular package, class method or variable is used at.
Adapt your source code to library changes by using the Migration feature.
Rename or move packages, classes, methods or variables and automatically correct all references in the code.

You are encouraged to visit our IntelliJ Renamer online forums or to
contact us via e-mail at feedback@intellij.com if you have any comments about
this release. In particular, we are very interested in any ease-of-use, user
interface suggestions that you may have. We will be posting regular updates
of our progress to our online forums.

Contents:
==============================================================================
  INSTALL.TXT         Installation instructions
  LICENSE.TXT         Software license
  README.TXT          This file
  bin/                Startup scripts for launching IntelliJ Renamer
  lib/                Library files
  help/               Online help files
  migration/          Sample migration map files

Installing IntelliJ Renamer
==============================================================================
  Please read the contents of the INSTALL file.

Uninstalling IntelliJ Renamer
==============================================================================
  To unintall IntelliJ Renamer simply delete the contents of 
  the IntelliJ Renamer home installation directory.

Contacting us:
==============================================================================
  sales@intellij.com       - Sales inquires, billing, order processing questions
  support@intellij.com     - Technical support (all products)
  suggestions@intellij.com - Feature suggestions
  info@intellij.com        - Product inquiries

Bug Reporting:
==============================================================================
  Send emails to bugs@intellij.com

Home Page:
==============================================================================
  http://www.intellij.com
