package xdoclet.ejb;

import java.io.*;
import java.util.Date;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.*;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.8 $
 */
public class LocalHomeInterfaceSubTask extends AbstractEjbSubTask
{

	protected static String DEFAULT_TEMPLATE_FILE = "home-local.j";

	public void setPattern( String new_pattern )
	{
		homeClassPattern = new_pattern;
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( LocalHomeInterfaceSubTask.class, "execute" );
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isEntity( getCurrentClass() ) || isSession( getCurrentClass() ) )
			{
				if( isEjb( getCurrentClass() ) )
				{
					if( dontGenerate() )
					{
						continue;
					}

					File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
					File beanFile = beanFile();

					if( file.exists() )
					{
						// Check modification timestamps
						if( file.lastModified() > beanFile.lastModified() )
						{
							cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
							continue;
						}
					}

					System.out.println( "Create LocalHome Interface for:" + getCurrentClass().toString() );
					file.getParentFile().mkdirs();

					String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;
					generateFileUsingTemplate( javaFile( getGeneratedClassName() ), template_file_name );
				}
			}
		}
	}

	protected String getGeneratedClassName()
	{
		return getHomeInterface( "local" );
	}

	/**
	 * @return    true if the local home interface should not be generated.
	 */
	protected boolean dontGenerate()
	{
		Category cat = getCategory( LocalHomeInterfaceSubTask.class, "dontGenerate" );
		if( isOnlyRemoteEjb( getCurrentClass() ) )
		{
			cat.debug( "Reject file " + getGeneratedClassName() + " because of view-type remote" );
			return true;
		}

		String interface_tag = DocletUtil.getText( getCurrentClass(), "ejb:home" );
		if( interface_tag == null )
		{
			return false;
		}

		String generate = getParameterValue( interface_tag, "generate", -1 );
		if( ( generate != null ) && ( generate.indexOf( "local" ) == -1 ) )
		{
			cat.debug( "Skip remote home interface for " + getGeneratedClassName() + " because of generate=" + generate + " flag." );
			return true;
		}
		return false;
	}
}
