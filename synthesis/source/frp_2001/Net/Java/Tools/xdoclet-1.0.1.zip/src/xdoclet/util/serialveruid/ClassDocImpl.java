package xdoclet.util.serialveruid;

import com.sun.javadoc.FieldDoc;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class ClassDocImpl extends xdoclet.util.serialveruid.ProgramElementDocImpl implements com.sun.javadoc.ClassDoc
{
	final java.lang.String qualifier;
	final java.lang.String name;

	final java.util.List fields;
	final java.util.List methods;
	final java.util.List constructors;

	public ClassDocImpl( int modifiers, String qualifier, String name, java.util.List fields, java.util.List methods, java.util.List constructors )
	{
		super( modifiers );

		this.qualifier = qualifier;
		this.name = name;

		this.fields = fields;
		this.methods = methods;
		this.constructors = constructors;
	}

	public boolean isSerializable()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isExternalizable()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isClass()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isOrdinaryClass()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isInterface()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isException()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isError()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isAbstract()
	{
		return java.lang.reflect.Modifier.isAbstract( super.modifiers );
	}

	public boolean isIncluded()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.MethodDoc[] serializationMethods()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.FieldDoc[] serializableFields()
	{
		throw new UnsupportedOperationException();
	}

	public boolean definesSerializableFields()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String name()
	{
		return name;
	}

	public java.lang.String typeName()
	{
		return name;
	}

	public java.lang.String qualifiedName()
	{
		if( qualifier.length() == 0 )
		{
			return name;
		}
		else
		{
			return qualifier + '.' + name;
		}
	}

	public java.lang.String qualifiedTypeName()
	{
		return qualifiedName();
	}

	public java.lang.String dimension()
	{
		return "";
	}

	public com.sun.javadoc.ClassDoc asClassDoc()
	{
		return this;
	}

	public java.lang.String toString()
	{
		return qualifiedName();
	}

	public com.sun.javadoc.ClassDoc[] importedClasses()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.PackageDoc[] importedPackages()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ConstructorDoc findConstructor( java.lang.String s, java.lang.String as[] )
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.FieldDoc findField( java.lang.String s )
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.MethodDoc findMethod( java.lang.String s, java.lang.String as[] )
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ClassDoc findClass( java.lang.String s )
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String modifiers()
	{
		return java.lang.reflect.Modifier.toString( isInterface() ? super.modifiers & 0xfffffbff : super.modifiers );
	}

	public com.sun.javadoc.ClassDoc superclass()
	{
		throw new UnsupportedOperationException();
	}

	public boolean subclassOf( com.sun.javadoc.ClassDoc classdoc )
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ClassDoc[] interfaces()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ClassDoc[] implementedInterfaces()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.FieldDoc[] fields()
	{
		return ( com.sun.javadoc.FieldDoc[] ) fields.toArray( new FieldDoc[fields.size()] );
	}

	public com.sun.javadoc.MethodDoc[] methods()
	{
		return ( com.sun.javadoc.MethodDoc[] ) methods.toArray( new com.sun.javadoc.MethodDoc[methods.size()] );
	}

	public com.sun.javadoc.ConstructorDoc[] constructors()
	{
		return ( com.sun.javadoc.ConstructorDoc[] ) constructors.toArray( new com.sun.javadoc.ConstructorDoc[constructors.size()] );
	}

	public com.sun.javadoc.ClassDoc[] innerClasses()
	{
		throw new UnsupportedOperationException();
	}
}
