package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */

/**
 * @created    August 21, 2001
 */
abstract class ProgramElementDocImpl extends xdoclet.util.serialveruid.DocImpl implements com.sun.javadoc.ProgramElementDoc
{
	final int          modifiers;

	ProgramElementDocImpl( int modifiers )
	{
		this.modifiers = modifiers;
	}

	public boolean isPublic()
	{
		return java.lang.reflect.Modifier.isPublic( modifiers );
	}

	public boolean isProtected()
	{
		return java.lang.reflect.Modifier.isProtected( modifiers );
	}

	public boolean isPrivate()
	{
		return java.lang.reflect.Modifier.isPrivate( modifiers );
	}

	public boolean isPackagePrivate()
	{
		return !isPublic() && !isPrivate() && !isProtected();
	}

	public boolean isStatic()
	{
		return java.lang.reflect.Modifier.isStatic( modifiers );
	}

	public boolean isFinal()
	{
		return java.lang.reflect.Modifier.isFinal( modifiers );
	}

	public com.sun.javadoc.ClassDoc containingClass()
	{
		throw new UnsupportedOperationException();
	}

	public int modifierSpecifier()
	{
		return modifiers;
	}

	public java.lang.String modifiers()
	{
		return java.lang.reflect.Modifier.toString( modifiers );
	}

	public abstract java.lang.String qualifiedName();

	public com.sun.javadoc.PackageDoc containingPackage()
	{
		throw new UnsupportedOperationException();
	}
}
