package xdoclet.util;

import java.io.StringReader;
import java.io.File;
import java.io.IOException;

import java.util.HashMap;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.InputSource;

import org.apache.tools.ant.BuildException;

import org.apache.log4j.Category;

import xdoclet.util.FileManager;

/**
 *  This handler implementation is capable of providing dtds from a local
 *  storage in stead of accessing them over the net. Further, it will throw an
 *  exception if the parsed xml is not acording to the DTD it specifies.
 *
 * @author     <a href="mailto:aslak.hellesoy@bekk.no">Aslak Helles�y</a>
 * @created    September 18, 2001
 * @version    $Revision: 1.1 $
 */
public class XmlValidator extends DefaultHandler
{

	private final HashMap _dtds = new HashMap();

	private Class      _resourceClass;

	/**
	 *  Creates a new XmlValidator.
	 *
	 * @param  resourceClass  the class used to load the local dtds. The registered
	 *      dtds must be loadable by resourceClass' ClassLoader
	 */
	public XmlValidator( Class resourceClass )
	{
		_resourceClass = resourceClass;
	}

	/**
	 *  Registers a local DTD document by its public id. This is necessary to avoid
	 *  DTD loading over the net.
	 *
	 * @param  publicId     the publicId of the DTD
	 * @param  dtdFileName  the file name of the local DTD, which must be loadable
	 *      by the class passed in the constructor.
	 */
	public void registerDTD( String publicId, String dtdFileName )
	{
		_dtds.put( publicId, dtdFileName );
	}

	/**
	 *  Called by parser when a DTD declaration is encountered in the parsed XML
	 *  document
	 *
	 * @param  publicId  the public id of the DTD
	 * @param  systemId  the system id of the DTD
	 * @return           an InputSource from containing the DTD document, provided
	 *      it has been previously registered via the {@link #registerDTD} method.
	 *      If not, null will be returned, and the parser will atempt to load the
	 *      DTD from the systemId value, Usually an Internet http URL.
	 */
	public InputSource resolveEntity( String publicId, String systemId )
	{
		String dtdFileName = ( String ) _dtds.get( publicId );
		if( dtdFileName != null )
		{
			String dtd = FileManager.getFileContent( dtdFileName, _resourceClass );
			return new InputSource( new StringReader( dtd ) );
		}
		else
		{
			System.out.println( "WARNING: couldn't load local DTD for publicId=" + publicId );
			return null;
		}
	}

	/**
	 *  Called by parser if a error occurs
	 *
	 * @param  e                   an exception describing the error
	 * @throws  SAXParseException  every time this method is called by the parser
	 */
	public void error( SAXParseException e )
			 throws SAXParseException
	{
		throw e;
	}

	/**
	 *  Called by parser if a warning occurs
	 *
	 * @param  e                   an exception describing the warning
	 * @throws  SAXParseException  every time this method is called by the parser
	 */
	public void warning( SAXParseException e )
			 throws SAXParseException
	{
		throw e;
	}

	/**
	 *  Validates an XML file for conformance to a declared DTD or XMLSchema. This
	 *  method is useful for subclasses that wish to verify that a generated XML
	 *  file is ok. Please note that the callers should make sure to register any
	 *  DTDs required for validation on the handler object.
	 *
	 * @param  dir                 directory where the XML file to be validated is
	 *      locted
	 * @param  xmlFileName         relative file name of the XML file to be
	 *      validated
	 * @exception  BuildException  if the xml could not be validated for any reason
	 */
	public void validate( File dir, String xmlFileName ) throws BuildException
	{
		// instantiate a validating parser
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setValidating( true );
		try
		{
			File xmlFile = new File( dir, xmlFileName );
			SAXParser parser = factory.newSAXParser();
			Category cat = Category.getInstance( XmlValidator.class.getName() );
			cat.debug( "Parsing " + xmlFile.getAbsolutePath() );
			parser.parse( xmlFile, this );
			cat.debug( "Parsing OK" );
		}
		catch( SAXParseException e )
		{
			String message = "Generated file [" + e.getSystemId() + ":line " + e.getLineNumber() + "] is not valid according to its DTD: ";
			throw new BuildException( message + e.getMessage() );
		}
		catch( SAXException e )
		{
			e.printStackTrace();
			throw new BuildException( "Couldn't initalize XML parser: " + e.getMessage() );
		}
		catch( IOException e )
		{
			e.printStackTrace();
			throw new BuildException( "Couldn't load XML file:" + e.getMessage() );
		}
		catch( ParserConfigurationException e )
		{
			e.printStackTrace();
			throw new BuildException( "Couldn't configure XML parser: " + e.getMessage() );
		}
		catch( NullPointerException e )
		{
			e.printStackTrace();
			throw new BuildException( "Couldn't load DTD: " + e.getMessage() );
		}
	}

}
