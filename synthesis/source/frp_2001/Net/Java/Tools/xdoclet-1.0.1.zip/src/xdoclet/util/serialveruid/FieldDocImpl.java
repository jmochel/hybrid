package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class FieldDocImpl extends xdoclet.util.serialveruid.MemberDocImpl implements com.sun.javadoc.FieldDoc
{
	final com.sun.javadoc.Type type;

	public FieldDocImpl( String name, int modifiers, com.sun.javadoc.Type type )
	{
		super( name, modifiers );

		this.type = type;
	}

	public boolean isField()
	{
		return true;
	}

	public boolean isTransient()
	{
		return java.lang.reflect.Modifier.isTransient( modifiers );
	}

	public boolean isVolatile()
	{
		return java.lang.reflect.Modifier.isVolatile( modifiers );
	}

	public com.sun.javadoc.Type type()
	{
		return type;
	}

	public com.sun.javadoc.SerialFieldTag[] serialFieldTags()
	{
		throw new UnsupportedOperationException();
	}
}
