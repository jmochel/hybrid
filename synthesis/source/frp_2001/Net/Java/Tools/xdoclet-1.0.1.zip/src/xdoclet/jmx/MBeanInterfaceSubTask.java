package xdoclet.jmx;

import xdoclet.SubTask;
import xdoclet.util.DocletUtil;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;
import com.sun.javadoc.ClassDoc;

import java.io.File;
import java.util.Date;
import java.util.StringTokenizer;

/**
 *  Generates MBean interface for JMX MBean.
 *
 * @author     Rickard Oberg (rickard@xpedio.com)
 * @created    September 4, 2001
 * @version    $Revision: 1.1 $
 */
public class MBeanInterfaceSubTask extends SubTask
{
	private static String DEFAULT_TEMPLATE_FILE = "mbean.j";

	public void execute() throws BuildException
	{
		Category cat = getCategory( MBeanInterfaceSubTask.class, "execute" );
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isMBean( classes[i] ) )
			{
				File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
				File beanFile = beanFile();

//				if( file.exists() )
//				{
//					// Check modification timestamps
//					if( file.lastModified() > beanFile.lastModified() )
//					{
//						cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
//						continue;
//					}
//				}

				System.out.println( "Create MBean Interface for:   " + getCurrentClass().toString() );
				generateFileUsingTemplate( javaFile( getGeneratedClassName() ), DEFAULT_TEMPLATE_FILE );
			}
		}
	}

	public String mbeanName()
	{
		return getMBeanName( getCurrentClass() );
	}

	protected String getMBeanName( ClassDoc clazz )
	{
		String bean_val = DocletUtil.getText( clazz, "jmx:mbean" );

		if( bean_val == null )
		{
			throw new BuildException( "@jmx:mbean class tag expected in class " + clazz.qualifiedName() + " but not found." );
		}

		String param_val = getParameterValue( bean_val, "name", -1 );

		if( param_val == null )
		{
			throw new BuildException( "'name' parameter of @jmx:mbean class tag expected in class " + clazz.qualifiedName() + " but not found." );
		}

		return param_val;
	}

	protected boolean isMBean( ClassDoc clazz )
	{
		return DocletUtil.hasTag( clazz, "jmx:mbean" );
	}

	protected String getGeneratedClassName()
	{
		return getCurrentClass() + "MBean";
	}

	protected File beanFile()
	{
		String tokenizedSourcePath = this.context.getSourcePath();
		StringTokenizer tok = new StringTokenizer( tokenizedSourcePath, File.pathSeparator );
		while( tok.hasMoreTokens() )
		{
			File f = new File( tok.nextToken(), javaFile( fullClassName() ) );
			if( f.lastModified() != 0 )
			{
				return f;
			}
		}
		throw new IllegalStateException( "Couldn't find bean " + fullClassName()
				 + "in sourcepath " + tokenizedSourcePath );
	}
}
