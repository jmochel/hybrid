package xdoclet.util;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import com.sun.javadoc.*;
import org.apache.log4j.Category;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 14, 2001
 * @version    $Revision: 1.5 $
 */
public final class DocletUtil
{
	/**
	 *  Convenience variable for printing and matching line separators in a system
	 *  portable manner.
	 */
	public final static String LINE_SEPARATOR = System.getProperty( "line.separator" );

	/**
	 *  char version of {@link #LINE_SEPARATOR}.
	 */
	public final static char LINE_SEPARATOR_CHAR = System.getProperty( "line.separator" ).charAt( 0 );

	public static String getText( Doc doc, String tagName )
	{
		return getText( doc, tagName, true );
	}

	public static String getText( Doc doc, String tagName, boolean superclasses )
	{
		Tag[] tags = null;

		if( doc instanceof ClassDoc )
		{
			tags = getTagsByName( ( ClassDoc ) doc, tagName, superclasses );
		}
		else if( doc instanceof MethodDoc )
		{
			tags = getTagsByName( ( MethodDoc ) doc, tagName );
		}
		else
		{
			throw new IllegalArgumentException( "doc argument passed to TemplateDoclet.getText is not of type ClassDoc or MethodDoc." );
		}

		if( tags != null && tags.length > 0 )
		{
			return getText( tags[0] );
		}
		else
		{
			return null;
		}
	}

	public static String getText( Tag tag )
	{
		String text = tag.text().trim();

		// To make tags separated in different lines work
		return text.replace( LINE_SEPARATOR_CHAR, ' ' );
	}

	public static Tag[] getTagsByName( MethodDoc method, String tag_name )
	{
		return method.tags( tag_name );
	}

	public static Tag[] getTagsByName( ClassDoc clazz, String tag_name )
	{
		return getTagsByName( clazz, tag_name, true );
	}

	public static Tag[] getTagsByName( ClassDoc clazz, String tag_name, boolean superclasses )
	{
		Category cat = getCategory( DocletUtil.class, "getTagsByName" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "Search for " + tag_name + " in " + clazz + " (look in superclasses=" + superclasses + ")" );
		}
		Tag[] tags = clazz.tags( tag_name );
		if( cat.isDebugEnabled() )
		{
			cat.debug( tags.length + " Tags Found" );
		}

		if( superclasses == true )
		{
			java.util.List tags_list = new ArrayList( Arrays.asList( tags ) );
			boolean found = false;

			clazz = clazz.superclass();
			while( clazz != null )
			{
				tags = clazz.tags( tag_name );

				for( int i = 0; i < tags.length; i++ )
				{
					// Do not add redundant tags (a tag defined exactly in base and
					// child). I have to do it manually because equals() is not
					// defined by javadoc's TagImpl!
					found = false;
					for( int j = 0; j < tags_list.size(); j++ )
					{
						if( tags_list.get( j ).toString().equals( tags[i].toString() ) )
						{
							found = true;
							break;
						}
					}

					if( !found )
					{
						tags_list.add( tags[i] );
					}
				}

				clazz = clazz.superclass();
			}

			return ( Tag[] ) tags_list.toArray( new Tag[0] );
		}
		else
		{
			return tags;
		}
	}

	public static boolean hasTag( Doc doc, String tag )
	{
		return hasTag( doc, tag, true );
	}

	public static boolean hasTag( Doc doc, String tag, boolean superclasses )
	{
		if( doc.tags( tag ).length > 0 )
		{
			return true;
		}
		else
		{
			if( superclasses == true )
			{
				while( doc != null && doc instanceof ClassDoc )
				{
					doc = ( ( ClassDoc ) doc ).superclass();

					if( doc != null && doc.tags( tag ).length > 0 )
					{
						return true;
					}
				}
			}

			return false;
		}
	}

	/**
	 *  Return an array of String from a String containing delimited values. For
	 *  example "a,b,c" will return a String[3] {"a","b","c"}.
	 *
	 * @param  delimited  the String value to tokenize
	 * @param  delimiter  the delimiter ("," or ";" for example)
	 * @return            an array of String delimited value
	 */
	public static String[] tokenizeDelimitedToArray( String delimited, String delimiter )
	{
		StringTokenizer st = new StringTokenizer( delimited, delimiter );
		String[] ret = new String[st.countTokens()];
		int i = 0;
		while( st.hasMoreTokens() )
		{
			ret[i++] = st.nextToken();
		}
		return ret;
	}

	/**
	 *  For now simply return the name as a Category
	 *
	 * @param  clazz  Description of Parameter
	 * @param  name   Description of Parameter
	 * @return        The Category value
	 */
	protected static Category getCategory( Class clazz, String name )
	{
		Category cat = Category.getInstance( clazz.getName() + "." + name );
		return cat;
	}

}
