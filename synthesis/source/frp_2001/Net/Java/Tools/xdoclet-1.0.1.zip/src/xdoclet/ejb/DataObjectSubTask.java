package xdoclet.ejb;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.lang.reflect.Modifier;
import java.beans.Introspector;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.*;
import xdoclet.util.serialveruid.ClassDocImpl;
import xdoclet.util.serialveruid.SerialVersionUidGenerator;
import xdoclet.util.serialveruid.FieldDocImpl;
import xdoclet.util.serialveruid.MethodDocImpl;
import xdoclet.util.serialveruid.ParameterImpl;
import xdoclet.util.serialveruid.TypeImpl;
import xdoclet.util.serialveruid.ConstructorDocImpl;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.9 $
 */
public class DataObjectSubTask extends AbstractEjbSubTask
{
	protected String   currentDataObjectClassname = "";
	protected static String DEFAULT_TEMPLATE_FILE = "dataobject.j";

	public void setPattern( String new_pattern )
	{
		dataObjectClassPattern = new_pattern;
	}

	public void isDataContentEquals( String pTemplate )
	{
		if( hasDataEquals( getCurrentClass() ) )
		{
			generate( pTemplate );
		}
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( DataObjectSubTask.class, "execute" );
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isEntity( getCurrentClass() ) )
			{
				if( hasDataContainer( getCurrentClass() ) )
				{
					if( hasCustomBulkData( getCurrentClass() ) )
					{
						// Don't make a new DataObject class; use the custom one instead
						Tag[] bdo = DocletUtil.getTagsByName( getCurrentClass(), "ejb:bulk-data" );
						StringTokenizer enum = new StringTokenizer( bdo[0].text(), " " );
						currentDataObjectClassname = enum.nextToken().trim();
						dataObjectClassnames.put( getCurrentClass().name(), currentDataObjectClassname );
					}
					else
					{
						currentDataObjectClassname = generateDataObjectClass();
						dataObjectClassnames.put( getCurrentClass().name(), currentDataObjectClassname );

						File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
						File beanFile = beanFile();

						if( file.exists() )
						{
							// Check modification timestamps
							if( file.lastModified() > beanFile.lastModified() )
							{
								cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
								continue;
							}
						}

						System.out.println( "Create Data Object for:        " + getCurrentClass().toString() );
						file.getParentFile().mkdirs();

						String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;
						generateFileUsingTemplate( javaFile( getGeneratedClassName() ), template_file_name );
					}
				}
			}
		}
	}

	public String parentDataObjectClass()
	{
		Category cat = getCategory( DataObjectSubTask.class, "parentDataObjectClass" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "Searching for @ejb:data-object in Current/Super Class " + getCurrentClass().name() );
		}
		if( DocletUtil.hasTag( getCurrentClass(), "ejb:data-object", false ) )
		{
			String extends_class = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object", false ), "extends", 0 );
			return extends_class != null ? extends_class : "java.lang.Object";
		}

		if( getCurrentClass().superclass() != null && isEjb( getCurrentClass().superclass() ) )
		{
			pushCurrentClass( getCurrentClass().superclass() );
			String clazz = dataObjectClass();
			popCurrentClass();
			if( clazz == null )
			{
				return "java.lang.Object";
			}
			return clazz;
		}
		else
		{
			return "java.lang.Object";
		}
	}

	public String serialVersionUID()
	{
		int modifiers = Modifier.PUBLIC;
		String class_name = getGeneratedClassName();
		int dot_pos = class_name.lastIndexOf( class_name );
		String qualifier = class_name.substring( 0, dot_pos );
		String name = class_name.substring( dot_pos );
		java.util.List[] docs = extractDocs( class_name );
		ClassDoc classdoc = new ClassDocImpl( modifiers, qualifier, name, docs[0], docs[1], docs[2] );

		return Long.toString( SerialVersionUidGenerator.computeSerialVersionUID( classdoc ) ) + "L";
	}

	protected String getGeneratedClassName()
	{
		return dataObjectClass();
	}

	protected boolean hasCustomBulkData( ClassDoc clazz )
	{
		Category cat = getCategory( DataObjectSubTask.class, "hasCustomBulkData" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "Searching @ejb:bulk-data in Class " + clazz );
		}
		return DocletUtil.hasTag( clazz, "ejb:bulk-data" );
	}

	/**
	 * @param  doc  Description of Parameter
	 * @return      True if there is a Data Container equals() needed because user
	 *      set tag "data-equals" to true or ommitted it
	 */
	protected boolean hasDataEquals( Doc doc )
	{
		Category cat = getCategory( DataObjectSubTask.class, "hasDataEquals" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "Searching @ejb:data-object equals for Class " + getCurrentClass().name() );
		}
		// When the tag is there and is set to "false" then return false
		if( DocletUtil.hasTag( getCurrentClass(), "ejb:data-object" ) )
		{
			String gen_equals = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object" ), "equals", 6 );

			if( gen_equals != null )
			{
				return !gen_equals.equalsIgnoreCase( "false" );
			}
			else
			{
				return true;
			}
		}
		else
		{
			//deprecated use ejb:data-object instead
			return !DocletUtil.hasTag( doc, "ejb:data-equals" ) || !DocletUtil.getText( doc, "ejb:data-equals" ).equals( "false" );
		}
	}

	private java.util.List[] extractDocs( String class_name )
	{
		Map foundFields = new HashMap();
		java.util.List ext_fields = new java.util.ArrayList();
		java.util.List ext_methods = new java.util.ArrayList();
		java.util.List ext_constructors = new java.util.ArrayList();
		ClassDoc cur_class = getCurrentClass();
		ArrayList full_constructor_params = new ArrayList();

		do
		{
			MethodDoc[] methods = cur_class.methods();

			for( int j = 0; j < methods.length; j++ )
			{
				if( isPersistentField( methods[j] ) && isGetter( methods[j].name() ) && !foundFields.containsKey( methods[j].name() ) )
				{
					// Store that we found this field so we don't add it twice
					foundFields.put( methods[j].name(), methods[j].name() );

					String field_name = Introspector.decapitalize( methodNameWithoutPrefix( methods[j] ) );

					if( isAggregate( methods[j] ) )
					{
						FieldDoc field = new FieldDocImpl( field_name, Modifier.PROTECTED, new TypeImpl( methods[j].returnType().typeName() + "Data" ) );
						ext_fields.add( field );

						//getter method
						ext_methods.add( new MethodDocImpl( methods[j].name(), Modifier.PUBLIC, new ParameterImpl[]{new ParameterImpl( new TypeImpl( methods[j].returnType().typeName() + "Data" ), field_name )}, methods[j].returnType() ) );
						//setter method
						ext_methods.add( new MethodDocImpl( "set" + methodNameWithoutPrefix( methods[j] ), Modifier.PUBLIC, new ParameterImpl[]{new ParameterImpl( new TypeImpl( methods[j].returnType().typeName() + "Data" ), field_name )}, new TypeImpl( "void" ) ) );
					}
					else
					{
						FieldDoc field = new FieldDocImpl( field_name, Modifier.PROTECTED, methods[j].returnType() );
						ext_fields.add( field );

						//getter method
						ext_methods.add( new MethodDocImpl( methods[j].name(), Modifier.PUBLIC, new ParameterImpl[0], methods[j].returnType() ) );
						//setter method
						ext_methods.add( new MethodDocImpl( "set" + methodNameWithoutPrefix( methods[j] ), Modifier.PUBLIC, new ParameterImpl[]{new ParameterImpl( methods[j].returnType(), field_name )}, new TypeImpl( "void" ) ) );
					}

					full_constructor_params.add( new ParameterImpl( methods[j].returnType(), field_name ) );
				}
			}

			// Add super class info
			cur_class = cur_class.superclass();
		}while ( cur_class != null );

		//fields:
		int modifiers = Modifier.STATIC | Modifier.FINAL;
		ext_fields.add( new FieldDocImpl( "serialVersionUID", modifiers, new TypeImpl( "long" ) ) );

		if( useSoftLocking( getCurrentClass() ) )
		{
			ext_fields.add( new FieldDocImpl( "_version", Modifier.PRIVATE, new TypeImpl( "long" ) ) );
		}

		//methods:
		if( hasDataEquals( getCurrentClass() ) )
		{
			ext_methods.add( new MethodDocImpl( "equals", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "Object", "", root.classNamed( "java.lang.Object" ) ) ) );
		}
		ext_methods.add( new MethodDocImpl( "toString", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "int" ) ) );

		if( useSoftLocking( getCurrentClass() ) )
		{
			ext_methods.add( new MethodDocImpl( "getVersion", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "long" ) ) );
			ext_methods.add( new MethodDocImpl( "setVersion", Modifier.PUBLIC, new ParameterImpl[]{new ParameterImpl( new TypeImpl( "long" ), "version" )}, new TypeImpl( "void" ) ) );
		}

		//constructors:
		modifiers = Modifier.PUBLIC;
		ext_constructors.add( new ConstructorDocImpl( class_name, modifiers, new ParameterImpl[0] ) );
		ext_constructors.add( new ConstructorDocImpl( class_name, modifiers, new ParameterImpl[]{new ParameterImpl( new TypeImpl( class_name ), "otherData" )} ) );
		ext_constructors.add( new ConstructorDocImpl( class_name, modifiers, ( ParameterImpl[] ) full_constructor_params.toArray( new ParameterImpl[0] ) ) );

		return new java.util.List[]{ext_fields, ext_methods, ext_constructors};
	}
}

