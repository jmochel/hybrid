package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class ParameterImpl implements com.sun.javadoc.Parameter
{
	com.sun.javadoc.Type type;
	java.lang.String   name;

	public ParameterImpl( com.sun.javadoc.Type type1, java.lang.String s )
	{
		type = type1;
		name = s;
	}

	public com.sun.javadoc.Type type()
	{
		return type;
	}

	public java.lang.String name()
	{
		return name;
	}

	public java.lang.String typeName()
	{
		return type.toString();
	}

	public java.lang.String toString()
	{
		return type.toString() + " " + name;
	}
}
