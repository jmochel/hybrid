package xdoclet.ejb;

import java.io.*;
import java.util.Date;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.*;

/**
 * @author     Vincent Harcq (vincent_harcq@yahoo.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.7 $
 */
public class SessionSubTask extends AbstractEjbSubTask
{
	protected static String DEFAULT_TEMPLATE_FILE = "session.j";

	public void setPattern( String new_pattern )
	{
		sessionClassPattern = new_pattern;
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( SessionSubTask.class, "execute" );
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isSession( getCurrentClass() ) )
			{
				File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
				File beanFile = beanFile();

				if( file.exists() )
				{
					// Check modification timestamps
					if( file.lastModified() > beanFile.lastModified() )
					{
						cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
						continue;
					}
				}

				System.out.println( "Create Session Class for:      " + getCurrentClass().toString() );
				file.getParentFile().mkdirs();

				String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;
				generateFileUsingTemplate( javaFile( getGeneratedClassName() ), template_file_name );
			}
		}
	}

	protected String getGeneratedClassName()
	{
		return sessionClass();
	}
}
