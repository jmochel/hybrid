package xdoclet.web;

import java.net.*;
import java.io.*;
import java.util.*;
import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;

/**
 *  Generates taglib.tld deployment descriptor for JSP taglibs.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 12, 2001
 * @version    $Revision: 1.6 $
 */
public class JspTaglibSubTask extends SubTask
{

	protected String   xmlEncoding = "UTF-8";

	protected String   taglibversion = "1.0";
	protected String   jspversion = "1.2";

	protected String   shortname = "";

	protected String   uri = "";

	protected String   displayname = "";
	protected String   smallicon = "";
	protected String   largeicon = "";
	protected String   description = "";
	private static String DEFAULT_TEMPLATE_FILE = "taglib_tld.j";
	private static String GENERATED_FILE_NAME = "taglib.tld";

	public void setXmlencoding( String xmlEncoding )
	{
		this.xmlEncoding = xmlEncoding;
	}

	public void setTaglibversion( String taglibversion )
	{
		this.taglibversion = taglibversion;
	}

	public void setJspversion( String jspversion )
	{
		this.jspversion = jspversion;
	}

	public void setShortname( String shortname )
	{
		this.shortname = shortname;
	}

	public void setUri( String uri )
	{
		this.uri = uri;
	}

	public void setDisplayname( String new_display_name )
	{
		displayname = new_display_name;
	}

	public void setSmallicon( String new_icon )
	{
		smallicon = new_icon;
	}

	public void setLargeicon( String new_icon )
	{
		largeicon = new_icon;
	}

	public void setDescription( String new_description )
	{
		description = new_description;
	}

	public String getXmlencoding()
	{
		return xmlEncoding;
	}

	public String getTaglibversion()
	{
		return taglibversion;
	}

	public String getJspversion()
	{
		return jspversion;
	}

	public String getShortname()
	{
		return shortname;
	}

	public String getUri()
	{
		return uri;
	}

	public String getDisplayname()
	{
		return displayname;
	}

	public String getSmallicon()
	{
		return smallicon;
	}

	public String getLargeicon()
	{
		return largeicon;
	}

	public String getDescription()
	{
		return description;
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( JspTaglibSubTask.class, "execute" );
		System.out.println( "Create " + GENERATED_FILE_NAME );
		generateFileUsingTemplate( GENERATED_FILE_NAME, DEFAULT_TEMPLATE_FILE );
	}

	/**
	 * @created    July 28, 2001
	 */
	public static class ContextParam implements java.io.Serializable
	{
		private String    paramName = null;
		private String    paramValue = null;
		private String    description = "";

		public void setName( String name )
		{
			paramName = name;
		}

		public void setValue( String value )
		{
			paramValue = value;
		}

		public void setDescription( String desc )
		{
			description = desc;
		}

		public String getName()
		{
			return paramName;
		}

		public String getValue()
		{
			return paramValue;
		}

		public String getDescription()
		{
			return description;
		}
	}

	/**
	 * @created    July 28, 2001
	 */
	public static class TagLib implements java.io.Serializable
	{
		private String    taglibURI = null;
		private String    taglibLocation = null;

		public void setURI( String uri )
		{
			taglibURI = uri;
		}

		public void setLocation( String location )
		{
			taglibLocation = location;
		}

		public String getURI()
		{
			return taglibURI;
		}

		public String getLocation()
		{
			return taglibLocation;
		}
	}
}
