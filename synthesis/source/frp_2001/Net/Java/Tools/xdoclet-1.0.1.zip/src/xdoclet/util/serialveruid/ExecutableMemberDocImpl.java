package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
class ExecutableMemberDocImpl extends xdoclet.util.serialveruid.MemberDocImpl implements com.sun.javadoc.ExecutableMemberDoc
{
	final xdoclet.util.serialveruid.ParameterImpl[] parameters;

	public ExecutableMemberDocImpl( String name, int modifiers, xdoclet.util.serialveruid.ParameterImpl[] parameters )
	{
		super( name, modifiers );

		this.parameters = parameters;
	}

	public boolean isNative()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isSynchronized()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ClassDoc[] thrownExceptions()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.Parameter[] parameters()
	{
		return parameters;
	}

	public com.sun.javadoc.ThrowsTag[] throwsTags()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.ParamTag[] paramTags()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String signature()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String flatSignature()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String toQualifiedString()
	{
		throw new UnsupportedOperationException();
	}
}
