package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
abstract class DocImpl implements com.sun.javadoc.Doc, java.lang.Comparable
{

	public void setRawCommentText( java.lang.String s )
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String getRawCommentText()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isField()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isMethod()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isConstructor()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isInterface()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isException()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isError()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isOrdinaryClass()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isClass()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String commentText()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.Tag[] tags()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.Tag[] tags( java.lang.String s )
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.SeeTag[] seeTags()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.Tag[] inlineTags()
	{
		throw new UnsupportedOperationException();
	}

	public com.sun.javadoc.Tag[] firstSentenceTags()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String toString()
	{
		return name();
	}

	public abstract java.lang.String name();

	public int compareTo( java.lang.Object obj )
	{
		throw new UnsupportedOperationException();
	}

}
