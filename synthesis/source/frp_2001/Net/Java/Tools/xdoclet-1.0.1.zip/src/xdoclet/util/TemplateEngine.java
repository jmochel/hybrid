package xdoclet.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.lang.reflect.*;
import java.util.*;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

/**
 *  The default template engine used by derived SubTasks. It looks for XML-ish
 *  <XDoclet:blabla>strings, just like JSP tag libraries. There's no support for
 *  scriptlets, because it's cleaner to use and implementing the XML-ish tags is
 *  easy, they are not heavyweight like jsp taglib implementations and there's
 *  no need for something like taglib.tld.
 *
 * @author     Rickard Oberg (rickard@dreambean.com)
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 14, 2001
 * @version    $Revision: 1.17 $
 * @see        #generate(java.lang.String)
 */
public abstract class TemplateEngine
{
	/**
	 *  The template file currently being processed.
	 */
	protected transient File templateFile = null;

	/**
	 *  The PrintWriter used for outputing the generated stuff.
	 *  xdoclet.util.PrettyPrintWriter tries to pretty format the generated file by
	 *  removing redundant spaces/lines.
	 *
	 * @see    xdoclet.util.PrettyPrintWriter
	 */
	protected transient PrettyPrintWriter out;

	/**
	 *  Where we are in the template file. Used for reporting errors.
	 */
	protected transient int currentLineNum = 0;

	/**
	 *  The current class stack is used for pushing/poping classes to/from it, so
	 *  that it's possible to work of the current class while not losing the
	 *  previous current class since template tags can be nested inside each other
	 *  and each may set a new class as the current class (by pushing the class to
	 *  top of stack).
	 *
	 * @see    #setCurrentClass()
	 * @see    #getCurrentClass()
	 * @see    #pushCurrentClass()
	 * @see    #popCurrentClass()
	 */
	private transient Stack currentClassStack = new Stack();

	/**
	 *  Reference to the current method. Unlike current class stack, there's no
	 *  stack for methods, because rarely you need to alter current method
	 *  reference nestedly.
	 *
	 * @see    #getCurrentMethod()
	 * @see    #setCurrentMethod()
	 */
	private transient MethodDoc currentMethod;

	/**
	 *  Reference to the current package. Unlike current class stack, there's no
	 *  stack for methods, because rarely you need to alter current package
	 *  reference nestedly.
	 *
	 * @see    #getCurrentPackage()
	 * @see    #setCurrentPackage()
	 */
	private transient PackageDoc currentPackage;

	/**
	 *  A config parameter settable from Ant build file. It sets the current
	 *  template file to templateFile, so thereafter the new template file is used.
	 *
	 * @param  templateFile  The new TemplateFile value
	 * @see                  #getTemplateFile()
	 */
	public void setTemplateFile( File templateFile )
	{
		this.templateFile = templateFile;
	}

	/**
	 *  Returns current template file.
	 *
	 * @return    The TemplateFile value
	 * @see       #setTemplateFile(java.io.File)
	 */
	public File getTemplateFile()
	{
		return templateFile;
	}

	/**
	 *  Sets current class to clazz by clearing currentClassStack stack and pushing
	 *  clazz into top of it.
	 *
	 * @param  clazz  The new CurrentClass value
	 * @see           #getCurrentClass()
	 */
	protected void setCurrentClass( ClassDoc clazz )
	{
		currentClassStack.clear();
		currentClassStack.push( clazz );
	}

	protected void setCurrentMethod( MethodDoc method )
	{
		currentMethod = method;
	}

	/**
	 *  Returns current package.
	 *
	 * @param  pakkage  The new CurrentPackage value
	 * @see             #setCurrentPackage(com.sun.javadoc.PackageDoc)
	 */
	protected void setCurrentPackage( PackageDoc pakkage )
	{
		currentPackage = pakkage;
		// since we're now working on a new package, clear the class stack
		currentClassStack.clear();
	}

	/**
	 *  Peeks and return the current class from top of currentClassStack stack.
	 *
	 * @return    The CurrentClass value
	 * @see       #setCurrentClass(com.sun.javadoc.ClassDoc)
	 */
	protected ClassDoc getCurrentClass()
	{
		try
		{
			return ( ClassDoc ) currentClassStack.peek();
		}
		catch( EmptyStackException e )
		{
			return null;
		}
	}

	/**
	 *  Returns current method.
	 *
	 * @return    The CurrentMethod value
	 * @see       #setCurrentMethod(com.sun.javadoc.MethodDoc)
	 */
	protected MethodDoc getCurrentMethod()
	{
		return currentMethod;
	}

	/**
	 *  Returns current package.
	 *
	 * @return    The CurrentPackage value
	 * @see       #setCurrentPackage(com.sun.javadoc.PackageDoc)
	 */
	protected PackageDoc getCurrentPackage()
	{
		return currentPackage;
	}

	/**
	 *  The main template parsing/processing/running logic. It searches for
	 *  <XDoclet: string, parses what is found after it till a matching</XDoclet:
	 *  is found in case of a block tag, or till a /> is found in case of a content
	 *  tag. It automatically calls the relevent tag implementation method with the
	 *  correct parameters. If a block tag, then the tag implementation accepts two
	 *  parameters, the body of the block tag as a string and a Properties object
	 *  containing all attributes. Note that if the tag doesn't have any attributes
	 *  the corresponding tag implementation typically only accepts a single string
	 *  value denoting the block body, though it can also accept a Properties as
	 *  the second parameter. Tags that may or may not have attributes can safely
	 *  accept the second Properties object, which will be filled either by nothing
	 *  or by all the given attributes. Content tag implementation methods have no
	 *  parameter but should return a String containing the result that should be
	 *  printed to the generated file. Tag implementation methods should define and
	 *  throw org.apache.tools.ant.BuildException if any serious error occurs.
	 *
	 * @param  template            Description of Parameter
	 * @exception  BuildException  Description of Exception
	 * @see                        #outputOf(java.lang.String)
	 */
	protected void generate( String template ) throws BuildException
	{
		Category cat = getCategory( TemplateEngine.class, "generate" );
		String XDOCLET_HEAD = "<XDoclet:";
		String XDOCLET_TAIL = "</XDoclet:";
		int index = 0;
		int prev_index = 0;
		int XDOCLET_HEAD_LEN = XDOCLET_HEAD.length();
		int XDOCLET_TAIL_LEN = XDOCLET_TAIL.length();
		int i = 0;

		while( true )
		{
			String cmd = "";

			index = template.indexOf( XDOCLET_HEAD, prev_index );

			if( index == -1 )
			{
				out.print( template.substring( prev_index ) );
				break;
			}
			else
			{
				out.print( template.substring( prev_index, index ) );

				i = index + XDOCLET_HEAD_LEN;

				boolean block = false;
				boolean has_atr = true;
				Properties attributes = new Properties();

				while( ( !Character.isWhitespace( template.charAt( i ) ) ) && template.charAt( i ) != '>' && template.charAt( i ) != '/' )
				{
					cmd += template.charAt( i );
					i++;
				}

				//cat.debug( "Found " + cmd + " ,line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );

				while( true )
				{
					if( template.charAt( i ) == '>' )
					{
						i++;
						has_atr = false;
						block = true;
						break;
					}
					else if( template.charAt( i ) == '/' )
					{
						i++;

						if( template.charAt( i ) == '>' )
						{
							i++;
							has_atr = false;
							block = false;
							break;
						}
						else
						{
							throw new BuildException( "Error in template file: > sign expected after / sign but something different found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
						}
					}
					else if( Character.isWhitespace( template.charAt( i ) ) )
					{
						i = skipWhitespace( template, i );
						continue;
					}
					else
					{
						has_atr = true;
						break;
					}
				}

				//has attributes, not obvious yet whether it's block or content element
				while( has_atr == true )
				{
					String attr_name = "";
					String attr_value = "";
					char qoute_char = '"';

					//read attribute name
					while( template.charAt( i ) != '=' && ( !Character.isWhitespace( template.charAt( i ) ) ) )
					{
						attr_name += template.charAt( i );
						i++;
					}

					i = skipWhitespace( template, i );

					//skip = sign
					if( template.charAt( i ) == '=' )
					{
						i++;
					}
					else
					{
						throw new BuildException( "Error in template file: = sign expected but something different found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
					}

					i = skipWhitespace( template, i );

					//skip " sign
					if( template.charAt( i ) == '"' )
					{
						i++;
						qoute_char = '"';
					}
					else if( template.charAt( i ) == '\'' )
					{
						i++;
						qoute_char = '\'';
					}
					else
					{
						throw new BuildException( "Error in template file: " + qoute_char + " sign expected but something different found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
					}

					//read attribute value
					while( template.charAt( i ) != qoute_char )
					{
						attr_value += template.charAt( i );
						i++;
					}

					//skip " sign
					i++;
					has_atr = true;

					if( attr_value.indexOf( XDOCLET_HEAD ) != -1 )
					{
						attr_value = outputOf( attr_value );
					}

					i = skipWhitespace( template, i );

					if( template.charAt( i ) == '>' )
					{
						i++;
						block = true;
						has_atr = false;
						//no more attributes
					}
					else if( template.charAt( i ) == '/' )
					{
						i++;

						if( template.charAt( i ) == '>' )
						{
							i++;
							block = false;
							has_atr = false;
							//no more attributes
						}
						else
						{
							throw new BuildException( "Error in template file: > sign expected after / sign but something different found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
						}
					}

					cat.debug( "Attribute " + attr_name + "=" + attr_value );
					attributes.setProperty( attr_name, attr_value );
				}

				if( block )
				{
					int open_nested_elem_count = 1;
					String new_body = "";
					int body_start_index = i;
					int body_end_index = -1;

					while( i < template.length() )
					{
						int from_index = i;
						body_end_index = template.indexOf( XDOCLET_TAIL + cmd, i );

						if( body_end_index == -1 )
						{
							throw new BuildException( "Error in template file: corresponding " + XDOCLET_TAIL + cmd + "/> not found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
						}
						else
						{
							open_nested_elem_count--;
						}

						// </XDoclet:cmd
						i = body_end_index + XDOCLET_TAIL_LEN + cmd.length();
						// skip spaces in </XDoclet:cmd   >
						i = skipWhitespace( template, i );
						// trailing >
						i++;

						int nested_start_index = template.indexOf( "XDoclet:" + cmd, from_index );
						//has nested elements with the same name, need to loop here for multiple nests.
						while( nested_start_index != -1 && nested_start_index < body_end_index )
						{
							if( template.charAt( nested_start_index - 1 ) == '<' )
							{
								// <XDoclet:blabla ...>
								open_nested_elem_count++;
							}
							else
							{
								throw new BuildException( "Error in template file: corresponding " + XDOCLET_TAIL + cmd + "/> not found, line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
							}
							nested_start_index = template.indexOf( "XDoclet:" + cmd, nested_start_index + 1 );
						}

						if( open_nested_elem_count == 0 )
						{
							break;
						}
					}

					new_body = template.substring( body_start_index, body_end_index );

					int prev_line_num = currentLineNum;
					int local_body_line_num = getLineNumber( template, body_start_index );
					currentLineNum += local_body_line_num;
					if( prev_line_num > 0 )
					{
						currentLineNum--;
					}

					invokeBlockMethod( cmd, new_body, attributes, template, i );

					currentLineNum = prev_line_num;
				}
				else
				{
					invokeContentMethod( cmd, attributes, template, i );
				}

				index = prev_index = i;
			}
		}

		out.flush();
	}

	/**
	 *  Calls generate() of the specified template content but instead of outputing
	 *  it to the generated file, it return the generated content. It's useful for
	 *  cases where you want to sythesize the result but use it instead of roughly
	 *  outputing it, for example it's used for the content tags nested inside an
	 *  attribute value such as: <XDoclet:blabla param1=" <XDoclet:aContentTag/>"/>
	 *  where we obviously don't want to output the result of aContentTag but use
	 *  it as the value of the param1 parameter.
	 *
	 * @param  template  Description of Parameter
	 * @return           Description of the Returned Value
	 * @see              #generate(java.lang.String)
	 */
	protected String outputOf( String template )
	{
		PrettyPrintWriter oldOut = out;
		ByteArrayOutputStream bout = new ByteArrayOutputStream();

		out = new PrettyPrintWriter( bout );
		generate( template );
		out.close();
		out = oldOut;

		return new String( bout.toByteArray() );
	}

	/**
	 *  Pushes class clazz to top of currentClassStack stack, making it effectively
	 *  the current class.
	 *
	 * @param  clazz  Description of Parameter
	 * @see           #getCurrentClass()
	 * @see           #setCurrentClass(com.sun.javadoc.ClassDoc)
	 * @see           #popCurrentClass()
	 */
	protected void pushCurrentClass( ClassDoc clazz )
	{
		currentClassStack.push( clazz );
	}

	/**
	 *  Popes current class from top currentClassStack stack. The poped class is no
	 *  longer the current class.
	 *
	 * @see    #getCurrentClass()
	 * @see    #setCurrentClass(com.sun.javadoc.ClassDoc)
	 * @see    #pushCurrentClass(com.sun.javadoc.ClassDoc)
	 */
	protected void popCurrentClass()
	{
		currentClassStack.pop();
	}

	/**
	 *  Invokes content tag implemenatation method named cmd. If first tries with
	 *  parameters params1, if not successul tries param2. This is used for cases
	 *  where it's not obvious whether the tag implementation methods expects a
	 *  Properties object or no parameter at all (the tag takes no attributes).
	 *
	 * @param  cmd                 Description of Parameter
	 * @param  params1             Description of Parameter
	 * @param  params2             Description of Parameter
	 * @param  template            Description of Parameter
	 * @param  i                   Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Description of Exception
	 * @see                        #invokeBlockMethod()
	 * @see                        #invokeContentMethod()
	 */
	private Object invokeMethod( String cmd, Object[] params1, Object[] params2, String template, int i ) throws BuildException
	{
		Category cat = getCategory( TemplateEngine.class, "invokeMethod" );
		try
		{
			Class[] param_types = new Class[params1.length];

			for( int j = 0; j < params1.length; j++ )
			{
				param_types[j] = params1[j].getClass();
			}

			Method m = getClass().getMethod( cmd, param_types );
			return m.invoke( this, params1 );
		}
		catch( InvocationTargetException e )
		{
			cat.error( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile(), e );
			throw new BuildException( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() + " ,exception: " + e.getMessage() );
		}
		catch( IllegalAccessException e )
		{
			cat.error( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile(), e );
			throw new BuildException( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() + " ,exception: " + e.getMessage() );
		}
		catch( NoSuchMethodException e )
		{
			Class[] param_types = new Class[params2.length];

			try
			{
				for( int j = 0; j < params2.length; j++ )
				{
					param_types[j] = params2[j].getClass();
				}

				Method m = getClass().getMethod( cmd, param_types );
				return m.invoke( this, params2 );
			}
			catch( InvocationTargetException e2 )
			{
				cat.error( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile(), e2 );
				throw new BuildException( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() + " ,exception: " + e.getMessage() );
			}
			catch( IllegalAccessException e2 )
			{
				cat.error( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile(), e2 );
				throw new BuildException( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() + " ,exception: " + e.getMessage() );
			}
			catch( NoSuchMethodException ex )
			{
				cat.error( "Invoking method failed: " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile(), ex );
				throw new BuildException( "Invoking method failed: Unknown command " + cmd + " , line=" + getLineNumber( template, i ) + " of template file: " + getTemplateFile() );
			}
		}
	}

	/**
	 *  Invokes block tag implemenatation method named cmd with the specified body
	 *  block and set of attributes.
	 *
	 * @param  cmd         Description of Parameter
	 * @param  block       Description of Parameter
	 * @param  attributes  Description of Parameter
	 * @param  template    Description of Parameter
	 * @param  i           Description of Parameter
	 * @see                #invokeMethod()
	 */
	private void invokeBlockMethod( String cmd, String block, Properties attributes, String template, int i )
	{

		Object[] params1 = null;
		Object[] params2 = null;

		//probable conditions
		if( attributes.size() > 0 )
		{
			params1 = new Object[]{block, attributes};
			params2 = new Object[]{block};
		}
		else
		{
			params1 = new Object[]{block};
			params2 = new Object[]{block, attributes};
		}

		invokeMethod( cmd, params1, params2, template, i );

	}

	/**
	 *  Invokes content tag implemenatation method named cmd with the specified set
	 *  of attributes. If attributes Properties object is not empty it tries to
	 *  find a method taking one prameter (Properties attributes), otherwise a
	 *  method with no parameter.
	 *
	 * @param  cmd         Description of Parameter
	 * @param  attributes  Description of Parameter
	 * @param  template    Description of Parameter
	 * @param  i           Description of Parameter
	 * @see                #invokeMethod()
	 */
	private void invokeContentMethod( String cmd, Properties attributes, String template, int i )
	{

		Object[] params1 = null;
		Object[] params2 = null;

		//probable conditions
		if( attributes.size() > 0 )
		{
			params1 = new Object[]{attributes};
			params2 = new Object[]{};
		}
		else
		{
			params1 = new Object[]{};
			params2 = new Object[]{attributes};
		}

		String result = ( String ) invokeMethod( cmd, params1, params2, template, i );

		if( result != null )
		{
			out.print( result );
		}

	}

	/**
	 *  Loops over the template content till reaching till_index index and returns
	 *  the number of lines it has encountered.
	 *
	 * @param  template    Description of Parameter
	 * @param  till_index  Description of Parameter
	 * @return             The LineNumber value
	 */
	protected static int getLineNumber( String template, int till_index )
	{
		int NL_LEN = DocletUtil.LINE_SEPARATOR.length();
		int index = 0;
		int line_num = 0;

		do
		{
			index = template.indexOf( DocletUtil.LINE_SEPARATOR, index );

			if( index != -1 )
			{
				line_num++;
				index += NL_LEN;
			}
			else
			{
				break;
			}
		}while ( index < till_index );

		return line_num;
	}

	/**
	 *  Returns an instance of log4j Category object. For now simply return the
	 *  classname+name as a Category.
	 *
	 * @param  clazz  Description of Parameter
	 * @param  name   Description of Parameter
	 * @return        The Category value
	 */
	protected static Category getCategory( Class clazz, String name )
	{
		return Category.getInstance( clazz.getName() + "." + name );
	}

	/**
	 *  Skips whitespaces, starting from inedx i till the first non-whitespace
	 *  character or end of template and returns the new index.
	 *
	 * @param  template  Description of Parameter
	 * @param  i         Description of Parameter
	 * @return           Description of the Returned Value
	 */
	protected static int skipWhitespace( String template, int i )
	{
		while( i < template.length() && Character.isWhitespace( template.charAt( i ) ) )
		{
			i++;
		}

		return i;
	}
}
