package xdoclet;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 19, 2001
 * @version    $Revision: 1.2 $
 */
public class DocletContext implements java.io.Serializable
{
	private String     sourcePath;
	private String     destDir;
	private String     mergeDir;
	private String     excludedTags;
	private SubTask[]  subTasks;

	public DocletContext( String sourcePath, String destDir, String mergeDir, String excludedTags, SubTask[] subTasks )
	{
		this.sourcePath = sourcePath;
		this.destDir = destDir;
		this.mergeDir = mergeDir;
		this.excludedTags = excludedTags;
		this.subTasks = subTasks;
	}

	public String getSourcePath()
	{
		return sourcePath;
	}

	public String getDestDir()
	{
		return destDir;
	}

	public String getMergeDir()
	{
		return mergeDir;
	}

	public String getExcludedTags()
	{
		if( excludedTags == null )
		{
			return "";
		}
		else
		{
			return excludedTags;
		}
	}

	public SubTask[] getSubTasks()
	{
		return subTasks;
	}

	public SubTask getSubTaskBy( String subtasks_name )
	{
		for( int i = 0; i < subTasks.length; i++ )
		{
			if( subTasks[i].getClass().getName().equals( subtasks_name ) )
			{
				return subTasks[i];
			}
		}

		return null;
	}
}
