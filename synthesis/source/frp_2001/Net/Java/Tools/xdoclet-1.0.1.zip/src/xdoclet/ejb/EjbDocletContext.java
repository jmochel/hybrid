package xdoclet.ejb;

import xdoclet.SubTask;
import xdoclet.DocletContext;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.2 $
 */
public final class EjbDocletContext extends DocletContext
{
	private String     ejbspec = null;

	public EjbDocletContext( String sourcePath, String destDir, String mergeDir, String ejbspec, String excludedTags, SubTask[] subTasks )
	{
		super( sourcePath, destDir, mergeDir, excludedTags, subTasks );

		this.ejbspec = ejbspec;
	}

	public String getEjbSpec()
	{
		return ejbspec;
	}
}
