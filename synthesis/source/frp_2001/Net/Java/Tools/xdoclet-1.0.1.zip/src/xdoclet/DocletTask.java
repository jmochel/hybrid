package xdoclet;

import java.util.*;
import java.io.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import com.sun.javadoc.*;
import xdoclet.ejb.EjbDocletContext;

/**
 *  A base class for all Tasks. It can also be used directly, useful for the
 *  case where you want to execute a template file but you don't want to bother
 *  writing a new task.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 19, 2001
 * @version    $Revision: 1.1 $
 */
public class DocletTask extends Task
{
	protected File     destDir;
	protected File     mergeDir;

	protected Path     sourcePath;
	protected Path     classpath;
	protected Reference classpathRef;

	protected Vector   filesets = new Vector();

	protected String   packageNames = null;
	protected String   excludePackageNames = null;
	protected String   excludedTags = null;

	protected Vector   templates = new Vector();

	public void setPackagenames( String src )
	{
		packageNames = src;
	}

	public void setExcludepackagenames( String src )
	{
		excludePackageNames = src;
	}

	public void setExcludedtags( String tags )
	{
		excludedTags = tags;
	}

	public void setDestdir( File dir )
	{
		destDir = dir;
	}

	public void setMergedir( File dir )
	{
		mergeDir = dir;
	}

	public void setSourcepath( Path src )
	{
		if( sourcePath == null )
		{
			sourcePath = src;
		}
		else
		{
			sourcePath.append( src );
		}
	}

	public void setClasspath( Path src )
	{
		if( classpath == null )
		{
			classpath = src;
		}
		else
		{
			classpath.append( src );
		}
	}

	public void setClasspathRef( org.apache.tools.ant.types.Reference ref )
	{
		this.classpathRef = ref;
		createClasspath().setRefid( ref );
	}

	/**
	 *  Create a nested <sourcepath ...>element for multiple source path support.
	 *
	 * @return    a nexted src element.
	 */
	public Path createSourcepath()
	{
		if( sourcePath == null )
		{
			sourcePath = new Path( project );
		}

		return sourcePath.createPath();
	}

	public Path createClasspath()
	{
		if( classpath == null )
		{
			classpath = new Path( project );
		}

		return classpath.createPath();
	}

	/**
	 *  Adds a set of files (nested fileset attribute).
	 *
	 * @param  set  The feature to be added to the Fileset attribute
	 */
	public void addFileset( FileSet set )
	{
		filesets.addElement( set );
	}

	/**
	 *  Adds a set of files (nested fileset attribute).
	 *
	 * @param  subtask  The feature to be added to the Template attribute
	 */
	public void addTemplate( TemplateSubTask subtask )
	{
		templates.addElement( subtask );
	}

	public void execute() throws BuildException
	{
		validateOptions();

		try
		{
			saveContext( getContext(), "DocletContext.edc" );
			createTask().execute();
		}
		catch( IOException ex )
		{
			throw new BuildException( "Running " + getTaskName() + " task failed. An IO error occured while writing context data." );
		}
	}

	protected Vector getSubTasks()
	{
		return templates;
	}

	protected DocletContext getContext()
	{
		Vector subtasks = getSubTasks();
		DocletContext context = new DocletContext( this.sourcePath.toString(), this.destDir.toString(),
				this.mergeDir != null ? this.mergeDir.toString() : null, this.excludedTags,
				( SubTask[] ) subtasks.toArray( new SubTask[0] ) );

		return context;
	}

	protected void validateOptions() throws BuildException
	{
		if( destDir == null )
		{
			throw new BuildException( "destDir attribute must be present.", location );
		}

		if( sourcePath == null )
		{
			throw new BuildException( "sourcePath attribute must be present.", location );
		}

		if( sourcePath.list().length == 0 )
		{
			throw new BuildException( "sourcePath attribute must be set!", location );
		}

		if( classpath == null )
		{
			classpath = org.apache.tools.ant.types.Path.systemClasspath;
		}

		if( ( packageNames == null && filesets.size() == 0 ) || ( packageNames != null && filesets.size() > 0 ) )
		{
			throw new BuildException( "Specify either packagenames attribute or nest a fileset to specify which files to be processed.", location );
		}
	}

	protected Javadoc createTask() throws BuildException
	{
		Javadoc javadoc = ( Javadoc ) project.createTask( "javadoc" );

		//javadoc.setVerbose(true);
		javadoc.setOwningTarget( this.getOwningTarget() );
		javadoc.setTaskName( this.getTaskName() );
		javadoc.setDescription( this.getDescription() );
		// set failOnError
		javadoc.setFailonerror( true );
		if( this.packageNames != null )
		{
			javadoc.setPackagenames( this.packageNames );
		}
		else if( filesets.size() > 0 )
		{
			String comma_sep_list = "";

			for( int i = 0; i < filesets.size(); i++ )
			{
				FileSet fs = ( FileSet ) filesets.elementAt( i );
				DirectoryScanner ds = fs.getDirectoryScanner( project );
				File from_dir = fs.getDir( project );
				String[] src_files = ds.getIncludedFiles();

				for( int j = 0; j < src_files.length; j++ )
				{
					File source_file = new File( from_dir + File.separator + src_files[j] );

					comma_sep_list += source_file.toString();
					comma_sep_list += ",";
				}
			}

			javadoc.setSourcefiles( comma_sep_list );
		}

		//\\javadoc.setExcludePackageNames( this.excludePackageNames );
		javadoc.setSourcepath( this.sourcePath );
		javadoc.setClasspath( this.classpath );
		javadoc.setClasspathRef( this.classpathRef );

		Javadoc.DocletInfo doclet = javadoc.createDoclet();
		doclet.setName( "xdoclet.DocletTask$DocletMain" );
		doclet.setPath( this.classpath );
		doclet.setPathRef( this.classpathRef );

		/*
		 * String path_str = this.getClass().getProtectionDomain().getCodeSource().getLocation().getFile().toString();
		 * if( path_str != null && path_str.startsWith( "/" ) )
		 * {
		 * it always begins with a / in front of it!!!
		 * path_str = path_str.substring( 1 );
		 * }
		 * doclet.createPath().setPath( path_str );
		 */

		return javadoc;
	}

	protected void saveContext( DocletContext context, String file_name ) throws java.io.IOException
	{
		FileOutputStream fos = new FileOutputStream( System.getProperty( "java.io.tmpdir" ) + File.separator + file_name );
		ObjectOutputStream oos = new ObjectOutputStream( new BufferedOutputStream( fos ) );

		oos.writeObject( context );
		oos.flush();
		fos.close();
	}

	/**
	 * @author     Ara Abrahamian (ara_e@email.com)
	 * @created    April 30, 2001
	 */
	public final static class DocletMain
	{
		public static boolean start( RootDoc root )
		{
			try
			{
				DocletContext context = loadContext();

				SubTask[] subtasks = context.getSubTasks();

				for( int i = 0; i < subtasks.length; i++ )
				{
					if( subtasks[i] != null )
					{
						subtasks[i].init( context, root );
						subtasks[i].execute();
					}
				}

				return true;
			}
			catch( IOException e )
			{
				System.out.println( "Running XDoclet failed. An IO error occured while reading context data." );

				return false;
			}
			catch( BuildException e )
			{
				System.out.println( "Running XDoclet failed:" );
				System.out.println( e );

				return false;
			}
		}

		private static DocletContext loadContext() throws IOException
		{
			File file = new File( System.getProperty( "java.io.tmpdir" ) + File.separator + "DocletContext.edc" );
			FileInputStream fis = new FileInputStream( file );
			ObjectInputStream ois = new ObjectInputStream( new BufferedInputStream( fis ) );
			DocletContext context = null;

			try
			{
				context = ( DocletContext ) ois.readObject();
			}
			catch( ClassNotFoundException e )
			{
				throw new BuildException( "Running XDoclet failed. A needed class was not found. Configure classpath of XDoclet task properly." );
			}

			fis.close();
			file.delete();

			return context;
		}
	}
}
