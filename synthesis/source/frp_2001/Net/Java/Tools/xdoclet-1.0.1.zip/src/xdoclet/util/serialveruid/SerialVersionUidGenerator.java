package xdoclet.util.serialveruid;

import com.sun.javadoc.*;

import java.util.Comparator;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.lang.reflect.Modifier;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.DigestOutputStream;
import java.security.NoSuchAlgorithmException;

/*
 * @author  Ara Abrahamian ara_e@email.com
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class SerialVersionUidGenerator
{
	/*
	 * Comparator object for Classes and Interfaces
	 */
	private static Comparator compareClassByName = new CompareClassByName();

	/*
	 * Comparator object for Members, Fields, and Methods
	 */
	private static Comparator compareMemberByName = new CompareMemberByName();

	/*
	 * Compute a hash for the specified class.  Incrementally add
	 * items to the hash accumulating in the digest stream.
	 * Fold the hash into a long.  Use the SHA secure hash function.
	 */
	public static long computeSerialVersionUID( ClassDoc cl )
	{
		ByteArrayOutputStream devnull = new ByteArrayOutputStream( 512 );
		long h = 0;

		try
		{
			MessageDigest md = MessageDigest.getInstance( "SHA" );
			DigestOutputStream mdo = new DigestOutputStream( devnull, md );
			DataOutputStream data = new DataOutputStream( mdo );

			data.writeUTF( cl.name() );

			int classaccess = cl.modifierSpecifier();
			classaccess &= ( Modifier.PUBLIC | Modifier.FINAL | Modifier.INTERFACE | Modifier.ABSTRACT );

			/*
			 * Workaround for javac bug that only set ABSTRACT for
			 * interfaces if the interface had some methods.
			 * The ABSTRACT bit reflects that the number of methods > 0.
			 * This is required so correct hashes can be computed
			 * for existing class files.
			 * Previously this hack was previously present in the VM.
			 */
			MethodDoc[] method = cl.methods();
			if( ( classaccess & Modifier.INTERFACE ) != 0 )
			{
				classaccess &= ( ~Modifier.ABSTRACT );
				if( method.length > 0 )
				{
					classaccess |= Modifier.ABSTRACT;
				}
			}

			data.writeInt( classaccess );

			/*
			 * Get the list of interfaces supported,
			 * Accumulate their names in Lexical order
			 * and add them to the hash
			 */
			if( !cl.dimension().equals( "" ) )
			{
				// !cl.isArray()

				/*
				 * In 1.2fcs, getInterfaces() was modified to return
				 * {java.lang.Cloneable, java.io.Serializable} when
				 * called on array classes.  These values would upset
				 * the computation of the hash, so we explicitly omit
				 * them from its computation.
				 */
				ClassDoc interfaces[] = cl.interfaces();
				Arrays.sort( interfaces, compareClassByName );

				for( int i = 0; i < interfaces.length; i++ )
				{
					data.writeUTF( "L" + interfaces[i].qualifiedName() );
				}
			}

			/*
			 * Sort the field names to get a deterministic order
			 */
			FieldDoc[] field = cl.fields();
			Arrays.sort( field, compareMemberByName );

			for( int i = 0; i < field.length; i++ )
			{
				FieldDoc f = field[i];

				/*
				 * Include in the hash all fields except those that are
				 * private transient and private static.
				 */
				int m = f.modifierSpecifier();
				if( Modifier.isPrivate( m ) && ( Modifier.isTransient( m ) || Modifier.isStatic( m ) ) )
				{
					continue;
				}

				data.writeUTF( f.name() );
				data.writeInt( m );
				data.writeUTF( getSignature( f.type().qualifiedTypeName(), f.type().asClassDoc(), f.type().dimension() ) );
			}

			/*
			 * if( hasStaticInitializer( cl ) )
			 * {
			 * data.writeUTF( "<clinit>" );
			 * data.writeInt( Modifier.STATIC ); // TBD: what modifiers does it have
			 * data.writeUTF( "()V" );
			 * }
			 */

			/*
			 * Get the list of constructors including name and signature
			 * Sort lexically, add all except the private constructors
			 * to the hash with their access flags
			 */
			MethodSignature[] constructors = MethodSignature.removePrivateAndSort( cl.constructors() );
			for( int i = 0; i < constructors.length; i++ )
			{
				MethodSignature c = constructors[i];
				String mname = "<init>";
				String desc = c.signature;
				desc = desc.replace( '/', '.' );
				data.writeUTF( mname );
				data.writeInt( c.member.modifierSpecifier() );
				data.writeUTF( desc );
			}

			/*
			 * Include in the hash all methods except those that are
			 * private transient and private static.
			 */
			MethodSignature[] methods = MethodSignature.removePrivateAndSort( method );
			for( int i = 0; i < methods.length; i++ )
			{
				MethodSignature m = methods[i];
				String desc = m.signature;
				desc = desc.replace( '/', '.' );
				data.writeUTF( m.member.qualifiedName() );
				data.writeInt( m.member.modifierSpecifier() );
				data.writeUTF( desc );
			}

			/*
			 * Compute the hash value for this class.
			 * Use only the first 64 bits of the hash.
			 */
			data.flush();
			byte hasharray[] = md.digest();
			for( int i = 0; i < Math.min( 8, hasharray.length ); i++ )
			{
				h += ( long ) ( hasharray[i] & 255 ) << ( i * 8 );
			}
		}
		catch( IOException ignore )
		{
			/*
			 * can't happen, but be deterministic anyway.
			 */
			h = -1;
		}
		catch( NoSuchAlgorithmException complain )
		{
			throw new SecurityException( complain.getMessage() );
		}

		return h;
	}

	/**
	 *  Compute the JVM signature for the class.
	 *
	 * @param  type_name  Description of Parameter
	 * @param  clazz      Description of Parameter
	 * @param  dimension  Description of Parameter
	 * @return            The Signature value
	 */
	static String getSignature( String type_name, ClassDoc clazz, String dimension )
	{
		String type = null;
		boolean is_array = dimension.equals( "" );

		if( is_array )
		{
			// clazz.isArray()

			ClassDoc cl = clazz;
			int dimensions = 0;

			StringTokenizer dimensions_st = new StringTokenizer( dimension, "[", true );
			while( dimensions_st.hasMoreTokens() )
			{
				dimensions_st.nextToken();
				dimensions++;
			}

			StringBuffer sb = new StringBuffer();
			for( int i = 0; i < dimensions; i++ )
			{
				sb.append( "[" );
			}
			sb.append( type_name );
			type = sb.toString();
		}
		else if( clazz == null )
		{
			//clazz.isPrimitive()

			if( type_name.equals( "int" ) )
			{
				type = "I";
			}
			else if( type_name.equals( "byte" ) )
			{
				type = "B";
			}
			else if( type_name.equals( "long" ) )
			{
				type = "J";
			}
			else if( type_name.equals( "float" ) )
			{
				type = "F";
			}
			else if( type_name.equals( "double" ) )
			{
				type = "D";
			}
			else if( type_name.equals( "short" ) )
			{
				type = "S";
			}
			else if( type_name.equals( "char" ) )
			{
				type = "C";
			}
			else if( type_name.equals( "boolean" ) )
			{
				type = "Z";
			}
			else if( type_name.equals( "void" ) )
			{
				type = "V";
			}
			else
			{
				type = "V";
			}
		}
		else
		{
			type = "L" + clazz.qualifiedName().replace( '.', '/' ) + ";";
		}

		return type;
	}

	/*
	 * Compute the JVM method descriptor for the method.
	 */
	static String getSignature( MethodDoc meth )
	{
		StringBuffer sb = new StringBuffer();

		sb.append( "(" );

		Parameter[] params = meth.parameters();
		// avoid clone
		for( int j = 0; j < params.length; j++ )
		{
			Parameter param = params[j];

			sb.append( getSignature( param.type().qualifiedTypeName(), param.type().asClassDoc(), param.type().dimension() ) );
		}
		sb.append( ")" );

		Type ret = meth.returnType();

		sb.append( getSignature( ret.qualifiedTypeName(), ret.asClassDoc(), ret.dimension() ) );
		return sb.toString();
	}

	/*
	 * Compute the JVM constructor descriptor for the constructor.
	 */
	static String getSignature( ConstructorDoc cons )
	{
		StringBuffer sb = new StringBuffer();

		sb.append( "(" );

		Parameter[] params = cons.parameters();
		// avoid clone

		for( int j = 0; j < params.length; j++ )
		{
			Parameter param = params[j];

			sb.append( getSignature( param.type().qualifiedTypeName(), param.type().asClassDoc(), param.type().dimension() ) );
		}
		sb.append( ")V" );
		return sb.toString();
	}

	/**
	 * @created    August 21, 2001
	 */
	private static class CompareClassByName implements Comparator
	{
		public int compare( Object o1, Object o2 )
		{
			Class c1 = ( Class ) o1;
			Class c2 = ( Class ) o2;
			return ( c1.getName() ).compareTo( c2.getName() );
		}
	}

	/**
	 * @created    August 21, 2001
	 */
	private static class CompareMemberByName implements Comparator
	{
		public int compare( Object o1, Object o2 )
		{
			String s1 = ( ( MemberDoc ) o1 ).qualifiedName();
			String s2 = ( ( MemberDoc ) o2 ).qualifiedName();

			if( o1 instanceof MethodDoc )
			{
				s1 += getSignature( ( MethodDoc ) o1 );
				s2 += getSignature( ( MethodDoc ) o2 );
			}
			else if( o1 instanceof ConstructorDoc )
			{
				s1 += getSignature( ( ConstructorDoc ) o1 );
				s2 += getSignature( ( ConstructorDoc ) o2 );
			}
			return s1.compareTo( s2 );
		}
	}

	/*
	 * It is expensive to recompute a method or constructor signature
	 * many times, so compute it only once using this data structure.
	 */
	/**
	 * @created    August 21, 2001
	 */
	private static class MethodSignature implements Comparator
	{
		MemberDoc         member;
		String            signature;

		private MethodSignature( MemberDoc m )
		{
			member = m;
			if( isConstructor() )
			{
				signature = SerialVersionUidGenerator.getSignature( ( ConstructorDoc ) m );
			}
			else
			{
				signature = SerialVersionUidGenerator.getSignature( ( MethodDoc ) m );
			}
		}

		/*
		 * Assumes that o1 and o2 are either both methods
		 * or both constructors.
		 */
		public int compare( Object o1, Object o2 )
		{
			/*
			 * Arrays.sort calls compare when o1 and o2 are equal.
			 */
			if( o1 == o2 )
			{
				return 0;
			}

			MethodSignature c1 = ( MethodSignature ) o1;
			MethodSignature c2 = ( MethodSignature ) o2;

			int result;
			if( isConstructor() )
			{
				result = c1.signature.compareTo( c2.signature );
			}
			else
			{
				// is a Method.
				result = c1.member.qualifiedName().compareTo( c2.member.qualifiedName() );
				if( result == 0 )
				{
					result = c1.signature.compareTo( c2.signature );
				}
			}

			return result;
		}

		private boolean isConstructor()
		{
			return member instanceof ConstructorDoc;
		}
		// cached parameter signature

		/*
		 * Given an array of Method or Constructor members,
		 * return a sorted array of the non-private members.
		 */
		/*
		 * A better implementation would be to implement the returned data
		 * structure as an insertion sorted link list.
		 */
		static MethodSignature[] removePrivateAndSort( MemberDoc[] m )
		{
			int numNonPrivate = 0;

			for( int i = 0; i < m.length; i++ )
			{
				if( !Modifier.isPrivate( m[i].modifierSpecifier() ) )
				{
					numNonPrivate++;
				}
			}

			MethodSignature[] cm = new MethodSignature[numNonPrivate];
			int cmi = 0;

			for( int i = 0; i < m.length; i++ )
			{
				if( !Modifier.isPrivate( m[i].modifierSpecifier() ) )
				{
					cm[cmi] = new MethodSignature( m[i] );
					cmi++;
				}
			}

			if( cmi > 0 )
			{
				Arrays.sort( cm, cm[0] );
			}

			return cm;
		}
	}
}
