package xdoclet;

import xdoclet.SubTask;
import org.apache.tools.ant.BuildException;

/**
 *  Generates The template file specified in templateFile configuration
 *  parameter.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    Sep 25, 2001
 * @version    $Revision: 1.1 $
 */
public class TemplateSubTask extends SubTask
{
	protected String   destinationFile = null;

	public void setDestinationfile( String destinationFile )
	{
		this.destinationFile = destinationFile;
	}

	public String getDestinationfile()
	{
		return destinationFile;
	}

	public void execute() throws BuildException
	{
		if( getTemplateFile() != null && getDestinationfile() != null )
		{
			System.out.println( "Generating '" + getDestinationfile() + "' using template file '" + getTemplateFile() + "'" );
			generateFileUsingTemplate( getDestinationfile(), getTemplateFile().toString() );
		}
		else
		{
			System.out.println( "Specify both destinationfile and templatefile configuration parameters please." );
		}
	}
}
