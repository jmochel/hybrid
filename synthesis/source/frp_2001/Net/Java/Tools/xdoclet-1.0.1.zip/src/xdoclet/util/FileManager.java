package xdoclet.util;

import java.util.Map;
import java.util.HashMap;
import java.io.File;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;

/**
 *  A utility class for handling common filing operations. It also caches loaded
 *  files.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    Aug 5, 2001
 * @version    $Revision: 1.1 $
 */
public final class FileManager
{
	private static Map fileCache = new HashMap();

	public static synchronized String getFileContent( String file_name, Class clazz )
	{
		String content = ( String ) fileCache.get( file_name );

		if( content != null )
		{
			return content;
		}

		try
		{
			File template_file = new File( file_name );
			java.io.InputStream in = null;

			if( template_file.exists() )
			{
				in = new BufferedInputStream( new FileInputStream( template_file ) );
			}
			else
			{
				in = clazz.getResourceAsStream( file_name );
			}

			if( in == null )
			{
				return null;
			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream( in.available() );
			byte[] b = new byte[in.available()];
			int len;

			while( ( len = in.read( b ) ) != -1 )
			{
				baos.write( b, 0, len );
			}

			content = new String( baos.toByteArray() );
			fileCache.put( file_name, content );

			return content;
		}
		catch( Exception e )
		{
			System.err.println( "Exception while reading from merge file." + e );
			return null;
		}
	}
}
