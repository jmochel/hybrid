package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
abstract class MemberDocImpl extends xdoclet.util.serialveruid.ProgramElementDocImpl implements com.sun.javadoc.MemberDoc
{
	java.lang.String   name;

	public MemberDocImpl( String name, int modifiers )
	{
		super( modifiers );

		this.name = name;
	}

	public boolean isIncluded()
	{
		throw new UnsupportedOperationException();
	}

	public boolean isSynthetic()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String qualifiedName()
	{
		return name();
	}

	public java.lang.String name()
	{
		return name;
	}

	public com.sun.javadoc.PackageDoc containingPackage()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String toString()
	{
		return name();
	}
}
