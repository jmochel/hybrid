package xdoclet.doc;

import xdoclet.SubTask;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

/**
 *  Extracts doc:blabla tags from ejbdoclet.* sources and generates an html file
 *  describing the tags and their parameters using a document.j file. Currently
 *  there is no configurable parameter for this subtask.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 19, 2001
 * @version    $Revision: 1.6 $
 */
public class DocumentTagsSubTask extends SubTask
{
	private static String DEFAULT_TEMPLATE_FILE = "templates_html.j";
	private static String GENERATED_FILE_NAME = "templates.html";

	private static String DEFAULT_TOC_TEMPLATE_FILE = "templates_toc_html.j";
	private static String GENERATED_TOC_FILE_NAME = "templates_toc.html";

	public void execute() throws BuildException
	{
		Category cat = getCategory( DocumentTagsSubTask.class, "execute" );
		System.out.println( "Create " + GENERATED_FILE_NAME );
		generateFileUsingTemplate( GENERATED_FILE_NAME, DEFAULT_TEMPLATE_FILE );

		System.out.println( "Create " + GENERATED_TOC_FILE_NAME );
		generateFileUsingTemplate( GENERATED_TOC_FILE_NAME, DEFAULT_TOC_TEMPLATE_FILE );
	}
}
