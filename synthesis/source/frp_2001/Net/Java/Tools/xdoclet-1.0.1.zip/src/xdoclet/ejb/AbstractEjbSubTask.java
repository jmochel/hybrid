package xdoclet.ejb;

import java.beans.Introspector;
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;
import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;

import xdoclet.*;
import xdoclet.util.*;
import org.apache.log4j.Category;

/**
 *  The abstract base class for all subtasks that work with EJBs. All EJB
 *  related template tags are imeplemnted here.
 *
 * @author     Rickard Oberg (rickard@dreambean.com)
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    May 4, 2001
 * @version    $Revision: 1.39 $
 */
public abstract class AbstractEjbSubTask extends SubTask
{
	/**
	 *  The EJB specification version to use. The generated files will be
	 *  compatible with the version specified.
	 *
	 * @see    #setEjbspec(java.lang.String)
	 * @see    #getEjbspec()
	 */
	protected String   ejbspec = null;

	/**
	 *  The current security role name, set by forAllSecurityRoles and returned by
	 *  securityRoleName. It somehow is like the current index for the
	 *  forAllSecurityRoles loop.
	 *
	 * @see    #forAllSecurityRoles(java.lang.String)
	 * @see    #securityRoleName()
	 */
	protected transient String currentSecurityRoleName;

	/**
	 *  The current relation, set by forAllRelationships and used by
	 *  forAllRelationshipRoles. It somehow is like the current index for the
	 *  forAllRelationships loop.
	 *
	 * @see    #forAllRelationships(java.lang.String)
	 * @see    #forAllRelationshipRoles(java.lang.String)
	 */
	protected transient RelationHolder curRelation;

	protected Hashtable relationSet = new Hashtable();

	/**
	 *  The id of the EJB referencing another EJB, used for setting up a correct
	 *  unique id for the ejb-ref.
	 *
	 * @see    #ejbRefId()
	 * @see    #forAllEjbRefs(java.lang.String,java.util.Properties)
	 * @see    #storeReferringClassId()
	 */
	protected transient String referringClassId;

	protected static HashMap dataObjectClassnames = new HashMap();

	/**
	 *  A configuration parameter for specifying the remote interface name pattern.
	 *  By default the value is used for deciding the remote interface name. {0} in
	 *  the value mean current class's symbolic name which for an EJBean is the EJB
	 *  name.
	 *
	 * @see    #getRemoteClassPattern()
	 */
	protected static String remoteClassPattern;

	/**
	 *  A configuration parameter for specifying the local interface name pattern.
	 *  By default the value is used for deciding the local interface name. {0} in
	 *  the value mean current class's symbolic name which for an EJBean is the EJB
	 *  name.
	 *
	 * @see    #getLocalClassPattern()
	 */
	protected static String localClassPattern;

	/**
	 *  A configuration parameter for specifying the home interface name pattern.
	 *  By default the value is used for deciding the home interface name. {0} in
	 *  the value mean current class's symbolic name which for an EJBean is the EJB
	 *  name.
	 *
	 * @see    #getHomeClassPattern()
	 */
	protected static String homeClassPattern;

	/**
	 *  A configuration parameter for specifying the local home interface name
	 *  pattern. By default the value is used for deciding the local home interface
	 *  name. {0} in the value mean current class's symbolic name which for an
	 *  EJBean is the EJB name.
	 *
	 * @see    #getLocalHomeClassPattern()
	 */
	protected static String localHomeClassPattern;

	/**
	 *  A configuration parameter for specifying the entity bean primary class name
	 *  pattern. By default the value is used for deciding the entity bean primary
	 *  class name. {0} in the value mean current class's symbolic name which for
	 *  an EJBean is the EJB name.
	 *
	 * @see    #getEntityPkClassPattern()
	 */
	protected static String entityPkClassPattern;

	/**
	 *  A configuration parameter for specifying the data object class name
	 *  pattern. By default the value is used for deciding the entity data object
	 *  class name. {0} in the value mean current class's symbolic name which for
	 *  an EJBean is the EJB name.
	 *
	 * @see    #getDataObjectClassPattern()
	 */
	protected static String dataObjectClassPattern;

	/**
	 *  A configuration parameter for specifying the concrete BMP entity bean class
	 *  name pattern. By default the value is used for deciding the concrete BMP
	 *  entity bean class name. {0} in the value mean current class's symbolic name
	 *  which for an EJBean is the EJB name.
	 *
	 * @see    #getEntityBmpClassPattern()
	 */
	protected static String entityBmpClassPattern;

	/**
	 *  A configuration parameter for specifying the concrete CMP entity bean class
	 *  name pattern. By default the value is used for deciding the concrete CMP
	 *  entity bean class name. {0} in the value mean current class's symbolic name
	 *  which for an EJBean is the EJB name.
	 *
	 * @see    #getEntityCmpClassPattern()
	 */
	protected static String entityCmpClassPattern;

	/**
	 *  A configuration parameter for specifying the concrete session bean class
	 *  name pattern. By default the value is used for deciding the concrete
	 *  session bean class name. {0} in the value mean current class's symbolic
	 *  name which for an EJBean is the EJB name.
	 *
	 * @see    #getEntityBmpClassPattern()
	 */
	protected static String sessionClassPattern;

	/**
	 *  Sets which EJB specification version to use. The generated files will be
	 *  compatible with the version specified.
	 *
	 * @param  spec  The new EjbSpec value
	 * @see          #ejbspec
	 * @see          #getEjbspec()
	 */
	public void setEjbspec( String spec )
	{
		ejbspec = spec;
	}

	/**
	 *  Returns the EJB specification version used. The generated files will be
	 *  compatible with the version specified.
	 *
	 * @return    The Ejbspec value
	 * @see       #ejbspec
	 * @see       #setEjbspec(java.lang.String)
	 */
	public String getEjbspec()
	{
		return ejbspec;
	}

	/**
	 *  Returns the configuration parameter for specifying the remote interface
	 *  name pattern. By default the value is used for deciding the remote
	 *  interface name. {0} in the value mean current class's symbolic name which
	 *  for an EJBean is the EJB name. If nothing explicitly specified by user then
	 *  "{0}" is used by default.
	 *
	 * @return    The RemoteClassPattern value
	 * @see       #remoteClassPattern
	 */
	public String getRemoteClassPattern()
	{
		if( remoteClassPattern != null )
		{
			return remoteClassPattern;
		}
		else
		{
			return "{0}";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the local interface name
	 *  pattern. By default the value is used for deciding the local interface
	 *  name. {0} in the value mean current class's symbolic name which for an
	 *  EJBean is the EJB name. If nothing explicitly specified by user then
	 *  "{0}Local" is used by default.
	 *
	 * @return    The LocalClassPattern value
	 * @see       #localClassPattern
	 */
	public String getLocalClassPattern()
	{
		if( localClassPattern != null )
		{
			return localClassPattern;
		}
		else
		{
			return "{0}Local";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the home interface name
	 *  pattern. By default the value is used for deciding the home interface name.
	 *  {0} in the value mean current class's symbolic name which for an EJBean is
	 *  the EJB name. If nothing explicitly specified by user then "{0}Home" is
	 *  used by default.
	 *
	 * @return    The HomeClassPattern value
	 * @see       #homeClassPattern
	 */
	public String getHomeClassPattern()
	{
		if( homeClassPattern != null )
		{
			return homeClassPattern;
		}
		else
		{
			return "{0}Home";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the local home interface
	 *  name pattern. By default the value is used for deciding the local home
	 *  interface name. {0} in the value mean current class's symbolic name which
	 *  for an EJBean is the EJB name. If nothing explicitly specified by user then
	 *  "{0}LocalHome" is used by default.
	 *
	 * @return    The LocalHomeClassPattern value
	 * @see       #localHomeClassPattern
	 */
	public String getLocalHomeClassPattern()
	{
		if( localHomeClassPattern != null )
		{
			return localHomeClassPattern;
		}
		else
		{
			return "{0}LocalHome";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the entity bean primary
	 *  class name pattern. By default the value is used for deciding the entity
	 *  bean primary class name. {0} in the value mean current class's symbolic
	 *  name which for an EJBean is the EJB name. If nothing explicitly specified
	 *  by user then "{0}PK" is used by default.
	 *
	 * @return    The EntityPkClassPattern value
	 * @see       #entityPkClassPattern
	 */
	public String getEntityPkClassPattern()
	{
		if( entityPkClassPattern != null )
		{
			return entityPkClassPattern;
		}
		else
		{
			return "{0}PK";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the data object class
	 *  name pattern. By default the value is used for deciding the entity data
	 *  object class name. {0} in the value mean current class's symbolic name
	 *  which for an EJBean is the EJB name. If nothing explicitly specified by
	 *  user then "{0}Data" is used by default.
	 *
	 * @return    The DataObjectClassPattern value
	 * @see       #dataObjectClassPattern
	 */
	public String getDataObjectClassPattern()
	{
		if( dataObjectClassPattern != null )
		{
			return dataObjectClassPattern;
		}
		else
		{
			return "{0}Data";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the concrete BMP entity
	 *  bean class name pattern. By default the value is used for deciding the
	 *  concrete BMP entity bean class name. {0} in the value mean current class's
	 *  symbolic name which for an EJBean is the EJB name. If nothing explicitly
	 *  specified by user then "{0}BMP" is used by default.
	 *
	 * @return    The EntityBmpClassPattern value
	 * @see       #entityBmpClassPattern
	 */
	public String getEntityBmpClassPattern()
	{
		if( entityBmpClassPattern != null )
		{
			return entityBmpClassPattern;
		}
		else
		{
			return "{0}BMP";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the concrete CMP entity
	 *  bean class name pattern. By default the value is used for deciding the
	 *  concrete CMP entity bean class name. {0} in the value mean current class's
	 *  symbolic name which for an EJBean is the EJB name. If nothing explicitly
	 *  specified by user then "{0}CMP" is used by default.
	 *
	 * @return    The EntityCmpClassPattern value
	 * @see       #entityCmpClassPattern
	 */
	public String getEntityCmpClassPattern()
	{
		if( entityCmpClassPattern != null )
		{
			return entityCmpClassPattern;
		}
		else
		{
			return "{0}CMP";
		}
	}

	/**
	 *  Returns the configuration parameter for specifying the concrete session
	 *  bean class name pattern. By default the value is used for deciding the
	 *  concrete session bean class name. {0} in the value mean current class's
	 *  symbolic name which for an EJBean is the EJB name. If nothing explicitly
	 *  specified by user then "{0}Session" is used by default.
	 *
	 * @return    The SessionClassPattern value
	 * @see       #entityBmpClassPattern
	 */
	public String getSessionClassPattern()
	{
		if( sessionClassPattern != null )
		{
			return sessionClassPattern;
		}
		else
		{
			return "{0}Session";
		}
	}

	/**
	 *  Evaluate the body block if ejb:aggregate is defined for current getter
	 *  method, denoting that the specified getter method returns an aggregated
	 *  object.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsNotAggregate(java.lang.String)
	 * @see                        #isAggregate(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsAggregate( String template ) throws BuildException
	{
		if( isAggregate( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if ejb:aggregate is not defined for current getter
	 *  method,.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsAggregate(java.lang.String)
	 * @see                        #isAggregate(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsNotAggregate( String template ) throws BuildException
	{
		if( !isAggregate( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if the current method is not an EJB local or remote
	 *  interface method.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Description of Exception
	 * @doc:tag                    type="block"
	 * @doc:param                  name="interface" optional="false"
	 *      description="The type of interface to check for the methods validity
	 *      in. Can be either \"local\" or \"remote\"."
	 */
	public void ifIsNotInterfaceMethod( String template, Properties attributes ) throws BuildException
	{
		String intFace = attributes.getProperty( "interface" );
		if( intFace == null )
		{
			throw new BuildException( "Error in template file.  <XDoclet:ifIsNotInterfaceMethod> must contain the interface parameter. " +
					"Allowed values are remote (default) or local." );
		}
		if( !isInterfaceMethod( intFace ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if the current method is an EJB local or remote
	 *  interface method.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="interface" optional="false"
	 *      description="The type of interface to check for the methods validity
	 *      in. Can be either \"local\" or \"remote\"."
	 */
	public void ifIsInterfaceMethod( String template, Properties attributes ) throws BuildException
	{
		String intFace = attributes.getProperty( "interface" );
		if( intFace == null )
		{
			throw new BuildException( "Error in template file.  <XDoclet:ifIsInterfaceMethod> must contain the interface parameter. " +
					"Allowed values are remote (default) or local." );
		}
		if( isInterfaceMethod( intFace ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if using EJB 2.0 and CMP version 2.x.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #usingCmp2Impl()
	 * @see                        #ifNotUsingCmp2(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifUsingCmp2( String template ) throws BuildException
	{
		if( usingCmp2Impl() )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if not using EJB 2.0 or using EJB 2.0 but CMP
	 *  version 1.x.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #usingCmp2Impl()
	 * @see                        #ifUsingCmp2(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifNotUsingCmp2( String template ) throws BuildException
	{
		if( !usingCmp2Impl() )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if ejb:data-object setdata="true". If not defined
	 *  then default is true.
	 *
	 * @param  pTemplate           Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #hasDataMethod(com.sun.javadoc.Doc)
	 * @see                        #ifIsWithDataContainer(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsWithDataMethod( String pTemplate ) throws BuildException
	{
		if( hasDataMethod( getCurrentClass() ) )
		{
			generate( pTemplate );
		}
	}

	/**
	 *  Evaluate the body block if ejb:data-object container="true". If not defined
	 *  then default is true.
	 *
	 * @param  pTemplate           Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #hasDataMethod(com.sun.javadoc.Doc)
	 * @see                        #ifIsWithDataContainer(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsWithDataContainer( String pTemplate ) throws BuildException
	{
		if( hasDataContainer( getCurrentClass() ) )
		{
			generate( pTemplate );
		}
	}

	/**
	 *  Initializes SubTask. It inherits values of the config parameters if not
	 *  explicitly defined for this sub-task, specifically the value of ejbspec is
	 *  inherited from the context.
	 *
	 * @param  context             The doclet execution context
	 * @param  root                A Javadoc RootDoc object, this is the object all
	 *      ClassDocs are accessible from.
	 * @exception  BuildException  Throw to stop the build process
	 */
	public void init( DocletContext context, RootDoc root ) throws BuildException
	{
		super.init( context, root );

		if( ejbspec == null )
		{
			//not explicitly set by user, then inherit it from task
			ejbspec = ( ( EjbDocletContext ) context ).getEjbSpec();
		}
	}

	/**
	 *  Used by dataMostSuperObjectClass() to get the data object's full qualified
	 *  class name. If name and package parameters of ejb:data-object defined,
	 *  theire values are used, otherwise defaults are used.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #dataMostSuperObjectClass()
	 */
	public String generateDataObjectClass() throws BuildException
	{
		String fileName = getCurrentClass().containingPackage().name();
		String name_pattern = null;
		String package_pattern = null;

		name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object" ), "name", -1 );
		if( name_pattern == null )
		{
			name_pattern = getDataObjectClassPattern();
		}

		package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object" ), "package", -1 );

		String dataobject_name = null;
		if( name_pattern.indexOf( "{0}" ) != -1 )
		{
			dataobject_name = MessageFormat.format( name_pattern, new Object[]{shortEjbName()} );
		}
		else
		{
			dataobject_name = name_pattern;
		}

		// Fix package name
		fileName = choosePackage( fileName, package_pattern );
		fileName += "." + dataobject_name;

		return fileName;
	}

	/**
	 *  Evaluate the body block if current class is of an EJB type.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntity(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifEntity( String template ) throws BuildException
	{
		if( isEntity( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if current class is of an stateless session bean
	 *  type.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isStatelessSession(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifStatelessSession( String template ) throws BuildException
	{
		if( isStatelessSession( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if current class is of an stateful session bean
	 *  type.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isStatefulSession(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifStatefulSession( String template ) throws BuildException
	{
		if( isStatefulSession( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body for each presistent field, regardless of being primary
	 *  key or not.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllPersistentMatchedFields(java.lang.String,java.lang.String,java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void forAllPersistentFields( String template ) throws BuildException
	{
		forAllPersistentMatchedFields( template, null, null );
	}

	/**
	 *  Evaluates the body for each presistent field. If only-pk="true" then use
	 *  only primary keys, if not-pk="true" then use only persistent fields that
	 *  are not primary keys. By default use all regardless of being primary key
	 *  field or not.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllPersistentMatchedFields(java.lang.String,java.lang.String,java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void forAllPersistentFields( String template, Properties attributes ) throws BuildException
	{
		if( attributes.getProperty( "only-pk" ) != null )
		{
			forAllPersistentMatchedFields( template, "ejb:pk-field", null );
		}
		else if( attributes.getProperty( "not-pk" ) != null )
		{
			forAllPersistentMatchedFields( template, null, "ejb:pk-field" );
		}
		else
		{
			forAllPersistentMatchedFields( template, null, null );
		}
	}

	/**
	 *  Generate only for all Persisted Fields matching a specific Tag or Persisted
	 *  fields that do not match a specific Tag
	 *
	 * @param  template            The body of the block tag
	 * @param  inclTag             Name of the tag that should be included.
	 * @param  exclTag             Name of the tag that should be excluded.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllPersistentFields(java.lang.String,java.util.Properties)
	 */
	public void forAllPersistentMatchedFields( String template, String inclTag, String exclTag ) throws BuildException
	{
		Category cat = getCategory( AbstractEjbSubTask.class, "forAllPersistentFields" );
		Map foundFields = new HashMap();
		ClassDoc old_cur_class = getCurrentClass();

		if( cat.isDebugEnabled() )
		{
			cat.debug( "BEGIN-----------------------------------------" );
		}
		do
		{
			if( cat.isDebugEnabled() )
			{
				cat.debug( "-----CLASS=" + getCurrentClass().name() + "----------------" );
			}
			MethodDoc[] methods = getCurrentClass().methods();

			for( int j = 0; j < methods.length; j++ )
			{
				setCurrentMethod( methods[j] );

				if( isPersistentField( getCurrentMethod() ) && isGetter( getCurrentMethod().name() ) && !foundFields.containsKey( getCurrentMethod().name() ) )
				{
					if( ( inclTag == null && exclTag == null )
							 || ( ( inclTag != null ) && ( DocletUtil.hasTag( getCurrentMethod(), inclTag ) ) )
							 || ( ( exclTag != null ) && ( !DocletUtil.hasTag( getCurrentMethod(), exclTag ) ) ) )
					{
						if( cat.isDebugEnabled() )
						{
							cat.debug( "METHOD(I=" + inclTag + " - E=" + exclTag + "=" + getCurrentMethod().name() );
						}
						// Store that we found this field so we don't add it twice
						foundFields.put( getCurrentMethod().name(), getCurrentMethod().name() );

						generate( template );
					}
				}
			}

			// Add super class info
			pushCurrentClass( getCurrentClass().superclass() );
		}while ( getCurrentClass() != null );

		if( cat.isDebugEnabled() )
		{
			cat.debug( "END-------------------------------------------" );
		}

		setCurrentClass( old_cur_class );
	}

	/**
	 *  Returns a string containing comma-specarated list of primary key fields
	 *  without their types.
	 *
	 * @return                     A string containing comma-specarated list of
	 *      primary key fields without their types.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #fieldList(java.lang.String,java.lang.String,boolean)
	 * @doc:tag                    type="content"
	 */
	public String pkfieldList() throws BuildException
	{
		return fieldList( "ejb:pk-field", null, false );
	}

	/**
	 *  Returns a string containing comma-specarated list of persistent fields
	 *  without their types.
	 *
	 * @return                     A string containing comma-specarated list of
	 *      persistent fields without their types.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #fieldList(java.lang.String,java.lang.String,boolean)
	 * @doc:tag                    type="content"
	 */
	public String persistentfieldList() throws BuildException
	{
		return fieldList( null, null, false );
	}

	/**
	 *  Returns a string containing comma-specarated list of persistent fields with
	 *  their types like an ordinary method parameter definition.
	 *
	 * @return                     A string containing comma-specarated list of
	 *      persistent fields with their types like an ordinary method parameter
	 *      definition.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #fieldList(java.lang.String,java.lang.String,boolean)
	 * @doc:tag                    type="content"
	 */
	public String persistentfieldNameValueList() throws BuildException
	{
		return fieldList( null, null, true );
	}

	/**
	 *  Evaluates the body block if current method is a create method. Create
	 *  methods should have ejb:create-method defined.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isCreateMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsCreateMethod( String template ) throws BuildException
	{
		if( isCreateMethod( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method is a home method. Home methods
	 *  should have ejb:home-method defined.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isHomeMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsHomeMethod( String template ) throws BuildException
	{
		if( isHomeMethod( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method is a ejbFind method.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isHomeMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsFinderMethod( String template ) throws BuildException
	{
		if( isFinderMethod( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Returns the name of current EJB bean.
	 *
	 * @return                     The name of current EJB bean.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #getEjbName(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="content"
	 */
	public String ejbName() throws BuildException
	{
		return getEjbName( getCurrentClass() );
	}

	/**
	 *  Returns the symbolic name of the current class. For an EJBean it's the
	 *  value of ejb:bean's name parameter.
	 *
	 * @return                     The symbolic name of the current class
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #shortEjbName()
	 * @doc:tag                    type="content"
	 */
	public String symbolicClassName() throws BuildException
	{
		return shortEjbName();
	}

	/**
	 *  Returns the full-qualified name of the current class's concrete class. This
	 *  is the class that is generated and is derived from current class.
	 *
	 * @return                     The full-qualified name of the current class's
	 *      concrete class
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #sessionClass()
	 * @see                        #entityBmpClass()
	 * @see                        #entityCmpClass()
	 * @see                        #messageDrivenClass()
	 * @doc:tag                    type="content"
	 */
	public String concreteFullClassName() throws BuildException
	{
		if( isSession( getCurrentClass() ) )
		{
			return sessionClass();
		}
		else if( isEntityBmp( getCurrentClass() ) )
		{
			return entityBmpClass();
		}
		else if( isEntityCmp( getCurrentClass() ) )
		{
			return entityCmpClass();
		}
		else if( isMessageDriven( getCurrentClass() ) )
		{
			return messageDrivenClass();
		}
		else
		{
			return super.fullClassName();
		}
	}

	/**
	 *  Returns short version of ejbName(). Example: "foo.bar.MyBean" ->"MyBean",
	 *  "foo/bar/MyBean" ->"MyBean"
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String shortEjbName() throws BuildException
	{
		Category cat = getCategory( AbstractEjbSubTask.class, "shortEjbName" );

		// Find the last part of the name
		StringTokenizer ejbNameTokens = new StringTokenizer( ejbName(), ":./\\-" );
		String name;
		do
		{
			name = ejbNameTokens.nextToken();
		}while ( ejbNameTokens.hasMoreTokens() );

		if( cat.isDebugEnabled() )
		{
			cat.debug( "Name=" + name );
		}

		return name;
	}

	/**
	 *  Returns the name of generated CMP class.
	 *
	 * @return                     The name of generated CMP class.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String entityCmpClass() throws BuildException
	{
		String fileName = getCurrentClass().containingPackage().name();
		String entity_name = MessageFormat.format( getEntityCmpClassPattern(), new Object[]{shortEjbName()} );

		fileName += "." + entity_name;

		return fileName;
	}

	/**
	 *  Returns the name of generated BMP class.
	 *
	 * @return                     The name of generated BMP class.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String entityBmpClass() throws BuildException
	{
		String fileName = getCurrentClass().containingPackage().name();
		String entity_name = MessageFormat.format( getEntityBmpClassPattern(), new Object[]{shortEjbName()} );

		fileName += "." + entity_name;

		return fileName;
	}

	/**
	 *  Returns the name of generated PK class.
	 *
	 * @return                     The name of generated PK class.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String pkClass() throws BuildException
	{
		String fileName = getCurrentClass().containingPackage().name();
		String name_pattern = null;
		String package_pattern = null;

		String pkClass = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:pk" ), "class", -1 );

		if( pkClass != null )
		{
			return pkClass;
		}

		name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:pk" ), "pattern", -1 );
		if( name_pattern == null )
		{
			name_pattern = getEntityPkClassPattern();
		}

		package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:pk" ), "package", -1 );

		String pkclass_name = null;
		if( name_pattern.indexOf( "{0}" ) != -1 )
		{
			pkclass_name = MessageFormat.format( name_pattern, new Object[]{shortEjbName()} );
		}
		else
		{
			pkclass_name = name_pattern;
		}

		// Fix package name
		fileName = choosePackage( fileName, package_pattern );
		if( fileName.length() > 0 )
		{
			fileName += ".";
		}
		fileName += pkclass_name;

		return fileName;
	}

	/**
	 *  Returns the name of generated session class.
	 *
	 * @return                     The name of generated session class.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String sessionClass() throws BuildException
	{
		String fileName = getCurrentClass().containingPackage().name();
		String session_name = MessageFormat.format( getSessionClassPattern(), new Object[]{shortEjbName()} );

		fileName += "." + session_name;

		return fileName;
	}

	/**
	 *  Returns the name of message-driven bean class.
	 *
	 * @return                     The name of generated message-driven bean class.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String messageDrivenClass() throws BuildException
	{
		return super.fullClassName();
	}

	/**
	 *  Returns the full qualified local or remote interface name for the bean,
	 *  depending on the value of type parameter.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="type" optional="false"
	 *      values="remote,local" description="Specifies the type of component
	 *      interface."
	 */
	public String componentInterface( Properties attributes ) throws BuildException
	{
		String type = attributes.getProperty( "type" );

		type = type != null ? type : "remote";

		return getComponentInterface( type );
	}

	/**
	 *  Returns the full qualified local or remote home interface name for the
	 *  bean, depending on the value of type parameter.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="type" optional="false"
	 *      values="remote,local" description="Specifies the type of component home
	 *      interface."
	 */
	public String homeInterface( Properties attributes ) throws BuildException
	{
		String type = attributes.getProperty( "type" );

		type = type != null ? type : "remote";

		return getHomeInterface( type );
	}

	/**
	 *  Returns unique id for the specified ejb-ref. It prefixes it with the
	 *  referring class's id, then a _ and the id of the ejb object.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String ejbRefId() throws BuildException
	{
		// TODO: refactor this properly to account for ejb:bean - it may not be needed anymore.
		Properties prop = new Properties();
		prop.setProperty( "tagName", "ejb:bean" );
		prop.setProperty( "paramNames", "name,jndiName" );
		return referringClassId + "_" + id( prop );
	}

	/**
	 *  Returns Bean type : "Entity", "Session" or "Message Driven".
	 *
	 * @return                     "Entity", "Session" or "Message Driven".
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntity(com.sun.javadoc.ClassDoc)
	 * @see                        #isSession(com.sun.javadoc.ClassDoc)
	 * @see                        #isMessageDriven(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="content"
	 */
	public String beanType() throws BuildException
	{
		if( isEntity( getCurrentClass() ) )
		{
			return "Entity";
		}
		else if( isSession( getCurrentClass() ) )
		{
			return "Session";
		}
		else if( isMessageDriven( getCurrentClass() ) )
		{
			return "Message Driven";
		}
		else
		{
			return "Unknown";
		}
	}

	/**
	 *  Returns data-object class name for the bean.
	 *
	 * @return                     The data-object class name for the bean.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String dataObjectClass() throws BuildException
	{
		return ( String ) dataObjectClassnames.get( getCurrentClass().name() );
	}

	/**
	 *  Evaluates the body block if current bean is a concrete bean meaning the
	 *  generate parameter of ejb:bean is either not specified or equals to "true",
	 *  otherwise the bean is just an abstract base class bean not meant to be used
	 *  as a EJBean but serve as the base for other EJBeans.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void ifIsAConcreteEJBean( String template, Properties attributes ) throws BuildException
	{
		String bean_tag = DocletUtil.getText( getCurrentClass(), "ejb:bean" );
		String generate = getParameterValue( bean_tag, "generate", -1 );

		if( generate == null )
		{
			generate( template );
		}
		else if( generate.equals( "true" ) || generate.equals( "yes" ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from one of the three EJB
	 *  types: EntityBean, SessionBean or MessageDrivenBean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntity(com.sun.javadoc.ClassDoc)
	 * @see                        #isSession(com.sun.javadoc.ClassDoc)
	 * @see                        #isMessageDriven(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isEntity( getCurrentClass() ) || isSession( getCurrentClass() ) ||
					isMessageDriven( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from MessageDrivenBean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isMessageDriven(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllMDBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isMessageDriven( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from SessionBean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isSession(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllSessionBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isSession( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from SessionBean which is
	 *  stateful.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isStatefulSession(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllStatefulSessionBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isStatefulSession( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from SessionBean which is
	 *  stateless.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isStatelessSession(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllStatelessSessionBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isStatelessSession( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from EntityBean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntity(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllEntityBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isEntity( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from EntityBean which is
	 *  CMP.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntityCmp(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllCmpEntityBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isEntityCmp( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Evaluates the body block for each EJBean derived from EntityBean which is
	 *  BMP.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntityBmp(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void forAllBmpEntityBeans( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( isDocletGenerated( getCurrentClass() ) )
			{
				continue;
			}

			if( isEntityBmp( getCurrentClass() ) )
			{
				generate( template );
			}
		}
	}

	/**
	 *  Returns the data-object class name highest in the hierarchy of derived
	 *  beans. Because of possible inheritance between entity bean, the type of the
	 *  generated getData method must be the one of the most super class of the
	 *  current entity bean. The current Data class must extend the corresponding
	 *  super Data class.
	 *
	 * @return                     The data-object class name highest in the
	 *      hierarchy of derived beans.
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String dataMostSuperObjectClass() throws BuildException
	{
		ClassDoc oldClass = getCurrentClass();
		String currentDataClass = ( String ) dataObjectClassnames.get( getCurrentClass().name() );
		// Begin at the first super class
		pushCurrentClass( getCurrentClass().superclass() );
		do
		{
			// Find if we have an abstract data class definition to generate
			MethodDoc[] methods = getCurrentClass().methods();
			boolean found = false;
			for( int i = 0; i < methods.length; i++ )
			{
				if( methods[i].name().equals( "getData" ) )
				{
					found = true;
					currentDataClass = generateDataObjectClass();
				}
				if( found )
				{
					break;
				}
			}
			pushCurrentClass( getCurrentClass().superclass() );
		}while ( getCurrentClass() != null );
		setCurrentClass( oldClass );
		return currentDataClass;
	}

	/**
	 *  Evaluates the body block for each setData method.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllSuper(java.lang.String,java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void forAllSuperSetData( String template ) throws BuildException
	{
		forAllSuper( template, "setData" );
	}

	/**
	 *  Evaluates the body block for each ejb:ejb-ref defined for the EJB. One of
	 *  the useful things is does is to lookup the EJB using the ejb-name parameter
	 *  of ejb:ejb-ref and fill in other required info.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void forAllEjbRefs( String template, Properties attributes ) throws BuildException
	{
		Tag[] tags = DocletUtil.getTagsByName( getCurrentClass(), "ejb:ejb-ref" );

		for( int i = 0; i < tags.length; i++ )
		{
			currentTag = tags[i];

			storeReferringClassId();
			pushCurrentClass( findEjb( getParameterValue( DocletUtil.getText( currentTag ), "ejb-name", -1 ) ) );
			generate( template );
			popCurrentClass();

			referringClassId = null;
		}

		currentTag = null;
	}

	/**
	 *  Evaluates the body block if current class is an CMP entity bean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void ifEntityIsCmp( String template ) throws BuildException
	{
		if( isEntityCmp( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current class is an BMP entity bean.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void ifEntityIsBmp( String template ) throws BuildException
	{
		if( isEntityBmp( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Returns the persistent type of current bean.
	 *
	 * @return                     "Container" or "Bean".
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntityCmp(com.sun.javadoc.ClassDoc)
	 * @see                        #isEntityBmp(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="content"
	 */
	public String persistenceType() throws BuildException
	{
		if( isEntityCmp( getCurrentClass() ) && !isEntityBmp( getCurrentClass() ) )
		{
			return "Container";
		}
		else
		{
			return "Bean";
		}
	}

	/**
	 *  Evaluates the body block if ejb:use-soft-locking is set for current class.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #useSoftLocking(com.sun.javadoc.ClassDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifUseSoftLocking( String template ) throws BuildException
	{
		if( useSoftLocking( getCurrentClass() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Returns current security role name set by the containing
	 *  forAllSecurityRoles.
	 *
	 * @return                     Current security role name
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllSecurityRoles(java.lang.String)
	 * @doc:tag                    type="content"
	 */
	public String securityRoleName() throws BuildException
	{
		return currentSecurityRoleName;
	}

	/**
	 *  Evaluates the body block for each ejb:permission defined in class level or
	 *  method level.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #hasPermission(com.sun.javadoc.Doc)
	 * @see                        #securityRoleName()
	 * @doc:tag                    type="block"
	 */
	public void forAllSecurityRoles( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();
		Set roleSet = new HashSet();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			// Get roles from class
			if( hasPermission( getCurrentClass() ) )
			{
				Tag[] permissions = DocletUtil.getTagsByName( getCurrentClass(), "ejb:permission" );

				for( int k = 0; k < permissions.length; k++ )
				{
					roleSet.addAll( Arrays.asList( DocletUtil.tokenizeDelimitedToArray( getParameterValue( permissions[k].text(), "role-name", 0 ), "," ) ) );
				}
				// Add roles to set
			}

			// Get roles from methods
			MethodDoc[] methods = getCurrentClass().methods();
			for( int j = 0; j < methods.length; j++ )
			{
				setCurrentMethod( methods[j] );

				if( hasPermission( getCurrentMethod() ) && isInterfaceMethod( getCurrentMethod() ) )
				{
					Tag[] permissions = DocletUtil.getTagsByName( getCurrentMethod(), "ejb:permission" );

					for( int k = 0; k < permissions.length; k++ )
					{
						roleSet.addAll( Arrays.asList( DocletUtil.tokenizeDelimitedToArray( getParameterValue( permissions[k].text(), "role-name", 0 ), "," ) ) );
					}
					// Add role to set
				}
			}

			//get roles from finders
			Tag[] finders = DocletUtil.getTagsByName( getCurrentClass(), "ejb:finder" );
			for( int j = 0; j < finders.length; j++ )
			{
				String value = getParameterValue( finders[j].text(), "role-name", 0 );

				if( value == null )
				{
					continue;
				}

				roleSet.addAll( Arrays.asList( DocletUtil.tokenizeDelimitedToArray( value, "," ) ) );
			}

			// and from pk field ( if any )

			Tag pk[] = DocletUtil.getTagsByName( getCurrentClass(), "ejb:pk" );
			for( int j = 0; j < pk.length; j++ )
			{
				String value = getParameterValue( pk[j].text(), "role-name", -1 );
				if( value == null )
				{
					continue;
				}
				roleSet.addAll( Arrays.asList( DocletUtil.tokenizeDelimitedToArray( value, "," ) ) );
			}
		}

		// Output set of roles
		Iterator roleEnum = roleSet.iterator();
		while( roleEnum.hasNext() )
		{
			currentSecurityRoleName = ( String ) roleEnum.next();

			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if ejb:interface-method defined for current
	 *  method.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isInterfaceMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifIsInterfaceMethod( String template ) throws BuildException
	{
		if( isInterfaceMethod( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method is ejbRemove method.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isRemoveMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="block"
	 */
	public void ifNotRemoveMethod( String template ) throws BuildException
	{
		if( !isRemoveMethod( getCurrentMethod() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Returns "Remote" is current method has ejb:remote-method defined, "Home"
	 *  otherwise.
	 *
	 * @return                     "Remote" or "Home".
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isRemoteMethod(com.sun.javadoc.MethodDoc)
	 * @doc:tag                    type="content"
	 */
	public String methodIntf() throws BuildException
	{
		return ( isRemoteMethod( getCurrentMethod() ) ? "Remote" : "Home" );
	}

	/**
	 *  Returns interface method name for the current interface method.
	 *
	 * @return                     "Remote" or "Home".
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #getInterfaceMethodName(java.lang.String)
	 * @doc:tag                    type="content"
	 */
	public String interfaceMethodName() throws BuildException
	{
		return getInterfaceMethodName( getCurrentMethod().name() );
	}

	/**
	 *  Evaluates the body block for each persistent field of current class (if
	 *  entity CMP). Looks at super classes as well. Searches for the getter
	 *  methods which has ejb:persistent-field defined.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntityCmp(com.sun.javadoc.ClassDoc)
	 * @see                        #isPersistentField(com.sun.javadoc.MethodDoc)
	 * @see                        #isGetter(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void forAllCmpFields( String template ) throws BuildException
	{
		if( isEntityCmp( getCurrentClass() ) )
		{
			ClassDoc oldClass = getCurrentClass();
			List already = new ArrayList();

			do
			{
				MethodDoc[] methods = getCurrentClass().methods();
				MethodDoc old_cur_method = getCurrentMethod();

				for( int j = 0; j < methods.length; j++ )
				{
					MethodDoc current_method = methods[j];
					if( !already.contains( current_method.name() ) )
					{

						setCurrentMethod( current_method );

						if( isPersistentField( current_method ) && isGetter( current_method.name() ) )
						{
							generate( template );
						}

						already.add( current_method.name() );
					}
				}

				setCurrentMethod( old_cur_method );

				// Add super class info
				pushCurrentClass( getCurrentClass().superclass() );
			}while ( getCurrentClass() != null );

			setCurrentClass( oldClass );
		}
	}

	/**
	 *  Evaluates the body block for each relationship. Relations are denoted by
	 *  ejb:relation for the getter method of the cmr-field.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isEntityCmp(com.sun.javadoc.ClassDoc)
	 * @see                        #isPersistentField(com.sun.javadoc.MethodDoc)
	 * @see                        #isGetter(java.lang.String)
	 * @see                        #ifIsACollection(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void forAllRelationships( String template ) throws BuildException
	{
		ClassDoc[] classes = root.classes();
		relationSet.clear();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			MethodDoc[] methods = getCurrentClass().methods();
			for( int j = 0; j < methods.length; j++ )
			{
				setCurrentMethod( methods[j] );

				Tag[] relation = DocletUtil.getTagsByName( getCurrentMethod(), "ejb:relation" );
				for( int k = 0; k < relation.length; k++ )
				{
					String value = getParameterValue( relation[k].text(), "name", 0 );

					if( value == null )
					{
						throw new BuildException( "must have attribute \"name\" for ejb:relation " + getCurrentClass().name() );
					}

					RelationHolder h = ( RelationHolder ) relationSet.get( value );
					if( h != null && h.left != null && h.right != null )
					{
						throw new BuildException( "attribute \"name\" in ejb:relation declared more than twice " + getCurrentClass().name() );
					}

					if( h == null )
					{
						h = new RelationHolder();
						h.left = classes[i];
						h.leftMethod = methods[j];
						h.right = null;
						relationSet.put( value, h );
					}
					else
					{
						h.right = classes[i];
						h.rightMethod = methods[j];
					}
				}
			}
		}

		Enumeration e = relationSet.elements();
		while( e.hasMoreElements() )
		{
			RelationHolder h = ( RelationHolder ) e.nextElement();

			setCurrentClass( h.left );
			setCurrentMethod( h.leftMethod );

			curRelation = h;

			if( h.right == null )
			{
				Tag[] relation = DocletUtil.getTagsByName( getCurrentMethod(), "ejb:relation" );
				String value = getParameterValue( relation[0].text(), "target-ejb", 0 );

				if( value == null )
				{
					throw new BuildException( "must have attribute \"right-ejb\" for ejb:relation " + getCurrentClass().name() + " or you have misspelled the name parameter" );
				}
			}

			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method's return type is either
	 *  java.util.Collection or java.util.Set. Used by forAllRelationships.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllRelationships(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsACollection( String template ) throws BuildException
	{
		if( isACollection( methodType() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method's return type is not a
	 *  java.util.Collection or java.util.Set. Used by forAllRelationships.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #forAllRelationships(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsNotACollection( String template ) throws BuildException
	{
		if( !isACollection( methodType() ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block for each relationship role.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void forAllRelationshipRoles( String template ) throws BuildException
	{
		generate( template );

		if( curRelation.right != null )
		{
			setCurrentClass( curRelation.right );
			setCurrentMethod( curRelation.rightMethod );

			generate( template );
		}
	}

	/**
	 *  Returns true if current method's return type is a java.util.Collection or
	 *  java.util.Set, false otherwise.
	 *
	 * @param  type  Description of Parameter
	 * @return       true if Collection or Set
	 */
	protected boolean isACollection( String type )
	{
		return ( type.equals( "java.util.Collection" ) || type.equals( "java.util.Set" ) );
	}

	/**
	 *  Returns the EJB name of the clazz by seaching for ejb:bean's name
	 *  parameter. Throws a BuildException if not specified.
	 *
	 * @param  clazz               the class we want its EJB name
	 * @return                     The EjbName value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String getEjbName( ClassDoc clazz ) throws BuildException
	{
		String bean_val = DocletUtil.getText( clazz, "ejb:bean" );

		if( bean_val == null )
		{
			throw new BuildException( "@ejb:bean class tag expected in class " + clazz.qualifiedName() + " but not found." );
		}

		String param_val = getParameterValue( bean_val, "name", -1 );

		if( param_val == null )
		{
			throw new BuildException( "'name' parameter of @ejb:bean class tag expected in class " + clazz.qualifiedName() + " but not found." );
		}

		return param_val;
	}

	/**
	 *  Implements functionality required by {@link #ifIsInterfaceMethod} and
	 *  {@link #ifIsNotInterfaceMethod}. To determine what interfaces the method
	 *  should appear in, check the first for a <code>view-type</code> parameter to
	 *  the method level <code>ejb:interface-method</code> tag. If that is absent
	 *  use the <code>view-type</code> tag from <code>ejb:bean</code> .
	 *
	 * @param  intFace             The type of interface to test the method for.
	 * @return                     true if the method should occur in the specified
	 *      interface.
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isInterfaceMethod( String intFace ) throws BuildException
	{
		String interfaceMethod = DocletUtil.getText( getCurrentMethod(), "ejb:interface-method" );
		if( interfaceMethod == null )
		{
			return false;
		}
		String viewType = getParameterValue( interfaceMethod, "view-type", -1 );
		if( "both".equals( viewType ) )
		{
			viewType = "local,remote";
		}

		if( viewType == null )
		{
			viewType = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "view-type", -1 );
			if( "both".equals( viewType ) )
			{
				viewType = "local,remote";
			}
		}
		if( viewType == null )
		{
			// default to remote
			viewType = "remote";
		}
		return viewType.indexOf( intFace ) >= 0;
	}

	/**
	 *  Return the fully qualified name of the component interface of type
	 *  specified. Works based on the <code>ejb:interface</code> class level tag.
	 *  Relevant parameters for the <code>ejb:interface</code> tag are:
	 *  <ul>
	 *    <li> remote-class: The fully qualified name of the remote class -
	 *    overrides all set patterns
	 *    <li> local-class: The fully qualified name of the local class - overrides
	 *    all set patterns
	 *    <li> remote-pattern: The pattern to be used to determine the unqualified
	 *    name of the remote class
	 *    <li> local-pattern: The pattern to be used to determine the unqualified
	 *    name of the local class
	 *    <li> pattern: The pattern to be used in determining the unqualified
	 *    remote and/or local interface name - used where remote- or local- pattern
	 *    are not specified.
	 *    <li> remote-package: The package the remote interface is to be placed in
	 *
	 *    <li> local-package: The package the local interface is to be placed in
	 *
	 *    <li> package: The package the remote and/or local interface is to be
	 *    placed in - used where remote- or local- package are not specified.
	 *  </ul>
	 *
	 *
	 * @param  type                Can be remote or local. Defaults to remote.
	 * @return                     The fully qualified name of the interface.
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String getComponentInterface( String type ) throws BuildException
	{
		// validate type
		if( !"remote".equals( type ) && !"local".equals( type ) )
		{
			throw new BuildException( "getComponentInterface can only take type=remote|local - received type=" + type );
		}

		String fileName = getCurrentClass().containingPackage().name();
		String name_pattern = null;
		String package_pattern = null;
		String component_interface = null;

		component_interface = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:interface" ), type + "-class", -1 );
		if( component_interface != null )
		{
			return component_interface;
		}

		name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:interface" ), type + "-pattern", -1 );
		if( name_pattern == null )
		{
			name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:interface" ), "pattern", -1 );
			if( name_pattern == null )
			{
				name_pattern = "remote".equals( type ) ? getRemoteClassPattern() : getLocalClassPattern();
			}
		}

		package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:interface" ), type + "-package", -1 );
		if( package_pattern == null )
		{
			package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:interface" ), "package", -1 );
		}

		String ejb_name = null;
		if( name_pattern.indexOf( "{0}" ) != -1 )
		{
			ejb_name = MessageFormat.format( name_pattern, new Object[]{shortEjbName()} );
		}
		else
		{
			ejb_name = name_pattern;
		}

		// Fix package name
		fileName = choosePackage( fileName, package_pattern );
		fileName += "." + ejb_name;

		return fileName;
	}

	/**
	 *  Similar to {@link #getComponentInterface}. Relies on the ejb:home tag,
	 *  which has the following relevant properties:
	 *  <ul>
	 *    <li> remote-class: The fully qualified name of the remote class -
	 *    overrides all set patterns
	 *    <li> local-class: The fully qualified name of the local class - overrides
	 *    all set patterns
	 *    <li> remote-pattern: The pattern to be used to determine the unqualified
	 *    name of the remote class
	 *    <li> local-pattern: The pattern to be used to determine the unqualified
	 *    name of the local class
	 *    <li> pattern: The pattern to be used in determining the unqualified
	 *    remote and/or local home interface name - used where remote- or local-
	 *    pattern are not specified.
	 *    <li> remote-package: The package the remote home interface is to be
	 *    placed in
	 *    <li> local-package: The package the local home interface is to be placed
	 *    in
	 *    <li> package: The package the remote and/or local home interface is to be
	 *    placed in - used where remote- or local- package are not specified.
	 *  </ul>
	 *
	 *
	 * @param  type                The type of home interface - can be remote or
	 *      local.
	 * @return                     The HomeInterface value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String getHomeInterface( String type ) throws BuildException
	{
		Category cat = getCategory( AbstractEjbSubTask.class, "getHomeInterface" );
		// validate type
		if( !"remote".equals( type ) && !"local".equals( type ) )
		{
			throw new BuildException( "getHomeInterface can only take type=remote|local - received type=" + type );
		}

		String fileName = getCurrentClass().containingPackage().name();
		String name_pattern = null;
		String package_pattern = null;
		String home_interface = null;

		home_interface = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:home" ), type + "-class", -1 );
		if( cat.isDebugEnabled() )
		{
			cat.debug( type + " home Interface for " + getCurrentClass().name() + " = " + home_interface );
		}
		if( home_interface != null )
		{
			return home_interface;
		}

		name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:home" ), type + "-pattern", -1 );
		if( name_pattern == null )
		{
			name_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:home" ), "pattern", -1 );
			if( name_pattern == null )
			{
				name_pattern = "remote".equals( type ) ? getHomeClassPattern() : getLocalHomeClassPattern();
			}
		}

		package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:home" ), type + "-package", -1 );
		if( package_pattern == null )
		{
			package_pattern = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:home" ), "package", -1 );
		}

		String ejb_name = null;
		if( name_pattern.indexOf( "{0}" ) != -1 )
		{
			ejb_name = MessageFormat.format( name_pattern, new Object[]{shortEjbName()} );
		}
		else
		{
			ejb_name = name_pattern;
		}

		// Fix package name
		fileName = choosePackage( fileName, package_pattern );
		fileName += "." + ejb_name;

		return fileName;
	}

	/**
	 *  Returns true if method is a create method marked with a ejb:create-method
	 *  tag, false otherwise.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The CreateMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isCreateMethod( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:create-method" );
	}

	/**
	 *  Returns true if method is a home method marked with a ejb:home-method tag,
	 *  false otherwise.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The HomeMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isHomeMethod( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:home-method" );
	}

	/**
	 *  Returns true if clazz is an CMP entity bean, false otherwise. Entity type
	 *  is determined by looking at the ejb:bean's type parameter.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The EntityCmp value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isEntityCmp( ClassDoc clazz ) throws BuildException
	{
		if( isEntity( clazz ) == false )
		{
			return false;
		}

		String value = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "type", -1 );

		if( value != null && value.equals( "CMP" ) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *  Returns true if clazz is an BMP entity bean, false otherwise. Entity type
	 *  is determined by looking at the ejb:bean's type parameter.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The EntityBmp value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isEntityBmp( ClassDoc clazz ) throws BuildException
	{
		if( isEntity( clazz ) == false )
		{
			return false;
		}

		String value = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "type", -1 );

		if( value != null && value.equals( "BMP" ) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *  Returns true if clazz is a session bean, false otherwise.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The Session value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isSession( ClassDoc clazz ) throws BuildException
	{
		return isOfType( clazz, "javax.ejb.SessionBean", TYPE_HIERARCHY );
	}

	/**
	 *  Returns true if clazz is a stateful session bean, false otherwise. Entity
	 *  type is determined by looking at the ejb:bean's type parameter.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The StatefulSession value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isStatefulSession( ClassDoc clazz ) throws BuildException
	{
		if( isSession( clazz ) == false )
		{
			return false;
		}

		String value = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "type", -1 );

		if( value != null && value.equals( "Stateful" ) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *  Returns true if clazz is a stateless session bean, false otherwise. Entity
	 *  type is determined by looking at the ejb:bean's type parameter.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The StatelessSession value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isStatelessSession( ClassDoc clazz ) throws BuildException
	{
		if( isSession( clazz ) == false )
		{
			return false;
		}

		String value = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "type", -1 );

		if( value != null && value.equals( "Stateless" ) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *  Returns true if clazz is a messgae-driven bean, false otherwise.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The MessageDriven value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isMessageDriven( ClassDoc clazz ) throws BuildException
	{
		return isOfType( clazz, "javax.ejb.MessageDrivenBean", TYPE_HIERARCHY );
	}

	/**
	 *  Returns true if clazz is an entity session bean, false otherwise.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The Entity value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isEntity( ClassDoc clazz ) throws BuildException
	{
		return isOfType( clazz, "javax.ejb.EntityBean", TYPE_HIERARCHY );
	}

	/**
	 *  Returns true if method is a persistent field, false otherwise. Persistent
	 *  fields are getter methods marked with a ejb:persistent-field tag.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The PersistentField value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isPersistentField( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:persistent-field" );
	}

	/**
	 *  Returns true if method is a primary key field, false otherwise. PK fields
	 *  are getter methods marked with a ejb:pk-field tag.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The PkField value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isPkField( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:pk-field" );
	}

	/**
	 *  Returns true if clazz has ejb:pk-field defined.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The PkFieldInHeader value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isPkFieldInHeader( ClassDoc clazz ) throws BuildException
	{
		return DocletUtil.hasTag( clazz, "ejb:pk-field" );
	}

	/**
	 *  Returns true if method is a component interface method, false otherwise.
	 *  Component interface methods are marked with a ejb:interface-method tag.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The RemoteMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isRemoteMethod( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:interface-method" );
	}

	/**
	 *  Returns true if method is an ejbRemove method, false otherwise.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The RemoveMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isRemoveMethod( MethodDoc method ) throws BuildException
	{
		return method.name().equals( "ejbRemove" );
	}

	/**
	 *  Returns true if method is an ejbFind method, false otherwise.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The FinderMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isFinderMethod( MethodDoc method ) throws BuildException
	{
		return method.name().startsWith( "ejbFind" );
	}

	/**
	 *  Returns true if method is an interface method, false otherwise. Interface
	 *  methods are remote/create/remove/finder/home methods.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The InterfaceMethod value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isInterfaceMethod( MethodDoc method ) throws BuildException
	{
		return isRemoteMethod( method ) ||
				isCreateMethod( method ) ||
				isRemoveMethod( method ) ||
				isFinderMethod( method ) ||
				isHomeMethod( method );
	}

	/**
	 *  Returns true if clazz is only a local EJB by looking at ejb:bean's
	 *  view-type parameter.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The OnlyLocalEjb value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isOnlyLocalEjb( ClassDoc clazz ) throws BuildException
	{
		String value = getParameterValue( DocletUtil.getText( clazz, "ejb:bean" ), "view-type", -1 );

		if( value != null && value.equals( "local" ) )
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	/**
	 *  Returns true if clazz is only a remote EJB by looking at ejb:bean's
	 *  view-type parameter.
	 *
	 * @param  classDoc            Description of Parameter
	 * @return                     The OnlyRemoteEjb value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isOnlyRemoteEjb( ClassDoc classDoc ) throws BuildException
	{
		String value = getParameterValue( DocletUtil.getText( classDoc, "ejb:bean" ), "view-type", -1 );

		if( ( value != null && value.equals( "remote" ) ) || value == null )
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 *  Returns the interface method name depending on its type.
	 *
	 * @param  name  Description of Parameter
	 * @return       "create" if ejbCreate, "remote" if ejbRemove, find <blabl>if
	 *      ejbFind, home <blabla>if ejbHome.
	 */
	protected String getInterfaceMethodName( String name )
	{
		if( name.equals( "ejbCreate" ) )
		{
			return "create";
		}
		else if( name.equals( "ejbRemove" ) )
		{
			return "remove";
		}
		else if( name.startsWith( "ejbFind" ) )
		{
			return toFinderMethod( name );
		}
		else if( name.startsWith( "ejbHome" ) )
		{
			return toHomeMethod( name );
		}
		else
		{
			return name;
		}
	}

	/**
	 *  Returns an array containing ejb:pk-field tags defined in class level.
	 *
	 * @return                     The PkFieldsInHeader value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String[] getPkFieldsInHeader() throws BuildException
	{
		Vector lPKs = new Vector();
		Tag[] lTags = DocletUtil.getTagsByName( getCurrentClass(), "ejb:pk-field" );

		for( int i = 0; i < lTags.length; i++ )
		{
			lPKs.addElement( lTags[i].text() );
		}

		return ( String[] ) lPKs.toArray( new String[0] );
	}

	/**
	 *  Returns true of clazz is an EJB (derived from an EJB type), false
	 *  otherwise.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The Ejb value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isEjb( ClassDoc clazz ) throws BuildException
	{
		return isOfType( clazz, "javax.ejb.SessionBean,javax.ejb.EntityBean,javax.ejb.MessageDrivenBean", TYPE_HIERARCHY );
	}

	/**
	 *  Returns true if method has ejb:aggregate, false otherwise.
	 *
	 * @param  method              Description of Parameter
	 * @return                     The Aggregate value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean isAggregate( MethodDoc method ) throws BuildException
	{
		return DocletUtil.hasTag( method, "ejb:aggregate" );
	}

	/**
	 *  Browse all super classes and search for a special method to generate it in
	 *  the current CMP/BMP class.
	 *
	 * @param  template            The body of the block tag
	 * @param  methodName          Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected void forAllSuper( String template, String methodName ) throws BuildException
	{
		ClassDoc oldClass = getCurrentClass();
		List already = new ArrayList();

		// Begin at the first super class
		pushCurrentClass( getCurrentClass().superclass() );

		do
		{
			// Find if we have an abstract data class definition to generate
			MethodDoc[] methods = getCurrentClass().methods();
			MethodDoc methodFound = null;
			for( int i = 0; i < methods.length; i++ )
			{
				if( methods[i].name().equals( methodName ) )
				{
					methodFound = methods[i];
				}
				if( methodFound != null )
				{
					break;
				}
			}

			if( methodFound != null )
			{
				// We can not use contains because it is based on equals() and
				// we need to compare based on compareTo()
				Iterator i = already.iterator();
				boolean contained = false;

				while( i.hasNext() )
				{
					if( ( ( MethodDoc ) i.next() ).compareTo( methodFound ) == 0 )
					{
						contained = true;
					}
					if( contained )
					{
						break;
					}
				}

				if( contained == false )
				{
					generate( template );
					already.add( methodFound );
				}
			}

			pushCurrentClass( getCurrentClass().superclass() );
		}while ( getCurrentClass() != null );

		setCurrentClass( oldClass );
	}

	/**
	 *  Returns true if ejbspec config parameter is "2.0" and ejb:bean's
	 *  cmp-version either not defined or is "2.x", false otherwise.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean usingCmp2Impl() throws BuildException
	{
		boolean ejbspec2 = ejbspec.equals( "2.0" );
		String cmp = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "cmp-version", -1 );
		return ( ejbspec2 && "2.x".equals( cmp ) );
	}

	/**
	 *  Returns comma-separated list of fields, excluding fields that have tags of
	 *  exclTag list, including fields that have tags of inclTag list. If
	 *  name_value_out is true, then the list is in fieldname="value" format.
	 *
	 * @param  inclTag             Fields that have at least of the tags of this
	 *      comma-separated list are used.
	 * @param  exclTag             Fields that don't have all of the tags of this
	 *      comma-separated list are used.
	 * @param  name_value_out      If true, then the list is in fieldname="value"
	 *      format.
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String fieldList( String inclTag, String exclTag, boolean name_value_out ) throws BuildException
	{
		Map foundFields = new HashMap();
		StringBuffer st = new StringBuffer();
		String type = null;
		String name = null;
		ClassDoc old_cur_class = getCurrentClass();

		do
		{
			MethodDoc[] methods = getCurrentClass().methods();

			for( int j = 0; j < methods.length; j++ )
			{
				setCurrentMethod( methods[j] );

				if( isPersistentField( getCurrentMethod() ) && isGetter( getCurrentMethod().name() ) && !foundFields.containsKey( getCurrentMethod().name() ) )
				{
					if( ( inclTag == null && exclTag == null )
							 || ( ( inclTag != null ) && ( DocletUtil.hasTag( getCurrentMethod(), inclTag ) ) )
							 || ( ( exclTag != null ) && ( !DocletUtil.hasTag( getCurrentMethod(), exclTag ) ) ) )
					{
						// Store that we found this field so we don't add it twice
						foundFields.put( getCurrentMethod().name(), getCurrentMethod() );

						name = propertyName();
						type = getCurrentMethod().returnType().toString();

						if( name_value_out )
						{
							String value = outputOf( "<XDoclet:propertyName/>" );

							if( foundFields.size() > 1 )
							{
								st.append( " + " );
							}

							st.append( "\"" ).append( name ).append( "=\" + " ).append( value );
						}
						else
						{
							if( foundFields.size() > 1 )
							{
								st.append( "," );
							}
							st.append( type ).append( ' ' ).append( name );
						}
					}
				}
			}

			// Add super class info
			pushCurrentClass( getCurrentClass().superclass() );
		}while ( getCurrentClass() != null );

		setCurrentClass( old_cur_class );

		return st.toString();
	}

	/**
	 *  Stores the id of current EJB for further use by other tags in
	 *  referringClassId attribute.
	 *
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected void storeReferringClassId() throws BuildException
	{
		// TODO: refactor this properly to take ejb:bean into account - may not be needed anymore.
		Properties prop = new Properties();
		prop.setProperty( "tagName", "ejb:bean" );
		prop.setProperty( "paramNames", "name" );
		referringClassId = id( prop );
	}

	/**
	 *  Returns package name for the fileName. If fileName ends with ".ejb" or
	 *  ".beans" then it's substituted by ".interfaces" by default. If
	 *  package_pattern not null then it's roughly used.
	 *
	 * @param  fileName            Description of Parameter
	 * @param  package_pattern     Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String choosePackage( String fileName, String package_pattern ) throws BuildException
	{
		Category cat = getCategory( AbstractEjbSubTask.class, "choosePackage" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "FileName=" + fileName + " - Pattern=" + package_pattern );
		}

		if( package_pattern != null )
		{
			// later we may do some parametric {0} fancy stuff here
			return package_pattern;
		}
		else
		{
			// ".ejb" -> ".interfaces"
			if( fileName.endsWith( ".ejb" ) )
			{
				fileName = fileName.substring( 0, fileName.length() - 4 ) + ".interfaces";
			}

			// ".beans" -> ".interfaces"
			else if( fileName.endsWith( ".beans" ) )
			{
				fileName = fileName.substring( 0, fileName.length() - 6 ) + ".interfaces";
			}
		}
		if( cat.isDebugEnabled() )
		{
			cat.debug( "FileName=" + fileName );
		}
		return fileName;
	}

	/**
	 *  Finds and returns the class with the specified ejbName. A BuildException is
	 *  thrown if not found.
	 *
	 * @param  ejbName             Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected ClassDoc findEjb( String ejbName ) throws BuildException
	{
		ClassDoc[] classes = root.classes();
		for( int i = 0; i < classes.length; i++ )
		{
			if( isEjb( classes[i] ) && ejbName.equals( getEjbName( classes[i] ) ) )
			{
				return classes[i];
			}
		}

		throw new BuildException( "No such EJB defined:" + ejbName );
	}

	/**
	 *  Converts ejbHome <blabla>to home <blabla>, the one that should appeare in
	 *  home interface.
	 *
	 * @param  methodName          Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String toHomeMethod( String methodName ) throws BuildException
	{
		// Remove "ejbHome" prefix and lower case first char in rest: "ejbHomeFoo"->"foo"
		return Character.toLowerCase( methodName.charAt( 7 ) ) + methodName.substring( 8 );
	}

	/**
	 *  Converts ejbFind <blabla>to find <blabla>, the one that should appeare in
	 *  home interface.
	 *
	 * @param  methodName          Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String toFinderMethod( String methodName ) throws BuildException
	{
		// Remove "ejb" prefix and lower case first char in rest: "ejbFindByPrimaryKey"->"findByPrimaryKey"
		return Character.toLowerCase( methodName.charAt( 3 ) ) + methodName.substring( 4 );
	}

	/**
	 *  Returns true if class/method denoted by doc has ejb:permission tag, false
	 *  otherwise.
	 *
	 * @param  doc                 Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean hasPermission( Doc doc ) throws BuildException
	{
		return DocletUtil.hasTag( doc, "ejb:permission" );
	}

	/**
	 *  Returns true if class/method denoted by doc has ejb:transaction tag, false
	 *  otherwise.
	 *
	 * @param  doc                 Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean hasTransaction( Doc doc ) throws BuildException
	{
		return DocletUtil.hasTag( doc, "ejb:transaction" );
	}

	/**
	 *  Returns true if clazz has ejb:use-soft-locking tag, false otherwise.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean useSoftLocking( ClassDoc clazz ) throws BuildException
	{
		String soft_locking_str = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:bean" ), "use-soft-locking", -1 );
		boolean soft_locking = stringToBoolean( soft_locking_str, false );

		return soft_locking;
	}

	/**
	 *  Returns true if ejb:data-object defined and setdata param is true, false if
	 *  not true.
	 *
	 * @param  doc                 Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean hasDataMethod( Doc doc ) throws BuildException
	{
		// When the tag is there and is set to "false" then return false
		if( DocletUtil.hasTag( getCurrentClass(), "ejb:data-object" ) )
		{
			String gen_set_date_str = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object" ), "setdata", -1 );
			boolean gen_set_date = stringToBoolean( gen_set_date_str, true );

			return gen_set_date;
		}
		else
		{
			return true;
		}
	}

	/**
	 *  Returns true if ejb:data-object defined and container param is true, false
	 *  if not true.
	 *
	 * @param  doc                 Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean hasDataContainer( Doc doc ) throws BuildException
	{
		// When the tag is there and is set to "false" then return false
		if( DocletUtil.hasTag( getCurrentClass(), "ejb:data-object" ) )
		{
			String data_container_str = getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:data-object" ), "container", -1 );
			boolean is_data_container = stringToBoolean( data_container_str, true );

			return is_data_container;
		}
		else
		{
			return true;
		}
	}

	/**
	 *  Returns the File pointing to where current class is stored.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #javaFile(java.lang.String)
	 */
	protected File beanFile() throws BuildException
	{
		String tokenizedSourcePath = this.context.getSourcePath();
		StringTokenizer tok = new StringTokenizer( tokenizedSourcePath, File.pathSeparator );
		while( tok.hasMoreTokens() )
		{
			File f = new File( tok.nextToken(), javaFile( fullClassName() ) );
			if( f.lastModified() != 0 )
			{
				return f;
			}
		}
		throw new IllegalStateException( "Couldn't find bean " + fullClassName()
				 + "in sourcepath " + tokenizedSourcePath );
	}

	private void writeObject( java.io.ObjectOutputStream out ) throws IOException
	{
		out.defaultWriteObject();
		out.writeObject( remoteClassPattern );
		out.writeObject( localClassPattern );
		out.writeObject( homeClassPattern );
		out.writeObject( localHomeClassPattern );
		out.writeObject( entityPkClassPattern );
		out.writeObject( dataObjectClassPattern );
		out.writeObject( entityBmpClassPattern );
		out.writeObject( entityCmpClassPattern );
		out.writeObject( sessionClassPattern );
		out.writeObject( dataObjectClassnames );
	}

	private void readObject( java.io.ObjectInputStream in ) throws IOException, ClassNotFoundException
	{
		in.defaultReadObject();
		remoteClassPattern = ( String ) in.readObject();
		localClassPattern = ( String ) in.readObject();
		homeClassPattern = ( String ) in.readObject();
		localHomeClassPattern = ( String ) in.readObject();
		entityPkClassPattern = ( String ) in.readObject();
		dataObjectClassPattern = ( String ) in.readObject();
		entityBmpClassPattern = ( String ) in.readObject();
		entityCmpClassPattern = ( String ) in.readObject();
		sessionClassPattern = ( String ) in.readObject();
		dataObjectClassnames = ( HashMap ) in.readObject();
	}

	/**
	 *  Holds class/method of the two end points of a relationship.
	 *
	 * @created    August 28, 2001
	 */
	public static class RelationHolder
	{
		public ClassDoc   left;
		public MethodDoc  leftMethod;
		public ClassDoc   right;
		public MethodDoc  rightMethod;
	}
}
