package xdoclet.web;

import java.util.*;
import java.io.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import com.sun.javadoc.*;

import xdoclet.*;
import xdoclet.web.vendor.*;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 2, 2001
 * @version    $Revision: 1.11 $
 */
public class WebDocletTask extends DocletTask
{
	protected WebXmlSubTask deploymentdescriptor;
	protected JspTaglibSubTask jsptaglib;
	protected JBossWebXmlSubTask jbosswebxml;
	protected StrutsConfigXmlSubTask strutsconfigxml;
	protected WebWorkConfigPropertiesSubTask webworkconfig;
	protected WebWorkActionDocsSubTask webworkdocs;

	public WebXmlSubTask createDeploymentdescriptor()
	{
		deploymentdescriptor = new WebXmlSubTask();
		return deploymentdescriptor;
	}

	public JspTaglibSubTask createJsptaglib()
	{
		jsptaglib = new JspTaglibSubTask();
		return jsptaglib;
	}

	public JBossWebXmlSubTask createJbosswebxml()
	{
		jbosswebxml = new JBossWebXmlSubTask();
		return jbosswebxml;
	}

	public StrutsConfigXmlSubTask createStrutsconfigxml()
	{
		strutsconfigxml = new StrutsConfigXmlSubTask();
		return strutsconfigxml;
	}

	public WebWorkConfigPropertiesSubTask createWebworkconfigproperties()
	{
		webworkconfig = new WebWorkConfigPropertiesSubTask();
		return webworkconfig;
	}

	public WebWorkActionDocsSubTask createWebworkactiondocs()
	{
		webworkdocs = new WebWorkActionDocsSubTask();
		return webworkdocs;
	}

	protected Vector getSubTasks()
	{
		Vector subtasks = super.getSubTasks();

		subtasks.addElement( this.deploymentdescriptor );
		subtasks.addElement( this.jsptaglib );
		subtasks.addElement( this.jbosswebxml );
		subtasks.addElement( this.strutsconfigxml );
		subtasks.addElement( this.webworkconfig );
		subtasks.addElement( this.webworkdocs );

		return subtasks;
	}
}
