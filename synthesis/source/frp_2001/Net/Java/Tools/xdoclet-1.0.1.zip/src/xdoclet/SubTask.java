package xdoclet;

import java.beans.Introspector;
import java.util.*;
import java.text.DateFormat;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.MessageFormat;
import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;

import xdoclet.util.*;
import org.apache.log4j.Category;

/**
 *  <p>
 *
 *  An abstract base class for all sub-tasks. Common code and the contract is
 *  defined here.</p> <p>
 *
 *  SubTask derives from xdoclet.util.TemplateEngine, where the template engine
 *  is implemented. Through inheritance it uses some of methods of
 *  TemplateEngine to control the template logic.</p> <p>
 *
 *  It is Serializable because the forked javadoc process uses serialization to
 *  load the settings specified by user via the Ant build file. All the fields
 *  that are set by Ant are serializable, the rest are transient because they
 *  are mostly state holders.</p> <p>
 *
 *  Because of the way Ant is designed all setter methods automatically are
 *  settable config parameters. Note that by default init() method inherits
 *  default setting from the containing task via DocletContext. Setter methods
 *  in sub-task gives the user finer control over config parameters of the
 *  sub-task.</p>
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 16, 2001
 * @version    $Revision: 1.49 $
 */
public abstract class SubTask
		 extends TemplateEngine implements java.io.Serializable
{
	/**
	 *  Destination directory where generated files will be stored.
	 *
	 * @see    #setDestdir(java.io.File)
	 */
	protected File     destDir = null;

	/**
	 *  Merge directory where XDoclet searches for external files that are to be
	 *  merged. Merge files internal to xdoclet.jar are picked from xdoclet.jar's
	 *  root instead of using mergeDir which is for external files. By default it
	 *  inherits its value from the shared DocletContext which is itself filled
	 *  with values set by user for the task.
	 *
	 * @see    #setMergedir(java.io.File)
	 */
	protected File     mergeDir = null;

	/**
	 *  Flag that indicates whether validation of generated XML should occur.
	 */
	protected boolean  validateXML = true;

	/**
	 *  The context info shared by all subtasks.
	 *
	 * @see    #init(xdoclet.DocletContext,com.sun.javadoc.RootDoc)
	 */
	protected transient DocletContext context;

	/**
	 *  Javadoc Doclet API's root. All ClassDocs are accessible from this root.
	 *
	 * @see    #init(xdoclet.DocletContext,com.sun.javadoc.RootDoc)
	 */
	protected transient RootDoc root;

	/**
	 *  The current Tag. Various template tag implementations set this value,
	 *  including looping tags such as forAllClassTags. There's no distinction
	 *  between class/method/field/contructory/whatever tags, and currentTag can
	 *  point to any one them.
	 */
	protected transient Tag currentTag;

	/**
	 *  The current method's current parameter. forAllMethodParams sets the value
	 *  while lopping over the parameters of current method.
	 *
	 * @see    #forAllMethodParams(java.lang.String)
	 */
	protected transient Parameter currentMethodParameter;

	/**
	 *  Template can use matchPattern as a place where they can put volatile
	 *  variable. You can set the value somewhere in the template and later use the
	 *  value.
	 */
	protected transient String matchPattern;

	/**
	 *  The current config parameter name. forAllConfigParameters sets the value
	 *  while lopping over values of the config parameter. Note that this is only
	 *  used for config parameters of type java.util.Vector. Other tags working
	 *  with config parameters use current config parameter name to lookup the
	 *  value of that parameter. For each config parameter there exists a
	 *  corresponding getter method in the subtask, so all public getter methods
	 *  can be used as config parameters.
	 *
	 * @see    #currentConfigParamIndex
	 * @see    #getConfigParameter(java.lang.String)
	 * @see    #forAllConfigParameters(java.lang.String,java.util.Properties)
	 */
	protected transient String currentConfigParam = null;

	/**
	 *  The current config parameter index. forAllConfigParameters sets the value
	 *  while lopping over values of the config parameter.
	 *
	 * @see    #currentConfigParam
	 * @see    #getConfigParameter(java.lang.String)
	 * @see    #forAllConfigParameters(java.lang.String,java.util.Properties)
	 */
	protected transient int currentConfigParamIndex = -1;

	/**
	 *  The current toekn. Currently forAllParameterTypes and forAllClassTagTokens
	 *  set it and currentToken returns the value. Tokens are computed for cases
	 *  where the value should be tokenized by a set of delimiters.
	 */
	protected transient String currentToken;

	/**
	 *  The StringTokenizer object doing the tokenization. It should be shared by
	 *  different tag implementations, that's why its defined class-level.
	 */
	protected transient StringTokenizer tagTokenizer;
	protected final static String XDOCLET_VERSION = "1.0";

	/**
	 *  Used by isOfType. isOfType searches for the type according to the type
	 *  parameter. TYPE_CONCRETE_TYPE specifies that only the type of the current
	 *  entity (class, method return type, parameter type depdening on the context)
	 *  should be checked for equality.
	 */
	protected final static int TYPE_CONCRETE_TYPE = 0;

	/**
	 *  Used by isOfType. isOfType searches for the type according to the type
	 *  parameter. TYPE_SUPERCLASS specifies that not only the type of the current
	 *  entity (class, method return type, parameter type depdening on the context)
	 *  should be checked for equality, but also direct superclasses and interfaces
	 *  of the entity.
	 */
	protected final static int TYPE_SUPERCLASS = 1;

	/**
	 *  Used by isOfType. isOfType searches for the type according to the type
	 *  parameter. TYPE_HIERARCHY specifies that not only the type of the current
	 *  entity (class, method return type, parameter type depdening on the context)
	 *  should be checked for equality, but also superclasses and interfaces of the
	 *  entity and recursively superclasses and interfaces.
	 */
	protected final static int TYPE_HIERARCHY = 2;

	/**
	 *  Used for setting the timestamp for xdoclet-generated marker in generated
	 *  files.
	 */
	protected final static DateFormat dateFormatter = DateFormat.getDateTimeInstance();

	/**
	 *  Default delimiter used inside a xdoclet tag attribute.
	 */
	protected final static String PARAMETER_DELIMITER = ",";

	/**
	 *  Sets the value of destDir.
	 *
	 * @param  dir  The new Destdir value
	 * @see         #destDir
	 */
	public void setDestdir( File dir )
	{
		destDir = dir;
	}

	/**
	 *  Sets the value of mergeDir.
	 *
	 * @param  dir  The new Mergedir value
	 * @see         #mergeDir
	 */
	public void setMergedir( File dir )
	{
		mergeDir = dir;
	}

	/**
	 *  Sets the value of validateXml. Can be accessed by subclasses generating
	 *  XML, so they can choose to validate the XML if appropriate.
	 *
	 * @param  flag  The new Validatexml value
	 * @see          #validateXML
	 */
	public void setValidatexml( boolean flag )
	{
		validateXML = flag;
	}

	/**
	 *  Returns the setter method name for the current method by prefixing the
	 *  method name with a 'set' and removing the getter method's 'get' or 'is'
	 *  prefixes, if any.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Description of Exception
	 * @see                        #methodNameWithoutPrefix()
	 * @see                        #getterMethod()
	 * @see                        #methodNameWithoutPrefix()
	 * @doc:tag                    type="content"
	 */
	public String setterMethod() throws BuildException
	{
		return "set" + methodNameWithoutPrefix();
	}

	/**
	 *  Returns the value for the specified configuration parameter. Null if the
	 *  config parameter not found.
	 *
	 * @param  param_name          Description of Parameter
	 * @return                     The ConfigParameter value
	 * @exception  BuildException  Description of Exception
	 */
	public Object getConfigParameter( String param_name ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "getConfigParameter" );

		Object param_value = null;

		try
		{
			// If the config param is of type java.util.Vector
			if( currentConfigParamIndex != -1 && param_name.equals( currentConfigParam ) )
			{
				java.lang.reflect.Method m = getClass().getMethod( "get" + currentConfigParam, null );

				// param_value = element at currentConfigParamIndex index of the Vector
				param_value = ( ( java.util.Vector ) m.invoke( this, new Class[]{Integer.class} ) ).elementAt( currentConfigParamIndex );
			}
			else
			{
				// Not a Vector-based config param, simply do a toStrig on the config param's value
				java.lang.reflect.Method m = getClass().getMethod( "get" + param_name, null );

				param_value = m.invoke( this, null ).toString();
			}
		}
		catch( NoSuchMethodException ex )
		{
			cat.error( param_name + " config parameter not found", ex );
		}
		catch( Exception ex )
		{
			cat.error( "Exception", ex );
		}
		return param_value;
	}

	/**
	 *  Returns 'get' or 'is' getter prefix part of the current method. Returns
	 *  empty string if the method doesn't start with either of te two getter
	 *  prefixes.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Description of Exception
	 * @doc:tag                    type="content"
	 */
	public String getterPrefix() throws BuildException
	{
		if( getCurrentMethod().name().startsWith( "get" ) )
		{
			return "get";
		}
		else if( getCurrentMethod().name().startsWith( "is" ) )
		{
			return "is";
		}
		else
		{
			return "";
		}
	}

	/**
	 *  Returns the getter method name for the current method by prefixing the
	 *  method name with the proper getter prefix.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Description of Exception
	 * @see                        #methodNameWithoutPrefix()
	 * @see                        #setterMethod()
	 * @see                        #getterPrefix()
	 * @see                        #methodNameWithoutPrefix()
	 * @doc:tag                    type="content"
	 */
	public String getterMethod() throws BuildException
	{
		return getterPrefix() + methodNameWithoutPrefix();
	}

	/**
	 *  Evaluate the body block if the value is of a primitive type.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Description of Exception
	 * @see                        #ifIsNotPrimitive(java.lang.String,java.util.Properties)
	 * @see                        #isPrimitiveType(java.lang.String)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="value" optional="false" description="A
	 *      string containsing the type name."
	 */
	public void ifIsPrimitive( String template, Properties attributes ) throws BuildException
	{
		String value = attributes.getProperty( "value" );

		if( isPrimitiveType( value ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if the value is not of a primitive type.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsPrimitive(java.lang.String,java.util.Properties)
	 * @see                        #isPrimitiveType(java.lang.String)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="value" optional="false" description="A
	 *      string containsing the type name."
	 */
	public void ifIsNotPrimitive( String template, Properties attributes ) throws BuildException
	{
		String value = attributes.getProperty( "value" );

		if( !isPrimitiveType( value ) )
		{
			generate( template );
		}
	}

	/**
	 *  Initializes SubTask. It inherits values of the config parameters if not
	 *  explicitly defined for this sub-task.
	 *
	 * @param  context             The doclet execution context
	 * @param  root                A Javadoc RootDoc object, this is the object all
	 *      ClassDocs are accessible from.
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #execute()
	 */
	public void init( DocletContext context, RootDoc root ) throws BuildException
	{
		this.context = context;
		this.root = root;

		if( destDir == null )
		{
			//not explicitly set by user, then inherit it from task
			destDir = new File( context.getDestDir() );
		}

		Category cat = getCategory( SubTask.class, "merge" );
		cat.debug( "MergeDir = " + mergeDir );

		if( mergeDir == null && context.getMergeDir() != null )
		{
			//not explicitly set by user, then inherit it from task
			mergeDir = new File( context.getMergeDir() );
		}

		cat.debug( "MergeDir = " + mergeDir );
	}

	/**
	 *  Called to start execution of the sub-task.
	 *
	 * @exception  BuildException  Throw to stop the build process
	 */
	public abstract void execute() throws BuildException;

	/**
	 *  The comment for the current method or current class.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #methodComment(java.util.Properties)
	 * @see                        #classComment(java.util.Properties)
	 * @doc:tag                    type="content"
	 * @doc:param                  name="no-comment-signs" optional="true"
	 *      description="If true then don't decorate the comment with comment
	 *      signs."
	 */
	public String comment( Properties attributes ) throws BuildException
	{
		//if class comment
		if( getCurrentMethod() == null || !getCurrentMethod().containingClass().equals( getCurrentClass() ) )
		{
			return classComment( attributes );
		}
		else
		{
			//if method comment
			return methodComment( attributes );
		}
	}

	/**
	 *  The comment for the current method.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #classComment(java.util.Properties)
	 * @doc:tag                    type="content"
	 * @doc:param                  name="no-comment-signs" optional="true"
	 *      values="true,false" description="If true then don't decorate the
	 *      comment with comment signs."
	 */
	public String methodComment( Properties attributes ) throws BuildException
	{
		String no_comment_signs = attributes.getProperty( "no-comment-signs" );

		if( no_comment_signs != null && no_comment_signs.equalsIgnoreCase( "true" ) )
		{
			return getCurrentMethod().commentText();
		}

		char[] spaces = getIndentChars( attributes );
		Tag[] method_tags = getCurrentMethod().tags();

		if( method_tags.length > 0 )
		{
			StringBuffer result = new StringBuffer();

			result.append( spaces ).append( "/**" ).append( DocletUtil.LINE_SEPARATOR );

			result.append( spaces ).append( " *  " ).append( getCurrentMethod().commentText() ).append( DocletUtil.LINE_SEPARATOR );

			for( int i = 0; i < method_tags.length; i++ )
			{
				if( method_tags[i].name().lastIndexOf( ':' ) == -1 )
				{
					//all of our ejbdoclet-specific tags have a ":"

					result.append( spaces ).append( " *  " ).append( method_tags[i].name() ).append( ' ' ).append( method_tags[i].text() ).append( DocletUtil.LINE_SEPARATOR );
				}
			}

			result.append( spaces ).append( " */" );

			return result.toString();
		}
		else
		{
			return "";
		}
	}

	/**
	 *  The comment for the current class.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #methodComment(java.util.Properties)
	 * @doc:tag                    type="content"
	 * @doc:param                  name="no-comment-signs" optional="true"
	 *      description="If true then don't decorate the comment with comment
	 *      signs."
	 */
	public String classComment( Properties attributes ) throws BuildException
	{
		String no_comment_signs = attributes.getProperty( "no-comment-signs" );

		if( no_comment_signs != null && no_comment_signs.equalsIgnoreCase( "true" ) )
		{
			return getCurrentClass().commentText();
		}

		char[] spaces = getIndentChars( attributes );
		Tag[] class_tags = getCurrentClass().tags();

		if( class_tags.length > 0 )
		{
			StringBuffer result = new StringBuffer();

			result.append( spaces ).append( "/**" ).append( DocletUtil.LINE_SEPARATOR );

			result.append( spaces ).append( " * " ).append( getCurrentClass().commentText() ).append( DocletUtil.LINE_SEPARATOR );

			for( int i = 0; i < class_tags.length; i++ )
			{
				if( class_tags[i].name().lastIndexOf( ':' ) == -1 )
				{
					//all of our ejbdoclet-specific tags have a ":"

					result.append( spaces ).append( " * " ).append( class_tags[i].name() ).append( ' ' );
					if( context.getExcludedTags().indexOf( class_tags[i].name() ) == -1 )
					{
						result.append( class_tags[i].text() ).append( DocletUtil.LINE_SEPARATOR );
					}
					else
					{
						result.append( "XDOCLET " ).append( XDOCLET_VERSION ).append( DocletUtil.LINE_SEPARATOR );
					}
				}
			}

			Calendar now = Calendar.getInstance();

			result.append( spaces ).append( " * @xdoclet-generated at " ).append( dateFormatter.format( now.getTime() ) ).append( DocletUtil.LINE_SEPARATOR );
			result.append( spaces ).append( " */" );

			return result.toString();
		}
		else
		{
			return "";
		}
	}

	/**
	 *  Returns the current package name. If we're in the context of a package
	 *  iteration, this is the name of the current package. If we're in the context
	 *  of a class iteration without a package iteration, return the name of the
	 *  current class' package.
	 *
	 * @return                     current package name
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String packageName() throws BuildException
	{
		if( getCurrentPackage() != null )
		{
			// first try to get the name from current package. It exists if
			return getCurrentPackage().name();
		}
		else
		{
			return getCurrentClass().containingPackage().name();
		}
	}

	/**
	 *  Returns the not-full-qualified name of the current class without the
	 *  package name.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String className() throws BuildException
	{
		return getCurrentClass().name();
	}

	/**
	 *  Returns the full-qualified name of the current class with the package name.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String fullClassName() throws BuildException
	{
		return getCurrentClass().qualifiedName();
	}

	/**
	 *  Returns the full-qualified name of the superclass of the current class.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String fullSuperclassName() throws BuildException
	{
		if( getCurrentClass().superclass() != null )
		{
			return getCurrentClass().superclass().qualifiedName();
		}
		else
		{
			return "java.lang.Object";
		}
	}

	/**
	 *  Returns the not-full-qualified name of the full-qualified class name
	 *  specified in the body of this tag.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void classOf( String template ) throws BuildException
	{
		String fullClassName = outputOf( template );
		out.print( fullClassName.substring( fullClassName.lastIndexOf( "." ) + 1 ) );
	}

	/**
	 *  Returns the not-full-qualified package name of the full-qualified class
	 *  name specified in the body of this tag.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void packageOf( String template ) throws BuildException
	{
		String fullClassName = outputOf( template );
		out.print( fullClassName.substring( 0, fullClassName.lastIndexOf( "." ) ) );
	}

	/**
	 *  Iterates over all imported classes and packages imported in the current
	 *  class and returns the list. The composed string has 'import ' in front of
	 *  each import statement, and each import is in a separate line.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public String importedList() throws BuildException
	{
		StringBuffer st = new StringBuffer();
		PackageDoc[] packages = getCurrentClass().importedPackages();
		ClassDoc[] classes = getCurrentClass().importedClasses();
		for( int i = 0; i < packages.length; i++ )
		{
			st.append( "import " ).append( packages[i].name() ).append( ".*;" ).append( DocletUtil.LINE_SEPARATOR );
		}
		for( int i = 0; i < classes.length; i++ )
		{
			st.append( "import " ).append( classes[i].toString() ).append( ";" ).append( DocletUtil.LINE_SEPARATOR );
		}
		return st.toString();
	}

	/**
	 *  Iterates over all exceptions thrown by the current method and returns a
	 *  string containing definition of all those exceptions.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="method" optional="true" description="The
	 *      method name of which exceptions list is extracted. If not specified
	 *      then current method is used."
	 * @doc:param                  name="skip" optional="true" description="A
	 *      comma-separated list of exception that should be skipped and not put
	 *      into the list."
	 */
	public String exceptionList( Properties attributes ) throws BuildException
	{
		String skipExceptions = attributes.getProperty( "skip" );
		String methodName = attributes.getProperty( "method" );

		ClassDoc[] exceptions = null;

		if( methodName == null )
		{
			exceptions = getCurrentMethod().thrownExceptions();
		}
		else
		{
			exceptions = getMethodDocForMethodName( methodName ).thrownExceptions();
		}

		if( exceptions == null )
		{
			exceptions = getCurrentMethod().thrownExceptions();
		}

		StringBuffer st = new StringBuffer();
		String type = null;

		for( int i = 0; i < exceptions.length; i++ )
		{
			type = exceptions[i].toString();

			if( skipExceptions == null || skipExceptions.indexOf( type ) == -1 )
			{
				if( i == 0 && skipExceptions == null )
				{
					st.append( "throws " );
				}
				else if( i > 0 || skipExceptions.length() != 0 )
				{
					st.append( "," );
				}

				st.append( type );
			}
		}

		return st.toString();
	}

	/**
	 *  Iterates over all exceptions thrown by the current method and returns a
	 *  string containing definition of all those parameters.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="includeDefinition" optional="true"
	 *      values="true,false" description="If true then include the parameter
	 *      type of parameters in the composed string."
	 */
	public String parameterList( Properties attributes ) throws BuildException
	{
		String incl = ( String ) attributes.get( "includeDefinition" );

		Parameter[] parameters = getCurrentMethod().parameters();
		StringBuffer st = new StringBuffer();
		String type = null;
		String name = null;

		for( int i = 0; i < parameters.length; i++ )
		{
			type = parameters[i].type().toString();
			name = parameters[i].name();

			if( i > 0 )
			{
				st.append( "," );
			}
			if( incl == null || !incl.equals( "false" ) )
			{
				st.append( type ).append( ' ' ).append( name );
			}
			else
			{
				st.append( name );
			}
		}

		return st.toString();
	}

	/**
	 *  Evaluate the body block if current class is abstract.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsClassNotAbstract(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsClassAbstract( String template ) throws BuildException
	{
		if( getCurrentClass().isAbstract() )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if current class is not abstract.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsClassAbstract(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsClassNotAbstract( String template ) throws BuildException
	{
		if( !getCurrentClass().isAbstract() )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body block if current method is abstract.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsNotAbstract(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsAbstract( String template ) throws BuildException
	{
		if( getCurrentMethod().isAbstract() )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body block if current method is not abstract.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsAbstract(java.lang.String)
	 * @doc:tag                    type="block"
	 */
	public void ifIsNotAbstract( String template ) throws BuildException
	{
		if( !getCurrentMethod().isAbstract() )
		{
			generate( template );
		}
	}

	/**
	 *  Gets the value of the parameter specified by paramName of current tag, and
	 *  assuming the value has the format of a typical method definition extracts
	 *  of parameter types out of it and evaluates the body for each parameter
	 *  type.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The parameter name that its value is used for extracting
	 *      parameter types out of it."
	 */
	public void forAllParameterTypes( String template, Properties attributes ) throws BuildException
	{
		String param_name = attributes.getProperty( "paramName" );
		String value = getParameterValue( DocletUtil.getText( currentTag ), param_name, -1 );
		String old_token = currentToken;

		// findAll(int p1, int p2) -> int p1, int p2
		value = value.substring( value.indexOf( '(' ) + 1, value.lastIndexOf( ')' ) );

		StringTokenizer st = new StringTokenizer( value, ",", false );

		while( st.hasMoreTokens() )
		{
			currentToken = st.nextToken();

			int spacepos_between_type_and_name = currentToken.lastIndexOf( ' ' );
			spacepos_between_type_and_name = spacepos_between_type_and_name == -1 ? currentToken.lastIndexOf( '\t' ) : spacepos_between_type_and_name;

			if( spacepos_between_type_and_name != -1 )
			{
				currentToken = currentToken.substring( 0, spacepos_between_type_and_name ).trim();
			}

			generate( template );
		}

		currentToken = old_token;
	}

	/**
	 *  Pops current class from top of stack.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #pushClass(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 */
	public void popClass( String template, Properties attributes ) throws BuildException
	{
		popCurrentClass();
	}

	/**
	 *  Pushes the class specified by value parameter to top of stack making it the
	 *  current class.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #popClass(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="value" optional="false"
	 *      values="return-type,whatever class name" description="If return-type
	 *      specified then push current method return type, else find the ClassDoc
	 *      for the class name and push it."
	 */
	public void pushClass( String template, Properties attributes ) throws BuildException
	{
		String value = attributes.getProperty( "value", "return-type" );
		ClassDoc cur_class = null;

		if( value.equalsIgnoreCase( "return-type" ) )
		{
			cur_class = getCurrentMethod().returnType().asClassDoc();

			if( cur_class == null )
			{
				throw new BuildException( "Javadoc couldn't load class " + getCurrentMethod().returnType().typeName() + ", add it to the sourcepath please." );
			}
		}
		else
		{
			cur_class = root.classNamed( value );

			if( cur_class == null )
			{
				throw new BuildException( "Javadoc couldn't load class " + value + ", add it to the sourcepath please." );
			}
		}

		pushCurrentClass( cur_class );
	}

	/**
	 *  Evaluate the body block if the entity is not of the specified type.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsOfType(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="value" optional="false"
	 *      values="class,return-type" description="If class then check current
	 *      class's type, if return-type then check current method return type."
	 * @doc:param                  name="type" optional="false" description="The
	 *      type we are checking against."
	 * @doc:param                  name="extent" optional="true"
	 *      values="concrete-type,superclass,hierarchy" description="Specifies the
	 *      extent of the type search. If concrete-type then only check the
	 *      concrete type, if superclass then check also superclass, if hierarchy
	 *      then search the whole hierarchy and find if the class is of the
	 *      specified type. Default is hierarchy."
	 */
	public void ifIsNotOfType( String template, Properties attributes ) throws BuildException
	{
		ifIsOfType_Impl( template, attributes, false );
	}

	/**
	 *  Evaluate the body block if the entity is of the specified type.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsNotOfType(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="value" optional="true"
	 *      values="class,return-type" description="If class then check current
	 *      class's type, if return-type then check current method return type.
	 *      Default is class."
	 * @doc:param                  name="type" optional="false" description="The
	 *      type we are checking against."
	 * @doc:param                  name="extent" optional="true"
	 *      values="concrete-type,superclass,hierarchy" description="Specifies the
	 *      extent of the type search. If concrete-type then only check the
	 *      concrete type, if superclass then check also superclass, if hierarchy
	 *      then search the whole hierarchy and find if the class is of the
	 *      specified type. Default is hierarchy."
	 */
	public void ifIsOfType( String template, Properties attributes ) throws BuildException
	{
		ifIsOfType_Impl( template, attributes, true );
	}

	/**
	 *  Iterates over all classes loaded by javadoc and evaluates the body of the
	 *  tag for each class. It descards classes that have a xdoclet-generated class
	 *  tag defined.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="abstract" optional="true"
	 *      values="true,false" description="If true then accept abstract classes
	 *      also; otherwise don't."
	 * @doc:param                  name="type" optional="true" description="For all
	 *      classes by the type."
	 * @doc:param                  name="extent" optional="true"
	 *      values="concrete-type,superclass,hierarchy" description="Specifies the
	 *      extent of the type search. If concrete-type then only check the
	 *      concrete type, if superclass then check also superclass, if hierarchy
	 *      then search the whole hierarchy and find if the class is of the
	 *      specified type. Default is hierarchy."
	 */
	public void forAllClasses( String template, Properties attributes ) throws BuildException
	{
		String abstract_str = attributes.getProperty( "abstract" );
		boolean accept_abstract_classes = stringToBoolean( abstract_str, true );

		ClassDoc[] classes = getAllClasses();
		ClassDoc cur_class = null;

		for( int i = 0; i < classes.length; i++ )
		{
			cur_class = classes[i];
			setCurrentClass( cur_class );

			if( isDocletGenerated( getCurrentClass() ) || ( getCurrentClass().isAbstract() == true && accept_abstract_classes == false ) )
			{
				continue;
			}

			String type_name = attributes.getProperty( "type" );
			int extent = extractExtentType( attributes.getProperty( "extent" ) );

			if( type_name != null )
			{
				if( isOfType( cur_class, type_name, extent ) )
				{
					generate( template );
				}
			}
			else
			{
				generate( template );
			}
		}
	}

	/**
	 *  Iterates over all packages loaded by javadoc. Subsequent calls to
	 *  forAllClasses will only iterate over the classes in the current package.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="abstract" optional="true"
	 *      values="true,false" description="If true then accept abstract classes
	 *      also; otherwise don't."
	 * @doc:param                  name="type" optional="true" description="For all
	 *      classes by the type."
	 * @doc:param                  name="extent" optional="true"
	 *      values="concrete-type,superclass,hierarchy" description="Specifies the
	 *      extent of the type search. If concrete-type then only check the
	 *      concrete type, if superclass then check also superclass, if hierarchy
	 *      then search the whole hierarchy and find if the class is of the
	 *      specified type. Default is hierarchy."
	 */
	public void forAllPackages( String template, Properties attributes ) throws BuildException
	{
		ClassDoc[] classes = root.classes();
		SortedSet packages = new TreeSet();

		for( int i = 0; i < classes.length; i++ )
		{
			packages.add( classes[i].containingPackage() );
		}

		PackageDoc cur_package = null;

		for( Iterator packageIterator = packages.iterator(); packageIterator.hasNext();  )
		{
			cur_package = ( PackageDoc ) packageIterator.next();
			setCurrentPackage( cur_package );
			generate( template );
		}
		// restore current package to null, so subsequent class iterations can
		// perform outside the context of a current packages
		setCurrentPackage( null );
	}

	/**
	 *  Loops through all methods for all classes after first sorting all the
	 *  methods.
	 *
	 * @param  template    The body of the block tag
	 * @param  attributes  The attributes of the template tag
	 * @doc:tag            type="block"
	 * @doc:param          name="type" optional="true" description="For all classes
	 *      by the type."
	 * @doc:param          name="extent" optional="true"
	 *      values="concrete-type,superclass,hierarchy" description="Specifies the
	 *      extent of the type search. If concrete-type then only check the
	 *      concrete type, if superclass then check also superclass, if hierarchy
	 *      then search the whole hierarchy and find if the class is of the
	 *      specified type. Default is hierarchy."
	 */
	public void forAllClassMethods( String template, Properties attributes )
	{
		String type_name = attributes.getProperty( "type" );
		int extent = extractExtentType( attributes.getProperty( "extent" ) );

		ClassDoc[] classes = getAllClasses();
		SortedSet methods = new TreeSet();

		for( int i = 0; i < classes.length; i++ )
		{
			if( type_name == null || isOfType( classes[i], type_name, extent ) )
			{
				MethodDoc[] classMethods = classes[i].methods();
				for( int j = 0; j < classMethods.length; j++ )
				{
					methods.add( classMethods[j] );
				}
			}
		}

		Iterator methodsIterator = methods.iterator();
		while( methodsIterator.hasNext() )
		{
			MethodDoc current = ( MethodDoc ) methodsIterator.next();
			setCurrentClass( current.containingClass() );
			setCurrentMethod( current );

			generate( template );
		}
	}

	/**
	 *  Returns the symbolic name of the current class. For a java bean it's the
	 *  same as the class name.
	 *
	 * @return                     The symbolic name of the current class
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String symbolicClassName() throws BuildException
	{
		return getCurrentClass().typeName();
	}

	/**
	 *  Merge contents of the file designated by the file parameter and evaluates
	 *  the body if the file is not found. It searches for the file in the
	 *  directory specified by mergeDir configuration parameter.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="file" optional="false" description="The
	 *      path to the file to be merged. The value of this parameter can have {0}
	 *      in it, if so {0} is replaced with the current class name and system
	 *      searches for the file in in mergeDir+packageName directory. {0} is for
	 *      cases where you want to define and merge a file per each class."
	 * @doc:param                  name="generateMergedFile" values="true,false"
	 *      description="If true then process the merged file also, otherwise only
	 *      merge it and do not process it. True if the default."
	 */
	public void merge( String template, Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "merge" );
		String merge_file_pattern = attributes.getProperty( "file" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "Pattern = " + merge_file_pattern );
		}
		if( merge_file_pattern != null )
		{
			String contents = getMergeFileContents( merge_file_pattern );

			if( contents != null )
			{
				String generate_merged_file = attributes.getProperty( "generateMergedFile" );

				if( generate_merged_file != null && !generate_merged_file.equalsIgnoreCase( "true" ) && !generate_merged_file.equalsIgnoreCase( "yes" ) )
				{
					out.print( contents );
				}
				else
				{
					generateUsingMergedFile( merge_file_pattern, contents );
				}
			}
			else
			{
				//use body of <EJBDoclet:merge>
				generateUsingMergedFile( getTemplateFile().toString(), template );
			}
		}
		else
		{
			cat.error( "<EJBDoclet:merge/> file parameter missing from template file, ignoring merge command." );
			generate( template );
		}
	}

	/**
	 *  Iterates over all methods of current class and evaluates the body of the
	 *  tag for each method.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="superclasses" optional="true"
	 *      values="true,false" description="If true then traverse superclasses
	 *      also, otherwise look up the tag in current concrete class only."
	 * @doc:param                  name="sort" optional="true" values="true,false"
	 *      description="If true then sort the methods list."
	 */
	public void forAllMethods( String template, Properties attributes ) throws BuildException
	{
		boolean superclasses = stringToBoolean( attributes.getProperty( "superclasses" ), true );
		boolean sort = stringToBoolean( attributes.getProperty( "sort" ), true );
		ClassDoc cur_class = getCurrentClass();
		List already = new ArrayList();

		do
		{
			MethodDoc[] methods = cur_class.methods();
			MethodDoc methodFound = null;
			if( sort == true )
			{
				List the_list = Arrays.asList( methods );

				//sort methods
				Collections.sort( the_list,
					new Comparator()
					{
						public int compare( Object o1, Object o2 )
						{
							MethodDoc m1 = ( MethodDoc ) o1;
							MethodDoc m2 = ( MethodDoc ) o2;

							return m1.name().compareTo( m2.name() );
						}

						public boolean equals( Object obj )
						{
							return obj == this;
							//dumb
						}
					} );

				methods = ( MethodDoc[] ) the_list.toArray( methods );
			}

			for( int j = 0; j < methods.length; j++ )
			{
				if( superclasses == false || ( superclasses == true && methods[j].containingClass() == cur_class ) )
				{

					// We can not use contains because it is based on equals() and
					// we need to compare based on compareTo()
					Iterator i = already.iterator();
					boolean contained = false;
					while( i.hasNext() )
					{
						if( ( ( MethodDoc ) i.next() ).compareTo( methods[j] ) == 0 )
						{
							contained = true;
						}
						if( contained )
						{
							break;
						}
					}
					if( contained == false )
					{
						setCurrentMethod( methods[j] );
						already.add( methods[j] );
						generate( template );
					}
				}
			}

			if( superclasses == true )
			{
				cur_class = cur_class.superclass();
			}
			else
			{
				break;
			}
		}while ( cur_class != null );
	}

	/**
	 *  Returns the type of the current method parameter, current method parameter
	 *  is set inside a forAllMethodParams tag in each iteration.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String methodParamType() throws BuildException
	{
		return currentMethodParameter.type().toString();
	}

	/**
	 *  Iterates over all parameters of current method and evaluates the body of
	 *  the tag for each method.
	 *
	 * @param  template            The body of the block tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 */
	public void forAllMethodParams( String template ) throws BuildException
	{
		Parameter[] parameters = getCurrentMethod().parameters();

		for( int k = 0; k < parameters.length; k++ )
		{
			currentMethodParameter = parameters[k];

			generate( template );
		}
	}

	/**
	 *  Evaluates the body if current class doesn't have at least one tag with the
	 *  specified name.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 * @doc:param                  name="error" description="Show this error
	 *      message if no tag found."
	 */
	public void ifDoesntHaveClassTag( String template, Properties attributes ) throws BuildException
	{
		if( !ifHasTag_Impl( template, attributes, true ) )
		{
			generate( template );
		}
		else
		{
			String error = attributes.getProperty( "error" );

			if( error != null )
			{
				out.print( error );
			}
		}
	}

	/**
	 *  Evaluates the body if current class has at least one tag with the specified
	 *  name.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 * @doc:param                  name="error" description="Show this error
	 *      message if no tag found."
	 */
	public void ifHasClassTag( String template, Properties attributes ) throws BuildException
	{
		if( ifHasTag_Impl( template, attributes, true ) )
		{
			generate( template );
		}
		else
		{
			String error = attributes.getProperty( "error" );

			if( error != null )
			{
				out.print( error );
			}
		}
	}

	/**
	 *  Evaluates the body if current method doesn't have at least one tag with the
	 *  specified name.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="error" description="Show this error
	 *      message if no tag found."
	 */
	public void ifDoesntHaveMethodTag( String template, Properties attributes ) throws BuildException
	{
		if( !ifHasTag_Impl( template, attributes, false ) )
		{
			generate( template );
		}
		else
		{
			String error = attributes.getProperty( "error" );

			if( error != null )
			{
				out.print( error );
			}
		}
	}

	/**
	 *  Evaluates the body if current method has at least one tag with the
	 *  specified name.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="error" description="Show this error
	 *      message if no tag found."
	 */
	public void ifHasMethodTag( String template, Properties attributes ) throws BuildException
	{
		if( ifHasTag_Impl( template, attributes, false ) )
		{
			generate( template );
		}
		else
		{
			String error = attributes.getProperty( "error" );

			if( error != null )
			{
				out.print( error );
			}
		}
	}

	/**
	 *  A utility method used by ifMethodTagValueEquals/ifMethodTagValueNotEquals
	 *  and ifClassTagValueEquals/ifClassTagValueNotEquals, return true if the
	 *  value of the tag/parameter equals with value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @param  for_class           Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	public boolean ifTagValueEquals_Impl( String template, Properties attributes, boolean for_class ) throws BuildException
	{
		Tag the_tag = null;
		String value = attributes.getProperty( "value" );

		// if currentTag is set first check against it, this is needed for forAll... tags
		// where currentTag is set by these tags and we don't need/want to delegate the
		// lookup to the surronding current class or method.
		if( currentTag != null && currentTag.name().equals( "@" + attributes.getProperty( "tagName" ) ) )
		{
			the_tag = currentTag;
		}
		else
		{
			Tag[] tags = null;

			if( for_class == true )
			{
				tags = DocletUtil.getTagsByName( getCurrentClass(), attributes.getProperty( "tagName" ) );
			}
			else
			{
				tags = DocletUtil.getTagsByName( getCurrentMethod(), attributes.getProperty( "tagName" ) );
			}

			if( tags != null && tags.length > 0 )
			{
				the_tag = tags[0];
			}
			//only the first tag is evaluated
		}

		String param_name = attributes.getProperty( "paramName" );
		String param_num = attributes.getProperty( "paramNum" );

		if( param_name != null || param_num != null )
		{
			//if has the specified param

			String tag_value = DocletUtil.getText( the_tag );
			String param_value = null;
			int param_int = -1;

			if( param_num != null )
			{
				param_int = Integer.valueOf( param_num ).intValue();
			}

			param_value = tokenizeValue( attributes, getParameterValue( tag_value, param_name, param_int ) );

			if( param_value != null && param_value.equals( value ) )
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			if( the_tag.text().trim().equals( value ) )
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}

	/**
	 *  Evaluate the body if the match variable equals with the value of the
	 *  specified tag/parameter.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="values" description="The valid values for
	 *      the parameter, comma separated. An error message is printed if the
	 *      parameter value is not one of the values."
	 * @doc:param                  name="default" description="The default value is
	 *      returned if parameter not specified by user for the tag."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 */
	public void ifClassTagValueMatches( String template, Properties attributes ) throws BuildException
	{
		String wanted_tag_value = getTagValue( attributes, true );

		if( wanted_tag_value.equals( matchPattern ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body if value for the class tag equals the specified value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifClassTagValueEquals( String template, Properties attributes ) throws BuildException
	{
		if( ifTagValueEquals_Impl( template, attributes, true ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body if value for the class tag not equals the specified
	 *  value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifClassTagValueNotEquals( String template, Properties attributes ) throws BuildException
	{
		if( !ifTagValueEquals_Impl( template, attributes, true ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body if value for the method tag equals the specified value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 */
	public void ifMethodTagValueEquals( String template, Properties attributes ) throws BuildException
	{
		if( ifTagValueEquals_Impl( template, attributes, false ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluates the body if value for the method tag not equals the specified
	 *  value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 */
	public void ifMethodTagValueNotEquals( String template, Properties attributes ) throws BuildException
	{
		if( !ifTagValueEquals_Impl( template, attributes, false ) )
		{
			generate( template );
		}
	}

	/**
	 *  Iterates over all class tags with the specified tagName and evaluates the
	 *  body of the tag for each class tag.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="values" description="The valid values for
	 *      the parameter, comma separated. An error message is printed if the
	 *      parameter value is not one of the values."
	 * @doc:param                  name="default" description="The default value is
	 *      returned if parameter not specified by user for the tag."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 */
	public String classTagValue( Properties attributes ) throws BuildException
	{
		return getTagValue( attributes, true );
	}

	/**
	 *  Sets the value of match variable. Match variable serves as a variable for
	 *  templates, you set it somewhere in template and look it up somewhere else
	 *  in temaplte. This tag does not return any content, it just sets the match
	 *  variable.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 */
	public String classTagValueMatch( Properties attributes ) throws BuildException
	{
		matchPattern = getTagValue( attributes, true );
		return "";
	}

	/**
	 *  Returns the value of match variable. Match variable serves as a variable
	 *  for templates, you set it somewhere in template and look it up somewhere
	 *  else in temaplte.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String matchValue() throws BuildException
	{
		return matchPattern;
	}

	/**
	 *  Iterates over all method tags with the specified tagName for the current
	 *  method probably inside of a forAllMethodTags body.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="paramName" description="The parameter
	 *      name. If not specified, then the raw content of the tag is returned."
	 * @doc:param                  name="paramNum" description="The zero-based
	 *      parameter number. It's used if the user used the space-separated format
	 *      for specifying parameters."
	 * @doc:param                  name="values" description="The valid values for
	 *      the parameter, comma separated. An error message is printed if the
	 *      parameter valueis not one of the values."
	 * @doc:param                  name="default" description="The default value is
	 *      returned if parameter not specified by user for the tag."
	 */
	public String methodTagValue( Properties attributes ) throws BuildException
	{
		return getTagValue( attributes, false );
	}

	/**
	 *  Iterates over all tags of current class with the name tagName and evaluates
	 *  the body of the tag for each method.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 * @doc:param                  name="tagKey" description="A tag property that
	 *      will be used as a unique key. This is used to avoid duplicate code due
	 *      to similar tags in superclasses."
	 */
	public void forAllClassTags( String template, Properties attributes ) throws BuildException
	{
		boolean superclasses = stringToBoolean( attributes.getProperty( "superclasses" ), true );
		Tag[] tags = DocletUtil.getTagsByName( getCurrentClass(), attributes.getProperty( "tagName" ), superclasses );
		Set done = new HashSet();
		matchPattern = null;

		String tagKey = attributes.getProperty( "tagKey" );

		for( int i = 0; i < tags.length; i++ )
		{
			if( tagKey != null )
			{
				String key = getParameterValue( DocletUtil.getText( tags[i] ), tagKey, -1 );
				if( !done.add( key ) )
				{
					// no change to set, therefore we must have already done this tag
					continue;
				}
			}

			currentTag = tags[i];

			generate( template );
		}

		currentTag = null;
		matchPattern = null;
	}

	/**
	 *  Iterates over all tokens in specified class tag with the name tagName and
	 *  evaluates the body for every token.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 * @doc:param                  name="superclasses" values="true,false"
	 *      description="If true then traverse superclasses also, otherwise look up
	 *      the tag in current concrete class only."
	 * @doc:param                  name="delimiter" description="delimiter for the
	 *      StringTokenizer. consult javadoc for java.util.StringTokenizer default
	 *      is ','"
	 * @doc:param                  name="skip" description="how many tokens to skip
	 *      on start"
	 */
	public void forAllClassTagTokens( String template, Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "forAllClassTagTokens" );
		boolean superclasses = stringToBoolean( attributes.getProperty( "superclasses" ), true );
		// get class tag value to iterate over
		String tagValue = getTagValue( attributes, true );
		String delimiter = attributes.getProperty( "delimiter" );
		String s = attributes.getProperty( "skip" );
		int skip;
		try
		{
			skip = Integer.valueOf( attributes.getProperty( "skip" ) ).intValue();
		}
		catch( Throwable t )
		{
			skip = 0;
		}

		if( delimiter == null )
		{
			if( cat.isDebugEnabled() )
			{
				cat.debug( "got null delimiter - forAllClassTagTokens" );
			}
			delimiter = PARAMETER_DELIMITER;
		}

		tagTokenizer = new StringTokenizer( tagValue, delimiter, false );
		currentToken = "";
		matchPattern = null;

		for( int i = 0; tagTokenizer.hasMoreTokens() && i < skip; i++ )
		{
			tagTokenizer.nextToken();
		}
		while( tagTokenizer.hasMoreTokens() )
		{
			currentToken = tagTokenizer.nextToken();
			if( cat.isDebugEnabled() )
			{
				cat.debug( "generate current token: " + currentToken );
			}
			generate( template );
		}

		currentToken = null;
		tagTokenizer = null;
		matchPattern = null;
	}


	/**
	 *  Returns current token inside forAllClassTagTokens.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     value of currently processed token
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String currentToken( Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "currentToken" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "current token:  " + currentToken );
		}
		if( currentToken == null )
		{
			cat.error( "null token found" );
			return "";
		}
		else
		{
			return currentToken;
		}
	}

	/**
	 *  Skips current token. returns empty string.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String skipToken( Properties attributes ) throws BuildException
	{
		if( tagTokenizer.hasMoreTokens() )
		{
			tagTokenizer.nextToken();
		}
		return "";
	}

	/**
	 *  Iterates over all methods of current class and evaluates the body of the
	 *  tag for each method.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag name."
	 */
	public void forAllMethodTags( String template, Properties attributes ) throws BuildException
	{
		Tag[] tags = getCurrentMethod().tags( attributes.getProperty( "tagName" ) );

		for( int i = 0; i < tags.length; i++ )
		{
			currentTag = tags[i];

			String m = getTagValue( attributes, false );
			if( matchPattern == null )
			{
				generate( template );
			}
			else if( matchPattern != null && ( matchPattern.equals( m ) || m.equals( "*" ) ) )
			{
				generate( template );
			}
		}

		currentTag = null;
	}

	/**
	 *  Returns the values of a configuration parameter with the name paramName.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 */
	public String configParameterValue( Properties attributes ) throws BuildException
	{
		String param_name = attributes.getProperty( "paramName" );
		Object config_param = getConfigParameter( param_name );

		if( config_param != null )
		{
			return config_param.toString();
		}
		else
		{
			return "";
		}
	}

	/**
	 *  Evaluate the body for all configuration parameters with the name paramName.
	 *  It's basically used for java.util.Vector-based parameter types, and the
	 *  body is evaluated for all items of the Vector.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 */
	public void forAllConfigParameters( String template, Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "forAllConfigParameters" );

		String param_name = attributes.getProperty( "paramName" );
		String param_value = "";

		try
		{
			java.lang.reflect.Method m = getClass().getMethod( "get" + param_name, null );
			Vector configParams = ( java.util.Vector ) m.invoke( this, null );

			for( int i = 0; i < configParams.size(); i++ )
			{
				currentConfigParam = param_name;
				currentConfigParamIndex = i;

				generate( template );
			}

			currentConfigParam = null;
			currentConfigParamIndex = -1;
		}
		catch( NoSuchMethodException ex )
		{
			cat.error( param_name + " config parameter not found", ex );
		}
		catch( Exception ex )
		{
			cat.error( "Exception", ex );
		}
	}

	/**
	 *  Evaluate the body if the value of the configuration parameter is greater or
	 *  equal to value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifConfigParamGreaterOrEquals( String template, Properties attributes ) throws BuildException
	{
		if( ifConfigParamGreaterOrEquals_Impl( template, attributes ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body if the value of the configuration parameter is not
	 *  greater or equal to value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifConfigParamNotGreaterOrEquals( String template, Properties attributes ) throws BuildException
	{
		if( !ifConfigParamGreaterOrEquals_Impl( template, attributes ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body if the value of the configuration parameter equals value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifConfigParamEquals( String template, Properties attributes ) throws BuildException
	{
		if( ifConfigParamEquals_Impl( template, attributes ) )
		{
			generate( template );
		}
	}

	/**
	 *  Evaluate the body if the value of the configuration parameter equals value.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="block"
	 * @doc:param                  name="paramName" optional="false"
	 *      description="The config parameter name, it's a parameter settable from
	 *      within build file."
	 * @doc:param                  name="value" optional="false" description="The
	 *      desired value."
	 */
	public void ifConfigParamNotEquals( String template, Properties attributes ) throws BuildException
	{
		if( !ifConfigParamEquals_Impl( template, attributes ) )
		{
			generate( template );
		}
	}

	/**
	 *  Return standard javadoc of current class.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String firstSentenceDescription() throws BuildException
	{
		String desc = getCurrentClass().firstSentenceTags().length > 0 ? getCurrentClass().firstSentenceTags()[0].text().trim() : "";
		// Check if there is a \n and replace it by a space
		return checkForWrap( desc );
	}

	/**
	 *  Return standard javadoc of current method.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String firstSentenceDescriptionOfCurrentMethod() throws BuildException
	{
		return getCurrentMethod().firstSentenceTags().length > 0 ? getCurrentMethod().firstSentenceTags()[0].text().trim() : "";
	}

	/**
	 *  Returns the return type of the current method.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String methodType() throws BuildException
	{
		return getCurrentMethod().returnType().qualifiedTypeName() + getCurrentMethod().returnType().dimension();
	}

	/**
	 *  Returns the name of the current method.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String methodName( Properties attributes ) throws BuildException
	{
		if( attributes != null )
		{
			String value = ( String ) attributes.get( "value" );
			if( value != null )
			{
				String m = getCurrentMethod().name().substring( Integer.parseInt( value ) );
				// replace first character to lowercase
				char firstU = m.charAt( 0 );
				char firstL = Character.toLowerCase( firstU );
				return firstL + m.substring( 1 );
			}
		}

		return getCurrentMethod() != null ? getCurrentMethod().name() : "";
	}

	/**
	 *  Returns the name of the current method without the first three characters.
	 *  Used for cases where the method name without the get/set prefix is needed.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String methodNameWithoutPrefix() throws BuildException
	{
		return methodNameWithoutPrefix( getCurrentMethod() );
	}

	/**
	 *  Merge with modified SubTask.methodNameWithoutPrefix
	 *
	 * @param  cur_method  Description of Parameter
	 * @return             Description of the Returned Value
	 */
	public String methodNameWithoutPrefix( MethodDoc cur_method )
	{
		String str = cur_method.name();

		if( str.startsWith( "get" ) || str.startsWith( "set" ) )
		{
			return str.substring( 3 );
		}
		else if( str.startsWith( "is" ) )
		{
			return str.substring( 2 );
		}
		else
		{
			return str;
		}
	}

	/**
	 *  Returns the current method name. Used inside block elements.
	 *
	 * @return    Description of the Returned Value
	 */
	public String currentMethodName()
	{
		return getCurrentMethod().name();
	}

	/**
	 *  Returns the property name extracted from the current method name. Remove
	 *  any getter/setter prefix from method name and decapitalize it.
	 *
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 */
	public String propertyName() throws BuildException
	{
		return Introspector.decapitalize( methodNameWithoutPrefix() );
	}

	/**
	 *  Generates an id attribute based on the given tag values. This is used for
	 *  generating id attribute for XML elements.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @doc:tag                    type="content"
	 * @doc:param                  name="tagName" optional="false" description="The
	 *      tag from which the value of the id is calculated."
	 * @doc:param                  name="paramNames" optional="false"
	 *      description="Comma separated list of parameter names. The list is
	 *      ordered, preferred param is before another param which is less
	 *      important. If the param exists, its value is taken and used as the id
	 *      value."
	 */
	public String id( Properties attributes ) throws BuildException
	{
		String tag_name = attributes.getProperty( "tagName" );
		String param_names = attributes.getProperty( "paramNames" );

		if( tag_name == null )
		{
			System.out.println( "tagName parameter not specified for id element. Ignoring id element." );
			return "";
		}

		if( param_names == null )
		{
			System.out.println( "paramNames parameter not specified for id element. Ignoring id element." );
			return "";
		}

		StringTokenizer st = new StringTokenizer( param_names, ",", false );
		//should have only one tag:
		Tag tag = DocletUtil.getTagsByName( getCurrentClass(), tag_name )[0];
		String tag_value = DocletUtil.getText( tag );
		String param_value = null;

		while( st.hasMoreTokens() )
		{
			param_value = getParameterValue( tag_value, st.nextToken(), -1 );

			if( param_value != null )
			{
				return param_value.replace( '/', '_' );
			}
		}

		return tag_name;
	}

	/**
	 *  Evaluate the body if current class has a method with the specified
	 *  name+parameters. If parameters not specified then any method with the given
	 *  name and any set of parameters is considered equal to the given method name
	 *  and so the test result is positive and the body is evaluated.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifDoesntHaveMethod(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="name" optional="false" description="The
	 *      name of the method we're searching for its existence in current class."
	 * @doc:param                  name="parameters" optional="true"
	 *      description="We're searching for a method that has the exact set of
	 *      parameters specified in parameters param."
	 * @doc:param                  name="delimiter" optional="true"
	 *      description="The parameters param is delimited by the string specified
	 *      in delimiter parameter."
	 */
	public void ifHasMethod( String template, Properties attributes ) throws BuildException
	{
		ifHasMethod_Impl( template, attributes, true );
	}

	/**
	 *  Evaluate the body if current class doesn't have a method with the specified
	 *  name+parameters. If parameters not specified then any method with the given
	 *  name and any set of parameters is considered equal to the given method name
	 *  and so the test result is positive and the body is evaluated.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifHasMethod(java.lang.String,java.util.Properties)
	 * @doc:tag                    type="block"
	 * @doc:param                  name="name" optional="false" description="The
	 *      name of the method we're searching for its existence in current class."
	 * @doc:param                  name="parameters" optional="true"
	 *      description="We're searching for a method that has the exact set of
	 *      parameters specified in parameters param."
	 * @doc:param                  name="delimiter" optional="true"
	 *      description="The parameters param is delimited by the string specified
	 *      in delimiter parameter."
	 */
	public void ifDoesntHaveMethod( String template, Properties attributes ) throws BuildException
	{
		ifHasMethod_Impl( template, attributes, false );
	}

	/**
	 *  Returns the current package name as path
	 *
	 * @return     current package name as path
	 * @doc:tag    type="content"
	 */
	public String packageNameAsPath()
	{
		return packageName().replace( '.', '/' );
	}

	/**
	 *  Searches for the MethodDoc of the method with name methodName and returns
	 *  it.
	 *
	 * @param  methodName  Description of Parameter
	 * @return             The MethodDocForMethodName value
	 */
	protected MethodDoc getMethodDocForMethodName( String methodName )
	{
		if( methodName != null )
		{
			MethodDoc[] methods = getCurrentClass().methods();

			for( int i = 0; i < methods.length; i++ )
			{
				String name = methods[i].name();

				if( name.equals( methodName ) )
				{
					return methods[i];
				}
			}
		}

		return null;
	}

	/**
	 *  Return the Value of a tag specified in a Properties object. This method
	 *  work on the currentTag object variable, matchs it against the Tag specified
	 *  in the attributes Properties and returns the value of the specified tag.
	 *  This method is used by various tag implementations, specially classTagValue
	 *  and methodTagValue.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @param  for_class           if true, then a fifth property superclasses is
	 *      searched, if this is set to true, then the tag is also searched in all
	 *      superclasses of current class. If for_class is set to false, current
	 *      method is searched for the tag.
	 * @return                     The TagValue value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #classTagValue(java.util.Properties)
	 * @see                        #methodTagValue(java.util.Properties)
	 */
	protected String getTagValue( Properties attributes, boolean for_class ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "getTagValue" );

		String tag_name = attributes.getProperty( "tagName" );
		String param_name = attributes.getProperty( "paramName" );
		String param_num = attributes.getProperty( "paramNum" );
		String valid_values = attributes.getProperty( "values" );
		String default_value = attributes.getProperty( "default" );

		String value = null;
		Tag the_tag = null;

		// First use currentTag, then if null or not the tag we're searching for
		// continue searching
		if( currentTag != null && currentTag.name().equals( "@" + tag_name ) )
		{
			the_tag = currentTag;
		}
		else
		{
			Tag[] tags = null;

			if( for_class == true )
			{
				boolean superclasses = stringToBoolean( attributes.getProperty( "superclasses" ), true );

				tags = DocletUtil.getTagsByName( getCurrentClass(), tag_name, superclasses );
			}
			else
			{
				tags = DocletUtil.getTagsByName( getCurrentMethod(), tag_name );
			}

			if( tags != null && tags.length > 0 )
			{
				// In case multiple tags are found, only the first is used.
				// Don't use this method if you want to get the value of a tag other
				// than the first, in other words don't use it if it's legal to have
				// multiple tags of that name for the entity.
				the_tag = tags[0];
			}
		}

		if( the_tag != null )
		{
			value = DocletUtil.getText( the_tag );

			// param_num is legacy! We previously supported space-separated tag values.
			// It's now only used with the value of 0 for single-value tags.
			if( param_name != null || param_num != null )
			{
				int param_int = -1;

				if( param_num != null )
				{
					param_int = Integer.valueOf( param_num ).intValue();
				}

				value = getParameterValue( value, param_name, param_int );

				if( value == null )
				{
					if( default_value != null )
					{
						return default_value;
					}
					else
					{
						mandatoryParamNotFound( param_name, tag_name, for_class );
					}
				}
			}

			if( cat.isDebugEnabled() )
			{
				cat.debug( tag_name + "-------" + param_name + "--------" + value );
			}

			// tokenize value if necesary
			value = tokenizeValue( attributes, value );

			if( valid_values == null )
			{
				return value;
			}
			else
			{
				// Check if user specified a valid value
				if( valid_values.indexOf( value ) != -1 )
				{
					return value;
				}
				else
				{
					invalidParamValueFound( param_name, tag_name, value, valid_values, for_class );
				}
			}
		}
		else
		{
			// If the tag/param not found use default if any
			if( default_value == null )
			{
				return "";
			}
			else
			{
				return default_value;
			}
		}

		//will never reach here though!
		return null;
	}

	/**
	 *  A utility method used for merging a file used by <EJBDoclet:merge/>tag. If
	 *  the merge_file_pattern parameter has a {0} in it then the {0} is replaced
	 *  with the sybolic class name of the current class, and the package structure
	 *  of the class is prefixed to it. If not search is done for the exact file
	 *  with the name specified in merge_file_pattern. Both of these two searches
	 *  search for the file in root directory designated of mergeDir config
	 *  parameter. It uses xdoclet.util.FileManager to load the file. FileManager
	 *  caches the content so that subsequent tries to load the file are served
	 *  from memory, without reloading the file again and again.
	 *
	 * @param  merge_file_pattern  The exact file name or a string that has a {0}
	 *      in it. {0} is substituted by symbolic class name of current class.
	 * @return                     The content of the text file.
	 * @see                        #merge(java.lang.String,java.util.Properties)
	 * @see                        #packageNameToPath(java.lang.String)
	 * @see                        #symbolicClassName()
	 * @see                        xdoclet.util.FileManager
	 */
	protected String getMergeFileContents( String merge_file_pattern )
	{
		Category cat = getCategory( SubTask.class, "merge" );

		if( merge_file_pattern.indexOf( "{0}" ) != -1 )
		{
			String ejb_name = MessageFormat.format( merge_file_pattern, new Object[]{symbolicClassName()} );
			String package_name = getCurrentClass().containingPackage().name();
			String merge_file_name = packageNameToPath( package_name ) + File.separator + ejb_name;
			File merge_file = new File( this.mergeDir + merge_file_name );

			if( cat.isDebugEnabled() )
			{
				cat.debug( "Search for File " + merge_file );
			}

			if( merge_file.exists() )
			{
				if( cat.isDebugEnabled() )
				{
					cat.debug( "Search for File OK" );
				}
				return FileManager.getFileContent( merge_file.toString(), this.getClass() );
			}
			else
			{
				if( cat.isDebugEnabled() )
				{
					cat.debug( "Search for File KO" );
				}
			}
		}
		else
		{
			File merge_file = new File( this.mergeDir + File.separator + merge_file_pattern );

			if( merge_file.exists() )
			{
				return FileManager.getFileContent( merge_file.toString(), this.getClass() );
			}
		}

		//was not found in mergedir, try the jar
		return FileManager.getFileContent( "/" + merge_file_pattern, this.getClass() );
	}

	/**
	 *  Parses and searches the value string for the parameter named param_name and
	 *  returns its value. Parameters are in name="value" format or if param_num
	 *  specified then can also be in space=separated format, which are used in
	 *  cases where the tag has only a single parameter.
	 *
	 * @param  value               Description of Parameter
	 * @param  param_name          Description of Parameter
	 * @param  param_num           Description of Parameter
	 * @return                     The ParameterValue value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected String getParameterValue( String value, String param_name, int param_num ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "getParameterValue" );
		cat.debug( "[value " + value + "] [param_name " + param_name + "] [param_num " + param_num + "]" );

		if( value == null )
		{
			cat.debug( "null value passed, returning null" );
			return null;
		}

		String attr_name = "";
		String attr_value = "";
		int i = 0;
		int params_parsed = 0;

		while( i < value.length() )
		{
			i = skipWhitespace( value, i );

			//explicitly to handle the tailing white spaces
			if( i >= value.length() )
			{
				break;
			}

			//read attribute name
			while( i < value.length() && value.charAt( i ) != '=' && ( !Character.isWhitespace( value.charAt( i ) ) ) )
			{
				attr_name += value.charAt( i );
				i++;
			}

			i = skipWhitespace( value, i );

			//skip = sign
			if( i < value.length() && value.charAt( i ) == '=' )
			{
				i++;
			}
			else
			{
				i = skipWhitespace( value, i );

				if( i < value.length() && value.charAt( i ) == '"' )
				{
					//if single value item like @blabla "value"
					if( params_parsed == 0 && value.trim().endsWith( "\"" ) )
					{
						String trimed_value = value.trim();

						return trimed_value.substring( 1, trimed_value.length() - 1 );
						//return the whole line minus start/end " signs as the parameter
					}
					else
					{
						cat.debug( "missing '=' sign: " + value );
						throw new BuildException( "Error in @tag: = sign expected after parameter name, class=" + getCurrentClass().qualifiedName() + ", @tags=" + value );
					}
				}
				else
				{
					//if single value item with no = and " signs
					if( params_parsed == 0 && param_num == 0 )
					{
						// we might have " - XXX: this code needs to be checked... dim.
						value = value.trim();

						if( value.startsWith( "\"" ) && value.startsWith( "\"" ) )
						{
							return value.substring( 1, value.length() - 1 );
						}

						return value;
						//return the whole line as the parameter
					}
					else
					{
						cat.debug( "malformed value: " + value );
						throw new BuildException( "Error in @tag: parameters should be in paramName=\"paramValue\" format, class=" + getCurrentClass().qualifiedName() + ", @tags=" + value );
					}
				}
			}

			i = skipWhitespace( value, i );

			//skip " sign
			if( i < value.length() && value.charAt( i ) == '"' )
			{
				i++;
			}
			else
			{
				throw new BuildException( "Error in @tag: \" sign expected but something different found, class=" + getCurrentClass().qualifiedName() + ", @tags=" + value );
			}

			//read attribute value
			while( i < value.length() )
			{
				if( value.charAt( i ) == '"' )
				{
					//if not escaped \" char
					if( value.charAt( i - 1 ) != '\\' )
					{
						//if last " (last parameter) in whole value string
						if( i + 1 >= value.length() )
						{
							break;
						}
						else
						{
							//if tailing " with whitespace after it
							if( Character.isWhitespace( value.charAt( i + 1 ) ) )
							{
								break;
							}
							else
							{
								//probably user does not know escaping is needed!
								throw new BuildException( "Error in @tag: to put \" in a parameter value you need to escape \" character with \\\", class=" + getCurrentClass().qualifiedName() + ", @tags=" + value );
							}
						}
					}
					else
					{
						//remove \"
						attr_value = attr_value.substring( 0, attr_value.length() - 1 );
						//append a single "
						attr_value += "\"";
						i++;

						continue;
					}
				}

				attr_value += value.charAt( i );
				i++;
			}

			//skip " sign
			if( i < value.length() && value.charAt( i ) == '"' )
			{
				i++;
			}
			else
			{
				throw new BuildException( "Error in @tag: tailing \" sign expected but not found, class=" + getCurrentClass().qualifiedName() + ", @tags=" + value );
			}

			if( param_name != null && attr_name.equalsIgnoreCase( param_name ) )
			{
				return attr_value;
			}
			else
			{
				params_parsed++;
				attr_name = "";
				attr_value = "";
			}
		}

		//param not found
		return null;
	}

	/**
	 *  Utility method to get classes for iteration used by various methods. The
	 *  result depends on the context: are we within a forAllPackages iteration or
	 *  not.
	 *
	 * @return    The AllClasses value
	 */
	protected ClassDoc[] getAllClasses()
	{
		ClassDoc[] classes;
		if( getCurrentPackage() == null )
		{
			// not in a forAllPackages context
			classes = root.classes();
		}
		else
		{
			classes = getCurrentPackage().allClasses();
		}
		return classes;
	}

	/**
	 *  Converts the package name to a valid path with File.separator characters
	 *  instead of . characters.
	 *
	 * @param  package_name  Description of Parameter
	 * @return               Description of the Returned Value
	 * @todo            This method could be static, and should maybe be
	 *      refactored to some util class? (Aslak)
	 */
	protected String packageNameToPath( String package_name )
	{
		StringTokenizer st = new StringTokenizer( package_name, "." );
		String result = "";

		while( st.hasMoreTokens() )
		{
			result += ( File.separator + st.nextToken() );
		}

		return result;
	}

	/**
	 *  Implementation of ifIsOfType and ifIsNotOfType tags.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @param  condition           Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifIsOfType(java.lang.String,java.util.Properties)
	 * @see                        #ifIsNotOfType(java.lang.String,java.util.Properties)
	 */
	protected void ifIsOfType_Impl( String template, Properties attributes, boolean condition ) throws BuildException
	{
		String value = attributes.getProperty( "value" );
		String type_name = attributes.getProperty( "type" );
		int extent = extractExtentType( attributes.getProperty( "extent" ) );
		Type cur_type = null;

		if( value == null || value.equalsIgnoreCase( "class" ) )
		{
			cur_type = getCurrentClass();
		}
		else if( value.equalsIgnoreCase( "return-type" ) )
		{
			cur_type = getCurrentMethod().returnType();

			if( cur_type.asClassDoc() != null )
			{
				cur_type = cur_type.asClassDoc();
			}
		}

		if( isOfType( cur_type, type_name, extent ) == condition )
		{
			generate( template );
		}
	}

	/**
	 *  Throws a BuildException exception to stop the build process. The
	 *  BuildException has an informative message to help user find out the casue
	 *  of the error casued by not specifying a mandatory parameter for a tag.
	 *
	 * @param  param_name          Description of Parameter
	 * @param  tag_name            Description of Parameter
	 * @param  for_class           Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected void mandatoryParamNotFound( String param_name, String tag_name, boolean for_class ) throws BuildException
	{
		if( for_class == true )
		{
			throw new BuildException( "Mandatory parameter '" + param_name + "' missing for @" + tag_name + " tag in " + fullClassName() + " class" );
		}
		else
		{
			throw new BuildException( "Mandatory parameter '" + param_name + "' missing for @" + tag_name + " tag in " + currentMethodName() + " method of " + fullClassName() + " class" );
		}
	}

	/**
	 *  Throws a BuildException exception to stop the build process. The
	 *  BuildException has an informative message to help user find out the casue
	 *  of the error casued by specifying an incorrect value for a parameter of a
	 *  tag.
	 *
	 * @param  param_name          Description of Parameter
	 * @param  tag_name            Description of Parameter
	 * @param  value               Description of Parameter
	 * @param  valid_values        Description of Parameter
	 * @param  for_class           Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected void invalidParamValueFound( String param_name, String tag_name, String value, String valid_values, boolean for_class ) throws BuildException
	{
		if( for_class == true )
		{
			throw new BuildException( "The value '" + value + "' specified for parameter '" + param_name + "' of tag @" + tag_name + " tag in " + fullClassName() + " class is not valid. Valid values for this tag are: {" + valid_values + "}." );
		}
		else
		{
			throw new BuildException( "The value '" + value + "' specified for parameter '" + param_name + "' of tag @" + tag_name + " tag in " + fullClassName() + " class is not valid. Valid values for this tag are: {" + valid_values + "}." );
		}
	}

	/**
	 *  Processes the file specified in merge_file_pattern that has the text
	 *  content contents. It resets currentLineNum to 0 upon calling generate() and
	 *  restores it back to its previous value. It also sets and restores
	 *  templateFile.
	 *
	 * @param  merge_file_pattern  Description of Parameter
	 * @param  contents            Description of Parameter
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        xdoclet.util.TemplateEngine#setTemplateFile(java.io.File)
	 * @see                        xdoclet.util.TemplateEngine#currentLineNum
	 */
	protected void generateUsingMergedFile( String merge_file_pattern, String contents ) throws BuildException
	{
		int line_num = currentLineNum;
		File prev_template_file = getTemplateFile();

		setTemplateFile( new File( merge_file_pattern ) );
		currentLineNum = 0;

		generate( contents );

		setTemplateFile( prev_template_file );
		currentLineNum = line_num;
	}

	/**
	 *  The implementation of ifConfigParamGreaterOrEquals and
	 *  ifConfigParamNotGreaterOrEquals tags. Currently the value can only be of a
	 *  float type like "2.0".
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifConfigParamGreaterOrEquals(java.lang.String,java.util.Properties)
	 * @see                        #ifConfigParamNotGreaterOrEquals(java.lang.String,java.util.Properties)
	 */
	protected boolean ifConfigParamGreaterOrEquals_Impl( String template, Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "ifConfigParamGreaterOrEquals_Impl" );

		String param_name = attributes.getProperty( "paramName" );
		String param_value = attributes.getProperty( "value" );

		if( param_name != null )
		{
			try
			{
				java.lang.reflect.Method m = getClass().getMethod( "get" + param_name, null );
				String config_value = ( String ) m.invoke( this, null );

				if( param_value.equals( config_value ) )
				{
					return true;
				}
				else
				{
					if( Float.parseFloat( config_value ) >= Float.parseFloat( param_value ) )
					{
						return true;
					}

					//maybe check for other formats here: "2.0 PD2" for example
				}
			}
			catch( NoSuchMethodException ex )
			{
				cat.error( param_name + " config parameter not found", ex );
			}
			catch( Exception ex )
			{
				cat.error( "Exception", ex );
			}
		}
		else
		{
			cat.error( "<EJBDoclet:ifConfigParamGreaterOrEquals/> version parameter missing from template file, ignoring ifConfigParamGreaterOrEquals command." );
			return true;
		}
		return false;
	}

	/**
	 *  The implementation of ifConfigParamEquals and ifConfigParamEquals tags.
	 *  Currently the value can only be of a float type like "2.0".
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #ifConfigParamEquals(java.lang.String,java.util.Properties)
	 * @see                        #ifConfigParamNotEquals(java.lang.String,java.util.Properties)
	 */
	protected boolean ifConfigParamEquals_Impl( String template, Properties attributes ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "ifConfigParamEquals_Impl" );
		String param_name = attributes.getProperty( "paramName" );
		String param_value = attributes.getProperty( "value" );

		if( param_name != null )
		{
			try
			{
				java.lang.reflect.Method m = getClass().getMethod( "get" + param_name, null );
				String config_value = ( String ) m.invoke( this, null );

				if( param_value.equals( config_value ) )
				{
					return true;
				}
			}
			catch( NoSuchMethodException ex )
			{
				cat.error( param_name + " config parameter not found" );
			}
			catch( Exception ex )
			{
				cat.error( "Exception", ex );
			}
		}
		else
		{
			cat.error( "<EJBDoclet:ifConfigParamGreaterOrEquals/> version parameter missing from template file, ignoring ifConfigParamGreaterOrEquals command." );
			return true;
		}
		return false;
	}

	/**
	 *  A utility method used for generating the dest_file based on template_file
	 *  template file.
	 *
	 * @param  dest_file           the path to the destination file prepended by
	 *      value of the destDir configuration parameter.
	 * @param  template_file_name  the template file name
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected void generateFileUsingTemplate( String dest_file, String template_file_name ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "generateFileUsingTemplate" );
		ClassDoc[] classes = getAllClasses();
		File file = new File( destDir.toString(), dest_file );

		/*
		 * File beanFile  = new File( destDir.toString(), javaFile( fullClassName() ) );
		 * How to check modification timestamps???
		 * if( file.exists() )
		 * {
		 * if( file.lastModified() > beanFile.lastModified() )
		 * {
		 * continue;
		 * }
		 * }
		 */

		file.getParentFile().mkdirs();

		setTemplateFile( new File( template_file_name ) );
		String content = FileManager.getFileContent( getTemplateFile().toString(), this.getClass() );

		if( content != null )
		{
			try
			{
				out = new PrettyPrintWriter( new BufferedWriter( new FileWriter( file ) ) );

				currentLineNum = 0;
				generate( content );
				out.close();
			}
			catch( IOException ex )
			{
				cat.error( "An error occured while writing output to file " + file, ex );
			}
		}
	}

	/**
	 *  A utility method used by ifHasClassTag/ifDoesntHaveClassTag and
	 *  ifHasMethodTag/ifDoesntHaveMethodTag, return true if at least one tag
	 *  exists with the specified name.
	 *
	 * @param  template            The body of the block tag
	 * @param  attributes          The attributes of the template tag
	 * @param  for_class           Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	protected boolean ifHasTag_Impl( String template, Properties attributes, boolean for_class ) throws BuildException
	{
		String tag_name = attributes.getProperty( "tagName" );
		String param_name = attributes.getProperty( "paramName" );
		String param_num = attributes.getProperty( "paramNum" );
		String value = null;

		// if currentTag is set first check against it, this is needed for forAll... tags
		// where currentTag is set by these tags and we don't need/want to delegate the
		// lookup to the surronding current class or method.
		if( currentTag != null && currentTag.name().equals( "@" + tag_name ) )
		{
			value = DocletUtil.getText( currentTag );

			if( param_name != null || param_num != null )
			{
				//if has the specified param

				int param_int = -1;

				if( param_num != null )
				{
					param_int = Integer.valueOf( param_num ).intValue();
				}

				value = tokenizeValue( attributes, getParameterValue( value, param_name, param_int ) );
				if( value != null )
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				//the tag exists

				return true;
			}
		}
		else
		{
			Tag[] tags = null;

			if( for_class == true )
			{
				boolean superclasses = stringToBoolean( attributes.getProperty( "superclasses" ), true );

				tags = DocletUtil.getTagsByName( getCurrentClass(), tag_name, superclasses );
			}
			else
			{
				// For a method

				tags = DocletUtil.getTagsByName( getCurrentMethod(), tag_name );
			}

			if( tags != null && tags.length > 0 )
			{
				//if has the specified param

				value = DocletUtil.getText( tags[0] );

				if( param_name != null || param_num != null )
				{
					//if has the specified param

					int param_int = -1;

					if( param_num != null )
					{
						param_int = Integer.valueOf( param_num ).intValue();
					}

					value = tokenizeValue( attributes, getParameterValue( value, param_name, param_int ) );

					if( value != null )
					{
						return true;
					}
				}
				else
				{
					//the tag exists

					return true;
				}
			}

			return false;
		}
	}

	/**
	 *  A utility method used by firstSentenceDescription to replace end of file by
	 *  space.
	 *
	 * @param  pText  Description of Parameter
	 * @return        Description of the Returned Value
	 */
	protected String checkForWrap( String pText )
	{
		int lIndex = pText.indexOf( DocletUtil.LINE_SEPARATOR );
		while( lIndex >= 0 )
		{
			if( lIndex < pText.length() - 1 )
			{
				pText = pText.substring( 0, lIndex ).trim() + " " +
						pText.substring( lIndex + 1 ).trim();
			}
			else
			{
				pText = pText.substring( 0, lIndex );
			}
			lIndex = pText.indexOf( DocletUtil.LINE_SEPARATOR );
		}
		// Avoid any trailing spaces
		return pText.trim();
	}

	/**
	 *  A utility method to get the black space characters used for indenting
	 *  comments.
	 *
	 * @param  attributes          The attributes of the template tag
	 * @return                     The IndentChars value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #methodComment()
	 * @see                        #classComment()
	 * @see                        #comment()
	 */
	private char[] getIndentChars( Properties attributes ) throws BuildException
	{
		String indent_str = attributes.getProperty( "indent" );

		if( indent_str == null )
		{
			return new char[0];
		}

		int indent = new Integer( indent_str ).intValue();
		char[] spaces = new char[indent];

		for( int i = 0; i < indent; i++ )
		{
			spaces[i] = ' ';
		}

		return spaces;
	}

	/**
	 *  The implementation of ifHasMethod and ifDoesntHaveMethod tags.
	 *
	 * @param  template    The body of the block tag
	 * @param  attributes  The attributes of the template tag
	 * @param  has_method  Description of Parameter
	 * @see                #ifHasMethod(java.lang.String,java.util.Properties)
	 * @see                #ifDoesntHaveMethod(java.lang.String,java.util.Properties)
	 * @see                #hasMethod()
	 */
	private void ifHasMethod_Impl( String template, Properties attributes, boolean has_method )
	{
		String methodName = attributes.getProperty( "name" );
		String parametersStr = attributes.getProperty( "parameters" );
		String delimiter = attributes.getProperty( "delimiter" );
		String[] parameters = null;

		if( parametersStr != null )
		{
			if( delimiter == null )
			{
				delimiter = PARAMETER_DELIMITER;
			}
			parameters = DocletUtil.tokenizeDelimitedToArray( parametersStr, delimiter );
		}

		if( hasMethod( getCurrentClass(), methodName, parameters ) == has_method )
		{
			generate( template );
		}
	}

	/**
	 *  Uses tokenNumber and delimiter to tokenize value and returns desired token
	 *
	 * @param  attributes          The attributes of the template tag
	 * @param  value               Description of Parameter
	 * @return                     Description of the Returned Value
	 * @exception  BuildException  Throw to stop the build process
	 */
	private String tokenizeValue( Properties attributes, String value ) throws BuildException
	{
		Category cat = getCategory( SubTask.class, "tokenizeValue" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( attributes.toString() );
		}
		if( value == null )
		{
			return null;
		}
		String tn = attributes.getProperty( "tokenNumber" );
		// bail out if there is no token number
		if( tn == null )
		{
			return value;
		}
		int tokenNumber = Integer.valueOf( tn ).intValue();
		if( cat.isDebugEnabled() )
		{
			cat.debug( "got token number: " + tokenNumber );
		}
		String delimiter = attributes.getProperty( "delimiter" );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "currentTag: " + currentTag.toString() );
		}
		if( cat.isDebugEnabled() )
		{
			cat.debug( "attributes again: " + attributes.toString() );
		}
		if( cat.isDebugEnabled() )
		{
			cat.debug( "get property: " + attributes.getProperty( "delimiter" ) );
		}
		if( delimiter == null )
		{
			if( cat.isDebugEnabled() )
			{
				cat.debug( "got null delimiter..." );
			}
			delimiter = PARAMETER_DELIMITER;
		}
		boolean returnDelimiters = stringToBoolean( attributes.getProperty( "returnDelimiters" ), false );
		if( cat.isDebugEnabled() )
		{
			cat.debug( "delimiters: " + delimiter );
		}
		if( cat.isDebugEnabled() )
		{
			cat.debug( "tokenizing value: " + value );
		}
		StringTokenizer st = new StringTokenizer( value, delimiter, returnDelimiters );
		if( st.countTokens() < tokenNumber + 1 )
		{
			if( cat.isDebugEnabled() )
			{
				cat.debug( "Need token " + tokenNumber + " but only " + st.countTokens() + " available -- value=" + value + " delimiter=" + delimiter + " returnDelimiters=" + returnDelimiters );
			}
			return "";
		}
		if( cat.isDebugEnabled() )
		{
			cat.debug( "amount tokens found: " + st.countTokens() );
		}
		for( int i = 0; i < tokenNumber; i++ )
		{
			st.nextToken();
		}
		return st.nextToken();
	}

	private void writeObject( java.io.ObjectOutputStream out ) throws IOException
	{
		out.defaultWriteObject();
		out.writeObject( getTemplateFile() != null ? getTemplateFile().toString() : null );
	}

	private void readObject( java.io.ObjectInputStream in ) throws IOException, ClassNotFoundException
	{
		in.defaultReadObject();

		String template_file_name = ( String ) in.readObject();

		if( template_file_name != null )
		{
			setTemplateFile( new File( template_file_name ) );
		}
	}

	/**
	 *  A utility method used by isOfType to check if the class_name is in the
	 *  comma-separated derived_from string.
	 *
	 * @param  derived_from  Description of Parameter
	 * @param  class_name    Description of Parameter
	 * @return               The InTypeList value
	 * @see                  #isOfType(com.sun.javadoc.ClassDoc,java.lang.String,int)
	 */
	protected static boolean isInTypeList( String derived_from, String class_name )
	{
		StringTokenizer st = new StringTokenizer( derived_from, "," );

		while( st.hasMoreTokens() )
		{
			if( st.nextToken().equals( class_name ) )
			{
				return true;
			}
		}

		return false;
	}

	/**
	 *  Returns true if cur_class is of type type. It searches for type in
	 *  cur_class's hierarchy according to the value of extent parameter.
	 *
	 * @param  extent              Can be one of TYPE_CONCRETE_TYPE,
	 *      TYPE_SUPERCALASS or TYPE_HIERARCHY
	 * @param  type                Description of Parameter
	 * @param  cur_type            Description of Parameter
	 * @return                     The OfType value
	 * @exception  BuildException  Throw to stop the build process
	 * @see                        #isInterfaceDerivedFrom(com.sun.javadoc.ClassDoc,java.lang.String)
	 * @see                        #isInTypeList(java.lang.String,java.lang.String)
	 */
	protected static boolean isOfType( Type cur_type, String type, int extent ) throws BuildException
	{
		if( cur_type instanceof ClassDoc )
		{
			ClassDoc cur_class = ( ClassDoc ) cur_type;

			do
			{
				//if cur_class is one of the classes in the derived-from list
				if( isInTypeList( type, cur_class.qualifiedName() ) == true )
				{
					return true;
				}
				else if( extent != TYPE_CONCRETE_TYPE )
				{
					//if cur_class's direct baseclass is one of the classes in the derived-from list
					if( cur_class.superclass() != null &&
							isInTypeList( type, cur_class.superclass().qualifiedName() ) == true )
					{
						return true;
					}
					else
					{
						// if one of implemented interfaces implements somewhere in its hierarchy ...
						ClassDoc[] interfaces = cur_class.interfaces();

						for( int j = 0; j < interfaces.length; j++ )
						{
							if( isInterfaceDerivedFrom( interfaces[j], type ) == true )
							{
								return true;
							}
						}
					}
				}

				if( extent == TYPE_HIERARCHY )
				{
					cur_class = cur_class.superclass();
				}
				else
				{
					break;
				}
			}while ( cur_class != null );
		}
		else
		{
			if( cur_type.toString().equals( type ) )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		return false;
	}

	/**
	 *  Returns true if the clazz generated by xdoclet. An xdoclet generated class
	 *  has a class-level xdoclet-generated tag.
	 *
	 * @param  clazz               Description of Parameter
	 * @return                     The DocletGenerated value
	 * @exception  BuildException  Throw to stop the build process
	 * @ejb:doclet-generated       class tag defined. EJBDoclet does not try to
	 *      analyze classes that are generated by EJBDoclet itself.
	 */
	protected static boolean isDocletGenerated( ClassDoc clazz ) throws BuildException
	{
		return DocletUtil.hasTag( clazz, "xdoclet-generated", false );
	}

	/**
	 *  Returns true if name is a primitive type, in that case name contains the
	 *  string "int"/"float"/etc.
	 *
	 * @param  name  Description of Parameter
	 * @return       The PrimitiveType value
	 */
	protected static boolean isPrimitiveType( String name )
	{
		return name.equals( "int" ) ||
				name.equals( "long" ) ||
				name.equals( "float" ) ||
				name.equals( "double" ) ||
				name.equals( "boolean" ) ||
				name.equals( "byte" ) ||
				name.equals( "short" ) ||
				name.equals( "char" );
	}

	/**
	 *  Returns true if the str string starts with a getter prefix ("get" or "is").
	 *
	 * @param  str  Description of Parameter
	 * @return      The Getter value
	 */
	protected static boolean isGetter( String str )
	{
		return str.startsWith( "get" ) || str.startsWith( "is" );
	}

	/**
	 *  Returned true if cur_interface is of type derived_from. Used by isOfType.
	 *
	 * @param  cur_interface  Description of Parameter
	 * @param  derived_from   Description of Parameter
	 * @return                The InterfaceDerivedFrom value
	 * @see                   #isInTypeList(java.lang.String,java.lang.String)
	 * @see                   #isOfType(com.sun.javadoc.ClassDoc,java.lang.String,int)
	 */
	protected static boolean isInterfaceDerivedFrom( ClassDoc cur_interface, String derived_from )
	{
		//if cur_interface is one of the classes in the derived-from list
		if( isInTypeList( derived_from, cur_interface.qualifiedName() ) == true )
		{
			return true;
		}
		else
		{
			// parents

			ClassDoc[] interfaces = cur_interface.interfaces();

			for( int i = 0; i < interfaces.length; i++ )
			{
				if( isInterfaceDerivedFrom( interfaces[i], derived_from ) == true )
				{
					return true;
				}
			}

			return false;
		}
	}

	/**
	 *  Returns true if a method with the specified methodName+parameters is found
	 *  in the class clazz. The parameters array can be empty, if so any method
	 *  with any set of parameters is considered equal to the method we're
	 *  searching for. if not empty all parameters of the method must be equal to
	 *  the ones specified in parameters array to have "method equality".
	 *
	 * @param  clazz       Description of Parameter
	 * @param  methodName  Description of Parameter
	 * @param  parameters  Description of Parameter
	 * @return             Description of the Returned Value
	 */
	protected static boolean hasMethod( ClassDoc clazz, String methodName, String[] parameters )
	{
		while( clazz != null )
		{
			MethodDoc[] methods = clazz.methods();
			methodLoop :
			for( int i = 0; i < methods.length; i++ )
			{
				if( methods[i].name().equals( methodName ) )
				{
					// All parameters must be equal to have "method equality"
					Parameter[] params = methods[i].parameters();
					for( int j = 0; j < params.length; j++ )
					{
						if( parameters == null || !params[j].typeName().equals( parameters[j] ) )
						{
							continue methodLoop;
						}
					}

					// The class has the given method
					return true;
				}
			}

			// Check super class info
			clazz = clazz.superclass();
		}

		return false;
	}

	/**
	 *  Converts the full qualified class name to a valid path with File.separator
	 *  characters instead of . characters and class name postfixed by a ".java".
	 *
	 * @param  className  Description of Parameter
	 * @return            Description of the Returned Value
	 */
	protected static String javaFile( String className )
	{
		return className.replace( '.', '/' ) + ".java";
	}

	/**
	 *  Return the integer constact based on the extent_str. Used by forAllClasses
	 *  and ifIsOfType_Impl. If the string doesn't have one of the expected values
	 *  TYPE_HIERARCHY is returned.
	 *
	 * @param  extent_str  Description of Parameter
	 * @return             Description of the Returned Value
	 * @see                #forAllClasses(java.lang.String,java.util.Properties)
	 * @see                #ifIsOfType_Impl(java.lang.String,java.util.Properties,boolean)
	 * @see                #TYPE_HIERARCHY
	 * @see                #TYPE_CONCRETE_TYPE
	 * @see                #TYPE_SUPERCLASS
	 */
	protected static int extractExtentType( String extent_str )
	{
		if( extent_str == null )
		{
			return TYPE_HIERARCHY;
		}
		else if( extent_str.equalsIgnoreCase( "concrete-type" ) )
		{
			return TYPE_CONCRETE_TYPE;
		}
		else if( extent_str.equalsIgnoreCase( "superclass" ) )
		{
			return TYPE_SUPERCLASS;
		}
		else if( extent_str.equalsIgnoreCase( "hierarchy" ) )
		{
			return TYPE_HIERARCHY;
		}
		else
		{
			return TYPE_HIERARCHY;
		}
	}

	/**
	 *  A utility method for converting a string to a boolean. "yes", "no", "true"
	 *  and "false" are valid values for a boolean string. If not one of then then
	 *  the value of default_value parameter is returned.
	 *
	 * @param  str            Description of Parameter
	 * @param  default_value  Description of Parameter
	 * @return                Description of the Returned Value
	 */
	protected static boolean stringToBoolean( String str, boolean default_value )
	{
		if( str == null )
		{
			return default_value;
		}
		else
		{
			if( str.equalsIgnoreCase( "false" ) || str.equalsIgnoreCase( "no" ) )
			{
				return false;
			}
			else if( str.equalsIgnoreCase( "true" ) || str.equalsIgnoreCase( "yes" ) )
			{
				return true;
			}
			else
			{
				return default_value;
			}
		}
	}

}
