package xdoclet.doc.info;

import xdoclet.SubTask;
import xdoclet.util.DocletUtil;

import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;
import com.sun.javadoc.*;
import java.util.*;
import java.io.File;

/**
 *  Extracts tag values from classes and method docs and generates an HTML
 *  report that summarizes all occurrances of this tag in a source tree.
 *  This task can be used to generate TODO lists (recommended tag is @todo),
 *  but any tag can be extracted. What tag to look for is set from Ant
 *
 * @author       <a href="mailto:aslak.hellesoy@bekk.no">Aslak Helles�y</a>
 * @created      September 18, 2001
 * @version      $Revision: 1.3 $
 */
public class InfoSubTask extends SubTask
{
	private String     _type = "Orders";
	private Properties _properties = new Properties();
	private String     _projectname = "Project Mayhem";

	private int        _tagCount;
	private final static String TODO_TEMPLATE_FILE = "todo.j";
	private final static String TODO_FILE_NAME = "todo.html";
	private final static String TODO_STYLESHEET_NAME = "todo.css";

	// generate one of these
	private final static String ALL_CLASSES_TEMPLATE = "all-classes.j";
	private final static String ALL_PACKAGES_TEMPLATE = "all-packages.j";
	private final static String OVERVIEW_PACKAGES_TEMPLATE = "overview-packages.j";
	// generate one of these for each package. goes into package's directory.
	private final static String CLASSES_LIST_TEMPLATE = "classes-list.j";
	private final static String PACKAGE_SUMMARY_TEMPLATE = "package-summary.j";
	// generate one of these for each class. goes into package's directory.
	private final static String CLASS_DETAILS_TEMPLATE = "class-details.j";

	public InfoSubTask() {
		setType( "todo" );
	}

	public void setType( String type )
	{
		_type = type;
	}

	public void setTag( String tag )
	{
		_properties.clear();
		_properties.setProperty( "tagName", tag );
	}

	public void setProjectname( String projectname )
	{
		_projectname = projectname;
	}

	public String projectname()
	{
		return _projectname;
	}

	public String type()
	{
		return _type;
	}

	public String methodTagValue()
	{
		return methodTagValue( _properties );
	}

	public String classTagValue()
	{
		return classTagValue( _properties );
	}

	public void forAllMethodTags( String template )
	{
		forAllMethodTags( template, _properties );
	}

	public void forAllClassTags( String template )
	{
		forAllClassTags( template, _properties );
	}

	public void forAllMethods( String template )
	{
		forAllMethods( template, _properties );
	}

	public void forAllPackages( String template )
	{
		forAllPackages( template, _properties );
	}

	public void ifHasMethodTag( String template )
	{
		ifHasMethodTag( template, _properties );
	}

	public String stylesheetlink()
	{
		String packageName = "";
		if( packageName() != null )
		{
			packageName = packageName();
		}
		StringTokenizer st = new StringTokenizer( packageName, "." );
		int n = st.countTokens();
		StringBuffer sb = new StringBuffer();
		for( int i = 0; i < n; i++ )
		{
			sb.append( "../" );
		}
		sb.append( "info.css" );
		return sb.toString();
	}

	/**
	 * @exception  BuildException  Description of Exception
	 * @info:todo                  generate an overview summary html too? (the
	 *      default right page). It could be the old todo file, a bit modified.
	 */
	public void execute() throws BuildException
	{
		Category cat = getCategory( InfoSubTask.class, "execute" );

		System.out.println( "Create info lists for " + _properties.getProperty( "tagName" ) + " tags" );
		// first, generate the general stuff on the root.
		generateFileUsingTemplate( "info.css", "info.css" );
		generateFileUsingTemplate( "index.html", "index.html" );
		generateFileUsingTemplate( "all-classes.html", ALL_CLASSES_TEMPLATE );
		generateFileUsingTemplate( "all-packages.html", ALL_PACKAGES_TEMPLATE );
		generateFileUsingTemplate( "overview-packages.html", OVERVIEW_PACKAGES_TEMPLATE );

		// now loop over all packages and classes
		ClassDoc[] classes = getAllClasses();
		SortedSet packages = new TreeSet();

		for( int i = 0; i < classes.length; i++ )
		{
			packages.add( classes[i].containingPackage() );
		}

		PackageDoc cur_package = null;

		for( Iterator packageIterator = packages.iterator(); packageIterator.hasNext();  )
		{
			cur_package = ( PackageDoc ) packageIterator.next();
			setCurrentPackage( cur_package );

			File oldDestDir = destDir;
			File dir = new File( destDir, packageNameAsPath() );
			setDestdir( dir );
			generateFileUsingTemplate( "classes-list.html", CLASSES_LIST_TEMPLATE );

			classes = getAllClasses();
			for( int i = 0; i < classes.length; i++ )
			{
				setCurrentClass( classes[i] );
				generateFileUsingTemplate( className() + "-details.html", CLASS_DETAILS_TEMPLATE );
			}
			setDestdir( oldDestDir );
		}
		// restore current package to null, so subsequent class iterations can
		// perform outside the context of a current packages
		setCurrentPackage( null );

	}

	public void ifTagCountNotZero( String template ) throws BuildException
	{
		if( _tagCount != 0 )
		{
			generate( template );
		}
	}

	public String tagCountInAllClassesAndMethods() throws BuildException
	{
		_tagCount = tagCountInAllClassesAndMethods_Impl( _properties );
		return String.valueOf( _tagCount );
	}

	public String tagCountInClassesAndMethodsInAPackage() throws BuildException
	{
		_tagCount = tagCountInClassesAndMethodsInAPackage_Impl( _properties, getCurrentPackage() );
		return String.valueOf( _tagCount );
	}

	public String tagCountInClassAndItsMethods() throws BuildException
	{
		_tagCount = tagCountInClassAndItsMethods_Impl( _properties, getCurrentClass() );
		return String.valueOf( _tagCount );
	}


	private int tagCountInAllClassesAndMethods_Impl( Properties attributes ) throws BuildException
	{
		int tagCount = 0;
		String tag_name = attributes.getProperty( "tagName" );

		ClassDoc[] classes = getAllClasses();
		SortedSet packages = new TreeSet();

		for( int i = 0; i < classes.length; i++ )
		{
			packages.add( classes[i].containingPackage() );
		}

		PackageDoc cur_package = null;

		for( Iterator packageIterator = packages.iterator(); packageIterator.hasNext();  )
		{
			cur_package = ( PackageDoc ) packageIterator.next();
			tagCount += tagCountInClassesAndMethodsInAPackage_Impl( attributes, cur_package );
		}

		return tagCount;
	}

	private int tagCountInClassesAndMethodsInAPackage_Impl( Properties attributes, PackageDoc packageDoc ) throws BuildException
	{
		int tagCount = 0;
		String tag_name = attributes.getProperty( "tagName" );

		ClassDoc[] classes = packageDoc.allClasses();
		for( int i = 0; i < classes.length; i++ )
		{
			tagCount += tagCountInClassAndItsMethods_Impl( attributes, classes[i] );
		}

		return tagCount;
	}

	private int tagCountInClassAndItsMethods_Impl( Properties attributes, ClassDoc classDoc ) throws BuildException
	{
		int tagCount = 0;
		String tag_name = attributes.getProperty( "tagName" );

		Tag[] classTags = DocletUtil.getTagsByName( classDoc, tag_name, false );
		if( classTags != null )
		{
			tagCount += classTags.length;
		}

		MethodDoc[] methods = classDoc.methods();
		for( int i = 0; i < methods.length; i++ )
		{
			Tag[] methodTags = DocletUtil.getTagsByName( methods[i], tag_name );
			if( methodTags != null )
			{
				tagCount += methodTags.length;
			}
		}
		return tagCount;
	}
}
