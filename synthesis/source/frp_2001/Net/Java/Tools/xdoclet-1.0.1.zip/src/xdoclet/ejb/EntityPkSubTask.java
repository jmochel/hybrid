package xdoclet.ejb;

import java.io.*;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.lang.reflect.Modifier;
import java.beans.Introspector;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.*;
import xdoclet.util.serialveruid.*;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.12 $
 */
public class EntityPkSubTask extends AbstractEjbSubTask
{
	protected static String DEFAULT_TEMPLATE_FILE = "entitypk.j";

	public void setPattern( String new_pattern )
	{
		entityPkClassPattern = new_pattern;
	}

	public void execute() throws BuildException
	{
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			Category cat = getCategory( EntityPkSubTask.class, "execute" );
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isEntity( getCurrentClass() ) )
			{
				File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
				File beanFile = beanFile();

				if( dontGenerate() )
				{
					continue;
				}

				if( file.exists() )
				{
					// Check modification timestamps
					if( file.lastModified() > beanFile.lastModified() )
					{
						cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
						continue;
					}
				}

				System.out.println( "Create Primary Key Class for:  " + getCurrentClass().toString() );
				file.getParentFile().mkdirs();

				String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;
				generateFileUsingTemplate( javaFile( getGeneratedClassName() ), template_file_name );
			}
		}
	}

	public String serialVersionUID()
	{
		int modifiers = Modifier.PUBLIC;
		String class_name = getGeneratedClassName();
		int dot_pos = class_name.lastIndexOf( class_name );
		String qualifier = class_name.substring( 0, dot_pos );
		String name = class_name.substring( dot_pos );
		java.util.List[] docs = extractDocs( class_name );
		ClassDoc classdoc = new ClassDocImpl( modifiers, qualifier, name, docs[0], docs[1], docs[2] );

		return Long.toString( SerialVersionUidGenerator.computeSerialVersionUID( classdoc ) ) + "L";
	}

	protected String getGeneratedClassName()
	{
		return pkClass();
	}

	private java.util.List[] extractDocs( String class_name )
	{
		Map foundFields = new HashMap();
		java.util.List ext_fields = new java.util.ArrayList();
		java.util.List ext_methods = new java.util.ArrayList();
		java.util.List ext_constructors = new java.util.ArrayList();
		ClassDoc cur_class = getCurrentClass();
		ArrayList full_constructor_params = new ArrayList();

		do
		{
			MethodDoc[] methods = cur_class.methods();

			for( int j = 0; j < methods.length; j++ )
			{
				if( isPersistentField( methods[j] ) && isGetter( methods[j].name() ) && !foundFields.containsKey( methods[j].name() ) )
				{
					// Store that we found this field so we don't add it twice
					foundFields.put( methods[j].name(), methods[j].name() );

					int modifiers = Modifier.PUBLIC;
					String field_name = Introspector.decapitalize( methodNameWithoutPrefix( methods[j] ) );
					FieldDoc field = new FieldDocImpl( field_name, modifiers, methods[j].returnType() );

					ext_fields.add( field );

					//getter method
					ext_methods.add( new MethodDocImpl( methods[j].name(), Modifier.PUBLIC, new ParameterImpl[0], methods[j].returnType() ) );
				}
				else if( isPkField( methods[j] ) && isGetter( methods[j].name() ) )
				{
					String field_name = Introspector.decapitalize( methodNameWithoutPrefix( methods[j] ) );
					full_constructor_params.add( new ParameterImpl( methods[j].returnType(), field_name ) );
				}
			}

			// Add super class info
			cur_class = cur_class.superclass();
		}while ( cur_class != null );

		int modifiers = Modifier.STATIC | Modifier.FINAL;
		ext_fields.add( new FieldDocImpl( "serialVersionUID", modifiers, new TypeImpl( "long" ) ) );

		modifiers = Modifier.TRANSIENT | Modifier.PRIVATE;
		ext_fields.add( new FieldDocImpl( "_hashCode", modifiers, new TypeImpl( "int" ) ) );

		modifiers = Modifier.TRANSIENT | Modifier.PRIVATE;
		ext_fields.add( new FieldDocImpl( "value", modifiers, new TypeImpl( "String" ) ) );

		ext_methods.add( new MethodDocImpl( "hashcode", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "int" ) ) );
		ext_methods.add( new MethodDocImpl( "equals", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "Object", "", root.classNamed( "java.lang.Object" ) ) ) );
		ext_methods.add( new MethodDocImpl( "toString", Modifier.PUBLIC, new ParameterImpl[0], new TypeImpl( "int" ) ) );

		//constructors:
		modifiers = Modifier.PUBLIC;
		ext_constructors.add( new ConstructorDocImpl( class_name, modifiers, new ParameterImpl[0] ) );
		ext_constructors.add( new ConstructorDocImpl( class_name, modifiers, ( ParameterImpl[] ) full_constructor_params.toArray( new ParameterImpl[0] ) ) );

		return new java.util.List[]{ext_fields, ext_methods, ext_constructors};
	}

	private boolean dontGenerate()
	{
		Category cat = getCategory( EntityPkSubTask.class, "dontGenerate" );

		if( "false".equals( getParameterValue( DocletUtil.getText( getCurrentClass(), "ejb:pk" ), "generate", -1 ) ) )
		{
			cat.debug( "Skip primary key for " + getGeneratedClassName() + " because of false generate flag" );
			return true;
		}

		if( pkClass() != null && pkClass().indexOf( "java.lang" ) != -1 )
		{
			cat.debug( "Skip primary key for " + getGeneratedClassName() + " because the pkClass (" + pkClass() + ") is a system class." );
			return true;
		}

		return false;
	}
}
