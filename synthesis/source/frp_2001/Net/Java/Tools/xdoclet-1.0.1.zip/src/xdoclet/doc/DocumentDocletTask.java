package xdoclet.doc;

import java.util.*;
import java.io.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import com.sun.javadoc.*;

import xdoclet.*;
import xdoclet.doc.info.InfoSubTask;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 19, 2001
 * @version    $Revision: 1.7 $
 */
public class DocumentDocletTask extends DocletTask
{
	protected DocumentTagsSubTask documenttags = null;
	protected InfoSubTask infotags = null;

	public DocumentTagsSubTask createDocumenttags()
	{
		documenttags = new DocumentTagsSubTask();
		return documenttags;
	}

	public InfoSubTask createInfo()
	{
		infotags = new InfoSubTask();
		return infotags;
	}

	protected Vector getSubTasks()
	{
		Vector subtasks = super.getSubTasks();

		subtasks.addElement( this.documenttags );
		subtasks.addElement( this.infotags );

		return subtasks;
	}
}
