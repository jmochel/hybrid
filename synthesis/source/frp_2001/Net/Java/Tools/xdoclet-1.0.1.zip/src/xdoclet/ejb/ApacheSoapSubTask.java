package xdoclet.ejb;

import java.net.*;
import java.io.*;
import java.util.*;
import java.text.MessageFormat;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Path;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.DocletUtil;
import xdoclet.ejb.AbstractEjbSubTask;

/**
 *  Generates deployment descriptor for Apache SOAP.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    August 23, 2001
 * @version    $Revision: 1.2 $
 */
public class ApacheSoapSubTask extends AbstractEjbSubTask
{
	protected String   xmlEncoding = "UTF-8";

	protected String   statelessSessionEjbProvider = "org.apache.soap.providers.StatelessEJBProvider";
	protected String   statefulSessionEjbProvider = "org.apache.soap.providers.StatefulEJBProvider";
	protected String   entityEjbProvider = "org.apache.soap.providers.EntityEJBProvider";

   protected Path    providerClasspath;

	protected String   contextProviderUrl = "";
	protected String   contextFactoryName = "";

	private static String DEFAULT_TEMPLATE_FILE = "apache-soap.j";
	private static String GENERATED_FILE_NAME = "soap-dds-{0}.xml";

	public void setXmlencoding( String xmlEncoding )
	{
		this.xmlEncoding = xmlEncoding;
	}

	public void setStatelessSessionEjbProvider( String statelessSessionEjbProvider )
	{
		this.statelessSessionEjbProvider = statelessSessionEjbProvider;
	}

	public void setStatefulSessionEjbProvider( String statefulSessionEjbProvider )
	{
		this.statefulSessionEjbProvider = statefulSessionEjbProvider;
	}

	public void setEntityEjbProvider( String entityEjbProvider )
	{
		this.entityEjbProvider = entityEjbProvider;
	}

   public void setProviderclasspath( Path providerClasspath )
	{
		this.providerClasspath = providerClasspath;
	}

	public void setContextProviderUrl( String contextProviderUrl )
	{
		this.contextProviderUrl = contextProviderUrl;
	}

	public void setContextFactoryName( String contextFactoryName )
	{
		this.contextFactoryName = contextFactoryName;
	}

	public String getXmlencoding()
	{
		return xmlEncoding;
	}

	public String getStatelessSessionEjbProvider()
	{
		return statelessSessionEjbProvider;
	}

	public String getStatefulSessionEjbProvider()
	{
		return statefulSessionEjbProvider;
	}

	public String getEntityEjbProvider()
	{
		return entityEjbProvider;
	}

   public Path getProviderClasspath()
	{
		return providerClasspath;
	}

   public String getContextProviderUrl()
	{
		return contextProviderUrl;
	}

	public String getContextFactoryName()
	{
		return contextFactoryName;
	}

	public void execute() throws BuildException
	{
		String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;

		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			if( DocletUtil.hasTag( classes[i], "soap:service" ) )
			{
				String service_urn = DocletUtil.getText( DocletUtil.getTagsByName( classes[i], "soap:service", false )[0] );
				String dest_file_name = getDestinationFile();

				System.out.println( "Create Apache SOAP deployment descriptor for class '" + classes[i].qualifiedName() + "', implementing SOAP service '" + service_urn + "', " + dest_file_name );
				generateFileUsingTemplate( dest_file_name, template_file_name );
			}
		}
	}

	protected String getDestinationFile()
	{
		return MessageFormat.format( GENERATED_FILE_NAME, new Object[]{symbolicClassName()} );
	}
}
