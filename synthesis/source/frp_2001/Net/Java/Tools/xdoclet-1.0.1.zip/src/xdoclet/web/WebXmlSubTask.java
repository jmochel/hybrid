package xdoclet.web;

import java.net.*;
import java.io.*;
import java.util.*;
import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.Path;
import org.apache.log4j.Category;

import xdoclet.*;

/**
 *  Generates web.xml deployment descriptor.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    June 19, 2001
 * @version    $Revision: 1.7 $
 */
public class WebXmlSubTask extends SubTask
{

	protected String   servletspec = "2.3";

	protected String   xmlEncoding = "UTF-8";
	protected String   smallicon = "";
	protected String   largeicon = "";
	protected String   displayname = "";
	protected String   description = "";
	protected boolean  distributable = true;

	protected Vector   contextParams = new Vector();

	protected int      sessiontimeout = 0;
	//container default

	protected Vector   welcomeFiles = new Vector();

	protected Vector   tagLibs = new Vector();
	private static String DEFAULT_TEMPLATE_FILE = "web_xml.j";
	private static String GENERATED_FILE_NAME = "web.xml";

	public void setServletspec( String new_servletspec )
	{
		servletspec = new_servletspec;
	}

	public void setXmlencoding( String new_xml_encoding )
	{
		xmlEncoding = new_xml_encoding;
	}

	public void setSmallicon( String new_icon )
	{
		smallicon = new_icon;
	}

	public void setLargeicon( String new_icon )
	{
		largeicon = new_icon;
	}

	public void setDisplayname( String new_display_name )
	{
		displayname = new_display_name;
	}

	public void setDescription( String new_description )
	{
		description = new_description;
	}

	public void setDistributable( boolean distributable )
	{
		this.distributable = distributable;
	}

	public void setSessiontimeout( int session_timeout )
	{
		sessiontimeout = session_timeout;
	}

	public String getServletspec()
	{
		return servletspec;
	}

	public Vector getContextparams()
	{
		return contextParams;
	}

	public String getXmlencoding()
	{
		return xmlEncoding;
	}

	public String getSmallicon()
	{
		return smallicon;
	}

	public String getLargeicon()
	{
		return largeicon;
	}

	public String getDisplayname()
	{
		return displayname;
	}

	public String getDescription()
	{
		return description;
	}

	public boolean getDistributable()
	{
		return distributable;
	}

	public int getSessiontimeout()
	{
		return sessiontimeout;
	}

	public Vector getWelcomefiles()
	{
		return welcomeFiles;
	}

	public WelcomeFile getWelcomefile()
	{
		return ( WelcomeFile ) getWelcomefiles().elementAt( currentConfigParamIndex );
	}

	public Vector getTaglibs()
	{
		return tagLibs;
	}

	public String welcomefile()
	{
		return ( ( WelcomeFile ) getWelcomefiles().elementAt( currentConfigParamIndex ) ).getFile();
	}

	public void addContextparam( ContextParam cp )
	{
		contextParams.addElement( cp );
	}

	public String contextParamName()
	{
		return ( ( ContextParam ) getContextparams().elementAt( currentConfigParamIndex ) ).getName();
	}

	public String contextParamValue()
	{
		return ( ( ContextParam ) getContextparams().elementAt( currentConfigParamIndex ) ).getValue();
	}

	public String contextParamDescription()
	{
		return ( ( ContextParam ) getContextparams().elementAt( currentConfigParamIndex ) ).getDescription();
	}

	public void addWelcomefile( WelcomeFile file )
	{
		welcomeFiles.addElement( file );
	}

	public void addTaglib( TagLib taglib )
	{
		tagLibs.addElement( taglib );
	}

	public String taglibUri()
	{
		return ( ( TagLib ) getTaglibs().elementAt( currentConfigParamIndex ) ).getUri();
	}

	public String taglibLocation()
	{
		return ( ( TagLib ) getTaglibs().elementAt( currentConfigParamIndex ) ).getLocation();
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( WebXmlSubTask.class, "execute" );
		System.out.println( "Create " + GENERATED_FILE_NAME );
		generateFileUsingTemplate( GENERATED_FILE_NAME, DEFAULT_TEMPLATE_FILE );
	}

	/**
	 * @created    July 28, 2001
	 */
	public static class ContextParam implements java.io.Serializable
	{
		private String    paramName = null;
		private String    paramValue = null;
		private String    description = "";

		public void setName( String name )
		{
			paramName = name;
		}

		public void setValue( String value )
		{
			paramValue = value;
		}

		public void setDescription( String desc )
		{
			description = desc;
		}

		public String getName()
		{
			return paramName;
		}

		public String getValue()
		{
			return paramValue;
		}

		public String getDescription()
		{
			return description;
		}
	}

	/**
	 * @created    July 28, 2001
	 */
	public static class TagLib implements java.io.Serializable
	{
		private String    taglibUri = null;
		private String    taglibLocation = null;

		public void setUri( String uri )
		{
			taglibUri = uri;
		}

		public void setLocation( String location )
		{
			taglibLocation = location;
		}

		public String getUri()
		{
			return taglibUri;
		}

		public String getLocation()
		{
			return taglibLocation;
		}
	}

	/**
	 * @created    Sep 18, 2001
	 */
	public static class WelcomeFile implements java.io.Serializable
	{
		private String    file = null;

		public void setFile( String file )
		{
			this.file = file;
		}

		public String getFile()
		{
			return file;
		}
	}
}
