package xdoclet.ejb;

import java.util.*;
import java.io.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import com.sun.javadoc.*;

import xdoclet.*;
import xdoclet.ejb.vendor.*;

/**
 *  A task that executes various EJB-specific sub-tasks.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.12 $
 */
public class EjbDocletTask extends DocletTask
{
	//default is ejb2.0
	private String     ejbspec = EjbSpecVersion.EJB_2_0;

	// Generic sub-tasks
	private DataObjectSubTask dataObject;
	private EjbDotXmlSubTask deploymentDescriptor;
	private EntityBmpSubTask entityBmp;
	private EntityCmpSubTask entityCmp;
	private EntityPkSubTask entityPk;
	private HomeInterfaceSubTask homeInterface = null;
	private LocalHomeInterfaceSubTask localHomeInterface = null;
	private RemoteInterfaceSubTask remoteInterface = null;
	private LocalInterfaceSubTask localInterface = null;
	private SessionSubTask session = new SessionSubTask();
	//mandatory sub-task

	// Vendor-specific sub-tasks
	private JBossSubTask jboss;
	private WebSphereSubTask webSphere;
	private OrionSubTask orion;
	private WebLogicSubTask webLogic;

	// SOAP sub-task, since it uses methods from AbstractEjbSubTask for EJB providers it should be here
	private ApacheSoapSubTask apachesoap;

	// Struts Form sub-task
	private StrutsFormSubTask strutsformsubtask;

	public void setEjbspec( EjbSpecVersion ejbspec )
	{
		this.ejbspec = ejbspec.getValue();
	}

	public DataObjectSubTask createDataobject()
	{
		dataObject = new DataObjectSubTask();
		return dataObject;
	}

	public EjbDotXmlSubTask createDeploymentdescriptor()
	{
		deploymentDescriptor = new EjbDotXmlSubTask();
		return deploymentDescriptor;
	}

	public EntityBmpSubTask createEntitybmp()
	{
		entityBmp = new EntityBmpSubTask();
		return entityBmp;
	}

	public EntityCmpSubTask createEntitycmp()
	{
		entityCmp = new EntityCmpSubTask();
		return entityCmp;
	}

	public EntityPkSubTask createEntitypk()
	{
		entityPk = new EntityPkSubTask();
		return entityPk;
	}

	public SessionSubTask createSession()
	{
		session = new SessionSubTask();
		return session;
	}

	public HomeInterfaceSubTask createHomeinterface()
	{
		homeInterface = new HomeInterfaceSubTask();
		return homeInterface;
	}

	public LocalHomeInterfaceSubTask createLocalhomeinterface()
	{
		localHomeInterface = new LocalHomeInterfaceSubTask();
		return localHomeInterface;
	}

	public RemoteInterfaceSubTask createRemoteinterface()
	{
		remoteInterface = new RemoteInterfaceSubTask();
		return remoteInterface;
	}

	public LocalInterfaceSubTask createLocalinterface()
	{
		localInterface = new LocalInterfaceSubTask();
		return localInterface;
	}

	public JBossSubTask createJboss()
	{
		jboss = new JBossSubTask();
		return jboss;
	}

	public WebSphereSubTask createWebSphere()
	{
		webSphere = new WebSphereSubTask();
		return webSphere;
	}

	public OrionSubTask createOrion()
	{
		orion = new OrionSubTask();
		return orion;
	}

	public WebLogicSubTask createWebLogic()
	{
		webLogic = new WebLogicSubTask();
		return webLogic;
	}

	public ApacheSoapSubTask createApachesoap()
	{
		apachesoap = new ApacheSoapSubTask();
		return apachesoap;
	}

	public StrutsFormSubTask createStrutsform()
	{
		strutsformsubtask = new StrutsFormSubTask();
		return strutsformsubtask;
	}

	protected Vector getSubTasks()
	{
		Vector subtasks = super.getSubTasks();

		subtasks.addElement( this.homeInterface );
		subtasks.addElement( this.localHomeInterface );
		subtasks.addElement( this.remoteInterface );
		subtasks.addElement( this.localInterface );
		subtasks.addElement( this.session );
		subtasks.addElement( this.entityPk );
		subtasks.addElement( this.dataObject );
		subtasks.addElement( this.entityBmp );
		subtasks.addElement( this.entityCmp );
		subtasks.addElement( this.deploymentDescriptor );
		subtasks.addElement( this.jboss );
		subtasks.addElement( this.orion );
		subtasks.addElement( this.webSphere );
		subtasks.addElement( this.webLogic );
		subtasks.addElement( this.apachesoap );
		subtasks.addElement( this.strutsformsubtask );

		return subtasks;
	}

	protected DocletContext getContext()
	{
		Vector subtasks = getSubTasks();
		EjbDocletContext context = new EjbDocletContext( this.sourcePath.toString(), this.destDir.toString(),
				this.mergeDir != null ? this.mergeDir.toString() : null, this.ejbspec, this.excludedTags,
				( SubTask[] ) subtasks.toArray( new SubTask[0] ) );

		return context;
	}

	/**
	 * @author     Ara Abrahamian (ara_e@email.com)
	 * @created    July 19, 2001
	 */
	public static class EjbSpecVersion extends org.apache.tools.ant.types.EnumeratedAttribute
	{
		public final static String EJB_1_1 = "1.1";
		public final static String EJB_2_0 = "2.0";

		public java.lang.String[] getValues()
		{
			return ( new java.lang.String[]{
					EJB_1_1, EJB_2_0
					} );
		}
	}
}
