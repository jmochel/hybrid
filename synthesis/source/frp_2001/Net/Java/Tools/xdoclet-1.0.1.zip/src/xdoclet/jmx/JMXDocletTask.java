package xdoclet.jmx;

import java.util.*;
import java.io.*;
import org.apache.tools.ant.*;
import org.apache.tools.ant.taskdefs.*;
import org.apache.tools.ant.types.*;
import com.sun.javadoc.*;

import xdoclet.*;
import xdoclet.web.vendor.*;
import xdoclet.web.WebXmlSubTask;
import xdoclet.web.JspTaglibSubTask;

/**
 * @author     Rickard Oberg (rickard@xpedio.com)
 * @created    August 4, 2001
 * @version    $Revision: 1.3 $
 */
public class JMXDocletTask extends DocletTask
{
	protected MBeanInterfaceSubTask mbeaninterface;

// protected ServiceXmlSubTask servicexml;

	public MBeanInterfaceSubTask createMbeaninterface()
	{
		mbeaninterface = new MBeanInterfaceSubTask();
		return mbeaninterface;
	}

// public ServiceXmlSubTask createServicexml()
// {
//    servicexml = new ServiceXmlSubTask();
//    return servicexml;
// }

	protected Vector getSubTasks()
	{
		Vector subtasks = super.getSubTasks();

		subtasks.addElement( this.mbeaninterface );

		return subtasks;
	}
}
