package xdoclet.util;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;

/**
 *  Extends the PrintWriter class by adding the possibility of emiting empty
 *  lines.
 *
 * @author     Andreas "Mad" Schaefer (andreas.schaefer@madplane.com)
 * @created    March 7, 2001
 * @version    $Revision: 1.2 $
 */
public class PrettyPrintWriter extends PrintWriter
{
	private StringBuffer lineBuffer = new StringBuffer();
	private int        lineBufferLength;

	public PrettyPrintWriter( OutputStream pOut )
	{
		super( pOut );
	}

	public PrettyPrintWriter( Writer pOut )
	{
		super( pOut );
	}

	public PrettyPrintWriter( Writer pOut, boolean pAutoFlush )
	{
		super( pOut, pAutoFlush );
	}

	/**
	 *  Closes the output stream and writes the last line.
	 */
	public void close()
	{
		if( lineBuffer.length() > 0 )
		{
			writeLine();
		}

		super.close();
	}

	public void write( char pBuffer[], int pOffset, int pLength )
	{
		for( int i = pOffset; i < pOffset + pLength; i++ )
		{
			char c = pBuffer[i];

			lineBuffer.append( c );
			lineBufferLength++;

			if( c == DocletUtil.LINE_SEPARATOR_CHAR )
			{
				writeLine();
			}
		}
	}

	public void write( int c )
	{
		lineBuffer.append( c );
		lineBufferLength++;

		if( c == DocletUtil.LINE_SEPARATOR_CHAR )
		{
			writeLine();
		}
	}

	public void write( String pText, int pOffset, int pLength )
	{
		this.write( pText.toCharArray(), pOffset, pLength );
	}

	public void println()
	{
		write( DocletUtil.LINE_SEPARATOR_CHAR );
	}

	protected void writeLine()
	{
		boolean all_spaces = true;
		char temp_char;

		if( lineBufferLength <= 2 && ( lineBuffer.charAt( 0 ) == DocletUtil.LINE_SEPARATOR_CHAR || lineBuffer.charAt( 0 ) == 10 || lineBuffer.charAt( 0 ) == 13 ) )
		{
			//only one char and the char=\n, ok

			all_spaces = false;
		}
		else
		{
			for( int j = 0; j < lineBufferLength; j++ )
			{
				temp_char = lineBuffer.charAt( j );

				if( !Character.isWhitespace( temp_char ) )
				{
					all_spaces = false;
					break;
				}
			}
		}

		if( all_spaces == false )
		{
			//if a useful line then write it, otherwise ignore garbage lines

			char[] line_chars = lineBuffer.toString().toCharArray();

			super.write( line_chars, 0, line_chars.length );
		}

		lineBuffer = new StringBuffer();
		//reset line buffer
		lineBufferLength = 0;
	}
}
