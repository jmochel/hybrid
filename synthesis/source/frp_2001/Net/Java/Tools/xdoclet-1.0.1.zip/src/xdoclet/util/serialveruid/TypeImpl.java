package xdoclet.util.serialveruid;

import com.sun.javadoc.ClassDoc;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class TypeImpl implements com.sun.javadoc.Type
{
	final String       name;
	final String       dimension;
	final ClassDoc     classdoc;

	public TypeImpl( String name )
	{
		this( name, "" );
	}

	public TypeImpl( String name, String dimension )
	{
		this( name, dimension, null );
	}

	public TypeImpl( String name, String dimension, ClassDoc classdoc )
	{
		this.name = name;
		this.dimension = dimension;
		this.classdoc = classdoc;
	}

	public java.lang.String typeName()
	{
		return name;
	}

	public java.lang.String qualifiedTypeName()
	{
		return name;
	}

	public java.lang.String dimension()
	{
		return dimension;
	}

	public java.lang.String toString()
	{
		return typeName();
	}

	public com.sun.javadoc.ClassDoc asClassDoc()
	{
		return classdoc;
	}
}
