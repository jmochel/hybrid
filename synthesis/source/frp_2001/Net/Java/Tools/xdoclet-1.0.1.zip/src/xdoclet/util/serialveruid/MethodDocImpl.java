package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class MethodDocImpl extends xdoclet.util.serialveruid.ExecutableMemberDocImpl implements com.sun.javadoc.MethodDoc
{
	final com.sun.javadoc.Type returnType;

	public MethodDocImpl( String name, int modifiers, xdoclet.util.serialveruid.ParameterImpl[] parameters, com.sun.javadoc.Type returnType )
	{
		super( name, modifiers, parameters );

		this.returnType = returnType;
	}

	public boolean isMethod()
	{
		return true;
	}

	public boolean isAbstract()
	{
		return java.lang.reflect.Modifier.isAbstract( modifiers );
	}

	public com.sun.javadoc.Type returnType()
	{
		return returnType;
	}

	public com.sun.javadoc.ClassDoc overriddenClass()
	{
		throw new UnsupportedOperationException();
	}
}
