package xdoclet.util.serialveruid;

/*
 * @author  arae
 * @created Aug 21, 2001
 * @version $Revision 1.1 $
 */
/**
 * @created    August 21, 2001
 */
public class ConstructorDocImpl extends xdoclet.util.serialveruid.ExecutableMemberDocImpl implements com.sun.javadoc.ConstructorDoc
{
	public ConstructorDocImpl( String name, int modifiers, xdoclet.util.serialveruid.ParameterImpl[] parameters )
	{
		super( name, modifiers, parameters );
	}

	public boolean isConstructor()
	{
		return true;
	}

	public java.lang.String qualifiedName()
	{
		throw new UnsupportedOperationException();
	}

	public java.lang.String name()
	{
		throw new UnsupportedOperationException();
	}
}
