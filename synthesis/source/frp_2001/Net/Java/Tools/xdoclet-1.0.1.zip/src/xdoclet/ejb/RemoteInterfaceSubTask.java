package xdoclet.ejb;

import java.io.*;
import java.util.Date;

import com.sun.javadoc.*;
import org.apache.tools.ant.BuildException;
import org.apache.log4j.Category;

import xdoclet.*;
import xdoclet.util.*;

/**
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    April 30, 2001
 * @version    $Revision: 1.10 $
 */
public class RemoteInterfaceSubTask extends AbstractEjbSubTask
{
	protected static String DEFAULT_TEMPLATE_FILE = "remote.j";

	public void setPattern( String new_pattern )
	{
		remoteClassPattern = new_pattern;
	}

	public void execute() throws BuildException
	{
		Category cat = getCategory( RemoteInterfaceSubTask.class, "execute" );
		ClassDoc[] classes = root.classes();

		for( int i = 0; i < classes.length; i++ )
		{
			setCurrentClass( classes[i] );

			//skip automatically generated classes
			if( isDocletGenerated( getCurrentClass() ) )
			{
				cat.debug( "Reject file because it is a doclet generated one" );
				continue;
			}

			if( isEntity( getCurrentClass() ) || isSession( getCurrentClass() ) )
			{
				if( isEjb( getCurrentClass() ) )
				{
					if( dontGenerate() )
					{
						continue;
					}

					File file = new File( destDir.toString(), javaFile( getGeneratedClassName() ) );
					File beanFile = beanFile();

					if( file.exists() )
					{
						// Check modification timestamps
						if( file.lastModified() > beanFile.lastModified() )
						{
							cat.debug( "Reject file because of timestamp " + new Date( file.lastModified() ) + " " + new Date( beanFile.lastModified() ) );
							continue;
						}
					}

					System.out.println( "Create Remote Interface for:   " + getCurrentClass().toString() );
					file.getParentFile().mkdirs();

					String template_file_name = getTemplateFile() != null ? getTemplateFile().toString() : DEFAULT_TEMPLATE_FILE;
					generateFileUsingTemplate( javaFile( getGeneratedClassName() ), template_file_name );
				}
			}
		}
	}

	protected String getGeneratedClassName()
	{
		return getComponentInterface( "remote" );
	}

	/**
	 * @return    true if the remote interface should not be generated.
	 */
	protected boolean dontGenerate()
	{
		Category cat = getCategory( RemoteInterfaceSubTask.class, "dontGenerate" );
		if( isOnlyLocalEjb( getCurrentClass() ) )
		{
			cat.debug( "Reject file " + getGeneratedClassName() + " because of view-type local" );
			return true;
		}

		String interfaceTag = DocletUtil.getText( getCurrentClass(), "ejb:interface" );
		if( interfaceTag == null )
		{
			return false;
		}

		String generate = getParameterValue( interfaceTag, "generate", -1 );
		if( ( generate != null ) && ( generate.indexOf( "remote" ) == -1 ) )
		{
			cat.debug( "Skip remote interface for " + getGeneratedClassName() + " because of generate=" + generate + " flag." );
			return true;
		}
		return false;
	}
}
