This is the directory where you put the needed jar files.

- Put these jar files in lib directory:
  - ejb.jar (v2.0), jms.jar for <ejbdoclet/> (bundled with distribution)
  - servlet.jar (v2.3), webwork.jar for <webdoclet/> (bundled with distribution)
  - parser.jar, ant.jar, jaxp.jar for Apache-Ant (not bundled with distribution)
  - xdoclet.jar and log4j.jar for XDoclet support (bundled with distribution)

  The sample won't compile without these jar files in classpath, though
  ejbdoclet will generate ejb-related sources and deployment descriptors and
  webdoclet will generate web.xml and taglib.tld, though later phases of build
  will fail.

The XDoclet Team.