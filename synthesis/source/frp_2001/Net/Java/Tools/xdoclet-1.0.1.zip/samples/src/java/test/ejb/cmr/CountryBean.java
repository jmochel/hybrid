package test.ejb.cmr;

/**
 * This bean represents the one-side of an 1:n bidirectional CMR relationship
 *
 * @author <a href="mailto:aslak.hellesoy@bekk.no">Aslak Helles�y</a>
 *
 * @ejb:bean
 *    type="CMP"
 *    cmp-version="2.x"
 *    name="CountryEJB"
 *    jndi-name="xdoclet.CountryEJBHome"
 *    local-jndi-name="xdoclet.CountryEJBLocalHome"
 *    view-type="both"
 *
 * @todo I dont't really want to have a query, but wls 6.1 seems to want one, sayin it can't be empty. HELP!
 * @ejb:finder
 *    signature="java.util.Collection findAll()"
 *    unchecked="true"
 *    query="WHERE id IS NOT NULL"
 *    result-type-mapping="Local"
 *
 * @weblogic:table-name city
 * @weblogic:data-source-name xdoclet.database
 *
 */
public abstract class CountryBean implements javax.ejb.EntityBean {

   private javax.ejb.EntityContext _entityContext;

   /**
    * @param id id of this country
    */
   public abstract void setId(java.lang.String id);

   /**
    * @return id of this country
    *
    * @ejb:persistent-field
    * @ejb:pk-field
    *
    * @weblogic:dbms-column id
    */
   public abstract java.lang.String getId();

   /**
    * @param name name of this country
    *
    * @ejb:interface-method view-type="local"
    * @ejb:interface-method view-type="remote"
    */
   public abstract void setName(java.lang.String name);

   /**
    * @return name of this country
    *
    * @ejb:interface-method view-type="local"
    * @ejb:interface-method view-type="remote"
    * @ejb:persistent-field
    *
    * @weblogic:dbms-column name
    */
   public abstract java.lang.String getName();

   /**
    * @param cities all cities of this country
    *
    * @ejb:interface-method view-type="local"
    */
   public abstract void setCities(java.util.Collection cities);

   /**
    * @return all cities of this country
    *
    * @ejb:interface-method view-type="local"
    * @todo remove the multiple parameter when ejb:relation is updated to figure it out from return type
    * @ejb:relation
    *    name="country-city"
    *    role-name="one-country-has-many-city"
    *    multiple="yes"
    *
    * @weblogic:relation
    *    name="country-city"
    */
   public abstract java.util.Collection getCities();

   public void setEntityContext(javax.ejb.EntityContext entityContext) {
      _entityContext = entityContext;
   }

   public void unsetEntityContext() {
      _entityContext = null;
   }

   public void ejbLoad() {
   }

   public void ejbActivate() {
   }

   public void ejbPassivate() {
   }

   public void ejbRemove() throws javax.ejb.RemoveException {
   }

   public void ejbStore() {
   }
}
