package test.ejb;

import java.util.Collection;
import javax.ejb.*;

import test.interfaces.Account;
import test.interfaces.AccountData;
import test.interfaces.Customer;

/**
 *   This is a teller bean. It is an example of how to use the EJBDoclet tags.
 *
 *   @ejb:bean type="Stateless" name="bank/Teller" jndi-name="ejb/bank/Teller"
 *   @ejb:ejb-ref ejb-name="bank/Account"
 *   @ejb:ejb-ref ejb-name="bank/Customer"
 *   @ejb:security-role-ref role-name="admin" role-link="Administrator"
 *   @ejb:permission role-name="Teller"
 *   @ejb:permission role-name="Administrator"
 *   @ejb:transaction type="Required"
 *   @ejb:transaction-type type="Container"
 *   @ejb:resource-ref res-name="jdbc/DBPool" res-type="javax.sql.DataSource" res-auth="Container"
 *
 *   @soap:service urn="TellerService"
 *
 *   @jboss:resource-ref res-ref-name="jdbc/DBPool" resource-name="MyDataSourceManager"
 *   @jboss:container-configuration name="Standard Stateless SessionBean"
 *   @jboss:ejb-ref-jndi ref-name="bank/Account" jndi-name="ejb/bank/Account"
 *
 */
public class TellerBean
   extends BaseTellerBean
   implements SessionBean
{
   // Public --------------------------------------------------------
   /**
    * Transfer money.
    *
    * @ejb:interface-method view-type="remote"
    */
   public void transfer(Account from, Account to, float amount)
   {
      try
      {
         from.withdraw(amount);
         to.deposit(amount);
      } catch (java.rmi.RemoteException e)
      {
         throw new EJBException(e);
      }
   }

   // SessionBean implementation ------------------------------------
   public void ejbActivate() {}
   public void ejbPassivate() {}
   public void setSessionContext(SessionContext ctx) {}

   /**
    * Remove
    *
    * @ejb:transaction type="Mandatory"
    */
   public void ejbRemove() {}

}
