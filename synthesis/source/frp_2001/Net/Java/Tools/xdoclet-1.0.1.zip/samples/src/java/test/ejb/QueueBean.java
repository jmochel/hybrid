package test.ejb;

import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.ejb.EJBException;

import javax.jms.MessageListener;
import javax.jms.Message;

/**
 * This is a Message Driven Bean based on a Queue.
 *
 * @ejb:bean name="QueueBean" transaction-type="Bean" acknowledge-mode="Auto-acknowledge"
 *                     destination-type="javax.jms.Queue" subscription-durability="NonDurable"
 * @jboss:destination-jndi-name "queue/testQueue"
 *
 * @author $Author: dimc $
 * @version $Revision: 1.6 $
 */
public class QueueBean implements MessageDrivenBean, MessageListener
{
   private MessageDrivenContext ctx = null;

   public void setMessageDrivenContext( MessageDrivenContext ctx )
      throws EJBException
   {
      this.ctx = ctx;
   }

   /**
    * @ejb:create-method
    */
   public void ejbCreate()
   {
   }

   public void ejbRemove()
   {
      ctx=null;
   }

   public void onMessage( Message message )
   {
      System.out.println("QueueBean got message" + message );
   }
}
