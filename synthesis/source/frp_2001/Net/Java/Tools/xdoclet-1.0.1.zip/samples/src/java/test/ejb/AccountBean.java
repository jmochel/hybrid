package test.ejb;

import java.util.Collection;
import javax.ejb.*;

import test.interfaces.Account;
import test.interfaces.AccountData;
import test.interfaces.Customer;

/**
 *   This is an account bean. It is an example of how to use the EJBDoclet tags.
 *
 *   @ejb:bean name="bank/Account" type="CMP" jndi-name="ejb/bank/Account" primkey-field="id"
 *   @ejb:finder signature="Collection findAll()" unchecked="true" transaction-type="NotSupported"
 *   @ejb:finder signature="Collection findByOwner(test.interfaces.Customer owner)" role-name="Teller" transaction-type="Supports"
 *   @ejb:finder signature="Collection findLargeAccounts(int balance)" role-name="Teller,IRS"
 *   @ejb:interface remote-class="test.interfaces.Account"
 *   @ejb:pk class="java.lang.Integer"
 *
 *   @jboss:table-name "account"
 *   @jboss:create-table "true"
 *   @jboss:remove-table "true"
 *   @jboss:tuned-updates "true"
 *   @jboss:read-only "false"
 *   @jboss:finder-query name="findLargeAccounts" query="$1 > 1000" order="balance"
 *
 *   @version $Revision: 1.16 $
 *   @author $Author: rinkrank $
 */
public abstract class AccountBean implements EntityBean
{
   public void setEntityContext(javax.ejb.EntityContext ctx)
   {

   }

   // Public --------------------------------------------------------
   /**
    * Deposit money.
    *
    * @ejb:interface-method
    */
   public void deposit(float amount)
   {
      setBalance(getBalance()+amount);
   }

   /**
    * Withdraw money.
    *
    * @ejb:interface-method
    * @todo This method should verify that the amount is positive
    */
   public void withdraw(float amount)
   {
      setBalance(getBalance()-amount);
   }


   /**
    * Balance of the account.
    *
    * @ejb:interface-method
    * @ejb:persistent-field
    * @ejb:transaction type="Supports"
    * @ejb:permission role-name="Customer,Administrator"
    *
    * @jboss:sql-type DOUBLE
    */
   public abstract float getBalance();

   /**
    * Balance of the account.
    *
    * This is not remote since changing the balance
    * of the account is done by calling "withdraw" or "deposit".
    *
    */
   public abstract void setBalance(float balance);

   /**
    * Id of this account.
    *
    * This is not remote since the primary key can be extracted by other means.
    *
    * @ejb:pk-field
    * @ejb:persistent-field
    *
    * @jboss:column-name "pk"
    */
   public abstract Integer getId();

   /**
    * Id of this account.
    *
    */
   public abstract void setId(Integer id);

   /**
    *  Owner of this account.
    *
    * @ejb:interface-method
    * @ejb:persistent-field
    * @ejb:permission role-name="Administrator"
    * @ejb:transaction type="Supports"
    */
   public abstract Customer getOwner();

   /**
    *  Owner of this account.
    *
    */
   public abstract void setOwner(Customer owner);

   /**
    * Generated bulk accessor.
    *
    * Not remote, but could be.
    *
    */
   public abstract void setData(AccountData data);

   /**
    * Generated bulk accessor.
    *
    * This is set as remote to allow clients to
    * get all data in one call.
    *
    * @ejb:interface-method
    * @ejb:permission role-name="Administrator"
    * @ejb:transaction type="Supports"
    */
   public abstract AccountData getData();

   /**
    * Create account.
    *
    * @ejb:create-method
    * @ejb:permission role-name="Administrator"
    */
   public Integer ejbCreate(AccountData data)
      throws CreateException
   {
      setId(data.getId());
      setData(data);

      return null;
   }

   /**
    * Create account.
    *
    */
   public void ejbPostCreate(AccountData data)
      throws CreateException
   {
   }

   /**
    * Transfer money
    *
    * @ejb:home-method
    */
   public void ejbHomeTransfer(Account from, Account to, float amount)
   {
      try
      {
         from.withdraw(amount);
         to.deposit(amount);
      } catch (java.rmi.RemoteException e)
      {
         throw new EJBException(e);
      }
   }

   // EntityBean implementation -------------------------------------
   /**
    * Remove
    *
    * @ejb:transaction type="Mandatory"
    */
   public void ejbRemove() throws RemoveException {}

}
