#! /bin/sh

CWD=`pwd`
DIRNAME=`dirname $0`

cd $DIRNAME

CP=../lib/ant.jar\
:../lib/jaxp.jar\
:../lib/crimson.jar\
:$JAVA_HOME/lib/tools.jar

$JAVA_HOME/bin/java -classpath $CP org.apache.tools.ant.Main $1 $2 $3 $4 $5

cd -
