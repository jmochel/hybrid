/*
 * Xpedio
 *
 * Copyright (C) 2001
 */
package test.web;

/**
 * Simple WebWork test action.
 *
 * @webwork:action name="foo" views="a=tjo.jsp,b=blah.jsp,c=duh.jsp"
 * @webwork:action name="bar" views="qwe=tjo.jsp,rty=blah.jsp,xyz=duh.jsp"
 * @webwork:action name="xyzzy" success="tjo.jsp" error="blah.jsp" input="duh.jsp"
 * @webwork:action name="myaction" success="tjo.jsp" error="blah.jsp" input="duh.jsp" views="login=login.jsp"
 * @author Rickard Oberg (rickard@xpedio.com)
 */
public class SimpleAction
   implements webwork.action.Action
{
   // Attributes ----------------------------------------------------

   // Static --------------------------------------------------------

   // Constructors --------------------------------------------------

   // Public --------------------------------------------------------
   public String execute()
   {
      // Simple. Very simple.
      return SUCCESS;
   }

   // Package protected ---------------------------------------------
   
   // Protected -----------------------------------------------------
   
   // Private -------------------------------------------------------

   // Inner classes -------------------------------------------------
}
