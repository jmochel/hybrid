package test.web;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * A timer filter, using Servlet 2.3 filtering feature.
 * See http://www.javaworld.com/javaworld/jw-06-2001/jw-0622-filters_p.html.
 *
 * @web:filter name="SimpleFilter" display-name="Simple Filter"
 * @web:filter-init-param name="param1" value="value1"
 * @web:filter-init-param name="param2" value="value2"
 * @web:filter-mapping url-pattern="/*.xml"
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 2, 2001
 * @version    $Revision: 1.2 $
 */
public class TimerFilter implements Filter
{
	private FilterConfig config = null;

	public void init(FilterConfig config) throws ServletException
	{
		this.config = config;
	}

	public void destroy()
	{
		config = null;
	}

	public void doFilter( ServletRequest request, ServletResponse response,
								 FilterChain chain) throws IOException, ServletException
	{
	long before = System.currentTimeMillis();

		chain.doFilter(request, response);

	long after = System.currentTimeMillis();

	String name = "";
		if (request instanceof HttpServletRequest)
			name	= ((HttpServletRequest)request).getRequestURI();

		config.getServletContext().log(name + ": " + (after - before) + "ms");
	}
}