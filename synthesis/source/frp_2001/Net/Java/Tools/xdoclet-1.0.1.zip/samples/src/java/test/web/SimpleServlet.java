package test.web;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;

/**
 * A simple Servlet.
 *
 * @web:servlet name="SimpleServlet" display-name="Simple Servlet" load-on-startup="1"
 * @web:servlet-init-param name="param1" value="value1"
 * @web:servlet-init-param name="param2" value="value2"
 * @web:servlet-mapping url-pattern="/simple/*"
 *
 * @web:resource-ref description="Test resource reference"
 *                   name="Queue"
 *                   type="javax.jms.Queue"
 *                   auth="Container"
 * @web:ejb-ref name="Account"
 *              type="Entity"
 *              home="test.interfaces.AccountHome"
 *              remote="test.interfaces.Account"
 *              link="Account"
 *              description="A test reference to the Account EJB"
 *
 * @jboss:resource-ref res-ref-name="Queue"
 *                     jndi-name="queue/A"
 * @jboss:ejb-ref-jndi ref-name="Account"
 *                     jndi-name="ejb/bank/Account"
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 3, 2001
 * @version    $Revision: 1.4 $
 */
public class SimpleServlet extends HttpServlet
{
	public void doPost( HttpServletRequest request,
			HttpServletResponse response ) throws IOException, ServletException
	{
		response.getWriter().println("Hi!");
	}
}
