// Interface that data objects should implement

package test.interfaces;

public interface Identifiable
{
   public java.lang.String getId();
}
