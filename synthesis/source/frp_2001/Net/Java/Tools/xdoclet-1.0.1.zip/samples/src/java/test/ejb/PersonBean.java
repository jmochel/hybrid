package test.ejb;

import java.util.Collection;
import javax.ejb.*;
import javax.naming.*;

import test.interfaces.Person;
import test.interfaces.PersonData;
import test.interfaces.PersonPK;

/**
 *   This is a person bean. It is an example of how to use the EJBDoclet tags.
 *
 *   @ejb:bean type="CMP" name="bank/Person" generate="false" use-soft-locking="true"
 *   @ejb:finder signature="Collection findAll()" role-name="Teller"
 *   @ejb:transaction type="Required"
 *   @ejb:data-object implements="test.interfaces.Identifiable" ver-uid="7523967970034398950L" equals="true"
 *   @ejb:env-entry name="blabla" value="12345" type="java.lang.Integer"
 *
 *   JBoss/JAWS CMP specific
 *   @jboss:table-name "person"
 *   @jboss:create-table "true"
 *   @jboss:remove-table "true"
 *   @jboss:tuned-updates "true"
 *   @jboss:read-only "false"
 */

public abstract class PersonBean
   implements EntityBean
{
   EntityContext ctx;

   // Public --------------------------------------------------------
   /**
    * Name of the person.
    *
    * @ejb:interface-method
    * @ejb:persistent-field
    * @ejb:transaction type="Supports"
    * @ejb:permission role-name="Customer"
    * @ejb:permission role-name="Administrator"
    */
   public abstract String getName();

   /**
    * Name of the customer.
    *
    */
   public abstract void setName(String name);

   /**
    * FirstName of the person.
    *
    * @ejb:interface-method
    * @ejb:persistent-field
    * @ejb:transaction type="Supports"
    * @ejb:permission role-name="Customer"
    * @ejb:permission role-name="Administrator"
    */
   public abstract String getFirstName();

   /**
    * Id of this person.
    *
    * @ejb:pk-field
    * @ejb:persistent-field
    */
   public abstract String getId();

   /**
    * Id of this person.
    *
    */
   public abstract void setId(String id);

   /**
    * Generated bulk accessor.
    *
    * Not remote, but could be.
    *
    */
   public void setData(PersonData data)
   {
         setId(data.getId());
         setName(data.getName());
   }

   /**
    * Create person.
    *
    * @ejb:create-method
    * @ejb:permission role-name="Administrator"
    */
   public PersonPK ejbCreate(PersonData data)
      throws CreateException
   {
        setId(data.getId());
      setData(data);

      return null;
   }

   /**
    * Create person.
    *
    */
   public void ejbPostCreate(PersonData data)
      throws CreateException
   {
   }

   // EntityBean implementation -------------------------------------
   // The below methods are optional, since EJBDoclet will generate
   // them. They are included just to show that it's possible to do so.
   public void ejbLoad() {}
   public void ejbStore() {}
   public void ejbActivate() {}
   public void ejbPassivate() {}
   public void setEntityContext(EntityContext ctx) { this.ctx = ctx; }
   public void unsetEntityContext() {}

   /**
    * Remove
    *
    * @ejb:transaction type="Mandatory"
    */
   public void ejbRemove() throws RemoveException {}

}
