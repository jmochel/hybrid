/*
 * Xpedio
 *
 * Copyright (C) 2001
 */
package test.jmx;

/**
 * Example of a very simple JMX MBean
 *
 * @author Rickard Oberg (rickard@xpedio.com)
 * @jmx:mbean name=":service=SimpleJMX"
 */
public class SimpleJMX
   implements SimpleJMXMBean
{
   // Attributes ----------------------------------------------------

   // Static --------------------------------------------------------

   // Constructors --------------------------------------------------

   // Public --------------------------------------------------------
   /**
    * Create a greeting.
    *
    * @jmx:managed-method
    */
   public String hello(String name)
   {
      return "Hello"+name+"!";
   }

   // Package protected ---------------------------------------------
   
   // Protected -----------------------------------------------------
   
   // Private -------------------------------------------------------

   // Inner classes -------------------------------------------------
}
