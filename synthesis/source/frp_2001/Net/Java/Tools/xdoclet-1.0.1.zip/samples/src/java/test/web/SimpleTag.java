package test.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import java.io.IOException;

/**
 * A simple JSP tag.
 *
 * @author     Ara Abrahamian (ara_e@email.com)
 * @created    July 13, 2001
 * @version    $Revision: 1.2 $
 */
public class SimpleTag extends TagSupport
{
	private String     action = null;

	/**
	 * Sets the action
	 *
	 * @jsp:attribute	required="true" rtexprvalue="true"
	 *                description="The action attribute"
	 */
	public String getAction()
	{
		return this.action;
	}

	public void setAction( String action )
	{
		this.action = action;
	}

	public int doStartTag() throws JspTagException
	{
	HttpServletRequest request = ( HttpServletRequest ) pageContext.getRequest();

		try
		{
		JspWriter out = pageContext.getOut();

			out.print( "Simple tag started." );
		}
		catch( IOException ioe )
		{
			ioe.printStackTrace();
		}

		return EVAL_BODY_INCLUDE;
	}

	public int doEndTag()
	{
		try
		{
		JspWriter out = pageContext.getOut();

			out.print( "Simple tag ended." );
		}
		catch( IOException ioe )
		{
			ioe.printStackTrace();
		}

		return EVAL_PAGE;
	}
}
