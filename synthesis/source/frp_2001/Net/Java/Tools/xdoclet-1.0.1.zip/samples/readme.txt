The samples illustrate the use of XDoclet. The source code contains @tag
declarations, the script/build.xml file the build process.

Running build.xml using Ant runs ejbdoclet and webdoclet so the deployment
descriptors and EJB-related classes and interfaces are generated, WAR, EJB-JAR
and EAR files created.

The build.xml shows a typical build process with XDoclet tasks in it. You can
use it as a template for build.xml file of your own project.

Instructions for end users:

- Put these jar files in lib directory:
  - ejb.jar (v2.0), jms.jar for <ejbdoclet/> (bundled with distribution)
  - servlet.jar (v2.3), webwork.jar for <webdoclet/> (bundled with distribution)
  - parser.jar, ant.jar, jaxp.jar for Apache-Ant (not bundled with distribution)
  - xdoclet.jar and log4j.jar for XDoclet support (bundled with distribution)

  The sample won't compile without these jar files in classpath, though
  ejbdoclet will generate ejb-related sources and deployment descriptors and
  webdoclet will generate web.xml and taglib.tld, though later phases of build
  will fail.

- Now run build.bat/.sh, you should see the build process output.
Note that you can run "build ejbdoclet" to run only the <ejbdoclet/> task which
does the EJB stuff or "build webdoclet" to run only the <webdoclet/> task which
does the web stuff.

What you get:
 - Generated source files went to src-gen directory.
 - Generated deployment descriptors went to the corresponding directory under
   build directory.
 - The EJB jar file and web WAR file are generated to build/j2ee, then an EAR
   file is generated.

Note:
By default <ejbdoclet/> will generate EJB 2.0 compatible output. If you are
using a 1.1 compatible application server you may want to tell <ejbdoclet/>
to generate 1.1 compatible output. To do this edit build.xml and set
ejbspec="1.1" for the <ejbdoclet/> task.

Have Fun!
The XDoclet Team.