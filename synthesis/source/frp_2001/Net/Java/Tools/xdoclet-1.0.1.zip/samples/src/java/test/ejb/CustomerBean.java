package test.ejb;

import java.util.Collection;
import javax.ejb.*;
import javax.naming.*;

import test.interfaces.Customer;
import test.interfaces.CustomerData;
import test.interfaces.CustomerPK;
import test.interfaces.AccountHome;

/**
 *   This is a customer bean. It is an example of how to use the EJBDoclet tags.
 *
 *   @ejb:bean type="CMP" name="bank/Customer" jndi-name="ejb/bank/Customer" view-type="both" use-soft-locking="true"
 *   @ejb:finder signature="Collection findAll()" role-name="Teller" transaction-type="NotSupported"
 *   @ejb:ejb-ref ejb-name="bank/Account"
 *   @ejb:security-role-ref role-name="admin" role-link="Administrator"
 *   @ejb:permission role-name="Teller"
 *   @ejb:transaction type="Required"
 *   @ejb:data-object extends="test.interfaces.PersonData" ver-uid="7523967970034398959L" equals="true"
 *   @ejb:pk extends="test.interfaces.PersonPK"
 *
 *   @jboss:ejb-ref-jndi ref-name="bank/Account" jndi-name="ejb/bank/Account"
 *
 *   @jboss:table-name "customer"
 *   @jboss:create-table "true"
 *   @jboss:remove-table "true"
 *   @jboss:tuned-updates "true"
 *   @jboss:read-only "true"
 *   @jboss:time-out "100"
 */

public abstract class CustomerBean
   extends PersonBean
{
   EntityContext ctx;

   // Public --------------------------------------------------------
   /**
    * Id of this person.
    *
    * @ejb:pk-field
    * @ejb:persistent-field
    */
   public abstract String getId();

   public abstract void setId(String id);

   /**
    * Credit limit
    *
    * @ejb:persistent-field
    */
   public abstract float getCredit();

   /**
    * Credit limit
    *
    */
   public abstract void setCredit(float credit);

   /**
    *  Accounts of this customer
    *
    * @ejb:interface-method
    * @ejb:transaction type="Supports"
    */
   public Collection getAccounts()
   {
      try
      {
         AccountHome home = (AccountHome)new InitialContext().lookup("java:comp/env/ejb/bank/Account");
         return home.findByOwner((Customer)ctx.getEJBObject());
      } catch (Exception e)
      {
         throw new EJBException(e);
      }
   }

   /**
    * Generated bulk accessor.
    *
    * Not remote, but could be.
    *
    */
   public void setData(CustomerData data){
      try
      {
         super.setData(data);
         setCredit(data.getCredit());
      } catch (Exception e)
      {
         throw new javax.ejb.EJBException(e);
      }
   }

   /**
    * Generated bulk accessor.
    *
    * This is set as remote to allow clients to
    * get all data in one call.
    *
    * @ejb:interface-method view-type="remote"
    * @ejb:transaction type="Supports"
    */
   public CustomerData getData(){
      return null;
   }

   /**
    * Create customer.
    *
    * @ejb:create-method
    * @ejb:permission role-name="Administrator"
    */
   public CustomerPK ejbCreate(CustomerData data)
      throws CreateException
   {
      setId(data.getId());
      setData(data);

      return null;
   }

   /**
    * Create customer.
    *
    */
   public void ejbPostCreate(CustomerData data)
      throws CreateException
   {
   }

   // EntityBean implementation -------------------------------------
   /**
    * Remove
    *
    * @ejb:transaction type="Mandatory"
    */
   public void ejbRemove() throws RemoveException {}

}
