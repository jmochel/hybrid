//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.compiler;

import java.util.*;
import java.io.*;
import starlight.util.LinkedList;


public class Lexer implements TokenSource {
    protected int first [] = null;
    protected int second[] = null;
    protected int lineNum = 0;
    protected int charPos = -1;
    protected int charIndex = -1;
    protected InputStream stream = null;
    protected int nextChar = ILLEGAL;
    protected String srcOrigin = null;
    private LinkedList tokens = new LinkedList(); // lookahead tokenlist

    public Lexer() {
        init();
    }
    public Lexer(File file) {
        init();
        open(file);
    }

    public String origin() { return srcOrigin; }

    public String yytext() { return "dummy"; }
    public String yyptext() { return "pdummy"; }

    protected int linenum() { return lineNum; }
    protected int charpos() { return charPos; }
    protected int offset() { return charIndex; }

    ////
    //  return the lookahead token
    public Token lookahead() {
        if (tokens.empty())
            tokens.enQ( lex() );
        return (Token) tokens.head();
    }
    ////
    //  true iff next token ID matches id.
    public boolean match(int id)
        { return (lookahead()!=null) && (lookahead().tokenID == id); }
    ////
    //  advance the input by discarding the current lookahead token
    public void advance()
        { ptok = lookahead(); tokens.deQ(); }
    ////
    // true if no more chars to read
    public boolean eoi()  { return nextChar == EOI; }

    ////
    //  return the K'th lookahead token
    public Token lookahead(int K) {                    // K is 1-based
        int n = tokens.count();
        while (n++ < K)
            tokens.enQ( lex() );
        Token tok = (Token) tokens.elementAt(K-1);     // list is 0-based
        return (Token) tokens.head();
    }
    ////
    //  return the previously current (:-)) token
    public Token lookback() { return ptok; }
    Token ptok = null;


    protected void ERROR(String s) { System.err.println(s); }

    // what you'll get on next getc
    protected int peekc() {
        if (nextChar == ILLEGAL)
            return nextc();
        return nextChar;
    }
    // return and clear the peek buffer
    protected int getc() {
        int ch = peekc();
        nextChar = ILLEGAL;
        return ch;
    }
    // refill the peek buffer
    protected int nextc() {
        if (stream == null)
            nextChar = EOI;
        else {
            try {
                nextChar = stream.read();
                charPos++;
                charIndex++;
                if (nextChar == '\r') {
                    nextChar = stream.read();   // xlat
                    charPos++;
                    charIndex++;
                }
                if (nextChar == '\n') {
                    lineNum++;
                    charPos = 0;
                }
                if (nextChar == -1)
                    nextChar = EOI;
            } catch (IOException e) {
                System.err.println("IO Exception on read!");
                nextChar = EOI;
            }
        }
        return nextChar;
    }
    protected boolean open(File file) {
        try {
            stream = new BufferedInputStream
                (new FileInputStream(file), 32768);
            lineNum = 1;
            charPos = 0;
            charIndex = 0;
            srcOrigin = file.getAbsolutePath();
        } catch (IOException e) {
            System.err.println("File <"+file+"> not found!");
            stream = null;
            lineNum = 0;
            charPos = -1;
            charIndex = -1;
        }
        return (stream != null);
    }
    protected void init() {
        first  = new int[256];
        second = new int[256];
        lineNum = 0;
        charPos = -1;
        charIndex = -1;

        for (int i=0; i<256; i++)
            first[i]=second[i]=0;

        // treat char(0) (null) as EOI
        first[0] = EOI;
        for (int i=1; i<=' '; i++)
            first[i] = WHITE;
        for (int i='0'; i<='9'; i++)
            first[i] = NUMBER;
        for (int i='a'; i<='z'; i++)
            first[i] = IDENT;
        for (int i='A'; i<='Z'; i++)
            first[i] = IDENT;
        first['_'] = IDENT;
        first['\''] = QUOTEDCHAR;
        first['"'] = QUOTEDSTRING;
    }

    protected Token yylex() { return lex(); }
    protected Token lex() {
        Token tok = new Token(ILLEGAL, linenum(), charpos(), offset());
        int ch = getc();
        // read a comment
        if (ch == '/' && ((peekc()=='*') || (peekc()=='/'))) {
            StringBuffer buf = new StringBuffer(80);
            ch = getc();
            if (ch=='*') {
                if (peekc()=='*') {
                    getc();     // DOCCOMMENT
                    tok.tokenID = DOCCOMMENT;
                } else {
                    tok.tokenID = CCOMMENT;
                }
                ch = getc();    // first char after comment start
                while ( ! ((ch=='*') && (peekc()=='/')) ) {
                    buf.append((char)ch);
                    ch = getc();
                }
                ch = getc();    // closing slash
            } else {
                // CPPCOMMENT
                ch = getc();    // first char after comment start
                tok.tokenID = CPPCOMMENT;
                while (ch!='\n') {
                    buf.append((char)ch);
                    ch=getc();
                }
            }
        } else switch (first[ch]) {
          case WHITE:
            tok.tokenID = WHITE;
            while (first[peekc()] == WHITE)
                ch = getc();
            break;

          case NUMBER: {
            tok.tokenID = NUMBER;

            if ((ch == '0') && (first[peekc()] == NUMBER)) {        // octal
                // OCTAL
                while ((peekc()>='0')&&(peekc()<='7')) {
                    ch = getc();
                }
            } else if ((ch=='0')&&((peekc()=='x')||(peekc()=='X'))) {   // hex
                // HEX
                ch = getc(); // read "0[xX]"
                while (((peekc()>='0')&&(peekc()<='9'))
                    || ((peekc()>='a')&&(peekc()<='f'))
                    || ((peekc()>='A')&&(peekc()<='F'))) {
                    ch = getc();
                }
            } else {
                // INT
                while ((peekc()>='0') && (peekc()<='9')) {
                    ch = getc();
                }
                if (peekc() == '.') {
                    // FLOAT
                    ch = getc();
                    while ((peekc()>='0') && (peekc()<='9')) {
                        ch = getc();
                    }
                }
                if ((peekc() == 'e') || (peekc() == 'E')) {
                    // SCIENTIFIC
                    ch = getc();
                    if ((peekc() == '+') || (peekc() == '-')) {
                        ch = getc();
                    }
                    while ((peekc()>='0') && (peekc()<='9')) {
                        ch = getc();
                    }
                }
            }
          } break;

          case IDENT: {
            tok.tokenID = IDENT;
            while ((first[peekc()] == IDENT) || (first[peekc()] == NUMBER))
                getc();
          } break;

          case QUOTEDCHAR: {
            tok.tokenID = QUOTEDCHAR;
            ch = getc();
            if (ch == '\\') {
                ch = getc();
                switch (ch) {
                  //case 'a': ch = '\a'; break;
                  case 'b': ch = '\b'; break;
                  case 't': ch = '\t'; break;
                  case 'n': ch = '\n'; break;
                  //case '\': ch = '\\'; break;
                }
            }
            if (peekc()=='\'')
                ch = getc();
          } break;

          case QUOTEDSTRING: {
            tok.tokenID = QUOTEDSTRING;
            while ((ch=getc()) != '"') {
                if (ch == '\\') {
                    ch = getc();
                    switch (ch) {
                      //case 'a': ch = '\a'; break;
                      case 'b': ch = '\b'; break;
                      case 't': ch = '\t'; break;
                      case 'n': ch = '\n'; break;
                      //case '\': ch = '\\'; break;
                    }
                }
            }
          } break;

          case EOI: {
            tok.tokenID = first[ch];
          } break;

          default:
            tok.tokenID = ILLEGAL;
            break;
        }
        return tok;
    }

    public static final int ILLEGAL        = -1 ;
    public static final int EOI            = 0 ;
    public static final int IDENT          = 1 ;
    public static final int NUMBER         = 2 ;
    public static final int QUOTEDSTRING   = 3 ;
    public static final int QUOTEDCHAR     = 4 ;
    public static final int CCOMMENT       = 5 ;
    public static final int CPPCOMMENT     = 6 ;
    public static final int DOCCOMMENT     = 7 ;
    public static final int WHITE          = 8 ;

}
