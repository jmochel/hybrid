//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.compiler;

import java.util.*;
import java.io.*;


public class JavaLexer extends Lexer {

    static public Hashtable reservedWords = null;
    protected char[] sourceCode = null;

    public JavaLexer(String srcName, char[] src)
        {   srcOrigin = srcName;
            sourceCode = src;
            init();
        }

    public JavaLexer(String srcName, String src)
        {   srcOrigin = srcName;
            sourceCode = src.toCharArray();
            init();
        }

    public JavaLexer(File src) throws IOException
        {   srcOrigin = src.getAbsolutePath();
            sourceCode = readFully(new FileInputStream(src));
            init();
        }

    private char[] readFully(InputStream src) throws IOException {
        int bufsize = 2048;
        CharArrayWriter out = new CharArrayWriter(bufsize);
        InputStreamReader in = new InputStreamReader(src);

        char[] buf = new char[bufsize];
        int count = 0;
        while ((count=in.read(buf)) != -1) {
            out.write(buf, 0, count);
        }
        in.close();
        return out.toCharArray();
    }

    public TokenHolder tokenize()
        {
            TokenHolder ts = new TokenHolder(srcOrigin);
            while (!eoi()) {
                ts.append(yylex());
            }
            return ts;
        }


    ////
    //  true iff next token ID matches id.
    public final boolean match(int id) { return super.match(id); }
    ////
    //  advance the input by discarding the current lookahead token
    public final void advance() { super.advance(); }
    ////
    //  return the lookahead token
    public final Token lookahead()  { return super.lookahead(); }
    ////
    //  return the K'th lookahead token (K is 1-based)
    public final Token lookahead(int K) { return super.lookahead(K); }
    ////
    //  return the previously current (:-)) token
    public final Token lookback() { return super.lookback(); }


    public final String yytext() {
        Token tok = lookahead();
        return tok.tokenText;
    }
    public final String yyptext() {
        Token tok = lookback();
        return tok.tokenText;
    }


    ///////////////////PROTECTED/PRIVATE//////////////////
    final public boolean eoi()  { return charAt(charIndex) == EOI; }

    final protected int peekc() {
        return charAt(charIndex);
    }
    // peek ahead, ignoring n characters.
    final protected int peekc(int n) {
        return charAt(charIndex + n);
    }
    final protected int getc() {
        int ch = peekc();
        ++charIndex;
        ++charPos;
        if (charAt(charIndex) == '\r') {
            ++charIndex;
            ++charPos;
        }
        if (charAt(charIndex) == '\n') {
            ++lineNum;
            charPos = 0;
        }
        return ch;
    }
    // not used; since we're reading from an array,
    // we don't have problems with pushback
    final protected int nextc() { return EOI; }

    final protected int charAt(int ix) {
        if ((sourceCode == null)
         || (ix >= sourceCode.length))
            return EOI;
        return sourceCode[ix];
    }

    static int[] first  = null;
    static int[] second = null;

    protected void init() {
        lineNum = 1;
        charPos = 0;
        charIndex = 0;

        if (first == null) {
            first  = new int[256];
            second = new int[256];

            for (int i=0; i<256; i++)
                first[i]=second[i]=ILLEGAL;

            // treat char(0) (null) as EOI
            first[0] = EOI;
            for (int i=1; i<=' '; i++)
                first[i] = WHITE;
            for (int i='0'; i<='9'; i++)
                first[i] = NUMBER;
            for (int i='a'; i<='z'; i++)
                first[i] = IDENT;
            for (int i='A'; i<='Z'; i++)
                first[i] = IDENT;
            first['_'] = IDENT;
            first['$'] = IDENT;
            first['\''] = CHARACTER;
            first['"'] = STRING;

            first['>'] = GT;
            first['<'] = LT;
            first['&'] = AND;
            first['|'] = OR;
            first['+'] = PLUS;
            first['-'] = MINUS;
            first['*'] = STAR;
            first['/'] = SLASH;
            first['%'] = PERCENT;
            first['^'] = CARET;
            first['!'] = NOT;
            first['='] = EQ;
            first['~'] = BITNOT;
            first[','] = COMMA;
            first['.'] = DOT;
            first['?'] = QUESTION;
            first[':'] = COLON;
            first[';'] = SEMI;
            first['('] = OPENPAREN;
            first['{'] = OPENBRACE;
            first['['] = OPENBRACKET;
            first[')'] = CLOSEPAREN;
            first['}'] = CLOSEBRACE;
            first[']'] = CLOSEBRACKET;

            second['>'] = SHR;
            second['<'] = SHL;
            second['&'] = ANDAND;
            second['|'] = OROR;
            second['+'] = PLUSPLUS;
            second['-'] = MINUSMINUS;
            second['='] = EQ;
        }
        if (reservedWords == null) {
            reservedWords = new Hashtable();
            reservedWords.put("package"   , new Integer(PACKAGE));
            reservedWords.put("import"    , new Integer(IMPORT));
            reservedWords.put("class"     , new Integer(CLASS));
            reservedWords.put("interface" , new Integer(INTERFACE));
            reservedWords.put("extends"   , new Integer(EXTENDS));
            reservedWords.put("implements", new Integer(IMPLEMENTS));
            reservedWords.put("if"        , new Integer(IF));
            reservedWords.put("else"      , new Integer(ELSE));
            reservedWords.put("for"       , new Integer(FOR));
            reservedWords.put("while"     , new Integer(WHILE));
            reservedWords.put("do"        , new Integer(DO));
            reservedWords.put("try"       , new Integer(TRY));
            reservedWords.put("catch"     , new Integer(CATCH));
            reservedWords.put("finally"   , new Integer(FINALLY));
            reservedWords.put("throw"     , new Integer(THROW));
            reservedWords.put("throws"    , new Integer(THROWS));
            reservedWords.put("switch"    , new Integer(SWITCH));
            reservedWords.put("case"      , new Integer(CASE));
            reservedWords.put("default"   , new Integer(DEFAULT));
            reservedWords.put("return"    , new Integer(RETURN));
            reservedWords.put("break"     , new Integer(BREAK));
            reservedWords.put("continue"  , new Integer(CONTINUE));
            reservedWords.put("new"       , new Integer(NEW));
            reservedWords.put("instanceof", new Integer(INSTANCEOF));

            reservedWords.put("true"      , new Integer(TRUE));
            reservedWords.put("false"     , new Integer(FALSE));
            reservedWords.put("null"      , new Integer(NULL));
            reservedWords.put("super"     , new Integer(SUPER));
            reservedWords.put("this"      , new Integer(THIS));

            reservedWords.put("void"      , new Integer(VOID));
            reservedWords.put("boolean"   , new Integer(BOOLEAN));
            reservedWords.put("byte"      , new Integer(BYTE));
            reservedWords.put("char"      , new Integer(CHAR));
            reservedWords.put("short"     , new Integer(SHORT));
            reservedWords.put("int"       , new Integer(INT));
            reservedWords.put("float"     , new Integer(FLOAT));
            reservedWords.put("long"      , new Integer(LONG));
            reservedWords.put("double"    , new Integer(DOUBLE));

            reservedWords.put("public"      , new Integer(PUBLIC));
            reservedWords.put("protected"   , new Integer(PROTECTED));
            reservedWords.put("private"     , new Integer(PRIVATE));
            reservedWords.put("static"      , new Integer(STATIC));
            reservedWords.put("final"       , new Integer(FINAL));
            reservedWords.put("native"      , new Integer(NATIVE));
            reservedWords.put("synchronized", new Integer(SYNCHRONIZED));
            reservedWords.put("abstract"    , new Integer(ABSTRACT));
            reservedWords.put("threadsafe"  , new Integer(THREADSAFE));
            reservedWords.put("transient"   , new Integer(TRANSIENT));
        }
    }
    protected Token lex() {
        Token tok = yylex();
        //while ((tok.tokenID==WHITE) || (tok.tokenID==COMMENT) || (tok.tokenID==DOCCOMMENT))
        //    tok = yylex();
        return tok;
    }
    protected Token yylex() {
        Token tok = new JavaToken(ILLEGAL, linenum(), charpos(), offset());
        int ch = getc();

        // comments
        if (ch == '/' && ((peekc()=='*') || (peekc()=='/'))) {
            StringBuffer buf = new StringBuffer(512);
            buf.append((char)ch);
            ch = getc();
            buf.append((char)ch);
            if (ch=='*') {
                if (peekc() == '*' && peekc(1) != '/') {    // check for /**/
                    ch = getc();
                    buf.append((char)ch);
                    tok.tokenID = DOCCOMMENT;
                } else tok.tokenID = COMMENT;

                ch = getc();        // first char after comment-start
                while ( ! (ch == '*' && peekc() == '/') ) {
                    buf.append((char)ch);
                    ch = getc();
                }
                buf.append((char)ch);           // star
                buf.append((char)getc());       // closing slash
            } else {
                tok.tokenID = COMMENT;         // cpp-style
                while ((ch=getc())!='\n')
                    buf.append((char)ch);
                buf.append((char)ch);           // append the '\n'
            }
            tok.tokenText = new String(buf);
        }
        else switch (first[ch]) {
          case WHITE: {
            tok.tokenID = WHITE;
            StringBuffer buf = new StringBuffer();
            buf.append((char)ch);
            if (ch != '\n') {
                while ((first[peekc()] == WHITE) && (peekc() != '\n'))
                    buf.append((char)getc());
            }
            tok.tokenText = new String(buf);
          } break;

          case NUMBER: {
            tok.tokenID = NUMBER;
            StringBuffer buf = new StringBuffer(80);
            buf.append((char)ch);
            if ((ch == '0') && (first[peekc()] == NUMBER)) {        // octal
                // OCTAL
                while ((peekc()>='0')&&(peekc()<='7')) {
                    ch = getc(); buf.append((char)ch);
                }
                if (peekc() == 'l' || peekc() == 'L') buf.append(getc());
            } else if ((ch=='0')&&((peekc()=='x')||(peekc()=='X'))) {   // hex
                // HEX
                ch = getc(); buf.append((char)ch);  // read "0[xX]"
                while (((peekc()>='0')&&(peekc()<='9'))
                    || ((peekc()>='a')&&(peekc()<='f'))
                    || ((peekc()>='A')&&(peekc()<='F'))) {
                    ch = getc(); buf.append((char)ch);
                }
                if (peekc() == 'l' || peekc() == 'L') buf.append(getc());
            } else {
                // INT
                while ((peekc()>='0') && (peekc()<='9')) {
                    ch = getc(); buf.append((char)ch);
                }
                if (peekc() == 'l' || peekc() == 'L') buf.append((char)getc());
                        else {
                    if (peekc() == '.') {
                        // FLOAT
                        ch = getc(); buf.append((char)ch);
                        while ((peekc()>='0') && (peekc()<='9')) {
                            ch = getc(); buf.append((char)ch);
                        }
                    }
                    if ((peekc() == 'e') || (peekc() == 'E')) {
                        // SCIENTIFIC
                        ch = getc();  buf.append((char)ch);
                        if ((peekc() == '+') || (peekc() == '-')) {
                            ch = getc(); buf.append((char)ch);
                        }
                        int sign = (ch=='-') ? -1 : 1;
                        while ((peekc()>='0') && (peekc()<='9')) {
                            ch = getc(); buf.append((char)ch);
                        }
                    }
                    if (peekc() == 'f' || peekc() == 'F'
                     || peekc() == 'd' || peekc() == 'D'){
                        ch = getc(); buf.append((char)ch);
                    }
                }
            }
            tok.tokenText = new String(buf);
          } break;

          case IDENT: {
            tok.tokenID = IDENT;
            StringBuffer buf = new StringBuffer(32);
            buf.append((char)ch);
            while ((first[peekc()] == IDENT) || (first[peekc()] == NUMBER))
                buf.append((char)getc());
            tok.tokenText = new String(buf);
            // check for token as a reserved word
            Integer i = (Integer)reservedWords.get(tok.tokenText);
            if (i != null)
                tok.tokenID = i.intValue();
          } break;

          case CHARACTER: {
            tok.tokenID = CHARACTER;
            StringBuffer buf = new StringBuffer(8);
            buf.append((char)ch);
            ch = getc();
            buf.append((char)ch);
            if (ch == '\\') {
                ch = getc();
                buf.append((char)ch);
            }
            if (peekc()=='\'') {
                ch = getc();
                buf.append((char)ch);
            }
            tok.tokenText = new String(buf);
          } break;

          case STRING: {
            tok.tokenID = STRING;
            StringBuffer buf = new StringBuffer(80);
            buf.append((char)ch);
            while ((ch=getc()) != '"') {
                buf.append((char)ch);
                if (ch == '\\') {
                    ch = getc();
                    buf.append((char)ch);
                    switch (ch) {
                      //case 'a': ch = '\a'; break;
                      case 'b': ch = '\b'; break;
                      case 't': ch = '\t'; break;
                      case 'n': ch = '\n'; break;
                      //case '\': ch = '\\'; break;
                    }
                }
            }
            buf.append((char)ch);
            tok.tokenText = new String(buf);
          } break;

          case GT:  case LT:    case AND:
          case OR:  case PLUS:  case MINUS: {
            if (second[peekc()] != 0) {
              if (second[peekc()] == EQ) {
                getc();
                switch(first[ch]) {
                  case GT   : tok.tokenID = GE;      break;   //  >=
                  case LT   : tok.tokenID = LE;      break;   //  <=
                  case AND  : tok.tokenID = ANDEQ;   break;   //  &=
                  case OR   : tok.tokenID = OREQ;    break;   //  |=
                  case PLUS : tok.tokenID = PLUSEQ;  break;   //  +=
                  case MINUS: tok.tokenID = MINUSEQ; break;   //  -=
                  default:  ERROR("SHOULDN'T BE HERE!!");
                }
              } else {              // second[peekc()] != EQ)
                switch(first[ch]) {
                  case GT   :
                    if (second[peekc()] == SHR) {
                      int c2 = getc();  // read ">>"
                      if (peekc() == '>') {
                        int c3 = getc();  // read ">>>"
                        if (peekc() == '=') {
                          int c4 = getc();  // read ">>>="
                          tok.tokenID = ROREQ;          //  >>>=
                        } else tok.tokenID = ROR;       //  >>>
                      } else if (peekc() == '=') {
                        int c3 = getc();  // read ">>="
                        tok.tokenID = SHREQ;                //  >>=
                      } else tok.tokenID = SHR;             //  >>
                    } else tok.tokenID = GT;                //  >
                    break;
                  case LT   :
                    if (second[peekc()] == SHL) {
                      int c2 = getc();  // read "<<"
                      if (peekc() == '=') {
                        int c3 = getc();  // read "<<="
                        tok.tokenID = SHLEQ;                //  <<=
                      } else tok.tokenID = SHL;             //  <<
                    } else tok.tokenID = LT;                //  <
                    break;
                  case AND  :
                    if (second[peekc()] == ANDAND) {
                      int c2 = getc();  // read "&&"
                      tok.tokenID = ANDAND;                 //  &&
                    } else tok.tokenID = AND;               //  &
                    break;
                  case OR   :
                    if (second[peekc()] == OROR) {
                      int c2 = getc();  // read "||"
                      tok.tokenID = OROR;                   //  ||
                    } else tok.tokenID = OR;                //  |
                    break;
                  case PLUS :
                    if (second[peekc()] == PLUSPLUS) {
                      int c2 = getc();  // read "++"
                      tok.tokenID = PLUSPLUS;           //  ++
                    } else tok.tokenID = PLUS;          //  +
                    break;
                  case MINUS:
                    if (second[peekc()] == MINUSMINUS) {
                      int c2 = getc();  // read "--"
                      tok.tokenID = MINUSMINUS;             //  --
                    } else tok.tokenID = MINUS;             //  -
                    break;
                  default:
                    ERROR("SHOULDN'T BE HERE!!");
                    break;
                }
              }
            } else {
              tok.tokenID = first[ch];      //  ><&|+-
            }
          } break;

          case STAR:    case SLASH: case PERCENT:
          case CARET:   case NOT:   case EQ: {
            if (peekc() == '=') {
              int eq = getc();
              switch(first[ch]) {
                  case STAR   : tok.tokenID = STAREQ;      break;   //  *=
                  case SLASH  : tok.tokenID = SLASHEQ;   break;     //  /=
                  case PERCENT: tok.tokenID = PERCENTEQ; break;     //  %=
                  case CARET  : tok.tokenID = CARETEQ;   break;     //  ^=
                  case NOT    : tok.tokenID = NOTEQ;       break;   //  !=
                  case EQ     : tok.tokenID = EQEQ;    break;       //  ==
                  default:  ERROR("SHOULDN'T BE HERE!!");
            } } else
              tok.tokenID = first[ch];          //  */%^!=
          } break;

          case BITNOT      : case COMMA       : case DOT         :
          case QUESTION    : case COLON       : case SEMI        :
          case OPENPAREN   : case CLOSEPAREN  : case OPENBRACE   :
          case CLOSEBRACE  : case OPENBRACKET : case CLOSEBRACKET: {
            tok.tokenID = first[ch];            // ~,.?:;(){}[]
          } break;

          case EOI: {
            tok.tokenID = first[ch];
          } break;

          default:
            tok.tokenID = ILLEGAL;
            break;
        }
        tok.length = offset() - tok.offset;
        if ((tok.tokenID > COMMENT) && (tok.tokenID <= CLOSEBRACKET))
            tok.tokenText = tokenStrings[tok.tokenID];

        return tok;
    }

    ////
    //  WARNING!!!  THESE EXIST IN SEVERAL PLACES!!!
    //  so be careful.
    public static final int ILLEGAL        = -1 ;
    public static final int EOI            =  0 ;
    public static final int IDENT          =  1 ;
    public static final int NUMBER         =  2 ;
    public static final int STRING         =  3 ;
    public static final int CHARACTER      =  4 ;
    public static final int WHITE          =  5 ;
    public static final int DOCCOMMENT     =  6 ;
    public static final int COMMENT        =  7 ;

    /* keyword: */
    public static final int PACKAGE        =  8 ;
    public static final int IMPORT         =  9 ;
    public static final int CLASS          = 10 ;
    public static final int INTERFACE      = 11 ;
    public static final int EXTENDS        = 12 ;
    public static final int IMPLEMENTS     = 13 ;
    public static final int IF             = 14 ;
    public static final int ELSE           = 15 ;
    public static final int FOR            = 16 ;
    public static final int WHILE          = 17 ;
    public static final int DO             = 18 ;
    public static final int TRY            = 19 ;
    public static final int CATCH          = 20 ;
    public static final int FINALLY        = 21 ;
    public static final int THROW          = 22 ;
    public static final int THROWS         = 23 ;
    public static final int SWITCH         = 24 ;
    public static final int CASE           = 25 ;
    public static final int DEFAULT        = 26 ;
    public static final int RETURN         = 27 ;
    public static final int BREAK          = 28 ;
    public static final int CONTINUE       = 29 ;
    public static final int NEW            = 30 ;
    public static final int INSTANCEOF     = 31 ;

    public static final int TRUE           = 32 ;
    public static final int FALSE          = 33 ;
    public static final int NULL           = 34 ;
    public static final int SUPER          = 35 ;
    public static final int THIS           = 36 ;

    /* type: */
    public static final int VOID           = 37 ;
    public static final int BOOLEAN        = 38 ;
    public static final int BYTE           = 39 ;
    public static final int CHAR           = 40 ;
    public static final int SHORT          = 41 ;
    public static final int INT            = 42 ;
    public static final int FLOAT          = 43 ;
    public static final int LONG           = 44 ;
    public static final int DOUBLE         = 45 ;

    /* modifier: */
    public static final int PUBLIC         = 46 ;
    public static final int PROTECTED      = 47 ;
    public static final int PRIVATE        = 48 ;
    public static final int STATIC         = 49 ;
    public static final int FINAL          = 50 ;
    public static final int NATIVE         = 51 ;
    public static final int SYNCHRONIZED   = 52 ;
    public static final int ABSTRACT       = 53 ;
    public static final int THREADSAFE     = 54 ;
    public static final int TRANSIENT      = 55 ;

    /* comparison operator: */
    public static final int GT             = 56 ;
    public static final int LT             = 57 ;
    public static final int GE             = 58 ;
    public static final int LE             = 59 ;
    public static final int NOTEQ          = 60 ;
    public static final int EQEQ           = 61 ;

    /* binary operator: */
    public static final int PLUS           = 62 ;
    public static final int MINUS          = 63 ;
    public static final int STAR           = 64 ;
    public static final int SLASH          = 65 ;
    public static final int PERCENT        = 66 ;
    public static final int SHL            = 67 ;
    public static final int SHR            = 68 ;
    public static final int ROR            = 69 ;
    public static final int AND            = 70 ;
    public static final int OR             = 71 ;
    public static final int ANDAND         = 72 ;
    public static final int OROR           = 73 ;
    public static final int CARET          = 74 ;

    /* assignment */
    public static final int EQ             = 75 ;
    public static final int ANDEQ          = 76 ;
    public static final int OREQ           = 77 ;
    public static final int PLUSEQ         = 78 ;
    public static final int MINUSEQ        = 79 ;
    public static final int STAREQ         = 80 ;
    public static final int SLASHEQ        = 81 ;
    public static final int PERCENTEQ      = 82 ;
    public static final int CARETEQ        = 83 ;
    public static final int SHLEQ          = 84 ;
    public static final int SHREQ          = 85 ;
    public static final int ROREQ          = 86 ;

    /* unary and oddballs */
    public static final int PLUSPLUS       = 87 ;
    public static final int MINUSMINUS     = 88 ;
    public static final int NOT            = 89 ;
    public static final int BITNOT         = 90 ;
    public static final int COMMA          = 91 ;
    public static final int DOT            = 92 ;
    public static final int QUESTION       = 93 ;
    public static final int COLON          = 94 ;
    public static final int SEMI           = 95 ;

    /* grouping */
    public static final int OPENPAREN      = 96 ;
    public static final int CLOSEPAREN     = 97 ;
    public static final int OPENBRACE      = 98 ;
    public static final int CLOSEBRACE     = 99 ;
    public static final int OPENBRACKET    = 100 ;
    public static final int CLOSEBRACKET   = 101 ;

    public static final int VISIBLE        = 102 ;


    public static final String[] tokenStrings =
    {
        /* EOI          */  "eoi",         // token 0 at index 0
        /* IDENT        */  "identifier",
        /* NUMBER       */  "number",
        /* STRING       */  "string",
        /* CHARACTER    */  "character",
        /* WHITE        */  "whitespace",
        /* DOCCOMMENT   */  "docComment",
        /* COMMENT      */  "comment",
        /* PACKAGE      */  "package",
        /* IMPORT       */  "import",
        /* CLASS        */  "class",
        /* INTERFACE    */  "interface",
        /* EXTENDS      */  "extends",
        /* IMPLEMENTS   */  "implements",
        /* IF           */  "if",
        /* ELSE         */  "else",
        /* FOR          */  "for",
        /* WHILE        */  "while",
        /* DO           */  "do",
        /* TRY          */  "try",
        /* CATCH        */  "catch",
        /* FINALLY      */  "finally",
        /* THROW        */  "throw",
        /* THROWS       */  "throws",
        /* SWITCH       */  "switch",
        /* CASE         */  "case",
        /* DEFAULT      */  "default",
        /* RETURN       */  "return",
        /* BREAK        */  "break",
        /* CONTINUE     */  "continue",
        /* NEW          */  "new",
        /* INSTANCEOF   */  "instanceof",
        /* TRUE         */  "true",
        /* FALSE        */  "false",
        /* NULL         */  "null",
        /* SUPER        */  "super",
        /* THIS         */  "this",
        /* VOID         */  "void",
        /* BOOLEAN      */  "boolean",
        /* BYTE         */  "byte",
        /* CHAR         */  "char",
        /* SHORT        */  "short",
        /* INT          */  "int",
        /* FLOAT        */  "float",
        /* LONG         */  "long",
        /* DOUBLE       */  "double",
        /* PUBLIC       */  "public",
        /* PROTECTED    */  "protected",
        /* PRIVATE      */  "private",
        /* STATIC       */  "static",
        /* FINAL        */  "final",
        /* NATIVE       */  "native",
        /* SYNCHRONIZED */  "synchronized",
        /* ABSTRACT     */  "abstract",
        /* THREADSAFE   */  "threadsafe",
        /* TRANSIENT    */  "transient",
        /* GT           */  ">",
        /* LT           */  "<",
        /* GE           */  ">=",
        /* LE           */  "<=",
        /* NOTEQ        */  "!=",
        /* EQEQ         */  "==",
        /* PLUS         */  "+",
        /* MINUS        */  "-",
        /* STAR         */  "*",
        /* SLASH        */  "/",
        /* PERCENT      */  "%",
        /* SHL          */  "<<",
        /* SHR          */  ">>",
        /* ROR          */  ">>>",
        /* AND          */  "&",
        /* OR           */  "|",
        /* ANDAND       */  "&&",
        /* OROR         */  "||",
        /* CARET        */  "^",
        /* EQ           */  "=",
        /* ANDEQ        */  "&=",
        /* OREQ         */  "|=",
        /* PLUSEQ       */  "+=",
        /* MINUSEQ      */  "-=",
        /* STAREQ       */  "*=",
        /* SLASHEQ      */  "/=",
        /* PERCENTEQ    */  "%=",
        /* CARETEQ      */  "^=",
        /* SHLEQ        */  "<<=",
        /* SHREQ        */  ">>=",
        /* ROREQ        */  ">>>=",
        /* PLUSPLUS     */  "++",
        /* MINUSMINUS   */  "--",
        /* NOT          */  "!",
        /* BITNOT       */  "~",
        /* COMMA        */  ",",
        /* DOT          */  ".",
        /* QUESTION     */  "?",
        /* COLON        */  ":",
        /* SEMI         */  ";",
        /* OPENPAREN    */  "(",
        /* CLOSEPAREN   */  ")",
        /* OPENBRACE    */  "{",
        /* CLOSEBRACE   */  "}",
        /* OPENBRACKET  */  "[",
        /* CLOSEBRACKET */  "]",
        /* VISIBLE      */  "visible type"
    };

}
