//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////

import java.io.*;
import starlight.compiler.*;
import starlight.compiler.parsers.*;


public class dent {

static int indentAmount = 4;
static int trailingComment = 40;

static public void main(String[] args) {
    try {
        int argc = 0;
        if (argc >= args.length)  usage();

        while (argc < args.length) {
            if (args[argc].startsWith("-i")) {
                indentAmount = Integer.valueOf(args[argc++].substring(2)).intValue();
            } else if (args[argc].startsWith("-t")) {
                trailingComment = Integer.valueOf(args[argc++].substring(2)).intValue();
            } else {
                File infile = new File(args[argc++]);
                if (!infile.exists()) {
                    System.out.println(infile.getPath() + " can't be found.");
                    break;
                }
                processFile(infile);
            }
        }
    } catch (Exception e) {
        System.err.println(e + ":  aborting.");
        e.printStackTrace();
    }
}

static void processFile(File infile) throws IOException {

    FileFormatter formatter = new FileFormatter();
    formatter.IndentAmount = indentAmount;
    formatter.TrailingCommentColumn = trailingComment;

    // tokenize the input file...
    TokenHolder src = TokenHolder.createFrom(infile);

    // get a formatted token stream from the parser.
    TokenHolder formatted = formatter.parse(src.tokens());

    // if it didn't choke, write the output
    if (formatter.fatal()) {
        System.err.println("Error while parsing "
                            + infile.getPath() + "; skipping.");
        return;
    }
    else {
        File outfile = makeTargetFileName(infile, "_PRETTY");
        PrintWriter out = new PrintWriter(
                          new FileWriter(outfile));

        for ( TokenSource tokens = formatted.tokens();
                !tokens.eoi(); tokens.advance() ) {
            JavaToken nextToken = (JavaToken)tokens.lookahead();
            out.print(nextToken.tokenText);
        }
        out.close();
    }
}

static public TokenHolder uncompact(TokenHolder src) {
    TokenSource tokens = src.tokens();
    TokenHolder out = new TokenHolder(src.origin());
    JavaToken prevToken = null;
    JavaToken nextToken = null;
    while (!tokens.eoi()) {
        prevToken = nextToken;
        nextToken = (JavaToken)tokens.lookahead();
        if (!JavaToken.canSqueeze(prevToken, nextToken))
            out.append(new JavaToken(JavaToken.WHITE, " "));
        out.append(nextToken);
        tokens.advance();
    }
    return out;
}

/**
 * Applies a suffix to the end of the file's base name,
 * before the type extension.  ie. "sample.txt" becomes
 * "sample_SUFFIX.txt"
 **/
static File makeTargetFileName(File file, String suffix) {
    String path = file.getPath();
    String fileType = "";
    int ix = path.lastIndexOf('.');
    if (ix != -1) {
        fileType = path.substring(ix);
        path = path.substring(0, ix);
    }
    return new File(path + suffix + fileType);
}
static void usage() {
System.out.println("                                                           dent  v0.1 ");
System.out.println("                                                                      ");
System.out.println("  USAGE:  java dent [options] sourcefile [sourcefile...]              ");
System.out.println("                                                                      ");
System.out.println("   ex. java dent -i4 MyClass.java                                     ");
System.out.println("                                                                      ");
System.out.println(" options:                                                             ");
System.out.println("       -iN       sets the indent size (default 4)                     ");
System.out.println("       -tN       trailing comment start column (default 40)           ");
System.out.println("                                                                      ");
System.out.println("   sourcefile    java source file to process (output will be saved    ");
System.out.println("                 to file SourceName_PRETTY.java)                      ");
System.out.println("                                                                      ");
System.exit(0);
}
}
