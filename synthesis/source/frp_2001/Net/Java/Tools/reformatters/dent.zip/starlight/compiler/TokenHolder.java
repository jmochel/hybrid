//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.compiler;
import java.io.*;
import java.util.Vector;
import starlight.util.Iterator;
import starlight.util.VectorIterator;

public class TokenHolder {

    private Vector toks = new Vector(64);

    // file name (or whatever) that the source came
    // from, for reporting.
    private String srcOrigin = null;


    public TokenHolder(String srcName)
        { srcOrigin = srcName; }

    public String origin()
        { return srcOrigin; }

    public void append(Token tok)
        { toks.addElement(tok); }

    public boolean empty()
        { return toks.size() == 0; }

    public int size()
        { return toks.size(); }

    public TokenSource tokens()
        { return new ParsibleRange(srcOrigin, begin(), end()); }

    public Iterator  begin() { return new VectorIterator(toks, 0);      }
    public Iterator  end  () { return new VectorIterator(toks, size()); }


static public TokenHolder createFrom(String srcFile, char[] src)
    { JavaLexer lex = new JavaLexer(srcFile, src); return lex.tokenize(); }

static public TokenHolder createFrom(String srcFile, String src)
    { JavaLexer lex = new JavaLexer(srcFile, src); return lex.tokenize(); }

static public TokenHolder createFrom(File   src) throws IOException
    { JavaLexer lex = new JavaLexer(src); return lex.tokenize(); }
}
