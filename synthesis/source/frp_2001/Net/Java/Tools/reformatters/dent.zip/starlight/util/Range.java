//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.util;

import java.util.Enumeration;


public class Range implements Enumeration {
    public Iterator begin = null;
    public Iterator end   = null;

    public Range(Iterator b, Iterator e) { begin = b; end = e; }

    public final boolean empty() { return begin.equals(end); }

    public final Object nextElement() { 
        if (empty()) return null; 
        Object o = begin.getValue();
        begin.inc();
        return o;
    }
    public final boolean hasMoreElements() {
        return !empty();
    }
}
