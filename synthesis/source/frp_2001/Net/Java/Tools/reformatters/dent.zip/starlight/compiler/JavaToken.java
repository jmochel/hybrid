//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.compiler;


public class JavaToken extends Token {

    public JavaToken(int t)
        { super(t); }

    public JavaToken(int t, String s )
        { super(t, s); }

    public JavaToken(int tid, int linenum)
        { super(tid, linenum); }

    public JavaToken(int tid, int linenum, int charpos, int offset)
        { super(tid, linenum, charpos, offset); }

    public String tokenTypeName(int tid)
        { return tokenStrings[tid]; }

    public String toString() {
        return "id=" + tokenID
                + "(" + tokenStrings[tokenID]
                + ") at line " + lineNumber
                + ", col " + charPos
                + ": '" + tokenText
                + "'";
    }
    public boolean equals(JavaToken tok)
        {
            if (tokenID != tok.tokenID)
                return false;
            switch(tokenID) {
            case EOI        : return true;  // all EOI's are equal
            case WHITE      :
            case DOCCOMMENT :
            case COMMENT    : return true;  // all whitespace & comments are equal
            case CHARACTER  :
            case NUMBER     :
            case STRING     :
            case VISIBLE    :
            case IDENT      : return tokenText.equals(tok.tokenText);
            }
            return true;
        }


    /**
     *  return true iff t1 and t2 don't need whitespace between them.
     */
    public static boolean canSqueeze(JavaToken t1, JavaToken t2) {
        if ((t1 == null) || (t2 == null))
            return true;
        if ( t1.isAngry()   ||  t2.isAngry()  )  return false;
        if ( t1.isPrickly()                   )  return false;
        if (!t1.isSnuggly() && !t2.isSnuggly())  return false;
        return true;
    }

    /**
     *  snuggly prefers NO whitespace to its left
     *  prickly HAS TO HAVE whitespace to its right
     *    angry HAS TO HAVE whitespace to its left and right
     */
    public final boolean isSnuggly() { return (touch[tokenID]&SNUGGLY)==SNUGGLY; }
    public final boolean isPrickly() { return (touch[tokenID]&PRICKLY)==PRICKLY; }
    public final boolean   isAngry() { return (touch[tokenID]&ANGRY)==ANGRY; }


    private static final int BLASE=0, SNUGGLY=1, PRICKLY=2, ANGRY=4;
    private static final int[] touch =
    {
        /* EOI          */  BLASE,         // token 0 at index 0
        /* IDENT        */  BLASE,
        /* NUMBER       */  BLASE,
        /* STRING       */  BLASE,
        /* CHARACTER    */  BLASE,
        /* WHITE        */  SNUGGLY,
        /* DOCCOMMENT   */  BLASE,
        /* COMMENT      */  BLASE,

        /* PACKAGE      */  BLASE,
        /* IMPORT       */  BLASE,
        /* CLASS        */  BLASE,
        /* INTERFACE    */  BLASE,
        /* EXTENDS      */  BLASE,
        /* IMPLEMENTS   */  BLASE,
        /* IF           */  PRICKLY,
        /* ELSE         */  BLASE,
        /* FOR          */  PRICKLY,
        /* WHILE        */  PRICKLY,
        /* DO           */  BLASE,
        /* TRY          */  BLASE,
        /* CATCH        */  PRICKLY,
        /* FINALLY      */  BLASE,
        /* THROW        */  BLASE,
        /* THROWS       */  BLASE,
        /* SWITCH       */  PRICKLY,
        /* CASE         */  BLASE,
        /* DEFAULT      */  BLASE,
        /* RETURN       */  PRICKLY,
        /* BREAK        */  BLASE,
        /* CONTINUE     */  BLASE,
        /* NEW          */  BLASE,
        /* INSTANCEOF   */  BLASE,
        /* TRUE         */  BLASE,
        /* FALSE        */  BLASE,
        /* NULL         */  BLASE,
        /* SUPER        */  BLASE,
        /* THIS         */  BLASE,
        /* VOID         */  BLASE,
        /* BOOLEAN      */  BLASE,
        /* BYTE         */  BLASE,
        /* CHAR         */  BLASE,
        /* SHORT        */  BLASE,
        /* INT          */  BLASE,
        /* FLOAT        */  BLASE,
        /* LONG         */  BLASE,
        /* DOUBLE       */  BLASE,
        /* PUBLIC       */  BLASE,
        /* PROTECTED    */  BLASE,
        /* PRIVATE      */  BLASE,
        /* STATIC       */  BLASE,
        /* FINAL        */  BLASE,
        /* NATIVE       */  BLASE,
        /* SYNCHRONIZED */  BLASE,
        /* ABSTRACT     */  BLASE,
        /* THREADSAFE   */  BLASE,
        /* TRANSIENT    */  BLASE,

        /* GT           */  ANGRY,
        /* LT           */  ANGRY,
        /* GE           */  ANGRY,
        /* LE           */  ANGRY,
        /* NOTEQ        */  ANGRY,
        /* EQEQ         */  ANGRY,

        /* PLUS         */  ANGRY,
        /* MINUS        */  ANGRY,
        /* STAR         */  ANGRY,
        /* SLASH        */  ANGRY,
        /* PERCENT      */  ANGRY,
        /* SHL          */  ANGRY,
        /* SHR          */  ANGRY,
        /* ROR          */  ANGRY,
        /* AND          */  ANGRY,
        /* OR           */  ANGRY,
        /* ANDAND       */  ANGRY,
        /* OROR         */  ANGRY,
        /* CARET        */  ANGRY,

        /* EQ           */  ANGRY,
        /* ANDEQ        */  ANGRY,
        /* OREQ         */  ANGRY,
        /* PLUSEQ       */  ANGRY,
        /* MINUSEQ      */  ANGRY,
        /* STAREQ       */  ANGRY,
        /* SLASHEQ      */  ANGRY,
        /* PERCENTEQ    */  ANGRY,
        /* CARETEQ      */  ANGRY,
        /* SHLEQ        */  ANGRY,
        /* SHREQ        */  ANGRY,
        /* ROREQ        */  ANGRY,

        /* PLUSPLUS     */  SNUGGLY,
        /* MINUSMINUS   */  SNUGGLY,
        /* NOT          */  SNUGGLY,
        /* BITNOT       */  SNUGGLY,
        /* COMMA        */  SNUGGLY + PRICKLY,
        /* DOT          */  SNUGGLY,
        /* QUESTION     */  SNUGGLY + PRICKLY,
        /* COLON        */  SNUGGLY + PRICKLY,
        /* SEMI         */  SNUGGLY + PRICKLY,

        /* OPENPAREN    */  SNUGGLY,
        /* CLOSEPAREN   */  SNUGGLY,
        /* OPENBRACE    */  PRICKLY,
        /* CLOSEBRACE   */  PRICKLY,
        /* OPENBRACKET  */  SNUGGLY,
        /* CLOSEBRACKET */  SNUGGLY,

        /* VISIBLE      */  BLASE,
    };

    ////
    //  WARNING!!!  THESE EXIST IN SEVERAL PLACES!!!
    //  so be careful.
    public static final int ILLEGAL        = -1 ;
    public static final int EOI            =  0 ;
    public static final int IDENT          =  1 ;
    public static final int NUMBER         =  2 ;
    public static final int STRING         =  3 ;
    public static final int CHARACTER      =  4 ;
    public static final int WHITE          =  5 ;
    public static final int DOCCOMMENT     =  6 ;
    public static final int COMMENT        =  7 ;

    /* keyword: */
    public static final int PACKAGE        =  8 ;
    public static final int IMPORT         =  9 ;
    public static final int CLASS          = 10 ;
    public static final int INTERFACE      = 11 ;
    public static final int EXTENDS        = 12 ;
    public static final int IMPLEMENTS     = 13 ;
    public static final int IF             = 14 ;
    public static final int ELSE           = 15 ;
    public static final int FOR            = 16 ;
    public static final int WHILE          = 17 ;
    public static final int DO             = 18 ;
    public static final int TRY            = 19 ;
    public static final int CATCH          = 20 ;
    public static final int FINALLY        = 21 ;
    public static final int THROW          = 22 ;
    public static final int THROWS         = 23 ;
    public static final int SWITCH         = 24 ;
    public static final int CASE           = 25 ;
    public static final int DEFAULT        = 26 ;
    public static final int RETURN         = 27 ;
    public static final int BREAK          = 28 ;
    public static final int CONTINUE       = 29 ;
    public static final int NEW            = 30 ;
    public static final int INSTANCEOF     = 31 ;

    public static final int TRUE           = 32 ;
    public static final int FALSE          = 33 ;
    public static final int NULL           = 34 ;
    public static final int SUPER          = 35 ;
    public static final int THIS           = 36 ;

    /* type: */
    public static final int VOID           = 37 ;
    public static final int BOOLEAN        = 38 ;
    public static final int BYTE           = 39 ;
    public static final int CHAR           = 40 ;
    public static final int SHORT          = 41 ;
    public static final int INT            = 42 ;
    public static final int FLOAT          = 43 ;
    public static final int LONG           = 44 ;
    public static final int DOUBLE         = 45 ;

    /* modifier: */
    public static final int PUBLIC         = 46 ;
    public static final int PROTECTED      = 47 ;
    public static final int PRIVATE        = 48 ;
    public static final int STATIC         = 49 ;
    public static final int FINAL          = 50 ;
    public static final int NATIVE         = 51 ;
    public static final int SYNCHRONIZED   = 52 ;
    public static final int ABSTRACT       = 53 ;
    public static final int THREADSAFE     = 54 ;
    public static final int TRANSIENT      = 55 ;

    /* comparison operator: */
    public static final int GT             = 56 ;
    public static final int LT             = 57 ;
    public static final int GE             = 58 ;
    public static final int LE             = 59 ;
    public static final int NOTEQ          = 60 ;
    public static final int EQEQ           = 61 ;

    /* binary operator: */
    public static final int PLUS           = 62 ;
    public static final int MINUS          = 63 ;
    public static final int STAR           = 64 ;
    public static final int SLASH          = 65 ;
    public static final int PERCENT        = 66 ;
    public static final int SHL            = 67 ;
    public static final int SHR            = 68 ;
    public static final int ROR            = 69 ;
    public static final int AND            = 70 ;
    public static final int OR             = 71 ;
    public static final int ANDAND         = 72 ;
    public static final int OROR           = 73 ;
    public static final int CARET          = 74 ;

    /* assignment */
    public static final int EQ             = 75 ;
    public static final int ANDEQ          = 76 ;
    public static final int OREQ           = 77 ;
    public static final int PLUSEQ         = 78 ;
    public static final int MINUSEQ        = 79 ;
    public static final int STAREQ         = 80 ;
    public static final int SLASHEQ        = 81 ;
    public static final int PERCENTEQ      = 82 ;
    public static final int CARETEQ        = 83 ;
    public static final int SHLEQ          = 84 ;
    public static final int SHREQ          = 85 ;
    public static final int ROREQ          = 86 ;

    /* unary and oddballs */
    public static final int PLUSPLUS       = 87 ;
    public static final int MINUSMINUS     = 88 ;
    public static final int NOT            = 89 ;
    public static final int BITNOT         = 90 ;
    public static final int COMMA          = 91 ;
    public static final int DOT            = 92 ;
    public static final int QUESTION       = 93 ;
    public static final int COLON          = 94 ;
    public static final int SEMI           = 95 ;

    /* grouping */
    public static final int OPENPAREN      = 96 ;
    public static final int CLOSEPAREN     = 97 ;
    public static final int OPENBRACE      = 98 ;
    public static final int CLOSEBRACE     = 99 ;
    public static final int OPENBRACKET    = 100 ;
    public static final int CLOSEBRACKET   = 101 ;

    public static final int VISIBLE        = 102 ;


    public static final String[] tokenStrings =
    {
        /* EOI          */  "eoi",         // token 0 at index 0
        /* IDENT        */  "identifier",
        /* NUMBER       */  "number",
        /* STRING       */  "string",
        /* CHARACTER    */  "character",
        /* WHITE        */  "whitespace",
        /* DOCCOMMENT   */  "docComment",
        /* COMMENT      */  "comment",
        /* PACKAGE      */  "package",
        /* IMPORT       */  "import",
        /* CLASS        */  "class",
        /* INTERFACE    */  "interface",
        /* EXTENDS      */  "extends",
        /* IMPLEMENTS   */  "implements",
        /* IF           */  "if",
        /* ELSE         */  "else",
        /* FOR          */  "for",
        /* WHILE        */  "while",
        /* DO           */  "do",
        /* TRY          */  "try",
        /* CATCH        */  "catch",
        /* FINALLY      */  "finally",
        /* THROW        */  "throw",
        /* THROWS       */  "throws",
        /* SWITCH       */  "switch",
        /* CASE         */  "case",
        /* DEFAULT      */  "default",
        /* RETURN       */  "return",
        /* BREAK        */  "break",
        /* CONTINUE     */  "continue",
        /* NEW          */  "new",
        /* INSTANCEOF   */  "instanceof",
        /* TRUE         */  "true",
        /* FALSE        */  "false",
        /* NULL         */  "null",
        /* SUPER        */  "super",
        /* THIS         */  "this",
        /* VOID         */  "void",
        /* BOOLEAN      */  "boolean",
        /* BYTE         */  "byte",
        /* CHAR         */  "char",
        /* SHORT        */  "short",
        /* INT          */  "int",
        /* FLOAT        */  "float",
        /* LONG         */  "long",
        /* DOUBLE       */  "double",
        /* PUBLIC       */  "public",
        /* PROTECTED    */  "protected",
        /* PRIVATE      */  "private",
        /* STATIC       */  "static",
        /* FINAL        */  "final",
        /* NATIVE       */  "native",
        /* SYNCHRONIZED */  "synchronized",
        /* ABSTRACT     */  "abstract",
        /* THREADSAFE   */  "threadsafe",
        /* TRANSIENT    */  "transient",
        /* GT           */  ">",
        /* LT           */  "<",
        /* GE           */  ">=",
        /* LE           */  "<=",
        /* NOTEQ        */  "!=",
        /* EQEQ         */  "==",
        /* PLUS         */  "+",
        /* MINUS        */  "-",
        /* STAR         */  "*",
        /* SLASH        */  "/",
        /* PERCENT      */  "%",
        /* SHL          */  "<<",
        /* SHR          */  ">>",
        /* ROR          */  ">>>",
        /* AND          */  "&",
        /* OR           */  "|",
        /* ANDAND       */  "&&",
        /* OROR         */  "||",
        /* CARET        */  "^",
        /* EQ           */  "=",
        /* ANDEQ        */  "&=",
        /* OREQ         */  "|=",
        /* PLUSEQ       */  "+=",
        /* MINUSEQ      */  "-=",
        /* STAREQ       */  "*=",
        /* SLASHEQ      */  "/=",
        /* PERCENTEQ    */  "%=",
        /* CARETEQ      */  "^=",
        /* SHLEQ        */  "<<=",
        /* SHREQ        */  ">>=",
        /* ROREQ        */  ">>>=",
        /* PLUSPLUS     */  "++",
        /* MINUSMINUS   */  "--",
        /* NOT          */  "!",
        /* BITNOT       */  "~",
        /* COMMA        */  ",",
        /* DOT          */  ".",
        /* QUESTION     */  "?",
        /* COLON        */  ":",
        /* SEMI         */  ";",
        /* OPENPAREN    */  "(",
        /* CLOSEPAREN   */  ")",
        /* OPENBRACE    */  "{",
        /* CLOSEBRACE   */  "}",
        /* OPENBRACKET  */  "[",
        /* CLOSEBRACKET */  "]",
        /* VISIBLE      */  "visible type"
    };
}
