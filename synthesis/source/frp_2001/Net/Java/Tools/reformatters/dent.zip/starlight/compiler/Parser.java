//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.compiler;

import java.util.*;
import starlight.util.*;

public class Parser
{
    public  TokenSource  lex = null;
    private Token        ptok;
    boolean              ignoreWhite = false;
    private IntegerStack parseStack = new IntegerStack(64);
    private BitSet       synch      = new BitSet();

    public Parser() { loadSyncSet(); }

    public void   ws() { ignoreWhite = false; }
    public void nows() { ignoreWhite = true ; }

    public boolean isWhite(int tok) { return false; }

    public void skipWhite() {
        while (isWhite(lex.lookahead().tokenID))
            lex.advance();
    }
    public Token lookahead() {
        if (ignoreWhite)  skipWhite();
        return lex.lookahead();
    }
    public boolean match(int t) {
        if (ignoreWhite)  skipWhite();
        return lex.match(t);
    }
    public void advance() {
        if (ignoreWhite)  skipWhite();
        ptok = lex.lookahead();
        lex.advance();
        if (ignoreWhite)  skipWhite();
    }

    public boolean     eoi() { return ( (lex==null) || lex.eoi() ); }
    public String   yytext() { return (ptok!=null)? ptok.tokenText: null; }
    public String     file() { return (lex!=null)? lex.origin(): "no file loaded"; }
    public int        line() { return (lex!=null)? lex.lookahead().lineNumber: 0; }

    public boolean warning() { return WorstErrorEncountered >= WARNING; }
    public boolean   error() { return WorstErrorEncountered >= ERROR; }
    public boolean   fatal() { return WorstErrorEncountered >= FATAL; }

    ////
    // 0 == EOI <= TERM < EPSILON < NONTERM < ACTION
    public int minNonterm = 0;
    public int minAction  = 0;

    public boolean ISTERM   (int i) { return i>=0 && i<minNonterm; }
    public boolean ISNONTERM(int i) { return i>=minNonterm && i<minAction; }
    public boolean ISACTION (int i) { return i>=minAction; }

    ////
    //  pop parse stack until top symbol is a term that's
    // in synch set; then read input until we match.
    //
    boolean yySynch() {
        while (!parseStack.empty()
            && !( ISTERM(parseStack.top())
               && synch.get(parseStack.top()) ))
            parseStack.pop();

        if (parseStack.empty()) {
            while (!eoi() && !synch.get(lookahead().tokenID))
                advance();
            if (!lex.eoi())
                advance();
            return false;
        }
        while ( !eoi() && !match(parseStack.top()) ) {
            advance();
        }
        if (eoi())
            return false;

        return true;
    }

    // utility fn for loadSyncSet()
    protected void addToSync(int tok) { synch.set(tok); }

    // override to load synch set
    protected void loadSyncSet() {}

    // override for initializations (hooking up lex'er, etc
    protected void initLLama() {}

    // override for action-specific init ??
    protected void initActs()  {}

    // override to execute the action identified by actNum
    protected void doAction(int actNum) {}

    // override to return prod num for this symbol,token pair
    protected int nextProduction(int symNum, int nextTok) {return -1;}

    // override to return ix'th symbol in the push-table entry for prod
    protected int nextSymbol(int prod, int ix) { return -1; }

    // push goal symbol and parse it.
    public void yyParse() { yyParse(minNonterm); }

    // push goal symbol (any non-term) and parse it.
    public void yyParse(int goal)
    {
        WorstErrorEncountered = NONE;

        initLLama();
        initActs();

        parseStack.clear();
        parseStack.push(goal);

        int goAround = 0;

        while (!parseStack.empty()) {
            if (goAround > 0)
                --goAround;

            if (ISACTION(parseStack.top()))
            {
                int act = parseStack.pop();
                doAction(act);
            }
            else if (ISTERM(parseStack.top()))
            {
                if (match(parseStack.top())) {
                    parseStack.pop();
                    advance();
                } else {    // handle errors
                            if (goAround == 0) {
                                goAround = 9;
                                lerror(NONFATAL,
                                     "inserting missing " + lookahead().tokenTypeName(parseStack.top()) );
                                int tmp = parseStack.pop();
                            } else {
                                lerror(NONFATAL,
                                     "expected " + lookahead().tokenTypeName(parseStack.top())
                                    + "; found " + lookahead().tokenTypeName(lookahead().tokenID)
                                    + " (" + lookahead().tokenText + ")");
                                if (yySynch() == false) {
                                    lerror(FATAL, "couldn't resynchronize.");
                                    return;
                            }   }
                }
            }
            else if (ISNONTERM(parseStack.top()))
            {
                // nonTerminal; pop it and push its rhs
                int prod = nextProduction(
                    parseStack.top(), lookahead().tokenID);
                if (prod != -1) {
                    parseStack.pop();
                    for (int sym, i=0;
                        (sym=nextSymbol(prod, i)) != -1;
                        i++ ) {
                        parseStack.push(sym);
                    }
                } else {    // handle errors
                            lerror(NONFATAL,
                                 "unexpected " + lookahead().tokenTypeName(lookahead().tokenID)
                                + " (" + lookahead().tokenText + ")");
                            if (yySynch() == false) {
                                lerror(FATAL, "couldn't resynchronize.");
                                return;
                            }
                }
            } else {        // handle errors
                            lerror(NONFATAL, "Parse Stack top = "
                                + parseStack.top()
                                + ".  How'd that get there?");
                            if (yySynch() == false) {
                                lerror(FATAL, "couldn't resynchronize.");
                                return;
                            }
            }
        }
    }

    public static final int NONE=0,
                            INFO=1,
                            WARNING=2,
                            ERROR=3,
                            NONFATAL=ERROR,
                            FATAL=4;

    protected int WorstErrorEncountered = NONE;

    public void lerror(int level, String txt) {

        if (level > WorstErrorEncountered)
            WorstErrorEncountered = level;

        switch (level) {
        case    INFO:    INFO(txt); break;
        case WARNING: WARNING(txt); break;
        case   ERROR:   ERROR(txt); break;
        case   FATAL:   FATAL(txt); break;
        }
    }
    protected void INFO(String s)
        { /* System.err.println(s); */ }

    protected void WARNING(String s)
        { System.err.println(file() + ":" + line() + ":" + s); }

    protected void ERROR(String s)
        { System.err.println(file() + ":" + line() + ":" + s); }

    protected void FATAL(String s)
        { System.err.println(file() + ":" + line() + ":" + s); }
}
