//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.util;

import java.util.*;


public class VectorIterator implements Iterator {
    Vector vector;
    int    index;

    public VectorIterator(Vector x)
        {
            vector = x;
            index  = 0;
        }
    public VectorIterator(Vector x, int ix)
        {
            if (ix < 0 || ix > x.size())
                throw new ArrayIndexOutOfBoundsException(ix);
            vector = x;
            index  = ix;
        }

    /**
    *  increment and return this iterator
    */
    public Iterator inc()
        {
            if (index < vector.size())
                ++index;
            else throw new ArrayIndexOutOfBoundsException(index);
            return this;
        }

    /**
    *  decrement and return this iterator
    */
    public Iterator dec()
        {
            if (index > 0)
                --index;
            else throw new ArrayIndexOutOfBoundsException(index);
            return this;
        }

    /**
    *  return true iff iterator points at same element
    * as other.
    */
    public boolean equals(Iterator other)
        {
            return ((other instanceof VectorIterator)
                 && (vector == ((VectorIterator)other).vector)
                 && (index  == ((VectorIterator)other).index ));
        }
    /**
    *  return the value at this iterator's position
    */
    public Object getValue() { return vector.elementAt(index); }
}
