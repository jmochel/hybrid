//////////////////////license & copyright header///////////////////////
//                                                                   //
//                Copyright (c) 1998 by Kevin Kelley                 //
//                                                                   //
// This program is free software; you can redistribute it and/or     //
// modify it under the terms of the GNU General Public License as    //
// published by the Free Software Foundation; either version 2 of    //
// the License, or (at your option) any later version.               //
//                                                                   //
// This program is distributed in the hope that it will be useful,   //
// but WITHOUT ANY WARRANTY; without even the implied warranty of    //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     //
// GNU General Public License for more details.                      //
//                                                                   //
// You should have received a copy of the GNU General Public License //
// along with this program in the file 'gpl.html'; if not, write to  //
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,  //
// Boston, MA 02111-1307, USA, or contact the author:                //
//                                                                   //
//                       Kevin Kelley  <kelley@iguana.ruralnet.net>  //
//                                                                   //
////////////////////end license & copyright header/////////////////////
package starlight.util;

import java.util.*;


public class LinkedList {

    private class Node {
        Node next;
        Object object;

        Node(Object o) { object = o; }
    }

    private class LLIterator implements Iterator {
        Node node = null;

        public LLIterator(Node x) {node = x; }

        public Iterator inc()
            { if (node!=null) node = node.next; return this; }

        public Iterator dec()
            { throw new RuntimeException("LinkedList can't back up!"); }

        public boolean equals(Iterator other) {
            if (other instanceof LLIterator)
                return node == ((LLIterator)other).node;
            return false;
        }

        public Object getValue()
            { if (node==null) return null; return node.object; }
    }

    Node head = null;
    Node tail = null;

    public Iterator begin() { return new LLIterator( head ); }
    public Iterator end  () { return new LLIterator( null ); }

    public Enumeration elements() { return new Range(begin(), end()); }

    public void push(Object o) {
        Node node = new Node(o);
        if (tail==null)
            head = tail = node;
        else {
            node.next = head;
            head = node;
    }   }
    public Object  pop() { return deQ(); }
    public Object  top() { if (head!=null) return head.object; return null; }

    ////
    //  append at end, remove from front.
    public void append(Object o) { enQ(o); }
    public Object remove() { return deQ(); }


    public Object head() { if (head!=null) return head.object; return null; }
    public Object tail() { if (tail!=null) return tail.object; return null; }

    public void clear() { head = tail = null; }

    public boolean empty() { return head==null; }
    public int     size () { return count(); }

    public int count() {
        int cnt = 0;
        Node node = head;
        while (node!=null) {
            node = node.next;
            cnt++;
        }
        return cnt;
    }
    public Object elementAt(int ix) {
        Node node = head;
        while ((node!=null) && (ix-- > 0))
            node = node.next;
        if (node!=null)
            return node.object;
        return null;
    }
    public void enQ(Object o) {
        Node node = new Node(o);
        if (tail==null)
            head = tail = node;
        else
            tail = tail.next = node;
    }
    public Object deQ() {
        Node node = head;
        if (head==tail)
            head = tail = null;
        else head = head.next;
        if (node!=null)
            return node.object;
        return null;
    }
}
