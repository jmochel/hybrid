/*
 * $Id: DocLint.java,v 1.4 2000/07/12 20:36:43 ernst Exp $
 *
 * Copyright (C) 2000  Ernst de Haan
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package com.jollem.doclint;

import com.sun.javadoc.*;
import java.util.*;

/**
 * Doclet that checks that there is information available for every package,
 * class, interface and member.
 *
 * @version $Revision: 1.4 $
 * @author Ernst de Haan
 *         (<A href="mailto:ernst@jollem.com">ernst@jollem.com</A>)
 */
public class DocLint extends Doclet {

   //-------------------------------------------------------------------------
   // all current state
   //-------------------------------------------------------------------------

   /**
    * The Doc item that holds information about the current run of
    * <EM>javadoc</EM>.
    */
   protected static RootDoc _rootDoc;

   /**
    * The Doc item that holds information about the current package, if any.
    */
   protected static PackageDoc _packageDoc;

   /**
    * The name of the current package, if any.
    */
   protected static String _packageName;

   /**
    * The Doc item that holds information about the current class, if any.
    */
   protected static ClassDoc _classDoc;

   /**
    * The fully qualified name of the current class or interface, if any.
    */
   protected static String _className;

   /**
    * The name of the current member. A member is either an executable member,
    * or a field.
    */
   protected static String _memberName;

   /**
    * The Doc item that holds information about the current field.
    */
   protected static FieldDoc _fieldDoc;

   /**
    * The Doc item that holds information about the current executable member,
    * if any. An executable member of a class is any constructor, instance
    * method or class function.
    */
   protected static ExecutableMemberDoc _executableMemberDoc;

   /**
    * The signature of the current executable member, if any.
    */
   protected static String _executableMemberSignature;


   //-------------------------------------------------------------------------
   // statistics
   //-------------------------------------------------------------------------

   protected static int _packageCount;
   protected static int _classCount;
   protected static int _fieldCount;
   protected static int _methodCount;
   protected static int _constructorCount;

   protected static int _undocumentedPackageCount;
   protected static int _undocumentedClassCount;
   protected static int _undocumentedFieldCount;
   protected static int _undocumentedMethodCount;
   protected static int _undocumentedConstructorCount;


   protected static void printStats() {

      int percUndocumentedPackages =
         computePercentage(_undocumentedPackageCount,
                           _packageCount);
      int percUndocumentedClasses =
         computePercentage(_undocumentedClassCount,
                           _classCount);
      int percUndocumentedFields =
         computePercentage(_undocumentedFieldCount,
                           _fieldCount);
      int percUndocumentedConstructors =
         computePercentage(_undocumentedConstructorCount,
                           _constructorCount);
      int percUndocumentedMethods =
         computePercentage(_undocumentedMethodCount,
                           _methodCount);

      _rootDoc.printNotice(
         "Undocumented packages: " + _undocumentedPackageCount + '/' +
         _packageCount + " (" + percUndocumentedPackages + "%).");
      _rootDoc.printNotice(
         "Undocumented classes: " + _undocumentedClassCount + '/' +
         _classCount + " (" + percUndocumentedClasses + "%).");
      _rootDoc.printNotice(
         "Undocumented fields: " + _undocumentedFieldCount + '/' +
         _fieldCount + " (" +
         percUndocumentedFields + "%).");
      _rootDoc.printNotice(
         "Undocumented constructors: " + _undocumentedConstructorCount + '/' +
         _constructorCount + " (" + percUndocumentedConstructors + "%).");
      _rootDoc.printNotice(
         "Undocumented methods: " + _undocumentedMethodCount + '/' +
         _methodCount + " (" + percUndocumentedMethods + "%).");
   }


   //-------------------------------------------------------------------------
   // start
   //-------------------------------------------------------------------------

   /**
    * Run this doclet for the specified packages or classes.
    *
    * @param rootDoc
    *    The information for this run of <EM>javadoc</EM>.
    *
    * @return
    *    On success, <CODE>true</CODE>, on failure: <CODE>false</CODE>.
    */
   public static boolean start(RootDoc rootDoc) {

      // Set current RootDoc
      _rootDoc = rootDoc;

      // Perform checks
      checkPackages(rootDoc.specifiedPackages());
      checkClasses(rootDoc.specifiedClasses());

      // Print stats
      printStats();

      // Unset current RootDoc
      _rootDoc = null;

      return true;
   }


   //-------------------------------------------------------------------------
   // top-level check methods, these are final
   //-------------------------------------------------------------------------

   /**
    * Checks all aspects of the documentation of the specified packages. This
    * class function will perform the following steps for every package:
    *
    * <P><UL>
    *    <LI>sets the fields <CODE>_packageDoc</CODE> and
    *        <CODE>_packageName</CODE>
    *    <LI>calls <CODE>checkPackageImpl()</CODE>
    *    <LI>calls <CODE>checkClasses(ClassDoc[])</CODE>
    * </UL>
    *
    * <P>If the argument is <CODE>null</CODE>, then no packages or classes are
    * checked.
    *
    * <P>At the end, both <CODE>_packageDoc</CODE> and
    * <CODE>_packageName</CODE> are set to <CODE>null</CODE>.
    *
    * <P>Note: This method does not handle duplicate elements gracefully.
    *
    * @param packages
    *    The packages to be checked. There should be no null elements, and no
    *    duplicate elements.
    */
   protected final static void checkPackages(PackageDoc[] packages) {

      int packageCount = (packages==null) ? 0 : packages.length;
      for (int i=0; i<packageCount; i++) {

         // Set current PackageDoc
         _packageDoc  = packages[i];
         _packageName = _packageDoc.name();

         // Update stats
         _packageCount++;

         // Perform the checks
         checkPackageImpl();
         checkClasses(_packageDoc.allClasses());
      }

      // Unset current PackageDoc
      _packageDoc = null;
      _packageName = null;
   }

   protected final static void checkClasses(ClassDoc[] classes) {

      int classCount = (classes==null) ? 0 : classes.length;
      for (int i=0; i<classCount; i++) {

         // Set current ClassDoc
         _classDoc = classes[i];
         _className = _classDoc.name();

         // Update stats
         _classCount++;

         // Perform the checks
         checkClassImpl();

         ConstructorDoc[] constructors = _classDoc.constructors();
         MethodDoc[] methods           = _classDoc.methods();
         FieldDoc[] fields             = _classDoc.fields();

         checkFields(fields);
         checkExecutableMembers(constructors);
         checkExecutableMembers(methods);
      }

      // Unset current ClassDoc
      _classDoc = null;
      _className = null;
   }

   protected final static void checkFields(FieldDoc[] fields) {

      int fieldCount = (fields==null) ? 0 : fields.length;
      for (int i=0; i<fieldCount; i++) {

         // Update stats
         _fieldCount++;

         // Set current field
         _fieldDoc   = fields[i];
         _memberName = _fieldDoc.name();

         // Perform checks
         checkFieldImpl();
      }

      // Unset current field
      _fieldDoc = null;
      _memberName = null;
   }

   protected final static void checkExecutableMembers(
      ExecutableMemberDoc[] members) {

      int memberCount = (members==null) ? 0 : members.length;
      for (int i=0; i<memberCount; i++) {

         _executableMemberDoc       = members[i];
         _executableMemberSignature = _executableMemberDoc.flatSignature();

         if (_executableMemberDoc instanceof ConstructorDoc) {
            _constructorCount++;
            checkConstructor();
         } else if (_executableMemberDoc instanceof MethodDoc) {
            _methodCount++;
            checkMethod();
         } else {
            // XXX
         }

         checkParameters();
         checkReturn();
         checkExceptions();
      }

      // Unset current MemberDoc
      _executableMemberDoc = null;
      _memberName          = null;
      _executableMemberSignature = null;
   }

   protected final static void checkConstructor() {
      _memberName = "<init>";
      checkConstructorImpl();
   }

   protected final static void checkMethod() {
      _memberName = _executableMemberDoc.name();
      checkMethodImpl();
   }

   protected final static void checkParameters() {
      checkParametersImpl();
   }
      
   protected final static void checkReturn() {
      if (_executableMemberDoc instanceof MethodDoc) {
         checkMethodReturnImpl();
      } else if (_executableMemberDoc instanceof ConstructorDoc) {
         checkConstructorReturnImpl();
      } // else ... XXX
   }
      
   protected final static void checkExceptions() {
      checkExceptionsImpl();
   }
      

   //-------------------------------------------------------------------------
   // second-level implementation methods, these can be overridden
   //-------------------------------------------------------------------------

   protected static void checkPackageImpl() {

      // Get details
      String     comment = _packageDoc.commentText();
      ClassDoc[] classes = _packageDoc.allClasses();

      // Perform checks
      if (isEmptyString(comment)) {
         _undocumentedPackageCount++;
         missingPackageComments();
      }
   }

   protected final static void checkClassImpl() {

      // Get details
      String comment = _classDoc.commentText();

      // Perform checks
      if (isEmptyString(comment)) {
         _undocumentedClassCount++;
         missingClassComments();
      }
   }

   protected static void checkFieldImpl() {

      // Get details
      String comment = _fieldDoc.commentText();

      // Perform checks
      if (isEmptyString(comment)) {
         _undocumentedFieldCount++;
         missingFieldComments();
      }
   }

   protected static void checkConstructorImpl() {
      // Get details
      String comment = _executableMemberDoc.commentText();

      // Perform checks
      if (isEmptyString(comment)) {
         _undocumentedConstructorCount++;
         missingConstructorComments();
      }
   }

   protected static void checkMethodImpl() {
      // Get details
      String comment = _executableMemberDoc.commentText();

      // Perform checks
      if (isEmptyString(comment)) {
         _undocumentedMethodCount++;
         missingMethodComments();
      }
   }

   protected static void checkParametersImpl() {

      Parameter[] params = _executableMemberDoc.parameters();
      ParamTag[]  tags   = _executableMemberDoc.paramTags();

      int paramCount = params.length;
      int tagCount   = tags.length;

      // Put all the tags in a map
      Map tagMap   = new HashMap(tagCount);
      for (int i=0; i<tagCount; i++) {
         ParamTag tag     = tags[i];
         String   name    = tag.parameterName();
         String   comment = tag.parameterComment();
         if (tagMap.containsKey(name)) {
            multipleCommentsForParameter(name, tagCount);
         } else if (! isEmptyString(comment)) {
            tagMap.put(name, tag);
         }
      }

      // Check that every parameter is described by a tag
      for (int i=0; i<paramCount; i++) {
         Parameter param = params[i];
         String    name  = param.name();
         if (! tagMap.containsKey(name)) {
             missingParameterComments(name);
         }
      }
      tagMap = null;

      // Put all the parameters in a map
      Map paramMap = new HashMap(paramCount);
      for (int i=0; i<paramCount; i++) {
         Parameter param = params[i];
         String    name  = param.name();
         paramMap.put(name, param);
      }

      // Check that every tag describes a parameter
      for (int i=0; i<tagCount; i++) {
         ParamTag tag = tags[i];
         String paramName = tag.parameterName();
         if (! paramMap.containsKey(paramName)) {
            foundCommentsForNonExistentParameter(paramName);
         }
      }
   }

   protected static void checkMethodReturnImpl() {
      MethodDoc methodDoc = (MethodDoc) _executableMemberDoc;
      Type  returnType    = methodDoc.returnType();
      Tag[] returnTags = methodDoc.tags("return");
      int tagCount = (returnTags==null) ? 0 : returnTags.length;
      boolean voidReturnType = "void".equals(returnType.qualifiedTypeName());

      if (tagCount == 0 && !voidReturnType) {
         missingCommentsForReturnValue();
      } else if (tagCount > 1 && !voidReturnType) {
         multipleCommentsForReturnValue(tagCount);
      } else if (tagCount > 0 && voidReturnType) {
         foundCommentsForNonExistentReturnValue(tagCount);
      }
   }

   protected static void checkConstructorReturnImpl() {
      // XXX
   }

   protected static void checkExceptionsImpl() {
      ClassDoc[]  exceptions = _executableMemberDoc.thrownExceptions();
      ThrowsTag[] tags       = _executableMemberDoc.throwsTags();

      int exceptionCount = exceptions.length;
      int tagCount       = tags.length;

      // Put all the tags in a map
      Map tagMap   = new HashMap(tagCount);
      for (int i=0; i<tagCount; i++) {
         ThrowsTag tag  = tags[i];
         String    name = tag.exceptionName();
         tagMap.put(name, tag);
      }

      // Check that every exception is described by a tag
      for (int i=0; i<exceptionCount; i++) {
         ClassDoc exception = exceptions[i];
         String name = exception.name();
         if (! tagMap.containsKey(name)) {
            missingCommentsForException(name);
         }
      }
      tagMap = null;

      // Put all the exceptions in a map
      Map exceptionMap = new HashMap(exceptionCount);
      for (int i=0; i<exceptionCount; i++) {
         ClassDoc exception = exceptions[i];
         String   name      = exception.name();
         exceptionMap.put(name, exception);
      }

      // Check that every tag describes an exception
      for (int i=0; i<tagCount; i++) {
         ThrowsTag tag = tags[i];
         String exceptionName = tag.exceptionName();
         if (! exceptionMap.containsKey(exceptionName)) {
            foundCommentsForNonExistentException(exceptionName);
         }
      }
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: package-level
   //-------------------------------------------------------------------------

   /**
    * Handler for the condition that a package has no associated comments.
    */
   protected static void missingPackageComments() {
      _rootDoc.printWarning("No comments for " + _packageName);
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: class-level
   //-------------------------------------------------------------------------

   /**
    * Handler for the condition that a class has no associated comments.
    */
   protected static void missingClassComments() {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className);
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: executable member-level
   //-------------------------------------------------------------------------

   /**
    * Hanlder for the conition that an executable member (constructor, class
    * function or instance method) has no associated comments.
    */
   protected static void missingMethodComments() {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            _executableMemberSignature);
   }

   /**
    * Hanlder for the conition that an executable member (constructor, class
    * function or instance method) has no associated comments.
    */
   protected static void missingConstructorComments() {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            _executableMemberSignature);
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: parameter-level
   //-------------------------------------------------------------------------

   /**
    * Hanlder for the conition that the parameter for an executable member
    * (constructor, class function or instance method) has no associated
    * comments.
    */
   protected static void missingParameterComments(String name) {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", parameter " + name);
   }

   protected static void multipleCommentsForParameter(String name,
                                                      int count) {
      _rootDoc.printWarning("Multiple comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", parameter " + name);
   }

   protected static void foundCommentsForNonExistentParameter(String name) {
      _rootDoc.printWarning("Found comment for non-existent " +
                            _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", parameter " + name);
   }

   //-------------------------------------------------------------------------
   // handle different special conditions: return value
   //-------------------------------------------------------------------------

   protected static void missingCommentsForReturnValue() {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", return value.");
   }

   protected static void multipleCommentsForReturnValue(int count) {
         _rootDoc.printWarning("Multiple comments for " + _packageName +
                               '.' + _className +
                               '.' + _memberName +
                               '.' + _executableMemberSignature +
                               ", return value (" + count + ").");
   }

   protected static void foundCommentsForNonExistentReturnValue(int count) {
      StringBuffer message = new StringBuffer(100);
      message.append("Found comment");

      if (count > 1) {
         message.append("s (");
         message.append(count);
         message.append(')');
      }

      message.append(" for non-existent ");
      message.append(_packageName);
      message.append('.');
      message.append(_className);
      message.append('.');
      message.append(_memberName);
      message.append('.');
      message.append(_executableMemberSignature);
      message.append(", return value.");

      _rootDoc.printWarning(message.toString());
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: throws clause-level
   //-------------------------------------------------------------------------

   protected static void missingCommentsForException(String name) {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", exception " + name);
   }

   protected static void foundCommentsForNonExistentException(String name) {
      _rootDoc.printWarning("Found comment for non-existent " +
                            _packageName +
                            '.' + _className +
                            '.' + _memberName +
                            '.' + _executableMemberSignature +
                            ", exception " + name);
   }


   //-------------------------------------------------------------------------
   // handle different special conditions: field-level
   //-------------------------------------------------------------------------

   protected static void missingFieldComments() {
      _rootDoc.printWarning("No comments for " + _packageName +
                            '.' + _className +
                            ", field " + _memberName);
   }


   //-------------------------------------------------------------------------
   // utility functions
   //-------------------------------------------------------------------------

   protected final static boolean isEmptyString(String s) {
      if (s == null || s.trim().length() == 0) {
         return true;
      } else {
         return false;
      }
   }

   protected final static int computePercentage(int n, int total) {
      if (total == 0) {
         return 0;
      }

      return (int) (((double) n) / ((double) total) * 100.0);
   }

}
