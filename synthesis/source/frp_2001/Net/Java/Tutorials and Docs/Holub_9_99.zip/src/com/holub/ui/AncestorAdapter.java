package com.holub.ui;

import javax.swing.event.*;

/** Corrects a flaw in Swing, provides an AncestorListener
 *	implementation made up of empty methods.
 */

public class AncestorAdapter implements AncestorListener
{	public void ancestorAdded	( AncestorEvent event ){}
	public void ancestorMoved	( AncestorEvent event ){}
	public void ancestorRemoved	( AncestorEvent event ){}
}
