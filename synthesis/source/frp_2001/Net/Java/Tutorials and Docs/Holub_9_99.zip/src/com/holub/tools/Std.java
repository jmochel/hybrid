package com.holub.tools;
import java.io.*;
import com.holub.asynch.JDK_11_unloading_bug_fix;

/** Convenience wrappers that takes care of the complexity of creating
 *	Readers and Writers simply to access standard input and output.
 *  For example, a call to
 *	<pre>
 *	Std.out().println("hello world");
 *	</pre>
 *	is identical in function to:
 *	<pre>
 *	new PrintWriter(System.out, true).println("hello world");
 *	</pre>
 *	and
 *	<pre>
 *	String line = Std.in().readLine();
 *	</pre>
 *	is identical in function to:
 *	<pre>
 *	String line;
 *	try
 *	{	line = new BufferedReader(new InputStreamReader(System.in)).readLine();
 *	}
 *	catch( Exception e )
 *	{	throw new Error( e.getMessage() );
 *	}
 *	</pre>
 *	Equivalent methods provide access to standard erro
 *	and a "bit bucket" that just absorbs output without printing it.
 *
 *	<p>All of these methods create "singleton" objects. For example, the
 *	same <code>PrintWriter</code> object that is created the first time
 *	you call <code>Std.out()</code> is returned by all subsequent calls.
 *  This way you don't incurr the overhead of a <code>new</code> with
 *	each I/O request.
 *
 *	@see com.holub.tools.P
 *	@see com.holub.tools.R
 *	@see com.holub.tools.E
 */

public final class Std
{
 	static{ new JDK_11_unloading_bug_fix(Std.class); }	//#bug_fix

	private static BufferedReader input;		//= null
	private static PrintWriter 	  output; 		//= null
	private static PrintWriter 	  error;  		//= null
	private static PrintWriter 	  bit_bucket;	//= null

	/*******************************************************************
	 * A private constructor, prevents anyone from manufacturing an
	 * instance.
	 */
	private Std(){}

	/*******************************************************************
	 * Get a BufferedReader that wraps System.in
	 */
	public static BufferedReader in()
	{	if( input == null )
			synchronized( Std.class )
			{	if( input == null )
					try
					{	input =	new BufferedReader(
										new InputStreamReader(System.in));
					}
					catch( Exception e )
					{	throw new Error( e.getMessage() );
					}
			}
		return input;
	}

	/*******************************************************************
	 * Get a PrintWriter that wraps System.out.
	 */
	public static PrintWriter out()
	{	if( output == null )
			synchronized( Std.class )
			{	if( output == null )
					output = new PrintWriter( System.out, true );
			}
		return output;
	}

	/*******************************************************************
	 * Get a PrintWriter that wraps System.err.
	 */

	public static PrintWriter err()
	{	if( error == null )
			synchronized( Std.class )
			{	if( error == null )
					error = new PrintWriter( System.err, true );
			}
		return error;
	}

	/*******************************************************************
	 * Get an output stream that just discards the characters that are
	 * sent to it. This convenience class makes it easy to write methods
	 * that are passed a "Writer" to which error messages or status information
	 * is logged. You could log output to standard output like this:
	 *	<pre>
	 *	x.method( Std.out() );	// pass in the stream to which messages are logged
	 *	</pre>
	 *	but you could cause the logged messages to simply disappear
	 *	by calling:
	 *	<pre>
	 *	x.method( Std.bit_bucket() );	// discard normal logging messages
	 *	</pre>
	 */

	public static PrintWriter bit_bucket()
	{	if( bit_bucket == null )
			synchronized( Std.class )
			{	if( bit_bucket == null )
					bit_bucket = new Bit_bucket();
			}
		return bit_bucket;
	}

	/**
	 * The Bit_bucket class overrides all methods of PrintWriter to
	 * do nothing.
	 */
	private static final class Bit_bucket extends PrintWriter
	{
		private Bit_bucket()
		{	super( System.err ); // Never used, but must pass something legal.
		}

		public void	   close()	   							{}
		public void	   flush()	   							{}
		public void	   print(boolean b)						{}
		public void	   print(char c)						{}
		public void	   print(char[] s)						{}
		public void	   print(double d)						{}
		public void	   print(float f)						{}
		public void	   print(int i)							{}
		public void	   print(long l)						{}
		public void	   print(Object o)						{}
		public void	   print(String  s)						{}
		public void	   println()							{}
		public void	   println(boolean b)					{}
		public void	   println(char c)						{}
		public void	   println(char[] s)					{}
		public void	   println(double d)					{}
		public void	   println(float f)						{}
		public void	   println(int i)						{}
		public void	   println(long l)						{}
		public void	   println(Object o)					{}
		public void	   write(char[] buf)					{}
		public void	   write(char[] buf, int off, int len)	{}
		public void	   write(int c)							{}
		public void	   write(String buf)					{}
		public void	   write(String buf, int off, int len)	{}
	}

	/**	A small test class, reads a line from standard intput and
	 *	echos it to standard output and standard error. Run it
	 *	with: <blockquote><i>java com.holub.tools.Std\$Test</i></blockquote>
	 *	(Don't type in the \ when using a Microsoft-style shell.)
	 */

	static public class Test
	{
		static public void main( String[] args ) throws IOException
		{	String s;
			while( (s = Std.in().readLine()) != null )
			{	Std.out().println( s );
				Std.err().println( s );
				Std.bit_bucket().println( s );
			}
		}
	}
}
