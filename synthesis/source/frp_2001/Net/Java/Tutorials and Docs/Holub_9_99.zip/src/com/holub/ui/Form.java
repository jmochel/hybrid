package com.holub.ui;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;		// Just for the test class
import java.awt.*;
import java.util.*;
import java.io.*;

import com.holub.ui.User_interface;
import com.holub.ui.AncestorAdapter;
import com.holub.tools.debug.Assert;
import com.holub.tools.debug.D;
import com.holub.tools.Std;		// Just for the test class

/**	The Form class builds simple forms in such a way that the form
 *	layout and contents can be changed without impacting the underlying
 *	logical model (and vice versa). A fixed layout is used (Yeah, I know.
 *	Live with it.)
 */

public class Form extends JComponent
{
	/* Elements are just stored in a vector. Another possibility is to
	 * store them several small vectors, placed in a hash table,
	 * keyed by class name (or <code>Class</code> object. This way
	 * I wouldn't have to do a linear search on the fields to find
	 * the attributes of a particular object when its attached.
	 * For the time being, a simple vector will do.
	 */

	private final Collection fields 	 = new Vector();

	/* Stuff to keep track of the preferred size, which is updated
	 * every time a field is added.
	 */

	private static final int INSET = 10;
	private final Dimension preferred_size = new Dimension();;

	public Dimension getPreferredSize(){ return preferred_size; }
	public Dimension getMinimumSize  (){ return preferred_size; }

	private final void update_preferred_size( Rectangle location )
	{	preferred_size.setSize
		(	Math.max( preferred_size.width,  
					  location.x + location.width  + 2*INSET  ),
			Math.max( preferred_size.height,
					  location.y + location.height + 2*INSET )
		);
	}

	/**	One visual element of a form. Specifies where on the form
	 *	the UI for a particular attribute of a particular class should
	 *	be placed. Note that the attribute is specified by class, not
	 *	object, so multiple objects of the same class can not be
	 *	represented directly. You can represent such a one-to-many
	 *	mapping by writing a class to represent the aggregate object,
	 *	however.
	 */

	public Form()
	{	addAncestorListener
		(	new AncestorAdapter()
			{	public void ancestorRemoved(AncestorEvent event)
				{	release();
				}
			}
		);
	}

	/** Add to the current form a field that represents an attribute
	 *  of some class.
	 */

	public final void add_field(String class_name, String attribute, Rectangle location, boolean is_read_only)
	{	fields.add( new Element(class_name, attribute, location, is_read_only ) );
		update_preferred_size( location );
		location.translate( INSET, INSET );
	}

	/** Add an invariant field to the current form.
	 */

	public final void add_field( JComponent item, Rectangle location)
	{	fields.add( new Element( item, location ) );
		update_preferred_size( location );
		location.translate( INSET, INSET );
	}

	/** Populate the form with elements described in UNICODE.
	 *	<b>Not yet implemented.</b>
	 */

	public void load( InputStream source )
	{	throw new UnsupportedOperationException(
							"Form.load() not yet supported" );
	}

	/** Flush a description of the form to the <code>Writer</code> in
	 *  the format discussed in the description of the {@link #load}
	 *	method. <b>Not yet implemented.</b>
	 */

	public void store( OutputStream destination )
	{	throw new UnsupportedOperationException(
							"Form.store() not yet supported" );
	}

	/** Attach some model-level object to the current form. When made
	 *	visible, the form will display the attributes of that object
	 *	that are specified by some <code>Element</code> of the form.
	 *	The form will maintain references to all the proxies provided
	 *	by the `thing` as long as the form is displayed, but these
	 *	proxies are released automatically when the form is shut down.
	 *	You'll have to reattach objects if you want to display the
	 *	form again. Note that you can attach objects while the form
	 *	is visible, but you should send it an `invalidate()` message
	 *	after doing so for the proxies of the newly-attached objects
	 *	to become visible.
	 */

	public final void attach( User_interface thing )
	{	Assert.is_true( thing != null, "thing==null" );
		D.ebug( "Attaching " + thing.getClass().getName() + "to Form" );

		for(Iterator i = fields.iterator(); i.hasNext() ;)
			((Element) i.next() ).attach(thing);
	}

	/** Attach some set of model-level objects to the current form. When made
	 *	visible, the form will display the attributes of that object
	 *	@param things. An array of things to display.
	 *		Objects in the array7 that don't implement <code>User_interface</code>
	 *		are silently ignored.
	 *		If more than one object in the array is an instance
	 *		of a given class, only the last such object (the one at the
	 *		higher index) is displayed. Proxies will be requested from
	 *		all objects of a given class, however.
	 */

	public final void attach( Object[] things )
	{	Assert.is_true( things != null, "things==null" );

		for( int i = 0; i < things.length; ++i )
		{	if( things[i]!=null && (things[i] instanceof User_interface))
				this.attach((User_interface) things[i]);
		}
	}

	/** Attach some set of model-level objects to the current form. When made
	 *	visible, the form will display the attributes of that object
	 *	@param things an iterator, initialized to traverse some <code>Collection</code>
	 *		or <code>Map</code> that contains objects that implement <code>User_interface</code>.
	 *		If more than one object in the collection is an instance
	 *		of a given class, only the last such object is displayed.
	 *		Proxies will be requested from all objects of a given class,
	 *		however.
	 */

	public final void attach( Iterator things )
	{	Assert.is_true( things != null, "things==null" );	

		while( things.hasNext() )
		{	Object	abstraction = things.next();
			if( abstraction instanceof User_interface )
				this.attach((User_interface)abstraction);
		}
	}

	/** Called by system when the form is invalidated. Actually lays
	 *	out the elements and makes them visible
	 */

	public final void doLayout()
	{	
		D.ebug("Laying out container");
		for( Iterator i = fields.iterator(); i.hasNext(); )
			((Element) i.next() ).activate();
	}

	/** Since a <code>Form</code> object does its own layout, it's
	 *	inappropriate for you to add a layout manager. (Though you
	 *	could argue reasonably that the Form should <u>be</u> a layout
	 *	manager, similar to a <code>GridBag</code>, that is passed <code>Element</code>
	 *	objects (similar to <code>GridBagConstraints</code>) that's bound
	 *	to a displayable object.)
	 *	<p>
	 *	This method does nothing but throw an <code>UnsupportedOperationException</code>
	 */

	public final void setLayout(LayoutManager manager)
	{	throw new UnsupportedOperationException(
								"May not set a layout manager in a Form");
	}

	/** A convenience method that wraps a wait request. The equivalent
	 *	code is:
	 *	<pre>
	 *	Form form;
	 *	//...
     *	try{ synchronized(form){form.wait();} }
     *	catch(InterruptedException e){}
	 *
	 */
	synchronized public final void wait_for_close()
	{	try{ wait(); }catch(InterruptedException e){/*ignore*/}
	}

	/** Release any waiting threads.
	 */

	synchronized public final void release()
	{	notifyAll();
	}

	/*******************************************************************
	 * A single element (field) in a form.
	 */

	private final class Element
	{
		private final Rectangle		location;
		private final String		class_name;
		private final String		attribute;
		private final boolean		is_read_only;	// Supplied by model, but unmodifiable
		private final boolean		is_invariant;	// Attrubte of the form itself
		private		  JComponent	proxy;

		/** Create a single element that represents some attribute of
		 *	some class in the logical model.
		 *	@param location	the location and size of the UI exposed by
		 *		   the proxy for this element.
		 *	@param the class that contains the attribute to be displayed
		 *	@param the attribute to display.
		 */
		public Element(String class_name, String attribute, Rectangle location, boolean is_read_only)
		{	this.location	  = location;
			this.class_name   = class_name;
			this.attribute 	  = attribute;
			this.is_read_only = is_read_only;
			this.is_invariant = false;
			this.proxy		  = null;

			Assert.is_true( class_name != null, "class_name==null" );
			Assert.is_true( attribute  != null, "attribute==null" );
			Assert.is_true( location   != null, "location==null" );
		}

		/** Create an "invariant" element, one that represents an
		 *	attribute of the form itself. Typically these elements will
		 *	be icons, labels, and other graphical things that appear
		 *	on every from, but which don't change from form to form.
		 *	@param location	the location and size of the UI exposed by
		 *		   the proxy for this element.
		 *	@param invariant the component to display at that location.
		 */

		public Element(JComponent proxy, Rectangle location)
		{	this.location	  = location;
			this.class_name   = "(Form)";
			this.attribute 	  = "invariant";
			this.is_read_only = true;
			this.is_invariant = true;
			this.proxy		  = proxy;

			Assert.is_true( proxy  	 != null, "proxy==null" 	);
			Assert.is_true( location != null, "location==null"	);

			Form.this.add(proxy);
		}

		/** Attach a specific object to this form. The attached object
		 *	will replace any object previously attached to the same
		 *	form. Generally, all objects that the form represents must
		 *	be attached before the form itself is displayed.
		 *	This message is passed only from a form to one of its elements,
		 *	thus is private.
		 *
		 *	@param thing The thing to display. If the thing's class is not
		 *				 the class specified in the original constructor,
		 *				 then this method silently ignores the request.
		 */
		private void attach( User_interface thing )
		{	Assert.is_true( thing != null, "thing==null" );
			D.ebug(   "Attaching " 			+ thing.getClass().getName()
					+ " to element for "	+ class_name +":"+ attribute 
					+ ( !is_invariant ? ""
									  : (" (invariant " 
									  		+ proxy.getClass().getName()
											+")"
									    )
					  )
				  );

			if( !is_invariant 
					&& thing.getClass().getName().equals(class_name) )
			{
				if( proxy != null )	
					Form.this.remove(proxy);

				proxy = thing.visual_proxy( attribute, is_read_only );

				if( proxy != null )
					Form.this.add(proxy);
			}
		}

		/** Passed from the form to an element when the form wants to
		 *	activate the element. Generally causes a UI to appear.
		 *	This message is passed only from a form to one of its elements,
		 *	thus is private.
		 *
		 *	@param here The Form on which the element is to be displayed
		 */

		private void activate()
		{	
			if( proxy==null || location==null )
				throw new RuntimeException( "No proxy for " +
											class_name +":"+ attribute );
			proxy.setBounds(location);
			proxy.setVisible(true);
		}
	}

	/******************************************************************
	 * Test the Form class
	 */

	static class Test
	{
		public static class Employee implements User_interface
		{
			private static Form form = new Form();
			static
			{	form.add_field( new JLabel	("Name:"),
								  new Rectangle	( 0,  0,  75,  20 ) );
											//    x   y  width height

				form.add_field( "com.holub.ui.Form$Test$Employee", "name", 						//#proxy
								  new Rectangle	( 75, 0,  200, 20 ), false );

				form.add_field( new JLabel	("Salary:"),
								  new Rectangle	( 0,  30, 75,  20 ) );

				form.add_field( "com.holub.ui.Form$Test$Employee", "salary",
								  new Rectangle	( 75, 30, 200, 20 ), true );
			}
			//------------------------------------------------------------

			private double   salary = 1000000000.0;		// works for Microsoft
			private Document name	= new PlainDocument();

			//------------------------------------------------------------
			public JComponent visual_proxy( String attribute, boolean is_read_only )
			{	JComponent proxy = null;

				if( attribute.equals("salary") && is_read_only )
				{	proxy = new JLabel( "" + salary );
				}
				else if( attribute.equals("name") && !is_read_only )
				{	proxy = new JTextField( name, null, 0 );	//#attach
				}
				else
				{	Std.err().println("Illegal attribute requested");
				}

				return proxy;
			}
			//------------------------------------------------------------

			public String toString()
			{	try
				{	String name_value =	  name.getLength() == 0
										? "n/a"
										: name.getText(0,name.getLength())
										;

					return "name=" + name_value + ", salary=" + salary;
				}
				catch( BadLocationException e ) // shouldn't happen
				{	throw new Error("Internal error, bad location in Employee name");
				}
			}

			public Employee()
			{	form.attach(this);	// attach attributes of current object to
									// the form.

				// could be a JDialog rather than a JFrame if you want it to
				// be modal.

				JComponent complete_form = create_initialization_form( form );

				JFrame frame = new JFrame("New Employee");
				frame.getContentPane().add( complete_form );
				frame.pack();
				frame.show();

				// Wait for the form to shut down:

				form.wait_for_close();
			}

			protected JComponent create_initialization_form( JComponent base_class_attributes )
			{	return base_class_attributes;
			}
		}

		public static void main( String[] args ) throws Exception
		{	Employee bill = new Employee();
			Std.out().println( bill.toString() );
			System.exit(0);
		}
	}
}
