package com.holub.tools;

public class D
{
	public static final void ebug_enable () {}
	public static final void ebug_disable() {}
	public static final void ebug    ( String text ) {}
}	
