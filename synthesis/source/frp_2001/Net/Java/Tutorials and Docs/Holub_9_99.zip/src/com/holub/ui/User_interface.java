package com.holub.ui;

import javax.swing.JComponent;
import java.awt.Container;

/** The <code>User_interface</code> interface allows you to make generic "forms"
 *	using a Presentation/Abstraction/Control, visual-proxy
 *	architecture. Objects that implement a <code>User_interface</code>
 *  return proxies ("views") for attributes of a  "business" object
 *  when asked.
 *	<p>
 *	(c) 1999, Allen I. Holub. All rights reserved.
 *	<p>
 *	@author		Allen Holub
 *	@version	1.1
 */

public interface User_interface
{
	/** Return a visual proxy for the attribute specified as an argument
	 *  or null if the requested attribute isn't recognized. All
	 *	objects that implement <code>User_interface</code>
	 *	must support a null "attribute" argument, which
	 *  will return the "default" view, whatever that is.
	 *
	 *	The individual proxies can use the JComponent's 
	 *	addAncestorListener() facility to find out when the surrounding
	 *	form is displayed or shut down. Similarly, they
	 *	can override addNotify() to find out who their parent is.
	 *
	 *  @param attribute_name  The attribute that this proxy represents or
	 *				<CODE>null</CODE> for the default type.
	 *	@returns	The proxy, or null if the requested attribute
	 *				is not supported or recognized.
	 */

	public JComponent visual_proxy( String attribute_name, boolean is_read_only );
}
