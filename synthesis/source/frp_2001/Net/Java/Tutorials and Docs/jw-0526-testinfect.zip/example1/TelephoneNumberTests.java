package example1;

import junit.framework.*;

public class TelephoneNumberTests extends TestCase {
    public static void main(String[] args) {
	junit.textui.TestRunner.run(suite());
    }

    public static TestSuite suite() {
	return new TestSuite(TelephoneNumberTests.class);
    }

    public TelephoneNumberTests(String testname) {
	super(testname);
    }

    public void testSimpleStringFormatting() throws Exception {
	// Build a complete phone number
	TelephoneNumber number = new TelephoneNumber("612", "630", "1063", "1623");
	assertEquals("Bad string", "(612) 630-1063 x1623", number.formatNumber());
    }

    public void testNullAreaCode() throws Exception {
	// Build a phone number without area code
	TelephoneNumber number = new TelephoneNumber(null, "630", "1063", "1623");
	assertEquals("Bad string", "630-1063 x1623", number.formatNumber());
    }

    public void testNullExtension() throws Exception {
	// Build a phone number without an extension
	TelephoneNumber number = new TelephoneNumber("612", "630", "1063", null);
	assertEquals("Bad string", "(612) 630-1063", number.formatNumber());
    }

    public void testNullAreaCodeAndExtension() throws Exception {
	// Build a phone number without area code or extension
	TelephoneNumber number = new TelephoneNumber(null, "630", "1063", null);
	assertEquals("Bad string", "630-1063", number.formatNumber());
    }

    public void testNullExchange() throws Exception {
	// Build a phone number without exchange
	TelephoneNumber number = new TelephoneNumber("612", null, "1063", "1623");
	try {
	    number.formatNumber();
	    assert("Should have thrown a NullPointerException", false);
	} catch(NullPointerException npe) {
	    // expected behavior
	}
    }
}
