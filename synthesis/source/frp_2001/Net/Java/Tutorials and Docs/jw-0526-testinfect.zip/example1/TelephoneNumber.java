package example1;

public class TelephoneNumber {
    private String areaCode;
    private String prefix;
    private String number;
    private String extension;

    public TelephoneNumber(String areaCode, String prefix, String number, String extension) {
	this.areaCode = areaCode;
	this.prefix = prefix;
	this.number = number;
	this.extension = extension;
    }

    public String formatNumber() {
	return "(" + areaCode + ") " + prefix + "-" + number + " x" + extension;
    }
}
