package junit.servletui;

import java.io.*;

/**
 * A writer that scrubs certain ASCII characters into HTML entities.
 *
 * Creation date: (6/29/99 11:27:55 PM)
 * @author: Michael T. Nygard
 */
public class HTMLWriter extends FilterWriter {
    /**
     * HTMLWriter constructor comment.
     * @param out java.io.Writer
     */
    protected HTMLWriter(java.io.Writer out) {
	super(out);
    }

    public void write(char cbuf[], int off, int len) throws IOException {
	for(int i = 0; i < len; i++) {
	    write(cbuf[i]);
	}
    }

    /**
     * Pass most characters directly through.  Treat certain sequences
     * specially
     */
    public void write(char c) throws IOException {
	switch(c) {
	case '\n':	out.write("<br>"); break;
	default:	out.write(c);
	}
    }

    public void write(String str, int off, int len) throws IOException {
	char[] chars = new char[len];
	str.getChars(off, off+len, chars, 0);
	for(int i = 0; i < len; i++) {
	    write(chars[i]);
	}
    }
}
