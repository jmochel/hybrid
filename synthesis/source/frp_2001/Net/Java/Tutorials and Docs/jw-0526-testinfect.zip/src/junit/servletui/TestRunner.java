package junit.servletui;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import junit.framework.*;
import junit.util.*;

/**
 * A servlet based tool to run tests.
 *
 * TestRunner expects the name of a TestCase class a request
 * parameter. If this class defines a static <code>suite</code> 
 * method it will be invoked and the returned test is run. 
 * Otherwise all the methods starting with "test" having 
 * no arguments are run.
 * <p>
 * TestRunner displays a trace of the test results, followed by a
 * summary at the end.
 * <p>
 * Some of this code is duplicated from junit.textui.TestRunner,
 * but this runner is thread-safe, whereas the other TestRunner
 * is not.  Servlets must always be thread-safe.
 * <p>
 * @author Michael T. Nygard
 * @see junit.textui.TestRunner
 */
public class TestRunner extends HttpServlet {
    /** The parameter name for the class to test.  The value of 
     * this parameter must be a fully-qualified class name. 
     */
    public static final String P_CLASS_NAME = "classname";

    /**
     * Creates the TestResult to be used for the test run.
     */
    protected TestResult createTestResult() {
	return new TestResult();
    }
    protected Test createTestSuite(String classUnderTest) throws Exception {
	Class testClass = null;
	Method suiteMethod = null;
	Test suite = null;

	try {
	    testClass = Class.forName(classUnderTest);
	} catch (Exception e) {
	    System.out.println(e);
	    e.printStackTrace();
	    throw new Exception("Suite class \"" + classUnderTest + "\" not found");
	}

	try {
	    suiteMethod = testClass.getMethod("suite", new Class[0]);
	    suite = (Test) suiteMethod.invoke(null, new Class[0]); // static method
	} catch (Exception e) {
	    // try to extract a test suite automatically
	    suite = new TestSuite(testClass);
	}
		
	if (suite == null) {
	    throw new Exception("Cannot create test suite from class " + classUnderTest + ".  Is there a 'public static Test suite()' method?");
	}

	return suite;
    }
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String[] classesUnderTest = req.getParameterValues(P_CLASS_NAME);

	if(classesUnderTest == null || classesUnderTest.length == 0) {
	    handleNoParameter(resp);
	    return;
	}
	
	PrintWriter out = resp.getWriter();

	resp.setContentType("text/html");

	out.println("<html><head>");
	out.println("<title>Test Results</title>");
	out.println("</head>");
	out.println("<body>");
	for(int i = 0; i < classesUnderTest.length; i++) {
	    out.println("<hr>");
		
	    Test suite;
	    try {
		suite = createTestSuite(classesUnderTest[i]);
	    } catch(Exception ex) {
		out.println(ex.getMessage());
		continue;
	    }

	    out.println("<h1>");
	    out.println(classesUnderTest[i]);
	    out.println("</h1>");
		
	    doRun(suite, out);
	}

	out.println("</body>");
	out.println("</html>");
    }
    protected void doRun(Test suite, final PrintWriter output) throws IOException {
	TestResult result = createTestResult();
	result.addListener(new TestListener() {
		public void startTest(Test test) {
		    output.write(".");
		}

		public void endTest(Test test) {
		}
		
		public void addError(Test test, Throwable error) {
		    output.write("E");
		}
		
		public void addFailure(Test test, Throwable failure) {
		    output.write("F");
		}
	    });

	long startTime = System.currentTimeMillis();
	suite.run(result);
	long endTime = System.currentTimeMillis();
	output.println();
	output.println("<p>Time: " + StringUtil.elapsedTimeAsString(endTime - startTime)+"</p>");

	print(result, output);
    }

    /** Spit out an error page when no parameters are given. */
    protected void handleNoParameter(HttpServletResponse resp) throws IOException, ServletException {
	PrintWriter out = resp.getWriter();
	out.println("<html><head><title>Bad parameter(s)</title></head>");
	out.println("<body>");
	out.println("<h1>Bad parameter(s)</h1>");
	out.println("<hr><h2>Allowed Parameters</h2>");
	out.println("<table><th>Parameter</th><th>Value</th>");
	out.println("<tr><td valign=\"top\"><code>"+P_CLASS_NAME+"</code></td><td>The fully-qualified name of the class to test.");
	out.println("If this class has a method like <code>public static TestSuite suite()</code>, then");
	out.println("the results of that method will be run.  Otherwise, all public void no-argument");
	out.println("methods in the class will be run as tests.</td></tr></table>");
	out.println("</body></html>");

	resp.setStatus(resp.SC_BAD_REQUEST);
    }

    protected synchronized void print(TestResult result, PrintWriter output) {
	printHeader(result, output);
	printErrors(result, output);
	printFailures(result, output);
    }

    protected void printErrors(TestResult result, PrintWriter output) {
	if (result.errorCount() != 0) {
	    print(output, result.errors());
	}
    }

    protected void printFailures(TestResult result, PrintWriter output) {
	if (result.failureCount() != 0) {
	    print(output, result.failures());
	}
    }

    protected void printHeader(TestResult result, PrintWriter output) {
	if (result.wasSuccessful()) {
	    output.println("<p>OK (" + result.runCount() + " tests)</p>");
	} else {
	    output.println("<p>FAILURES!!!</p>");
	    output.println("<table border=0>");
	    output.println("<tr><td>Run</td><td>"+result.runCount()+"</td></tr>");
	    output.println("<tr><td>Failed</td><td>"+result.failureCount()+"</td></tr>");
	    output.println("<tr><td>Errors</td><td>"+result.errorCount()+"</td></tr>");
	    output.println("</table>");
	}
    }

    protected void print(PrintWriter output, Enumeration failures) {
	while(failures.hasMoreElements()) {
	    TestFailure failure = (TestFailure) failures.nextElement();
	    output.println("<b>");
	    output.println(failure.failedTest());
	    output.println("</b>");
	    output.println("<pre>");
	    failure.thrownException().printStackTrace(output);
	    output.println("</pre>");
	    output.println("<br>");
	}
    }
}
