This is the complete JUnit 3.2 distribution plus the servlet test case runner, as well as the build and packaging scripts needed to create the J2EE web component.

For the original distribution archive of JUnit 3.2, refer to http://www.xprogramming.com/ftp/TestingFramework/JUnit/junit32.zip.
