package example2;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface TelephoneNumber extends EJBObject {
    public String formatNumber() throws RemoteException;
}
