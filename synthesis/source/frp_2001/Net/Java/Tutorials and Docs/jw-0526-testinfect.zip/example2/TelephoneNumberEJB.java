package example2;

import javax.ejb.*;

public class TelephoneNumberEJB implements SessionBean {
    private String areaCode;
    private String prefix;
    private String number;
    private String extension;

    // A no-argument constructor is necessary
    public TelephoneNumberEJB() {
    }

    // These methods are required for the session bean interface
    public void ejbRemove() {
    }

    public void ejbActivate() {
    }

    public void ejbPassivate() {
    }

    public void setSessionContext(SessionContext sc) {
    }

    // This is the actual create method used by the container
    public void ejbCreate(String areaCode, String prefix, String number, String extension) throws CreateException {
	this.areaCode = areaCode;
	this.prefix = prefix;
	this.number = number;
	this.extension = extension;
    }

    // Our one "business" method
    public String formatNumber() {
	return "(" + areaCode + ") " + prefix + "-" + number + " x" + extension;
    }
}
