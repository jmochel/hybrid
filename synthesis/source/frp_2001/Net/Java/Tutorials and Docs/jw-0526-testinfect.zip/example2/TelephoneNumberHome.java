package example2;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;

public interface TelephoneNumberHome extends EJBHome {
    public TelephoneNumber create(String areaCode, String exchange, String number, String extension) throws RemoteException, CreateException;
}
