package tinybasic;

class SubroutineScope extends Scope{
    public SubroutineScope(Scope prev){
	super(prev);
    }


}
