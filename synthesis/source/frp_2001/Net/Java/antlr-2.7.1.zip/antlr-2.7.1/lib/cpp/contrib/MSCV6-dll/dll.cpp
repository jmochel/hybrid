#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

BOOL APIENTRY DllMain(HANDLE module_, DWORD reason_, LPVOID)
{
    return TRUE;
}
