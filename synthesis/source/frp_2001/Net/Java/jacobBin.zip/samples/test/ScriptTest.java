import com.jacob.com.*;
import com.jacob.activeX.*;

class ScriptTest
{
  public static void main(String args[])
  {
    System.runFinalizersOnExit(true);

    try {
      String lang = "VBScript";
      ActiveXComponent sC = new ActiveXComponent("ScriptControl");
      Object sControl = sC.getObject();
      Dispatch.put(sControl, "Language", lang);
      errEvents te = new errEvents();
      DispatchEvents de = new DispatchEvents((Dispatch)sControl, te);
      Variant result = Dispatch.call(sControl, "Eval", args[0]);
      System.out.println("eval("+args[0]+") = "+ result);
    } catch (ComException e) {
      e.printStackTrace();
    }
  }
}

class errEvents {
  public void Error(Variant[] args)
  {
    System.out.println("java callback for error!");
  }
  /*
  public void Timeout(Variant[] args)
  {
    System.out.println("java callback for error!");
  }
  */
}
