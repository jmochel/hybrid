/* ============================================================================
 * Copyright (c) 1997-1999 The Java Apache Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Every modification must be notified to the Java Apache Project
 *    and redistribution of the modified code without prior notification
 *    is NOT permitted in any form.
 *
 * 4. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * 5. The names "JServ", "JServ Servlet Engine" and "Java Apache Project"
 *    must not be used to endorse or promote products derived from this 
 *    software without prior written permission.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * THIS SOFTWARE IS PROVIDED BY THE JAVA APACHE PROJECT "AS IS" AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE JAVA APACHE PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Java Apache Group. For more information 
 * on the Java Apache Project and the JServ Servlet Engine project, 
 * please see <http://java.apache.org/>.
 *
 */
package org.apache.util.testharness;
import java.util.Properties;
import javax.servlet.*;
import javax.servlet.http.*;

import test.framework.*;

/**
 *	An example test suite for the EnvDumpServlet.
 *
 * @author Rob Crawford <crawford@iac.net>
 * @version $Revision: 1.3 $ $Date: 1999/01/29 19:36:54 $
 *
 */
public class Example extends TestCase {
	ServletHarness		_harness;

public Example(String name) {
	super(name);
	}

protected void setUp() {
	try {
		_harness = new
		ServletHarness("org.apache.jserv.servlets.EnvDumpServlet",
				new Properties());
		}
	catch (Exception e) {
		e.printStackTrace();
		System.exit(0);
		}
	}

public void testOneVariable() {
	try {
		TestRequest req = new TestRequest();
		req.setHeader("Foo", "bar");
		req.setHeader("Baz", "plugh");
		TestResponse res = _harness.service(req);
		assert("Content type was wrong: " + res.getContentType(),
			res.getContentType().equals("text/html"));
		byte[] content = res.getContent();
		for (int i = 0; i < content.length; i++) {
			System.out.print((char)content[i]);
			}
		}
	catch (Exception e) {
		e.printStackTrace();
		System.exit(0);
		}
	}

protected void tearDown() {
	_harness.destroy();
	_harness = null;
	}

public static Test suite() {
	TestSuite suite = new TestSuite();

	suite.addTest(new Example("testOneVariable"));

	return suite;
	}

public static void main(String args[]) {
	try {
		test.textui.TestRunner.run(suite());
		}
	catch (Exception e) {
		e.printStackTrace();
		}
	}

}
