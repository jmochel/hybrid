/* ============================================================================
 * Copyright (c) 1997-1999 The Java Apache Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Every modification must be notified to the Java Apache Project
 *    and redistribution of the modified code without prior notification
 *    is NOT permitted in any form.
 *
 * 4. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * 5. The names "JServ", "JServ Servlet Engine" and "Java Apache Project"
 *    must not be used to endorse or promote products derived from this 
 *    software without prior written permission.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * THIS SOFTWARE IS PROVIDED BY THE JAVA APACHE PROJECT "AS IS" AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE JAVA APACHE PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Java Apache Group. For more information 
 * on the Java Apache Project and the JServ Servlet Engine project, 
 * please see <http://java.apache.org/>.
 *
 */
package org.apache.util.testharness;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpUtils;

/**
 *	TestRequest
 *
 *	Provides a means to programmatically build a request to a
 * servlet, for testing purposes.
 *
 * @author Rob Crawford <crawford@iac.net>
 * @version $Revision: 1.3 $ $Date: 1999/01/29 19:36:54 $
 *
 */
public class TestRequest implements HttpServletRequest {
	private int		_method = TestRequest.GET;
	private Vector		_cookies = null;
	private URL		_request_url = null;

	private String		_protocol = "HTTP/1.1";
	private String		_remote_addr = "127.0.0.1";
	private String		_remote_host = "localhost";
	private String		_remote_user = null;
	private String		_auth_type = null;
	private String		_request_uri = null;
	private String		_servlet_path = null;
	private String		_path_info = null;
	private String		_path_translated = null;
	private String		_query_string = null;

	private Hashtable	_parameters = null;
	private Hashtable	_headers = null;
	private byte[]		_content = null;

//
//
//-- Request Methods
//
//
	public static final int		GET = 1;
	public static final int		POST = 2;
	public static final int		PUT = 3;
	public static final int		DELETE = 4;

//
//-- Constructors
//
public TestRequest() {
	_cookies = new Vector();
	_parameters = new Hashtable();
	_headers = new Hashtable();
	}

public TestRequest(int method) {
	this();
	setMethod(method);
	}

public TestRequest(int method, String request) {
	this(method);
	// Assumption -- that the request is in the format of:
	// <scheme>://<host>/<servlet-path>?<query-string>
	StringTokenizer toker = new StringTokenizer(request, "?");
	String url_str = toker.nextToken();
	_request_uri = url_str;
	String query_str;
	try {
		query_str = toker.nextToken();
		}
	catch (NoSuchElementException e) {
		query_str = "";
		}
	try {
		if (url_str == null) {
			throw new IllegalArgumentException();
			}
		_request_url = new URL(url_str);
		Hashtable query_parms = HttpUtils.parseQueryString(query_str);
		if (query_parms != null) {
			Enumeration keys = query_parms.keys();
			while (keys.hasMoreElements()) {
				String key = (String) keys.nextElement();
				String[] args = (String[]) query_parms.get(key);
				for (int i = 0; i < args.length; i++) {
					addParameter(key, args[i]);
					}
				}
			}
		}
	catch (Exception e) {
		throw new IllegalArgumentException("The request parameter " +
			"must be a URL, optionally with a query string. IE, " +
			"http://foo.com/bar?baz=plugh");
		}
	_servlet_path = _request_url.getFile();
	}

//
//
//
public void setMethod(int method) {
	if ((method != TestRequest.GET) &&
			(method != TestRequest.POST) &&
			(method != TestRequest.PUT) &&
			(method != TestRequest.DELETE)) {
		throw new IllegalArgumentException("Must be one of " +
			"TestRequest.GET, POST, PUT, or DELETE.");
		}
	_method = method;
	}

public void setMethod(String method) {
	if (method.equals("GET")) {
		setMethod(TestRequest.GET);
		}
	else if (method.equals("POST")) {
		setMethod(TestRequest.POST);
		}
	else if (method.equals("PUT")) {
		setMethod(TestRequest.PUT);
		}
	else if (method.equals("DELETE")) {
		setMethod(TestRequest.DELETE);
		}
	else {
		throw new IllegalArgumentException("Must be one of GET, " +
			"POST, PUT, or DELETE.");
		}
	}

public void setRequestURI(String uri) {
	_request_uri = uri;
	}

public void setRequestURL(URL request_url) {
	_request_url = request_url;
	}

public void setProtocol(String protocol) {
	_protocol = protocol;
	}

public void setRemoteHost(String host) {
	_remote_host = host;
	}

public void setRemoteAddress(String addr) {
	_remote_addr = addr;
	}

public void setContent(byte[] content) {
	_content = content;
	}

public void setServletPath(String servlet_path) {
	_servlet_path = servlet_path;
	}

public void setRemoteUser(String remote_user) {
	_remote_user = remote_user;
	if (_auth_type == null)
		setAuthType("BASIC"); // FIXME
	}

public void setAuthType(String auth_type) {
	_auth_type = auth_type;
	}

public void setPathInfo(String path_info) {
	_path_info = path_info;
	}

public void setPathTranslated(String path_translated) {
	_path_translated = path_translated;
	}

public void setQueryString(String query_string) {
	_query_string = query_string;
	}

public void setHeader(String name, String value) {
	_headers.put(name, value);
	}

public void addParameter(String name, String value) {
	Vector vec = (Vector) _parameters.get(name);
	if (vec == null) {
		vec = new Vector();
		_parameters.put(name, vec);
		}
	vec.addElement(value);
	}

//
//-- Cookie manipulation methods
//
public void addCookie(Cookie cookie) {
	_cookies.addElement(cookie);
	}

public void removeCookie(Cookie cookie) {
	_cookies.removeElement(cookie);
	}

public void clearCookies() {
	_cookies.removeAllElements();
	}

//
//
//
//
//
//-- Implementation of ServletRequest
//
//
//
//
//
public int getContentLength() {
	if (_content == null)
		return -1;
	else
		return _content.length;
	}

public String getContentType() {
	return null; // FIXME (?)
	}

public String getProtocol() {
	return _protocol;
	}

public String getScheme() {
	return _request_url.getProtocol();
	}

public String getServerName() {
	return _request_url.getHost();
	}

public int getServerPort() {
	if (_request_url.getPort() == -1) return 80;
	return _request_url.getPort();
	}

public String getRemoteAddr() {
	return _remote_addr;
	}

public String getRemoteHost() {
	return _remote_host;
	}

public String getRealPath(String path) {
	return null; // FIXME (?)
	}

public ServletInputStream getInputStream() throws IOException {
	return new TestInputStream(_content);
	}

//
//	ServletInputStream
//
//
	private class TestInputStream extends ServletInputStream {
			InputStream in = null;
			long available = -1;

		TestInputStream(byte[] content) {
			in = new ByteArrayInputStream(content);
			available = content.length;
			}

		public int read() throws IOException {
			if (available > 0) {
				available--;
				return in.read();
				}
			return -1;
			}

		public int read(byte[] b) throws IOException {
			return read(b, 0, b.length);
			}

		public int read(byte[] b, int off, int len)
				throws IOException {
			if (available > 0) {
				if (len > available) {
					// shrink len
					len = (int) available;
					}
				int read = in.read(b, off, len);
				if (read != -1) {
					available -= read;
					}
				else {
					available = -1;
					}
				return read;
				}
			return -1;
			}

		public long skip(long n) throws IOException {
			long skip = in.skip(n);
			available -= skip;
			return skip;
			}

		public void close() throws IOException {
			// do we care?
			}
		} // TestInputStream

/**
 *
 *	@deprecated	Note: getParameter() is deprecated. Please
 *			use getParameterValues
 *
 */
public String getParameter(String name) {
	Vector vec = (Vector) _parameters.get(name);
	if (vec == null) return null;
	return (String) vec.elementAt(0);
	}

public String[] getParameterValues(String name) {
	Vector vec = (Vector) _parameters.get(name);
	if (vec == null) return null;
	String[] strings = new String[vec.size()];
	for (int i = 0; i < strings.length; i++) {
		strings[i] = (String) vec.elementAt(i);
		}
	return strings;
	}

public Enumeration getParameterNames() {
	return _parameters.keys();
	}

public Object getAttribute(String name) {
	return null; // FIXME (?)
	}

public String getCharacterEncoding() {
	return null; // FIXME
	}

public BufferedReader getReader() throws IOException {
	return new BufferedReader(new InputStreamReader(getInputStream()));
	}

//
//
//
//
//
//-- Implementation of HttpServletRequest
//
//
//
//
//
public Cookie[] getCookies() {
	Cookie[] cookies = new Cookie[_cookies.size()];
	for (int i = 0; i < cookies.length; i++) {
		cookies[i] = (Cookie) _cookies.elementAt(i);
		}
	return cookies;
	}

public String getMethod() {
	switch (_method) {
		case TestRequest.POST:		return "POST";
		case TestRequest.PUT:		return "PUT";
		case TestRequest.DELETE:	return "DELETE";
		case TestRequest.GET:
		default:			return "GET";
		}
	}

public String getRequestURI() {
	return _request_uri;
	}

public String getServletPath() {
	return _servlet_path;
	}

public String getPathInfo() {
	return _path_info;
	}

public String getPathTranslated() {
	return _path_translated;
	}

public String getQueryString() {
	return _query_string;
	}

public String getRemoteUser() {
	return _remote_user;
	}

public String getAuthType() {
	return _auth_type;
	}

public String getHeader(String name) {
	return (String) _headers.get(name);
	}

public int getIntHeader(String name) {
	return Integer.parseInt(getHeader(name));
	}

public long getDateHeader(String name) {
	try {
		if (getHeader(name) == null) return -1;
		Date date = DateFormat.getInstance().parse(getHeader(name));
		return date.getTime();
		}
	catch (ParseException e) {
		throw new IllegalArgumentException(e.getMessage());
		}
	}

public Enumeration getHeaderNames() {
	return _headers.keys();
	}

//
//
//
//-- Session code. None of it is implemented.
//
//
//
public HttpSession getSession(boolean create) {
	return null; // FIXME
	}

public String getRequestedSessionId() {
	return null; // FIXME
	}

public boolean isRequestedSessionIdValid() {
	return false; // FIXME
	}

public boolean isRequestedSessionIdFromCookie() {
	return false; // FIXME
	}

public boolean isRequestedSessionIdFromUrl() {
	return false; // FIXME
	}

}
