/* ============================================================================
 * Copyright (c) 1997-1999 The Java Apache Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. Every modification must be notified to the Java Apache Project
 *    and redistribution of the modified code without prior notification
 *    is NOT permitted in any form.
 *
 * 4. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * 5. The names "JServ", "JServ Servlet Engine" and "Java Apache Project"
 *    must not be used to endorse or promote products derived from this 
 *    software without prior written permission.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the Java Apache Project
 *    (http://java.apache.org/)."
 *
 * THIS SOFTWARE IS PROVIDED BY THE JAVA APACHE PROJECT "AS IS" AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE JAVA APACHE PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Java Apache Group. For more information 
 * on the Java Apache Project and the JServ Servlet Engine project, 
 * please see <http://java.apache.org/>.
 *
 */
package org.apache.util.testharness;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 *	TestResponse
 *
 *	Provides a means to programmatically test a response from a
 * servlet, for testing purposes.
 *
 * @author Rob Crawford <crawford@iac.net>
 * @version $Revision: 1.3 $ $Date: 1999/01/29 19:36:54 $
 *
 */
public class TestResponse implements HttpServletResponse {
	private String			_content_type;
	private int			_content_length;

	private Vector			_cookies;
	private Hashtable		_headers;
	private Hashtable		_messages;
	private Hashtable		_errors;

	private TestOutputStream	_out_stream;

public TestResponse() {
	_cookies = new Vector();
	_headers = new Hashtable();
	_messages = new Hashtable();
	_errors = new Hashtable();
	}

public Vector getCookies() {
	return (Vector) _cookies.clone();
	}

public Cookie getCookie(String name) {
	Cookie search_item = null;
	Enumeration enum = _cookies.elements();
	while (enum.hasMoreElements()) {
		Cookie cookie = (Cookie) enum.nextElement();
		if (cookie.getName().equals(name)) {
			search_item = cookie;
			}
		}
	return search_item;
	}

public String getContentType() {
	return _content_type; // FIXME (?)
	}

public int getContentLength() {
	return _content_length;
	}

public byte[] getContent() {
	return _out_stream.getContent();
	}

public String getHeader(String name) {
	return (String) _headers.get(name);
	}

public String getMessage(int message_key) {
	return (String) _messages.get(new Integer(message_key));
	}

public String getError(int error_key) {
	return (String) _errors.get(new Integer(error_key));
	}

//
//
//-- Implementation for ServletResponse
//
//
public void setContentLength(int len) {
	_content_length = len;
	}

public void setContentType(String type) {
	_content_type = type;
	}

public ServletOutputStream getOutputStream() throws IOException {
	_out_stream = new TestOutputStream();
	return _out_stream;
	}

public PrintWriter getWriter() throws IOException {
	return new PrintWriter(getOutputStream());
	}

/**
 *	A simple implementation of a ServletOutputStream that let's
 * the user get the returned content back.
 *
 */
	private class TestOutputStream extends ServletOutputStream {
			ByteArrayOutputStream	_content;

		TestOutputStream() {
			_content = new ByteArrayOutputStream();
			}

		public void write(int b) throws IOException {
			_content.write(b);
			}

		public byte[] getContent() {
			return _content.toByteArray();
			}
		}

/**
 *	I don't think this is needed for the most recent version
 * of the JSDK, but I could have that backwards.
 *
 */
public String getCharacterEncoding() {
	return null; // FIXME
	}

//
//
//-- Implementation for HttpServletResponse
//
//
public void addCookie(Cookie cookie) {
	_cookies.addElement(cookie);
	}

public boolean containsHeader(String name) {
	return _headers.containsKey(name);
	}

public void setStatus(int sc, String sm) {
	_messages.put(new Integer(sc), sm);
	}

public void setStatus(int sc) {
	setStatus(sc, "");
	}

public void setHeader(String name, String value) {
	_headers.put(name, value);
	}

public void setIntHeader(String name, int value) {
	_headers.put(name, new Integer(value));
	}

public void setDateHeader(String name, long date) {
	_headers.put(name, new Long(date));
	}

public void sendError(int sc, String msg) throws IOException {
	_errors.put(new Integer(sc), msg);
	}

public void sendError(int sc) throws IOException {
	sendError(sc, "");
	}

public void sendRedirect(String location) throws IOException {	
	setStatus(SC_MOVED_PERMANENTLY, location);
	}

/**
 *	Methods related to rewriting URLs for sessions. I don't use
 * that, so I don't use these. They _should_ be implemented, because
 * you're _supposed_ to use them, but I don't.
 *
 */
public String encodeUrl(String url) {
	return null; // FIXME
	}

public String encodeRedirectUrl(String url) {
	return null; // FIXME
	}

}
