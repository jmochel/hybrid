wnaspi32.dll v1.04
Copyright (c) 1999 Jukka Poikolainen Software
All Rights Reserved.

LICENSE

This is FREE software and may be distributed stand-alone. 
This product may NOT be distributed within another product.

WARRANTY

YOU USE THIS SOFTWARE AT YOUR OWN RISK. THE AUTHOR WON'T
BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY 
OTHER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE.

DESCRIPTION

ASPI Layer for Windows 2000 and Windows NT 4.0 SP#4+.

For ASPI-based CD/DVD recording applications under NT environment.

LIMITATIONS

Supports only CD/DVD devices.

(harddisks, scanners etc. are not supported)

INSTALLATION

Copy wnaspi32.dll to the WINNT/System32 folder.

SUPPORT

No support.
