			Thumber Readme

	
	*****Introduction*****


Note:  For the latest version of Thumber, check: http://tawba.tripod.com/thumber.htm

Thumber is a multi-purpose image management tool designed to automate many of the routine tasks associated with viewing, cataloging, transforming, renaming, presenting, transferring, editing, and archiving digital images. Although it will work with any JPEG images, it includes many additional features specifically designed for use with the images produced by digital cameras.

Thumber's digital camera-specific features take advantage of the fact that the pictures produced by most digital cameras contain more than initially meets the eye. In addition to the picture, most digital cameras store information about the image, as well as mini "thumbnail" images within the files they produce.  Most graphic and image viewing software doesn't know how to find or read this information and ignores it. Thumber can read, display and manipulate this information in a variety of ways.  For example, a web page with tens or hundreds of thumbnails can be created in seconds using Thumber -- no further HTML editing is necessary.


	*****Installation Instructions*****

Thumber is distributed in three versions: Full, Lite and Manual.  If you have downloaded the full or lite version then simply click on the setup.exe file to install.  If you have downloaded the manual install version, then read the file titled "Manual install.txt" for details.

IMPORTANT: Thumber was written using Visual Basic 6 and requires some "helper" (a.k.a. "Runtime") files in order to work properly.  These files are distributed with the full version of Thumber, but not with the lite or manual install versions.  These files are freely available, and your system may already have them.  However, If you are unsure or you cannot seem to run Thumber without an error, download them from the link on Thumber's page (http://tawba.tripod.com/thumber.htm).


	*****Program Status*****

Thumber is shareware, meaning you are expected to "register" it (i.e. pay a small fee for it) to purchase the program. While Thumber will operate without registration, it is limited to processing a fixed number of images per session (the number varies depending on specific task). You can register Thumber on-line using the Kagi payment processing service:

	http://order.kagi.com/?R8U


	*****Distribution Status*****

You may freely redistribute Thumber as long as you make no modifications and this file is included.


	*****Troubleshooting Tips*****


1. If you get an error when trying to start Thumber, you may not have the latest Visual Basic files.  Go to Thumber's page (http://tawba.tripod.com/thumber.htm) and get the Visual Basic runtime files.  

2. If you get an error complaining about Tabctl32.ocx or Comdlg32.ocx, try manually registering these components by using the Regsvr32 application that comes with Windows.  Go to Start|Run and type these commands:

           regsvr32 tabctl32.ocx
           regsvr32 comdlg32.ocx



	*****Credits*****

Included with Thumber are two files that help it rotate and save images.  JPEGTRAN is necessary to rotate images and is based on code written by the Independent JPEG group.  Although it is included with Thumber, it is also available from many popular FTP sites.  Try the Simtel archive at ftp.simtel.net or any of its mirror locations: ftp.simtel.net/pub/simtelnet/msdos/graphics/jpeg6b32.zip.  A second file, ijl15.dll, helps Thumber open and save JPEG files.  This file was created by Intel.


	*****Disclaimer*****

Your use of this software constitutes your agreement to the following terms: 

TawbaWare (http://tawba.tripod.com/) and the author take no responsibility for any damages caused by this program.  Thumber is provided 'as is' without warranty of any kind.  Use it at your own risk.  I disclaim all warranties, either express or implied, including the warranties of merchantability and fitness for a particular purpose. In no event shall I be liable for any damages whatsoever including direct, indirect, incidental, consequential, loss of business profits or special damages.  

Whew!  Use at your own risk and enjoy!

Max Lyons
tawbaware@kagi.com
