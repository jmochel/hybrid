Easy Thumbnails 1.0
===================

Introduction
------------
Easy Thumbnails is a handy new freeware utility for creating
accurate thumbnail images and scaled-down copies from a wide
range of popular picture formats. An elegant interface makes it
simplicity itself to find your images and select them for
processing individually, in batches, or in whole folders, using a
well-designed file selector and built-in image viewer. You can
use slider controls to rotate images and adjust their contrast,
brightness, sharpness and quality, and preview the results.
Thumbnails can be created in any existing folder or a new folder,
and you can identify them clearly by adding a prefix or suffix to
their titles. If you're an image processing enthusiast, you will
appreciate the option of choosing from a selection of six
size-reduction algorithms for the best possible results.

Easy Thumbnails is a genuine freeware product, without the
annoyance of advertising, intrusive spyware components, or nag
screens. It comes from Fookes Software, the developers of the
award-winning NoteTab text editors.

You'll find updates and other great software at our Web site...
http://www.fookes.com/


Installation
------------
Extract the Setup.exe file from the .zip package, execute it, and
follow the instructions.

System Requirements
...................
- Windows 95/98/2000/NT4/ME
- 1.4 MB of free disk space
- 16 MB of RAM (32 MB for NT)

How to Uninstall
................
You can uninstall Easy Thumbnails by using the Control Panel's
Add/Remove Programs dialog box or the Uninstall Easy Thumbnails
icon in the Start menu.


Feedback
--------
Bug reports, criticism, praise, and comments are very welcome.
You can send these to <feedback@fookes.com>.


I hope you will find Easy Thumbnails useful. Do tell others about
our software. The more successful it becomes, the more we will be
encouraged to continue developing software of this nature.

--Eric G.V. Fookes
Developer and founder of Fookes Software

_________________________________________________________________
 Easy Thumbnails� is a trademark of Fookes Software, Switzerland
         Copyright � 2001, Fookes Software, Switzerland
                     - All Rights Reserved -

Windows is a trademark of Microsoft Corporation registered in the
  U.S. and other countries.  
All other trademarks and service marks are the property of their
  respective owners.
