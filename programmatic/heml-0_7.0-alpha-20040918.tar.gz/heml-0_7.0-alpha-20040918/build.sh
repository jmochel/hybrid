echo
echo
echo Heml Build Environment
echo ++++++++++++++++++++++
echo 
echo 
echo Checking your environment first ...
echo 
echo
# ----- Verify and Set Required Environment Variables -------------------------
echo 1. Checking for a JAVA_HOME ...
if [ "$JAVA_HOME" = "" ] ; then
  echo You must set JAVA_HOME to point at your Java Development Kit installation
  exit 1
fi
echo "    OK JAVA_HOME=$JAVA_HOME"
echo
# ----- Verify and Set Required Environment Variables -------------------------
echo 2. Checking your system ...
if [ "$TERM" = "cygwin" ] ; then
  S=';'
echo cygwin system, classpath separator set to $S
else
  S=':'
echo Plain vanilla unix system -- classpath separator set to $S
fi
echo

# ---- Check for a COCOON_HOME -----------------------------------------------
echo Cocoon home: $COCOON_HOME
echo 3. Checking for COCOON_HOME ...
if [ "$COCOON_HOME" = "" ] ; then 
  echo You must set COCOON_HOME to the directory of a Cocoon2 build environment
  exit 1
fi
echo "    OK, COCOON_HOME=$COCOON_HOME"
echo 

# ------ Select the proper build file ----------------------------------------
HEML_BUILD=build.xml
#case $COCOON_HOME in 
#     *2.0* ) echo "your cocoon home is a 2.0.x build; I'll use the regular"
#              echo "build.xml"
#              HEML_BUILD=build.xml
#              ;;
#     *xml-cocoon2* )  echo "your cocoon home is 2.1 dev; I'll use the 2.1"
#                    echo "cocoon build"
 #             HEML_BUILD=build-new.xml
 #             ;;
#esac
echo Setting build file to $HEML_HOME/$HEML_BUILD
echo 

CLASSPATH=`echo $COCOON_HOME/tools/lib/ant* | tr " " $S` 
CLASSPATH=$CLASSPATH$S`echo $COCOON_HOME/lib/endorsed/xerces*`
CLASSPATH=$CLASSPATH$S`echo $COCOON_HOME/lib/endorsed/xalan*`
CLASSPATH=$CLASSPATH$S$JAVA_HOME/lib/tools.jar 
CLASSPATH=$CLASSPATH$S`echo $COCOON_HOME/lib/endorsed/xml-api*`
CLASSPATH=$CLASSPATH$S`echo $COCOON_HOME/lib/optional/jtidy*`
echo Your Classpath:
echo $CLASSPATH
echo 
echo
echo Executing Ant Build
echo +++++++++++++++++++
echo
echo
$JAVA_HOME/bin/java -cp $CLASSPATH  -Dheml.home=$HEML_HOME -Dbasedir=$HEML_HOME -Dtomcat.home="$TOMCAT_HOME" -Dexist.home=$EXIST_HOME -Dant.home=$ANT_HOME -Dcocoon.home=$COCOON_HOME org.apache.tools.ant.Main -buildfile $HEML_HOME/$HEML_BUILD   $1
