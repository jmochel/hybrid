package org.heml.chronology.parse;

import java.util.Date;

import org.heml.chronology.format.*;

import org.jdom.Element;

import org.w3c.dom.*;


public abstract class CalendricalParser implements DateParser {
    static String DATE_PATTERN;
    static String PACKAGE_PREFIX = "org.heml.chronology.parse";

    public abstract Date getEarliestDate();

    public abstract Date getLatestDate();

    public abstract String getString(String lang, String country, String calendarString);

    public abstract void setString(String dateString);

    public org.jdom.Element convertToJdomElement(org.w3c.dom.Element e) {
        org.jdom.input.DOMBuilder builder = new org.jdom.input.DOMBuilder();

        return builder.build(e);
    }

    public org.w3c.dom.Element convertToDomElement(org.jdom.Element e) {
        org.w3c.dom.Element toReturn = null;
        org.jdom.output.DOMOutputter out = new org.jdom.output.DOMOutputter();

        try {
            toReturn = out.output(e);
        } catch (org.jdom.JDOMException except) {
            System.out.println("Couldn't convert " + except.toString() + 
                               " to DOM dying gracelessly");
            System.exit(1);
        }

        return toReturn;
    }

    public CalendricalParser getParserByName(String name) {
        try {
            Class c = Class.forName(PACKAGE_PREFIX + "." + name);

            return (CalendricalParser) c.newInstance();
        } catch (Exception e) {
            System.out.println("getParserByName error: " + e + 
                               "\n returning an XMLSchemaGYear parser, which is probably not what you wanted");
        }

        return new Year();
    }

    /**************************
     * Returns a CalendricalParser corrsponding to the Element passed in,
     * and set to that element as well.
     */
    public CalendricalParser getInitializedParser(org.w3c.dom.Element e) {
        org.jdom.Element jdomElement = convertToJdomElement(e);
        CalendricalParser parser = getParserByName(jdomElement.getName());
        parser.setElement(e);

        return parser;
    }

    public long getEarliestTime() {
        return this.getEarliestDate().getTime();
    }

    public long getLatestTime() {
        return this.getLatestDate().getTime();
    }

    public abstract String getLatestDateString(String language, String country, 
                                               String calendarString);

    public abstract String getEarliestDateString(String language, 
                                                 String country, 
                                                 String calendarString);

    /*
    public static String getEarliestDateString(String country, String language, String calendarString) {
            
    public static long getLatestTime(String dateString) {
       CalendaricalParser cp  = new this();
       this.setString(dateString);
       return d.getLatestTime();
       }
    */
}
