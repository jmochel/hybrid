package org.heml.chronology.parse;

import java.util.Date;

import org.heml.chronology.format.*;

import org.jdom.Element;

import org.w3c.dom.*;


public class DateRange extends CalendricalParser {
    static String DATE_PATTERN = "G yyyy";
    private org.w3c.dom.Element element;
    private org.w3c.dom.Element child;
    private CalendricalParser startingDate;
    private CalendricalParser endingDate;

    public void setElement(org.w3c.dom.Element e) {
        this.element = e;

        org.jdom.Element jdomElement = convertToJdomElement(e);
        org.jdom.Namespace namespace = jdomElement.getNamespace();
        this.startingDate = getInitializedParser(convertToDomElement(
                                                         jdomElement.getChild(
                                                                 "StartingDate", 
                                                                 namespace)));
        this.endingDate = getInitializedParser(convertToDomElement(
                                                       jdomElement.getChild(
                                                               "EndingDate", 
                                                               namespace)));
    }

    public Date getEarliestDate() {
        return startingDate.getEarliestDate();
    }

    public Date getLatestDate() {
        return endingDate.getLatestDate();
    }

    public void setString(String dateString) {
    }
    public String getString(String language, String country, String calendarString) {
	    return getEarliestDateString(language, country, calendarString) +  " - " + getLatestDateString( language, country, calendarString);
     }
    public String getLatestDateString(String language, String country, 
                                      String calendarString) {
        return endingDate.getLatestDateString(language, country, calendarString);
    }

    public String getEarliestDateString(String language, String country, 
                                        String calendarString) {
        return startingDate.getEarliestDateString(language, country, 
                                                  calendarString);
    }
}
