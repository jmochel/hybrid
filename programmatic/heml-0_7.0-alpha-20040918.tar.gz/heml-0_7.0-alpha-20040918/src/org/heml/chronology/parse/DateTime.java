/*
************************************************************** 
* $RCSfile: DateTime.java,v $                                     *
*                                                            *
* $Revision: 1.6 $                                       *
*                                                            *
* $Date: 2004/09/08 17:44:46 $                               *
*                                                            *
* Copyright (C) 2001 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.chronology.parse;

import java.util.*;

import org.heml.chronology.format.*;

import org.jdom.*;


public class DateTime extends org.heml.chronology.parse.Date {
    private static String DATE_PATTERN = "G y MMMM d kk:mm:ss";
    int hour, minute, second = 0;
private static boolean VERBOSE = false;
    public DateTime() {
    }


    public void setString(String xmlDateString) {
        java.lang.String datePart, timePart;
        int wheresT = xmlDateString.indexOf("T");
        datePart = xmlDateString.substring(0,wheresT);
        timePart = xmlDateString.substring(wheresT +1);
        if (VERBOSE) System.out.println("DateTimeString:" + xmlDateString + "\nDate part: " + datePart + "\nTimePart: " + timePart);
        super.setString(datePart);
       int firstColonPos = timePart.indexOf(":");
       int secondColonPos = timePart.indexOf(":",firstColonPos + 1);
       hour = parseInt(timePart.substring(0,firstColonPos));
       minute = parseInt(timePart.substring(firstColonPos + 1, secondColonPos));
       second = parseInt(timePart.substring(secondColonPos+1));
       if (VERBOSE) System.out.println("FirstColonPos: " + firstColonPos + "\nSecondColonPos: " + secondColonPos); 
    }


    public java.util.Date getEarliestDate() {
        calendar.set(year, month, day, hour, minute, second); 
        calendar.set(calendar.MILLISECOND,0);
        return calendar.getTime();
    }

    public java.util.Date getLatestDate() {
        calendar.set(year, month, day, hour, minute, second);
        calendar.set(calendar.MILLISECOND,999);
        return calendar.getTime();
    }


    public static String getEarliestDateString(String language, String country,
                                               String calendar,
                                               String xmlDateString) {
        DateTime dt = new DateTime();
        dt.setString(xmlDateString);

        return dt.getEarliestDateString(language, country, calendar);
    }

    public static String getLatestDateString(String language, String country,
                                             String calendar,
                                             String xmlDateString) {
        DateTime dt = new DateTime();
        dt.setString(xmlDateString);

        return dt.getLatestDateString(language, country, calendar);
    }

    public static long getEarliestTime(String xmlDateString) {
        DateTime dt = new DateTime();


        // System.out.println("made schema");
        dt.setString(xmlDateString);

        // System.out.println("Set string");
        return dt.getEarliestTime();
    }

    public static long getLatestTime(String xmlDateString) {
        DateTime dt = new DateTime();
        dt.setString(xmlDateString);

        return dt.getLatestTime();
    }

    public String getLatestDateString(String language, String country,
                                      String calendarString) {
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country,
                                                      calendarString,
                                                      this.DATE_PATTERN);

        return icf.getFormattedDate(this.getLatestTime());
    }
    public String getString(String language, String country,
                                                          String calendarString) {

                            return getLatestDateString(language, country, calendarString);
                                }
    public String getEarliestDateString(String language, String country,
                                        String calendarString) {
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country,
                                                      calendarString,
                                                      this.DATE_PATTERN);

        return icf.getFormattedDate(this.getEarliestTime());
    }


    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println(
                    "Give me two args:\n 1) and DateTimeString, like 2001-07-02T20:12:13\n 2) an output calendar ");
        }

        try {
            System.out.println("Input value: " + args[0]);
            System.out.println("earliest date is:" + 
                               getEarliestTime(args[0]));
            System.out.println("which is: " + 
                               getEarliestDateString(args[2], "UK", args[1], 
                                                     args[0]));
            System.out.println("latest date is: " + getLatestTime(args[0]));

            System.out.println("which is: " + 
                               getLatestDateString(args[2], "UK", args[1], 
                                                   args[0]));
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
