package org.heml.chronology.parse;

import java.util.Date;

import org.w3c.dom.*;


public interface DateParser {
    public void setElement(Element hemlAbsoluteDateElement);

    public Date getEarliestDate();

    public Date getLatestDate();

    public long getEarliestTime();

    public long getLatestTime();

    public void setString(String dateString);
}