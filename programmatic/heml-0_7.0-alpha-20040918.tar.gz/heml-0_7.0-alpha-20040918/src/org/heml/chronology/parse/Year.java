/*
************************************************************** 
* $RCSfile: Year.java,v $                                     *
*                                                            *
* $Revision: 1.1 $                                       *
*                                                            *
* $Date: 2004/09/08 17:44:46 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.chronology.parse;

import java.util.*;

import org.heml.chronology.format.*;

import org.jdom.*;


public class Year extends CalendricalParser implements DateParser {
    private static String DATE_PATTERN = "G y";
    String xmlGYearString;
    Calendar calendar;
    int xmlGYearInt = 666; // :TODO: a magic number to show an error

    public Year() {
    }

    public void setElement(org.w3c.dom.Element e) {
        org.jdom.Element xmlGYear = convertToJdomElement(e);
        xmlGYearString = xmlGYear.getText();
        setString(xmlGYearString);
    }

    public void setInt(int xmlGYearInt) {
        calendar = GregorianCalendar.getInstance();

        if (xmlGYearInt < 0) {
            //System.out.println("Setting to BC Era");
            calendar.set(GregorianCalendar.ERA, GregorianCalendar.BC);

            //System.out.println("BC Era Set");
        }

        this.xmlGYearInt = xmlGYearInt;
    }

    public void setString(String xmlGYearString) {
        this.xmlGYearString = xmlGYearString;

        try {
            // System.out.println("Trying to parse: " + xmlGYearString);
            xmlGYearInt = java.lang.Integer.parseInt(xmlGYearString);
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("bailing out, returning today's date");
        }

        calendar = GregorianCalendar.getInstance();

        if (xmlGYearInt < 0) {
            //System.out.println("Setting to BC Era");
            calendar.set(GregorianCalendar.ERA, GregorianCalendar.BC);

            //System.out.println("BC Era Set");
        }
    }

    public java.util.Date getEarliestDate() {
        calendar.set(java.lang.Math.abs(xmlGYearInt), 
                     calendar.getMinimum(calendar.MONTH), 
                     calendar.getMinimum(calendar.DAY_OF_MONTH), 
                     calendar.getMinimum(calendar.HOUR_OF_DAY), 
                     calendar.getMinimum(calendar.MINUTE), 
                     calendar.getMinimum(calendar.SECOND));
        calendar.set(calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public java.util.Date getLatestDate() {
        calendar.set(java.lang.Math.abs(xmlGYearInt), 
                     calendar.getMaximum(calendar.MONTH), 
                     calendar.getMaximum(calendar.DAY_OF_MONTH), 
                     calendar.getMaximum(calendar.HOUR_OF_DAY), 
                     calendar.getMaximum(calendar.MINUTE), 
                     calendar.getMaximum(calendar.SECOND));
        calendar.set(calendar.MILLISECOND, 0);

        return calendar.getTime();
    }

    public String getLatestDateString(String language, String country, 
                                      String calendarString) {
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country, 
                                                      calendarString, 
                                                      DATE_PATTERN);

        return icf.getFormattedDate(this.getLatestTime());
    }

    public String getEarliestDateString(String language, String country, 
                                        String calendarString) {
        //System.out.println("I'm using date pattern: " + this.DATE_PATTERN);
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country, 
                                                      calendarString, 
                                                      this.DATE_PATTERN);

        return icf.getFormattedDate(this.getEarliestTime());
    }

    public String getString (String language, String country, String calendar) {
	    return getDateString (language, country, calendar);
    }
    public String getDateString (String language, String country,
			                                    String calendar) {
	            String earlyString = getEarliestDateString(language, country, calendar);        String lateString = getLatestDateString(language, country, calendar);
		            if (earlyString.equals(lateString)) {
				                return earlyString;
						        } else {
								            return earlyString.concat(" / ").concat(lateString);
									            }
			        }

    
    public String getDateString(String language, String country, 
                                String calendar, String xmlDateString) {
        setString(xmlDateString);
	return getDateString(language, country, calendar);
    }

    public long getEarliestTime(String xmlGYear) {
        setString(xmlGYear);

        return getEarliestTime();
    }

    public long getLatestTime(String xmlGYear) {
        setString(xmlGYear);

        return getLatestTime();
    }

    /*
     public static String getEarliestDateString(String language, String country,
          String calendar, String xmlDateString){
                   
            XMLSchemaGYear d = new XMLSchemaGYear();
            d.setString(xmlDateString);
            return d.getEarliestDateString(language, country, calendar);
            }
            
       public static String getLatestDateString(String language, String country,
             String calendar, String xmlDateString){
            XMLSchemaGYear d = new XMLSchemaGYear();
            d.setString(xmlDateString);
            return d.getLatestDateString(language, country, calendar);
       }
             
      public static String getDateString(String language, String country,
             String calendar, String xmlDateString){
            XMLSchemaGYear d = new XMLSchemaGYear();
            d.setString(xmlDateString);
            String earlyString = d.getEarliestDateString(language, country, calendar);
            String lateString = d.getLatestDateString(language, country, calendar);
            if (earlyString.equals(lateString)) {
                return earlyString;
            }
            else {return earlyString.concat(" / ").concat(lateString);
            }
       }
            
          public static long getEarliestTime(String xmlGYear) {
              XMLSchemaGYear g = new XMLSchemaGYear();
              g.setString(xmlGYear);
              return g.getEarliestTime();
          }
            
            public static long getLatestTime(String xmlGYear) {
                XMLSchemaGYear g = new XMLSchemaGYear();
                g.setString(xmlGYear);
                return g.getLatestTime();
            }
        public static void main (String[] args) {
          try{
            System.out.println("Input value: " + args[0]);
            System.out.println("earliest date is: " + getEarliestTime(args[0]));
            //System.out.println(getEarliestDateString("en", "UK", "hebrew", "2001"));
            System.out.println("which is: " + getEarliestDateString(args[2], "UK", args[1],  args[0]));
            System.out.println("latest date is: " + getLatestTime(args[0]));
                 
            System.out.println("which is: " + getLatestDateString(args[2], "UK", args[1], args[0]));
            System.out.println("resloved to: "+  getDateString(args[2], "UK", args[1], args[0]));
          }
          catch(Exception e) {System.out.println("Exception: " + e);}
        }
    */
}
