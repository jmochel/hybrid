/*
************************************************************** 
* $RCSfile: IntCalDate.java,v $                                     *
*                                                            *
* $Revision: 1.7 $                                       *
*                                                            *
* $Date: 2004/09/08 17:44:46 $                               *
*                                                            *
* Copyright (C) 2001 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.chronology.parse;

import com.ibm.icu.util.*;

import com.ibm.icu.text.*;
import java.util.*;

import org.heml.chronology.format.*;

import org.jdom.*;

import org.jdom.input.*;

import org.w3c.dom.*;


public class IntCalDate extends CalendricalParser {
    private static String DATE_PATTERN = "G y MMMM dd";

    //Element xmlDate;
    String calendarString;
    com.ibm.icu.util.Calendar intCalendar;
    String era, calendarLang;
    int year;
    String month;
    int day;
    org.jdom.Namespace namespace;
    DOMBuilder builder;

    public IntCalDate() {
    }

    public void setElement(org.w3c.dom.Element in) {
        builder = new DOMBuilder();

        org.jdom.Element xmlIntDate = builder.build(in);
        namespace = xmlIntDate.getNamespace();
        this.calendarString = xmlIntDate.getChild("IntCalendar", namespace)
                                        .getText();
        this.year = parseInt(xmlIntDate.getChild("IntCalYear", namespace)
                                       .getText());

        this.era = xmlIntDate.getChild("IntCalEra", namespace).getText();
        this.month = xmlIntDate.getChild("IntCalMonth", namespace)
                                        .getText();
        this.day = parseInt(xmlIntDate.getChild("IntCalDay", namespace)
                                      .getText());
        this.calendarLang = xmlIntDate.getChild("IntCalendar", namespace).getAttribute("lang").getValue();

        if (calendarString.equals("Hebrew")) {
            this.intCalendar = new HebrewCalendar();
        } else if (calendarString.equals("Islamic")) {
            this.intCalendar = new IslamicCalendar();
        } else if (calendarString.equals("Chinese")) {
            this.intCalendar = new ChineseCalendar();
        } else if (calendarString.equals("Japanese")) {
           this.intCalendar  = new JapaneseCalendar();
        } else {
            this.intCalendar = new com.ibm.icu.util.GregorianCalendar();
        }
    }

    public void setString(String e) {
    }

    private int parseInt(String intString) {
        try {
            return java.lang.Integer.parseInt(intString);
        } catch (Exception e) {
            System.out.println("Error parsing intString '" + intString + "'");
        }

        return 666; //magic number :TODO:
    }

    public java.util.Date getEarliestDate() {
                     DateFormat formatter =  DateFormat.getDateInstance(intCalendar, DateFormat.LONG, new Locale(calendarLang, "CAN"));
            SimpleDateFormat sdfin = (SimpleDateFormat) formatter;
            sdfin.applyPattern("G y.MMMM.d.H.m.s.S");

        //intCalendar = new com.ibm.icu.util.GregorianCalendar(new java.util.Locale("en", "US"));
        //System.out.println("Calendar: " + intCalendar);
        //formatter.setCalendar(intCalendar);
        String dateString = era + " " + year + "." + month + "." + day + ".0.0.0.0";
       // System.out.println("parsing datestring: " + dateString + " in cal " + calendarString);
        try {
        java.util.Date parsedDate = sdfin.parse(dateString);
        /*
        intCalendar.set(intCalendar.ERA, era);
        intCalendar.set(year, month, day, 
                        intCalendar.getMinimum(intCalendar.HOUR_OF_DAY), 
                        intCalendar.getMinimum(intCalendar.MINUTE), 
                        intCalendar.getMinimum(intCalendar.SECOND));
        */
        return parsedDate;
        }
        catch (Exception e) {
          System.out.println("failed to parse datestring: " + e);
          return new java.util.Date();
        }
    }

    public java.util.Date getLatestDate() {
           DateFormat formatter =  DateFormat.getDateInstance(intCalendar, DateFormat.LONG, new Locale(calendarLang, "CAN"));
            SimpleDateFormat sdfin = (SimpleDateFormat) formatter;
            sdfin.applyPattern("G y.MMMM.d.H.m.s.S");

        //intCalendar = new com.ibm.icu.util.GregorianCalendar(new java.util.Locale("en", "US"));
        //System.out.println("Calendar: " + intCalendar);
        //formatter.setCalendar(intCalendar);
        String dateString = era + " " + year + "." + month + "." + day + ".23.59.59.999";
       // System.out.println("parsing datestring: " + dateString + " in cal " + calendarString);
        try {
        java.util.Date parsedDate = sdfin.parse(dateString);
        return parsedDate;
          }
        catch (Exception e) {
         return new java.util.Date();
          }
        }
    public String getString(String language, String country, String calendarString) {
	             InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
				                                                           language, country,
											                                                         calendarString,
																		                                                       DATE_PATTERN);
		     return icf.getFormattedDate(this.getEarliestTime());
    }
    public String getLatestDateString(String language, String country, 
                                      String calendarString) {
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country, 
                                                      calendarString, 
                                                      DATE_PATTERN);

        return icf.getFormattedDate(this.getLatestTime());
    }

    public String getEarliestDateString(String language, String country, 
                                        String calendarString) {
        //System.out.println("I'm using date pattern: " + this.DATE_PATTERN);
        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, country, 
                                                      calendarString, 
                                                      this.DATE_PATTERN);

        return icf.getFormattedDate(this.getEarliestTime());
    }

    public static long getLatestTime(org.w3c.dom.Element e) {
        IntCalDate d = new IntCalDate();
        d.setElement(e);

        return d.getLatestTime();
    }

    public static long getEarliestTime(org.w3c.dom.Element e) {
        IntCalDate d = new IntCalDate();
        d.setElement(e);
        System.out.println("returned from setElement()");
        return d.getEarliestTime();
    }

    public static String getEarliestDateString(String language, String country, 
                                               String calendar, 
                                               org.w3c.dom.Element e) {
        IntCalDate d = new IntCalDate();
        d.setElement(e);

        return d.getEarliestDateString(language, country, calendar);
    }

    public static String getLatestDateString(String language, String country, 
                                             String calendar, 
                                             org.w3c.dom.Element e) {
        IntCalDate d = new IntCalDate();
        d.setElement(e);

        return d.getLatestDateString(language, country, calendar);
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println(
                    "Give me two args:\n 1) a filename \n 2) an output calendar ");
        }

        try {
            org.jdom.input.SAXBuilder sb = new org.jdom.input.SAXBuilder();
            org.jdom.output.DOMOutputter out = new org.jdom.output.DOMOutputter();
            org.jdom.Document doc = sb.build(new java.io.File(args[0]));
            System.out.println("built doc");
            org.w3c.dom.Element e = out.output(doc.getRootElement());
            System.out.println("got root element");
            System.out.println("Your earliest time is: " + 
                               getEarliestTime(e));
            System.out.println("In the " + args[1] + 
                               " calendar this is: \n\t" + 
                               getEarliestDateString(args[2], "uk", args[1], e));
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
