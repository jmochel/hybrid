package org.heml.chronology.parse;

import java.util.Date;

import org.heml.chronology.format.*;

import org.jdom.Element;

import org.w3c.dom.*;


public abstract class PassOnParser extends CalendricalParser {
    static String DATE_PATTERN = "G yyyy";
    private org.w3c.dom.Element element;
    private org.w3c.dom.Element child;
    private CalendricalParser p;

    public void setElement(org.w3c.dom.Element e) {
        this.element = e;

        org.jdom.Element jdomElement = convertToJdomElement(e);
        java.util.List children = jdomElement.getChildren();
        org.jdom.Element child = (org.jdom.Element) children.get(0);
        org.w3c.dom.Element childInDOM = convertToDomElement(child);
        p = getInitializedParser(childInDOM);
    }
    public String getString(String language, String country, String calendarString) {
	    return p.getString(language, country, calendarString);
    }
    public Date getEarliestDate() {
        return p.getEarliestDate();
    }

    public Date getLatestDate() {
        return p.getLatestDate();
    }

    public void setString(String dateString) {
    }

    public String getLatestDateString(String language, String country, 
                                      String calendarString) {
        return p.getLatestDateString(language, country, calendarString);
    }

    public String getEarliestDateString(String language, String country, 
                                        String calendarString) {
        return p.getEarliestDateString(language, country, calendarString);
    }
}
