package org.heml.chronology.parse;

import java.util.Date;

import org.heml.chronology.format.*;

import org.jdom.Element;

import org.w3c.dom.*;


public class StartingDate extends PassOnParser {
    public StartingDate() {
    }
}