package org.heml.chronology.parse;

import java.util.Date;

import org.heml.chronology.format.*;

import org.jdom.Element;

import org.w3c.dom.*;


public class Chronology extends CalendricalParser {
    static String DATE_PATTERN = "G yyyy";
    private org.w3c.dom.Element element;
    private org.w3c.dom.Element child;
    private CalendricalParser p;

    public Chronology() {
    }

    public void setElement(org.w3c.dom.Element e) {
        this.element = e;

        org.jdom.Element jdomElement = convertToJdomElement(e);
        java.util.List children = jdomElement.getChildren();
        org.jdom.Element child = (org.jdom.Element) children.get(0);

        //if it is a heml:Comment, then get the next, thank you.
        if (child.getName().equals("Comment") || child.getName().equals("ChronologicalDerivation")) {
            child = (org.jdom.Element) children.get(1);
        }

        org.w3c.dom.Element childInDOM = convertToDomElement(child);
        p = getInitializedParser(childInDOM);
    }

    public Date getEarliestDate() {
        return p.getEarliestDate();
    }

    public Date getLatestDate() {
        return p.getLatestDate();
    }

    public void setString(String dateString) {
    }

    /*
    public Date getEarliestDate() {
      return p.getTime();
      }
    */
    /*
    public Date getLatestDate() {
    intCalendar.clear();
    intCalendar.set(year, month, day, intCalendar.getMaximum(intCalendar.HOUR_OF_DAY), intCalendar.getMaximum(intCalendar.MINUTE), intCalendar.getMaximum(intCalendar.SECOND));
    return intCalendar.getTime();
    }
    */
    public String getString (String language, String country, String calendarString) {
	   return p.getString(language, country, calendarString);
    }
    public String getLatestDateString(String language, String country, 
                                      String calendarString) {
        return p.getLatestDateString(language, country, calendarString);
    }

    public String getEarliestDateString(String language, String country, 
                                        String calendarString) {
        return p.getEarliestDateString(language, country, calendarString);
    }

    public static long getLatestTime(org.w3c.dom.Node e) {
        Chronology c = new Chronology();
        c.setElement((org.w3c.dom.Element) e);

        return c.getLatestTime();
    }

    public static long getEarliestTime(org.w3c.dom.Node e) {
        Chronology c = new Chronology();
        c.setElement((org.w3c.dom.Element) e);

        return c.getEarliestTime();
    }

    public static String getEarliestDateString(String language, String country, 
                                               String calendar, 
                                               org.w3c.dom.Node e) {
        Chronology c = new Chronology();
        c.setElement((org.w3c.dom.Element) e);

        return c.getEarliestDateString(language, country, calendar);
    }

    public static String getLatestDateString(String language, String country, 
                                             String calendar, 
                                             org.w3c.dom.Node e) {
        Chronology c = new Chronology();
        c.setElement((org.w3c.dom.Element) e);

        return c.getLatestDateString(language, country, calendar);
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println(
                    "Give me two args:\n 1) a filename \n 2) an output calendar ");
        }

        try {
            org.jdom.input.SAXBuilder sb = new org.jdom.input.SAXBuilder();
            org.jdom.output.DOMOutputter out = new org.jdom.output.DOMOutputter();
            org.jdom.Document doc = sb.build(new java.io.File(args[0]));
            org.w3c.dom.Element e = out.output(doc.getRootElement());
            System.out.println("Your earliest time is: " + 
                               getEarliestTime(e));
            System.out.println("In the " + args[1] + 
                               " calendar this is: \n\t" + 
                               getEarliestDateString("en", "uk", args[1], e));
            System.out.println("Your latest time is: " + getLatestTime(e));
            System.out.println("In the " + args[1] + 
                               " calendar this is: \n\t" + 
                               getLatestDateString("en", "uk", args[1], e));
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
