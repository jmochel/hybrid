/*
************************************************************** 
* $RCSfile: InternationalCalendarFactory.java,v $                                     *
*                                                            *
* $Revision: 1.1 $                                       *
*                                                            *
* $Date: 2003/02/10 19:27:18 $                               *
*                                                            *
* Copyright (C) 2001 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.chronology;

import java.util.Locale;
import com.ibm.icu.text.*;
import com.ibm.icu.util.*;
import org.jdom.*;

public class InternationalCalendarFactory {

    public InternationalCalendarFactory() {
    }


    public Calendar getCalendarInstance(Locale locale, 
                                        String calendar) {
        //System.out.println("Calendar request string is: " + calendar);
        Calendar calendarInstance = new GregorianCalendar(
                                            java.util.Locale.getDefault()); // so this sets the default value to Gregorian Calendar. :TODO: throw an

        // exception?
        //Build the appropriate international calendar.
        if (calendar.equalsIgnoreCase("Gregorian")) {
            calendarInstance = new GregorianCalendar(locale);
        } else if (calendar.equalsIgnoreCase("Buddhist")) {
            calendarInstance = new BuddhistCalendar(locale);
        } else if (calendar.equalsIgnoreCase("Hebrew")) {
            calendarInstance = new HebrewCalendar(locale);
        } else if (calendar.equalsIgnoreCase("Chinese")) {
            // :TODO: deal more intellengently with the TimeZone
            calendarInstance = new ChineseCalendar();
        } else if (calendar.equalsIgnoreCase("Japanese")) {
            calendarInstance = new JapaneseCalendar(locale);
        } else if (calendar.equalsIgnoreCase("Islamic")) {
            calendarInstance = new IslamicCalendar(locale);
        } else if (calendar.equalsIgnoreCase("IslamicSacred")) {
            IslamicCalendar ic = new IslamicCalendar(locale);
            ic.setCivil(false);
            calendarInstance = (Calendar) ic;
        }

        return calendarInstance;
    }
  public static Calendar getCalendarInstanceStatic(Locale locale, String calendarString) {
    InternationalCalendarFactory icf = new InternationalCalendarFactory();
    return icf.getCalendarInstance(locale, calendarString);
    }
}
