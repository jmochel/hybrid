package org.heml.chronology.format;

import com.ibm.icu.text.*;
import com.ibm.icu.util.*;

import org.jdom.*;


public class XMLSchemaGYearFormatter {
    public XMLSchemaGYearFormatter() {
    }

    public int getFormattedDate(long time) {
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTimeInMillis(time);

        int year = gc.get(GregorianCalendar.YEAR);

        if (gc.get(GregorianCalendar.ERA) == GregorianCalendar.BC) {
            year = year * -1;
        }

        return year;
    }

    public int getFormattedDate(String timeString) {
        long time = Long.parseLong(timeString);

        return getFormattedDate(time);
    }

    public static void main(String[] args) {
        XMLSchemaGYearFormatter sgy = new XMLSchemaGYearFormatter();
        System.out.println(args[0] + " parsed becomes " + 
                           sgy.getFormattedDate(args[0]));
    }
}