/*
 **************************************************************
 *                                                            * 
 * $RCSfile: JdomUtils.java,v $   
 *                                                            *
 * $Revision: 1.3 $ 
 *                                                            *
 * $Date: 2004/09/08 17:41:52 $  
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 *                                                            *
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 */
package org.heml.util;

import java.awt.*;
import java.awt.Font.*;

import org.jdom.Element;

import org.w3c.dom.*;


public class JdomUtils {
    public JdomUtils() {
    }

    public static org.jdom.Element convertToJdomElement(org.w3c.dom.Element e) {
        org.jdom.input.DOMBuilder builder = new org.jdom.input.DOMBuilder();

        return builder.build(e);
    }

    public static org.w3c.dom.Element convertToDomElement(org.jdom.Element e) {
        org.w3c.dom.Element toReturn = null;
        org.jdom.output.DOMOutputter out = new org.jdom.output.DOMOutputter();

        try {
            toReturn = out.output(e);
        } catch (org.jdom.JDOMException except) {
            System.out.println("Couldn't convert " + except.toString() + 
                               " to DOM dying gracelessly");
            System.exit(1);
        }

        return toReturn;
    }
    public static java.lang.String getStringDeep(org.jdom.Element e) {
      java.lang.StringBuffer out = new java.lang.StringBuffer();
      java.util.List list = e.getContent();
      java.util.ListIterator iterator = list.listIterator();
      Object thisContent;
      while (iterator.hasNext()) {
        thisContent = iterator.next();
        if (thisContent instanceof org.jdom.Text) {
           org.jdom.Text myText = (org.jdom.Text) thisContent;
           out.append(myText.getText());
           }
        else if (thisContent instanceof org.jdom.Element) {
           org.jdom.Element myElement = (org.jdom.Element) thisContent;
           out.append(getStringDeep(myElement));
           }
       }
       return out.toString();
    }
}
