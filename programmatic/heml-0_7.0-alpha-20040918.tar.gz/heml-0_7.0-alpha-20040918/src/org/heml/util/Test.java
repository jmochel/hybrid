package org.heml.util;

import com.ibm.icu.util.*;
import com.ibm.icu.text.*;
import java.util.*;
public class Test {
    private static com.ibm.icu.util.Calendar getCal(String calendarString) {
    
        if (calendarString.equals("Hebrew")) {
            return new HebrewCalendar();
        } else if (calendarString.equals("Islamic")) {
             return new IslamicCalendar();
        } else if (calendarString.equals("Chinese")) {
            return new ChineseCalendar();
        } else if (calendarString.equals("Japanese")) {
            return new JapaneseCalendar();
        } else {
            return  new com.ibm.icu.util.GregorianCalendar();
        }
} 
    public static void main(String[] args) {
            //Locale locIn = new Locale(args[
            DateFormat intFormatter =  DateFormat.getDateInstance(getCal(args[1]), DateFormat.LONG, new Locale(args[2], "CAN"));
            SimpleDateFormat sdfin = (SimpleDateFormat) intFormatter;
            sdfin.applyPattern("G yyyy.MMMM.d");
            DateFormat localFormatter = DateFormat.getDateInstance(getCal(args[3]), DateFormat.LONG, new Locale(args[4], "CAN"));
            SimpleDateFormat sdf = (SimpleDateFormat) localFormatter;
            sdf.applyPattern("G yyyy.MMMM.d");
            try {
            Date foo = intFormatter.parse(args[0]);//formatter.setCalendar(new HebrewCalendar());
            System.out.println(localFormatter.format(foo));

          }
            catch (Exception e) {
             System.out.println(e);  
           }
          }
  } 
