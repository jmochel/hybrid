/*
************************************************************** 
* $RCSfile: ApplicationFrame.java,v $                                     *
*                                                            *
* $Revision: 1.2 $                                       *
*                                                            *
* $Date: 2002/08/23 17:45:19 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.util;

import java.awt.*;
import java.awt.event.*;


/**
 * borrowed shamlessly from the O'Reilly Java 2D book!
 * Not used in final production, but as a jig for <code>main</code> 
 * testing methods.
 */
public class ApplicationFrame extends Frame {
    public ApplicationFrame() {
        this("ApplicationFrame v1.0");
    }

    public ApplicationFrame(String title) {
        super(title);
        createUI();
    }

    protected void createUI() {
        setSize(500, 400);
        center();

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });
    }

    public void center() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        int x = (screenSize.width - frameSize.width) / 2;
        int y = (screenSize.height - frameSize.height) / 2;
        setLocation(x, y);
    }
}