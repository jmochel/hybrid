/*
**************************************************************
*                                                            * 
* $RCSfile: DateParseTest.java,v $                                                  *
*                                                            *
* $Revision: 1.2 $                                                 *
*                                                            *
* $Date: 2002/08/23 17:45:19 $                                                     *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.test;

import java.lang.*;
import java.lang.Integer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;


/*************************
 * Main method prints out the local representations of
 * 'AD 1789' and 'BC 585' in all available locales. It also
 * does a round-trip format and parse of these dates to
 * ensure that these work. Note the number of locales for which
 * proper <code>ERA</code> strings are not provided (and therefore default to
 * 'AD' and 'BC' instead).
 */
public class DateParseTest {
    public static void main(String[] args) {
        Date dateOutBC;
        Date dateOutAD;
        Date ADDateReturn;
        Date BCDateReturn;
        String dateOutStringAD;
        String dateOutStringBC;
        Date BCDate = new Date();
        Date ADDate = new Date();
        String pattern = "G yyyy MMM";
        String BCString = "BC 585";
        String ADString = "AD 1789";
        SimpleDateFormat format = new SimpleDateFormat(pattern, 
                                                       new Locale("en", "UK"));
        SimpleDateFormat formatBase = new SimpleDateFormat(pattern, 
                                                           new Locale("en", 
                                                                      "UK"));

        try {
            BCDate = format.parse(BCString);
            ADDate = format.parse(ADString);
        } catch (Exception e) {
            System.out.println(e);
        }

        Locale[] theLocales = DateFormat.getAvailableLocales();
        String spacer = "    ";

        for (int x = 0; x < theLocales.length; x++) {
            System.out.println("For Locale: " + theLocales[x].toString());

            format = new SimpleDateFormat(pattern, theLocales[x]);
            dateOutStringBC = format.format(BCDate);

            try {
                BCDateReturn = format.parse(dateOutStringBC);

                System.out.println(spacer + "Back to: " + 
                                   formatBase.format(BCDateReturn));
            } catch (Exception e) {
                System.out.println(spacer + "***failed to parse back " + 
                                   dateOutStringBC);
            }

            dateOutStringAD = format.format(ADDate);

            try {
                ADDateReturn = format.parse(dateOutStringAD);
            } catch (Exception e) {
                System.out.println(spacer + "****failed to parse back " + 
                                   dateOutStringAD);
            }

            System.out.println(spacer + "BC Date is: " + dateOutStringBC);
            System.out.println(spacer + "AD Date is: " + dateOutStringAD);
        }
    }
}

/*--- Formatted in Sun Java Convention Style on Wed, Jul 12, '00 ---*/
/*------ Formatted by Jindent 3.11 trial --- http://www.jindent.de ------*/
