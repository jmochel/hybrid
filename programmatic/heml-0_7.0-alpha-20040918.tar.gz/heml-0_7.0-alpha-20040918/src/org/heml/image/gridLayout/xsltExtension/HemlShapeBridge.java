/*
************************************************************** 
* $RCSfile: HemlShapeBridge.java,v $                         *
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2003/06/19 18:04:41 $                               *
*                                                            *
* Copyright (C) 2000 Susan Barnett                           *
*                    Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/

package org.heml.image.gridLayout.xsltExtension;

import java.awt.*;
import org.apache.batik.dom.GenericDOMImplementation;
import org.heml.image.gridLayout.CylindricalEquidistantMapDefinition;
import org.apache.batik.svggen.*;
import org.apache.xerces.dom.*;
import org.heml.image.hemlEvent.*;
import org.heml.image.text.WrappingSvgText;
import org.jdom.Element;
import org.jdom.Namespace;
import org.w3c.dom.*;

/***
 * Bridge between the XSLT stylesheets and the grid placement classes.  Allows for the plotting of
 * location labels.
 **/
public class HemlShapeBridge {
    protected CylindricalEquidistantMapDefinition mapster;
    private final boolean VERBOSE = false; // output level for debugging

    /**
     * Constructs and Initializes a <code>HemlShapeBridge</code> based upon the input parameters.  
     * @param map the map upon which the location labels are to be written
     **/
    public HemlShapeBridge(CylindricalEquidistantMapDefinition map) {
        this.mapster = map;
    }
    
	/**
	 * Generates an SVG object that includes the plotted location labels
	 * @param node includes the information about the events to be plotted
	 * @return an SVG element including the plotted labels
	 **/
    public org.w3c.dom.Element generateSvg(Node node) {

        HemlEventCollection hemlEventCollection = new HemlEventCollection();
        org.jdom.Element wrapper = org.heml.util.JdomUtils.convertToJdomElement((org.w3c.dom.Element) node);
        java.util.Iterator itr = wrapper.getChildren().iterator();

        // collect required information from dom for each event
        while (itr.hasNext()) {
            HemlEventMapPlotter hemp = new HemlEventMapPlotterForLocation((org.jdom.Element) itr.next(),this.mapster);
            if ((hemp.getLabel().length() != 0) && (hemp.getText().length() != 0)) {
                hemlEventCollection.add(hemp);
            }
        }
        
        Document domFactory = new DocumentImpl();
        SVGGraphics2D svggen = new SVGGraphics2D(domFactory);
		// try to paint the labels to the map.  If unsuccessful, print out error report
        try {
            paint((Graphics)svggen, hemlEventCollection);
        } catch (Throwable t) {
            return svgErrorReport(t);
        }
        return svggen.getTopLevelGroup();
    }
    
    /**
     * Paints the reqired heml event labels to the map if possible.
     * @param graphics
     * @param hemlEventCollection
     **/
    public void paint(Graphics graphics, HemlEventCollection hemlEventCollection) {
        org.apache.batik.svggen.SVGGraphics2D g2 = (org.apache.batik.svggen.SVGGraphics2D) graphics;
        Composite c_alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .2f);
        Composite c_black = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .99f);

        //draw each of the shapes
        for (int i = 0; i < hemlEventCollection.size(); i++) {
        	org.w3c.dom.Element previousTop = g2.getTopLevelGroup();
	     	if (VERBOSE){
	        	System.out.println("\tDrawing Shape: " 
	        						+ ((HemlEventMapPlotter)hemlEventCollection.get(i)).getText());
			}           	
			
			//draw the location shape specified
          	g2.setComposite(c_alpha);
          	g2.setColor(Color.red);
           	g2.fill(((HemlEventMapPlotter)hemlEventCollection.get(i)).getShape());
           	g2.setComposite(c_black);
          	g2.setColor(Color.red);
          	g2.draw(((HemlEventMapPlotter)hemlEventCollection.get(i)).getShape());

         	org.w3c.dom.Element newTop = g2.getTopLevelGroup();
        	newTop.setAttribute("id", ((HemlEventMapPlotter)hemlEventCollection.get(i)).getId());
         	previousTop.appendChild(newTop);
        	g2.setTopLevelGroup(previousTop);
        }
    }
    
    /*
     *
     **/
    //public double getBaseX(){}
    
    /*
     *
     **/
    //public double getBaseY(){}

    /*
     *
     **/
    private org.w3c.dom.Element svgErrorReport(Throwable t) {
        // the SVG element we will return
        org.w3c.dom.Element e;

        // the object that generates wrapped svg from a string
        WrappingSvgText wst = new WrappingSvgText();

        // the string to be returned
        String out;
        
        // exceptions, etc. put us in deep water.
        // we therefore format the complete stack trace.
        java.io.StringWriter sw = new java.io.StringWriter();
        java.io.PrintWriter pw = new java.io.PrintWriter(sw, true);
        t.printStackTrace(pw);
        out = sw.toString();

        e = wst.generate(out, 400, WrappingSvgText.LEFT, "Times", 10, 1f);
        e.setAttribute("id", "HEML_ERROR");

        return e;
    }
}