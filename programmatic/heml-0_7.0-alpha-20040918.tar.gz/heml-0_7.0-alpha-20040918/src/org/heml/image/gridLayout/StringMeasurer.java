/*
**************************************************************
*                                                            * 
* $RCSfile: StringMeasurer.java,v $                          *
*                                                            *
* $Revision: 1.3 $                                           *   
*                                                            *
* $Date: 2002/11/03 18:53:54 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.gridLayout;

import java.awt.Dimension;

//package org.heml.image.text;
//import java.awt.*;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.font.*;
import java.awt.geom.*;

import java.text.*;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;

import org.apache.xalan.extensions.XSLProcessorContext;
import org.apache.xalan.templates.ElemExtensionCall;

//import com.sun.awt.svg.*;
import org.apache.xerces.dom.*;

import org.apache.xpath.DOMHelper;
import org.apache.xpath.objects.XNodeSet;

import org.w3c.dom.*;


/**
 * Represents the positioned label for an event on a timeline. To be
 * distinguished from a <code>TimelineMarker</code>.
 */
public class StringMeasurer {
    // Generous debugging output when set 'true'
    private static final boolean VERBOSE = false;
    private java.awt.font.FontRenderContext frc;
    private java.awt.Font font;

	/**
	 * Constructs and initializes a <code>StringMeasurer</code>.
	 * @param fontName the font of the string to be measured
	 * @param fontSize the font size of the string to be measured
	 * @param graphics the state information for rendering the string to be measured
	 **/
    public StringMeasurer(String fontName, int fontSize, 
                          java.awt.Graphics graphics) {
        this.font = new java.awt.Font(fontName, java.awt.Font.PLAIN, fontSize);

        Graphics2D g2 = (Graphics2D) graphics;

        this.frc = g2.getFontRenderContext();
    }

    /**
     * Calculates the width of the input string
     * @param text the string to be measured
     * @return the width of the input string
     **/
    public int getWidth(String text) {
        java.awt.geom.Rectangle2D.Float bounds = (java.awt.geom.Rectangle2D.Float) font.getStringBounds(
                                                         text, frc);

        if (VERBOSE) {
            System.out.println("bounds: " + bounds.toString());
        }

        Float f = new Float(bounds.width);

        return f.intValue();
    }

    public static void main(String[] args) {
        Document domFactory = new DocumentImpl();
        SVGGraphics2D g2 = new SVGGraphics2D(domFactory);
        g2.setSVGCanvasSize(new Dimension(600, 800));
        StringMeasurer sm = new StringMeasurer(args[0], 12, g2);
        System.out.println("The length of your string \"" + args[1] + 
                           "\" is " + sm.getWidth(args[1]));
    }
}