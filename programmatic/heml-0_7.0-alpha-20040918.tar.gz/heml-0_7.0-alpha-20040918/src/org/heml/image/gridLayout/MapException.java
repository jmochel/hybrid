/*
************************************************************** 
* $RCSfile: MapException.java,v $                            *
*                                                            *
* $Revision: 1.3 $                                           *
*                                                            *
* $Date: 2002/11/03 17:20:29 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.gridLayout;

/**
 * Thrown when the point to be plotted on the map lies outside of the map boundaries.
 **/
public class MapException extends java.lang.Exception {
	/***
     * Constructs a <code>MapException</code> without a detail message.
     **/
    public MapException() {
        super();
    }

    /**
	 * Constructs a <code>MapException</code> with the specified detail message. 
	 * The error message can later be retrieved by the <code>getMessage()</code> method.
	 * @param message the detail message.
	 */
    public MapException(String message) {
        super(message);
    }
}