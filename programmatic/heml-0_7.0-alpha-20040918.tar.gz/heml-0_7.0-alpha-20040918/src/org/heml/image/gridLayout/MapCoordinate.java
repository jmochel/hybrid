/*
 ************************************************************** 
 * $RCSfile: MapCoordinate.java,v $                           *
 *                                                            *
 * $Revision: 1.7 $                                           *
 *                                                            *
 * $Date: 2002/11/03 18:42:32 $                               *
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Susan Barnett                                          *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 ************************************************************** 
 */
package org.heml.image.gridLayout;

/***
 * Holds coordinate information for a point on a map.
 **/
public class MapCoordinate {
    public float hours;
    public float minutes;
    public float seconds;

    /** 
	 * Constructs and initializes a <code>MapCoordinate</code>.
	 * @param hours the coordinate's hours
	 * @param minutes the coordinate's minutes
	 * @param seconds the coordinate's seconds
	 */ 
    public MapCoordinate(float hours, float minutes, float seconds) {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }
}