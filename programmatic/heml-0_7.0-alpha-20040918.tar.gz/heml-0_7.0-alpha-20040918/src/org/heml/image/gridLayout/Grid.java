/*
************************************************************** 
* $RCSfile: Grid.java,v $                                    *
*                                                            *
* $Revision: 1.8 $                                       *
*                                                            *
* $Date: 2002/12/06 14:21:25 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.image.gridLayout;

/***
 * Creates and maintains the integrity of a grid in the form of a two-dimensional array.
 * Access to cells only through <code>cellFactory</code>.  Each <code>Cell</code> in this <code>Grid</code> is set to an 
 * integer value depending upon its current state. 
 **/
public class Grid {
    public int[][] grid;
    protected int rows;
    protected int columns;
    private final int FULL = 0; // constant variables for cell's state
    private final int FREE = 1; // constant variables for cell's state

    /***
     * Creates a <code>Grid</code> and sets all <code>Cells</code> in the <code>Grid</code> to FREE.
     * <code>Cell</code>s may be assigned one of two states:
     * <ul>
	 *  <li> FULL - representing a <code>Cell</code> that is not free and cannot be overwritten under any
     *              circumstances (e.g. contains text or a specific location point).
     *  <li> FREE - representing a <code>Cell</code> that may be overwritten
     * </ul>
     **/
    public Grid(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        grid = new int[this.rows][this.columns];

        // set all cells in the grid initially to FREE
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.columns; j++) {
                grid[i][j] = FREE;
            } // end for columns
        } // end for rows
    }

    /***
     * Changes <code>Cell</code>'s state value to desired integer value.
     * @param current the <code>Cell</code> for which the state change is desired
     * @param int the desired state of <code>Cell</code>, such that:
     * <ul>
     *  <li> 0 represents FULL
     *  <li> 1 represents FREE
     * </ul>
     **/
    public void setState(Cell current, int state) {
        grid[current.row][current.column] = state;
    }

    /***
     * Returns the current state of the input <code>Cell</code>.
     * @param current the <code>Cell</code> whose state is required
     * @return the integer value of the requested cell, such that:
     * <ul>
     *  <li> 0 represents FULL
     *  <li> 1 represents FREE
     * </ul>
     **/
    public int getState(Cell current) {
        return grid[current.row][current.column];
    }

    /***
     * Checks input <code>Cell</code> for availability.
     * @param current the <code>Cell</code> whose state is to be checked
     * @return true if current <code>Cell</code> is FREE; false otherwise.
     **/
    public boolean isFree(Cell current) {
        return (grid[current.row][current.column] == FREE);
    }

    /***
     * Creates a <code>Cell</code> which is certain to be within this <code>Grid</code>.
     * @param row the desired row position for this <code>Cell</code>
     * @param col the desired column position for this <code>Cell</code>
     * @return requested <code>Cell</code> if it is valid with respect to this <code>Grid</code>
     * @throws GridException If the requested <code>Cell</code> lies outside of this <code>Grid</code>.
     **/
    public Cell cellFactory(int row, int col) throws GridException {
        if ((row < 0) || (col < 0)) {
            throw new GridException("Your row or column is smaller than 0");
        } else if (row >= this.rows) {
            int currentRows = this.rows - 1; // make error message more intuitive to user
            throw new GridException("Your row is " + rows + 
                                    " and this is bigger than " + 
                                    currentRows + 
                                    ", which is the number of rows in this Grid object");
        } else if (col >= this.columns) {
            int currentColumns = this.columns - 1; // make error message more intuitive to user
            throw new GridException("Your column is " + columns + 
                                    " and this is bigger than " + 
                                    currentColumns + 
                                    ", which is the number of columns in this Grid object");
        } else {
            return new Cell(row, col);
        }
    }




    /*** 
     * Allows access to <code>Cell</code>s within this <code>Grid</code>.
     **/
    public class Cell {
        public int row;
        public int column;

        /***
         * May only be accessed by the cellFactory to ensure the integrity of the grid
         * and prevent access to cells that lie outside of the grid bounds
         ***/
        private Cell(int row, int column) {
            this.row = row;
            this.column = column;
        }

        /***
         * Overrides inherited <code>equals</code> method.
         * @param other the <code>Cell</code> to be compared to this <code>Cell</code>
         * @return true if input <code>Cell</code> and this <code>Cell</code> are the same <code>Cell</code>; false otherwise.
         **/
        public boolean equals(Cell other) {
            return ((this.row == other.row) && (this.column == other.column));
        }
        
    } // end Cell class
    
} // end Grid class
