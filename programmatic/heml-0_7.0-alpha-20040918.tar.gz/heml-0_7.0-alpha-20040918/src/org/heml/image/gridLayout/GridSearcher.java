/*
************************************************************** 
* $RCSfile: GridSearcher.java,v $                            *
*                                                            *
* $Revision: 1.10 $                                           *
*                                                            *
* $Date: 2003/07/30 22:18:31 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/

package org.heml.image.gridLayout;

/***
 * Determines the most suitable location for labels on the <code>Grid</code>.
 **/
public class GridSearcher {
    // class variables
    private final int FULL = 0; // constant variable for cell state
    private final int FREE = 1; // constant variable for cell state
    private final int SPACE = 4; // constant variable for how many columns must be between text labels
    private final int SEARCH_SPAN = 100; // determines how far out getAnyProximate will search from base

    private Grid g;
    private Grid.Cell[] found;
    private Grid.Cell base; // base cell for searching
    protected String justification = " ";
    private int currentlyFound = 0; // keeps track of how many cells have been found
    private int cellsRequired = 0; // number of cells needed for label
    private int radial = 0; // distance from base to search
    private int wrapWidth = 0; // length at which a string is to be wrapped
    private float wrapHeight = 0;

    // booleans to stop searching once an edge has been hit (performance)
    private boolean rightEdge = false;
    private boolean leftEdge = false;
    private boolean topEdge = false;
    private boolean bottomEdge = false;

    /*** 
     * Constructs and initializes a <code>GridSearcher</code> that will search <code>Grid g</code>.
     * @param g the <code>Grid</code> all searching will be done on.
     **/
    public GridSearcher(Grid g) {
        this.g = g;
        this.wrapWidth = g.columns / 4; // set the point where a string must be wrapped 
    }

    /***
     * Returns an <code>array</code> of <code>Cells</code> over which the label may be written.
     * @param cellsRequired the number of adjacent <code>Cells</code> needed to place the label.
     * @param base the <code>Cell</code> searching should begin from.
     * @param wrapHeight the height required if a label is wrapped.  Used to determine whether further
     * cells are required in the case of wrapping.
     * @return an <code>array</code> of <code>Cells</code> representing the area on the <code>Grid</code> that the label
     * is to be placed.
     * @throws AvailabilityException if the labels will not fit onto the supplied <code>Grid</code>.
     **/
    public Grid.Cell[] getLabelCells(int cellsRequired, Grid.Cell base, 
                                     float wrapHeight)
                              throws AvailabilityException {                   	
        // may need to reset cells required to fill entire rectangle for wrapping
        if (wrapHeight >= 1) {
            cellsRequired = (int) (this.wrapWidth * wrapHeight);
        }

        // set method variables    
        this.cellsRequired = cellsRequired;
        found = new Grid.Cell[this.cellsRequired]; // initialize array to hold required cells
        this.base = base; // set base cell
        this.wrapHeight = wrapHeight;

        // search for cells, if not found throw an AvailabilityException
        try {
            // conduct a radial search for the required cells
            found = radialSearch(base);

            // if the cells were successfully found
            if (currentlyFound == this.cellsRequired) {
                // set found cells to FULL
                for (int i = 0; i < cellsRequired; i++) {
                    g.setState(found[i], FULL);
                }
                return found;
            } else {
                throw new AvailabilityException();
            }
        } catch (AvailabilityException ae) {
            throw ae;
        } // deal with this exception at a higher level
    }

    /***
     * Conducts a radial search from the base search and fanning out.  Distance of search
     * from base is determined by the int SEARCH_SPAN.
     * @param base the <code>Cell</code> searching should begin with
     * @return an <code>array</code> containing the <code>Cells</code> that hold the label in the <code>Grid</code>
     * @throws AvailabilityException if the required cells are not found
     **/
    private Grid.Cell[] radialSearch(Grid.Cell base)
                              throws AvailabilityException {
        // search out up to SEARCH_SPAN times
        for (radial = 1; radial < SEARCH_SPAN; radial++) {
            // search right cell for availability
            if (!rightEdge) {
                found[currentlyFound] = getRight(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getRightWrap();
                    } else {
                        getRightAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search left cell for availability
            if (!leftEdge) {
                found[currentlyFound] = getLeft(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getLeftWrap();
                    } else {
                        getLeftAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell above and to the right for availability
            if (!rightEdge && !topEdge) {
                found[currentlyFound] = getUpRight(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getRightWrap();
                    } else {
                        getRightAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell above and to the left for availability
            if (!leftEdge && !topEdge) {
                found[currentlyFound] = getUpLeft(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getLeftWrap();
                    } else {
                        getLeftAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell below and right for availability
            if (!bottomEdge && !rightEdge) {
                found[currentlyFound] = getDownRight(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getRightWrap();
                    } else {
                        getRightAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell below and left for availability
            if (!bottomEdge && !leftEdge) {
                found[currentlyFound] = getDownLeft(base, radial);

                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getLeftWrap();
                    } else {
                        getLeftAdjacent();
                    }
                }

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell above for availability
            if (!topEdge) {
                found[currentlyFound] = getUp(base, radial);

                // if found search for adjacent cells
                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getRightWrap();
                    } else {
                        getRightAdjacent();
                    }

                    // if cells not found to the right, check cells to the left
                    if (currentlyFound == 0) {
                        currentlyFound++; // search from originally found cell

                        // if the string is sufficiently long with respect to the map, send it to text wrapping
                        if (this.wrapHeight >= 1) {
                            getLeftWrap();
                        } else {
                            getLeftAdjacent();
                        }
                    }
                } // end if found[...] != base

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method
            }

            // else search cell below for availability
            if (!bottomEdge) {
                found[currentlyFound] = getDown(base, radial);

                // if found search for adjacent cells
                if (found[currentlyFound] != base) {
                    currentlyFound++;

                    // if the string is sufficiently long with respect to the map, send it to text wrapping
                    if (this.wrapHeight >= 1) {
                        getRightWrap();
                    } else {
                        getRightAdjacent();
                    }

                    // if cells not found to the right, check cells to the left
                    if (currentlyFound == 0) {
                        currentlyFound++; // search from originally found cell

                        // if the string is sufficiently long with respect to the map, send it to text wrapping
                        if (this.wrapHeight >= 1) {
                            getLeftWrap();
                        } else {
                            getLeftAdjacent();
                        }
                    }
                } // end if found[...] != base

                if (currentlyFound == this.cellsRequired) {
                    return found;
                } // if required cells found, return and exit method 
            }
        } // end for

        // if method reaches this point, the required cells have not been found, so throw exception
        throw new AvailabilityException();
    }

    /*** 
     * Checks the <code>Cell</code> to the (right + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getRight(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell right = g.cellFactory(currentBase.row, 
                                            currentBase.column + offset);

            if (g.isFree(right)) {
                return right;
            } else {
                return currentBase;
            } // return original cell if right not available
        } catch (GridException e) {
            rightEdge = true;

            return currentBase;
        } // return original cell if right not available
    }

    /*** 
     * Checks the <code>Cell</code> to the (left + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getLeft(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell left = g.cellFactory(currentBase.row, 
                                           currentBase.column - offset);

            if (g.isFree(left)) {
                return left;
            } else {
                return currentBase;
            } // return original cell if left not available
        } catch (GridException e) {
            leftEdge = true;

            return currentBase;
        } // return original cell if left not available
    }

    /***
     * Checks the <code>Cell</code> (below + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getDown(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell down = g.cellFactory(currentBase.row + offset, 
                                           currentBase.column);

            if (g.isFree(down)) {
                return down;
            } else {
                return currentBase;
            } // return original cell if down invalid
        } catch (GridException e) {
            bottomEdge = true;

            return currentBase;
        } // return original cell if down invalid
    }

    /*** 
     * Checks the <code>Cell</code> (above + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getUp(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell up = g.cellFactory(currentBase.row - offset, 
                                         currentBase.column);

            if (g.isFree(up)) {
                return up;
            } else {
                return currentBase;
            } // return original cell if up not available
        } catch (GridException e) {
            topEdge = false;

            return currentBase;
        } // return original cell if up not available
    }

    /*** 
     * Checks the <code>Cell</code> to the (right and below + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getDownRight(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell downRight = g.cellFactory(currentBase.row + offset, 
                                                 currentBase.column + 
                                                 offset);

            if (g.isFree(downRight)) {
                return downRight;
            } else {
                return currentBase;
            } // return original cell if up not available
        } catch (GridException e) {
            return currentBase;
        } // return original cell if up not available
    }

    /*** 
     * Checks the <code>Cell</code> to the (below and left + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getDownLeft(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell downLeft = g.cellFactory(currentBase.row + offset, 
                                                currentBase.column - offset);

            if (g.isFree(downLeft)) {
                return downLeft;
            } else {
                return currentBase;
            } // return original cell if up not available
        } catch (GridException e) {
            return currentBase;
        } // return original cell if up not available
    }

    /*** 
     * Checks the <code>Cell</code> to the (right and up + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getUpRight(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell upRight = g.cellFactory(currentBase.row - offset, 
                                               currentBase.column + offset);

            if (g.isFree(upRight)) {
                return upRight;
            } else {
                return currentBase;
            } // return original cell if up not available
        } catch (GridException e) {
            return currentBase;
        } // return original cell if up not available
    }

    /*** 
     * Checks the <code>Cell</code> to the (left and up + offset) of the base <code>Cell</code> for validity and occupation.
     * @param currentBase the anchor <code>Cell</code> for the search
     * @param offset how far from base <code>Cell</code> search should be conducted
     * @return the checked <code>Cell</code> if available; the input currentBase <code>Cell</code> otherwise.
     **/
    private Grid.Cell getUpLeft(Grid.Cell currentBase, int offset) {
        try {
            Grid.Cell upLeft = g.cellFactory(currentBase.row - offset, 
                                              currentBase.column - offset);

            if (g.isFree(upLeft)) {
                return upLeft;
            } else {
                return currentBase;
            } // return original cell if up not available
        } catch (GridException e) {
            return currentBase;
        } // return original cell if up not available
    }

    /***
     * Searches right until a cell is unavailable or the required amount of cells are found.  
     * If search unsuccessful, currentlyFound will be set to zero.  
     * If successful, currentlyFound will equal cellsRequired.
     **/
    private void getRightAdjacent() {
        // while required cells are not all found and cells are still valid keep searching
        do {
            found[currentlyFound] = getRight(found[currentlyFound - 1], 1);
            currentlyFound++;
        } while ((currentlyFound != cellsRequired) && 
                 (found[currentlyFound - 1] != found[currentlyFound - 2]));

        // if cellsRequired not found, reset currentlyFound to zero to start searching again
        if (currentlyFound != cellsRequired) {
            currentlyFound = 0;
        } else {
            this.justification = "LEFT";
        }
    }

    /***
     * Searches left until a cell is unavailable or the required amount of cells are found.  
     * If search unsuccessful, currentlyFound will be set to zero.  
     * If successful, currentlyFound will equal cellsRequired.
     **/
    private void getLeftAdjacent() {
        // while required cells are not all found and cells are still valid keep searching
        do {
            found[currentlyFound] = getLeft(found[currentlyFound - 1], 1);
            currentlyFound++;
        } while ((currentlyFound != cellsRequired) && 
                 (found[currentlyFound - 1] != found[currentlyFound - 2]));

        // if cellsRequired not found, reset currentlyFound to zero to start searching again
        if (currentlyFound != cellsRequired) {
            currentlyFound = 0;
        } else {
            this.justification = "RIGHT";
        }
    }

    /***
     * Searches right then left with wrap until a cell is unavailable or the required amount of cells are found.  
     * If search unsuccessful, currentlyFound will be set to zero.  
     * If successful, currentlyFound will equal cellsRequired.  Wrap will always search downward.
     **/
    private void getRightWrap() {
        // while required cells are not all found and cells are still valid keep searching
        Grid.Cell base = found[currentlyFound - 1];

        // find first row
        do {
            found[currentlyFound] = getRight(found[currentlyFound - 1], 1);
            currentlyFound++;
        } while ((currentlyFound != (this.wrapWidth - 1)) && 
                 (found[currentlyFound - 1] != found[currentlyFound - 2]));

        // if cells still available, search for remaining rows
        for (int j = 1; j < this.wrapHeight; j++) {
            if ((found[currentlyFound - 1] != found[currentlyFound - 2] || 
                    found[currentlyFound - 1].row != found[currentlyFound - 2].row) && 
                    (currentlyFound < cellsRequired)) {
                found[currentlyFound] = getDown(base, 1);
                base = found[currentlyFound];
                currentlyFound++;

                if (found[currentlyFound - 1].row != found[currentlyFound - 2].row) {
                    while ((currentlyFound < (this.wrapWidth * (j + 1))) && 
                           (found[currentlyFound - 1] != found[currentlyFound - 2]) && 
                           (currentlyFound < cellsRequired)) {
                        found[currentlyFound] = getRight(found[currentlyFound - 1], 1);
                        currentlyFound++;
                    }
                }
            }
        }

        // if cellsRequired not found, reset currentlyFound to zero to start searching again
        if (currentlyFound != cellsRequired) {
            currentlyFound = 0;
        } else {
            this.justification = "LEFT";
        }
    }

    /***
     * Searches left then right with wrap until a cell is unavailable or the required amount of cells are found.  
     * If search unsuccessful, currentlyFound will be set to zero.  
     * If successful, currentlyFound will equal cellsRequired.  Wrap will always search downward
     **/
    private void getLeftWrap() {
        Grid.Cell base = found[currentlyFound - 1];

        // while required cells are not all found and cells are still valid keep searching
        // find first row
        do {
            found[currentlyFound] = getLeft(found[currentlyFound - 1], 1);
            currentlyFound++;
        } while ((currentlyFound != (this.wrapWidth - 1)) && 
                 (found[currentlyFound - 1] != found[currentlyFound - 2]));

        // if cells still available, search for remaining rows
        for (int j = 1; j < this.wrapHeight; j++) {
            if ((found[currentlyFound - 1] != found[currentlyFound - 2] || 
                        found[currentlyFound - 1].row != found[currentlyFound - 2].row) && 
                    (currentlyFound < cellsRequired)) {
                found[currentlyFound] = getDown(base, 1);
                base = found[currentlyFound];
                currentlyFound++;

                if (found[currentlyFound - 1].row != found[currentlyFound - 2].row) {
                    while ((currentlyFound < (this.wrapWidth * (j + 1))) && 
                           (found[currentlyFound - 1] != found[currentlyFound - 2]) && 
                           (currentlyFound < cellsRequired)) {
                        found[currentlyFound] = getLeft(found[currentlyFound - 1], 1);
                        currentlyFound++;
                    }
                }
            }
        }

        // if cellsRequired not found, reset currentlyFound to zero to start searching again
        if (currentlyFound != cellsRequired) {
            currentlyFound = 0;
        } else {
            this.justification = "RIGHT";
        }
    }
} // end gridSearcher class
