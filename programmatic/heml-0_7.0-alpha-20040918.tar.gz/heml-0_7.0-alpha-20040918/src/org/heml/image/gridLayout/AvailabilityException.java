/*
************************************************************** 
* $RCSfile: AvailabilityException.java,v $                                     *
*                                                            *
* $Revision: 1.7 $                                       *
*                                                            *
* $Date: 2002/12/06 14:21:25 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *    
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.image.gridLayout;

/***
 * Thrown when there are no available <code>Cells</code> left to search on the <code>Grid</code> 
 * and searching was not completed.
 **/
public class AvailabilityException extends Exception {
    int completed;
    int fontSize;
    java.awt.Point gridDimensions;

    /***
     * Constructs an <code>AvailabilityException</code> without a detail message.
     **/
    public AvailabilityException() {
        super();
    }
    
    /**
	 * Constructs an <code>AvailabilityException</code> with the specified detail message. 
	 * The error message can later be retrieved by the <code>getMessage()</code> method.
	 * @param message the detail message.
	 */
    public AvailabilityException(String message) {
        super(message);
    }

    /*** 
     * Records the state of the <code>GridSearcher</code> at the time the <code>AvailabilityException</code>
     * was thrown.
     * @param completed the amount of labels that had been successfully plotted
     * @param fontSize the current font size of the labels
     * @param gridDimensions the dimensions of the <code>Grid</code> upon which the labels were being plotted
     **/
    public void setData(int completed, int fontSize, int rows, int columns) {
        this.completed = completed;
        this.fontSize = fontSize;
        gridDimensions = new java.awt.Point(rows, columns);
    }

    /*** 
     * Returns the label font size at time of the <code>AvailabilityException</code>.
     * @return the size of the labels that were being plotted when the <code>AvailabilityException</code> was thrown.
     **/
    public int getFontSize() {
        return fontSize;
    }

    /*** 
     * Returns the number of labels successfully plotted at the time of the <code>AvailabilityException</code>.
     * @return the number of labels already plotted when the <code>AvailabilityException</code> was thrown.
     **/
    public int getCompleted() {
        return completed;
    }

    /*** 
     * Returns the dimensions of the <code>Grid</code> upon which the labels were being plotted.
     * @return the <code>Grid</code> dimensions.
     **/
    public java.awt.Point getGridDimensions() {
        return gridDimensions;
    }

    /***
     * Reports on the state of the data at the time of the <code>AvailabilityException</code>.
     * @return a <code>String</code> detailing the number of labels completed and the font size
     * of the labels at the time the <code>AvailabilityException</code> was thrown.
     **/
    public java.lang.String toString() {
        return "Avaliabliity Exception: no room left after" + getCompleted() + 
               " labels had been drawn at font size " + getFontSize();
    }
}