/*
************************************************************** 
* $RCSfile: HemlLocationBridge.java,v $                     *
*                                                            *
* $Revision: 1.17 $                                           *
*                                                            *
* $Date: 2003/06/19 18:04:41 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/

package org.heml.image.gridLayout.xsltExtension;

import java.awt.*;
import java.util.Date;
import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;
import org.apache.xerces.dom.*;
import org.heml.chronology.format.*;
import org.heml.image.gridLayout.*;
import org.heml.image.hemlEvent.*;
import org.heml.image.text.WrappingSvgText;
import org.jdom.Element;
import org.jdom.Namespace;
import org.w3c.dom.*;

/***
 * Bridge between the XSLT stylesheets and the grid placement classes.  Allows for the plotting of
 * location labels.
 **/
public class HemlLocationBridge {
	private final boolean VERBOSE = false; // output level for debugging
    private static float ADVANCE = 0.85f;
    protected CylindricalEquidistantMapDefinition mapster;
    protected String fontName;

    /**
     * Constructs and Initializes a <code>HemlLocationBridge</code> based upon the input parameters.  
     * @param map the map upon which the location labels are to be written
     * @param fontName the name of the location label's font
     **/
    public HemlLocationBridge(CylindricalEquidistantMapDefinition map, String fontName) {
        this.mapster = map;
        this.fontName = fontName;
    }
    
	/**
	 * Generates an SVG object that includes the plotted location labels
	 * @param node includes the information about the locations to be plotted
	 * @return an SVG element including the plotted labels
	 **/
    public org.w3c.dom.Element generateSvg(Node node) {

        HemlEventCollection hemlEventCollection = new HemlEventCollection();
        org.jdom.Element wrapper = org.heml.util.JdomUtils.convertToJdomElement((org.w3c.dom.Element) node);
        java.util.Iterator itr = wrapper.getChildren().iterator();

        // collect required information from dom for each event
        while (itr.hasNext()) {
            HemlEventMapPlotter hemp = new HemlEventMapPlotter((org.jdom.Element) itr.next(),this.mapster);
            if ((hemp.getLabel().length() != 0) && (hemp.getText().length() != 0)) {
                hemlEventCollection.add(hemp);
            }
        }
        
        Document domFactory = new DocumentImpl();
        SVGGraphics2D svggen = new SVGGraphics2D(domFactory);
		// try to paint the labels to the map.  If unsuccessful, print out error report
        try {
            paintLoop(svggen, hemlEventCollection, fontName, 12, 3);
        } catch (Throwable t) {
            return svgErrorReport(t);
        }
        return svggen.getTopLevelGroup();
    }
    
    /**
     * Attempts to paint the labels to the map via <code>paint</code> method.  
     * If unsuccessful, will try successively smaller font sizes
     * until the labels are plotted or the font size is minimum.
     * @param graphics
     * @param hemlEventCollection the heml events requiring painting
     * @param fontName the name of the font in which the labels are to be written
     * @param startFontSize the original font size to try painting with
     * @param minFontSize the minimum font size to try painting with
     * @throws AvailabilityException if the labels would not fit onto the map
     * @throws GridException if the labels began outside the bounds of the subsequent <code>Grid</code>
     * @throws EmptyStringException if a label to be painted was empty
     **/
    public void paintLoop(Graphics graphics, HemlEventCollection hemlEventCollection, String fontName, int startFontSize, int minFontSize)
                   throws AvailabilityException, GridException, EmptyStringException {

        try {
        	if (VERBOSE){
            	System.out.println("Trying to paint at : " + startFontSize);
            }
            paint(graphics, hemlEventCollection, fontName, startFontSize);
        } catch (AvailabilityException avEx) {
            if (startFontSize == minFontSize) {
                throw avEx;
            } else {
                paintLoop(graphics, hemlEventCollection, fontName, startFontSize - 1, minFontSize);
            }
        }
    }
    
    /**
     * Paints the reqired heml event labels to the map if possible.
     * @param graphics
     * @param hemlEventCollection
     * @param fontName
     * @param fontSize
     * @throws AvailabilityException
     * @throws GridException
     * @throws EmptyStringException
     **/
    public void paint(Graphics graphics, HemlEventCollection hemlEventCollection, String fontName, int fontSize) 
    		throws AvailabilityException, GridException, EmptyStringException {

        float columnWidth = 4f; // width of point's oval + 1 to avoid overlap
        org.apache.batik.svggen.SVGGraphics2D g2 = (org.apache.batik.svggen.SVGGraphics2D) graphics;
        java.awt.Font font = new java.awt.Font(fontName, java.awt.Font.PLAIN, fontSize);
        WrappingSvgText wst = new WrappingSvgText(g2);
        g2.setFont(font);

        HemlEventMapPlotter[] current;
        Composite c_alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .2f);
        Composite c_black = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .99f);

        // plot all points on grid before plotting on map in case of AvEx
        current = toHemlEventMapPlotter(hemlEventCollection);
        GridBuilder gb = new GridBuilder(columnWidth, 1.3f, font, ADVANCE, g2, current, this.mapster);
        gb.processLocations();

        // if no AvEx thrown, plot all points
        //draw each of the labels and locations
        for (int i = 0; i < current.length; i++) {
            if (current[i].isPlotted()) {
            	
            	// debugging code
            	if (VERBOSE){
            		System.out.println("Drawing String: " + current[i].getText());
                  	System.out.println("x: " + current[i].getRect().getX());
                   	System.out.println("y: " + current[i].getRect().getY());
                }
                
                org.w3c.dom.Element previousTop = g2.getTopLevelGroup();
                g2.setStroke(new java.awt.BasicStroke((float) fontSize / 17f));
                g2.setColor(Color.black);
                g2.setComposite(c_black);
                
                //draw label, beginning at the recommended starting point
                if (current[i].isWrapped()) {
                    float dummy = wst.print(current[i].getText(), (float) current[i].getRect().getWidth(), 
                                            current[i].getJustification(), fontName, fontSize, ADVANCE, 
                                            (float) current[i].getRect().getX(), (float) current[i].getRect().getY() + (fontSize / 4));
                } 
                else {
                    g2.drawString(current[i].getText(), (float) current[i].getRect().getX(), ((float) current[i].getRect().getY() + fontSize));
                }

                g2.setComposite(c_alpha);
                g2.setColor(Color.red);

                //draw the location shape specified
                g2.fill(current[i].getShape());
                g2.setComposite(c_black);
                g2.setColor(Color.red);
                g2.draw(current[i].getShape());

				// draw line between point and text if necessary
                g2.setColor(Color.blue);
                if (current[i].getLine() != null) {
                    g2.draw(current[i].getLine());
                }
                
                org.w3c.dom.Element newTop = g2.getTopLevelGroup();
                newTop.setAttribute("id", current[i].getId());
                previousTop.appendChild(newTop);
                g2.setTopLevelGroup(previousTop);
            }
        }
    }
    
    
    /*
     *
     **/
    public HemlEventMapPlotter[] toHemlEventMapPlotter(HemlEventCollection hec) {
        HemlEventMapPlotter[] out = new HemlEventMapPlotter[hec.size()];
        java.util.ListIterator li = hec.listIterator();

        for (int x = 0; x < hec.size(); x++) {
            out[x] = (HemlEventMapPlotter) li.next();
        }

        return out;
    }

    /*
     *
     **/
    private org.w3c.dom.Element svgErrorReport(Throwable t) {
        // the SVG element we will return
        org.w3c.dom.Element e;

        // the object that generates wrapped svg from a string
        WrappingSvgText wst = new WrappingSvgText();

        // the string to be returned
        String out;

        //Avex's have a user-friendly error report
        if (t instanceof AvailabilityException) {
            out = t.toString();
        }
        // other exceptions, etc. put us in deep water.
        // we therefore format the complete stack trace.
        else {
            java.io.StringWriter sw = new java.io.StringWriter();
            java.io.PrintWriter pw = new java.io.PrintWriter(sw, true);
            t.printStackTrace(pw);
            out = sw.toString();
        }

        e = wst.generate(out, 400, WrappingSvgText.LEFT, "Times", 10, 1f);
        e.setAttribute("id", "HEML_ERROR");

        return e;
    }
}
