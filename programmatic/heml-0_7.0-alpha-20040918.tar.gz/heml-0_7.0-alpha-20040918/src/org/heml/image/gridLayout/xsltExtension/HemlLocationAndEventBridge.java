/*
************************************************************** 
* $RCSfile: HemlLocationAndEventBridge.java,v $                     *
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2004/09/08 17:45:24 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.gridLayout.xsltExtension;

import java.awt.*;

import java.util.Date;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;

import org.apache.xerces.dom.*;

import org.heml.chronology.format.*;

import org.heml.image.gridLayout.*;
import org.heml.image.hemlEvent.*;
import org.heml.image.text.WrappingSvgText;

import org.jdom.Element;
import org.jdom.Namespace;

import org.w3c.dom.*;

/***
 * Bridge between the XSLT stylesheets and the grid placement classes.  Allows for the plotting of joint
 * location and event text.
 **/
public class HemlLocationAndEventBridge
{
    private static float ADVANCE = 0.85f;
    protected CylindricalEquidistantMapDefinition mapster;
    protected String fontName;
    protected Color  locationLabelColor, eventLabelColor;
    private int startingFontSize;
    private String lang, country, calendar;
    private final boolean VERBOSE = false; // output level for debugging purposes
    private final boolean DEBUG   = false; // debug grid output

    /**
     * Constructs and Initializes a <code>HemlLocationAndEventBridge</code> based upon the input parameters.  
     * @param map the map upon which the location labels are to be written
     * @param fontName the name of the location label's font
     * @param startingFontSize the initial desired size of font for printing on map
     * @param lang the language of input text labels
     * @param country the originating country
     * @param calendar the original calendar
     **/
    public HemlLocationAndEventBridge(CylindricalEquidistantMapDefinition map, 
                              String fontName, int startingFontSize, String lang, String country, String calendar, String locationLabelColorString, String eventLabelColorString)
    {
        this.mapster = map;
        this.fontName = fontName;
		this.lang = lang;
		this.country = country;
		this.calendar = calendar;
          try {
            this.locationLabelColor = Color.decode(locationLabelColorString);
            this.eventLabelColor = Color.decode(eventLabelColorString);
            }
          catch (Exception e) {
          System.out.println("error processing color " + locationLabelColorString + " or " + eventLabelColorString + ": " + e);
            this.locationLabelColor = Color.cyan;
            this.eventLabelColor    = Color.cyan;
          }
		// debugging code
		if (VERBOSE){
			System.out.println("fontName: " + fontName);
		}
		this.startingFontSize = startingFontSize;
    }

    /**
     * Generates an SVG object that includes the plotted location and event labels
     * @param node includes the information about the events and locations to be plotted
     * @return an SVG element including the plotted labels
     **/
    public org.w3c.dom.Element generateSvg(Node node)
    {
        org.jdom.Element el;
        HemlEventCollection hemlEventCollection = new HemlEventCollection();
        org.jdom.Element wrapper = org.heml.util.JdomUtils.convertToJdomElement((org.w3c.dom.Element)node);
        java.util.Iterator itr = wrapper.getChildren().iterator();

        // collect required information from dom for each event
        int foo = 0;
		//make location labels for every heml:Location element. Omit heml:LocationRef s
        while (itr.hasNext())
        {
            el = (org.jdom.Element)itr.next();
            org.jdom.Element locationEl = el.getChild("Location", el.getNamespace());
            // debugging code
            if (VERBOSE){
            	System.out.println("New Location el: " + locationEl.toString());
	    		System.out.println("fromLocationRef? " + locationEl.getAttributeValue("fromLocationRef"));
	    	}
	    	//don't use != "true" somehow null seems to get by that one
            if (locationEl.getAttributeValue("fromLocationRef") == null){
            	if (VERBOSE){
                	System.out.println("There is a location element");
                }

                HemlEventMapPlotter hemp = new HemlEventMapPlotterForLocation(el, this.mapster);
                hemp.setTextColor(locationLabelColor);
		  		hemp.setShapeColor(java.awt.Color.magenta);
                if (hemp.getText() != null && hemp.getLabel() != null)
                {
                    hemlEventCollection.add(hemp);
                    //test the WithText variant
                    //hemlEventCollection.add(new HemlEventMapPlotterForEventAndChronology(el, this.mapster));
                }
                else {if (VERBOSE) System.out.println("getText() returns: " + hemp.getText());}

                foo++;
            }
            else
            {
                //System.out.println("Hey, no Location element");
            }
        }

        itr = wrapper.getChildren().iterator();
		//make event labels for every event
		HemlEventMapPlotterForEventAndChronology hempec;
        while (itr.hasNext())
        {
            el = (org.jdom.Element)itr.next();
	    	hempec = new  HemlEventMapPlotterForEventAndChronology(el, this.mapster, lang, country, calendar);
	    	hempec.setTextColor(eventLabelColor);
            hemlEventCollection.add(hempec);
        }

        Document domFactory = new DocumentImpl();
        SVGGraphics2D svggen = new SVGGraphics2D(domFactory);

        // try to paint the labels to the map.  If unsuccessful, print out error report
        try
        {
            paintLoop(svggen, hemlEventCollection, fontName, startingFontSize, 3);
        }
        catch (Throwable t)
        {

            return svgErrorReport(t);
        }

        return svggen.getTopLevelGroup();
    }

    /**
     * Attempts to paint the labels to the map via <code>paint</code> method.  
     * If unsuccessful, will try successively smaller font sizes
     * until the labels are plotted or the font size is minimum.
     * @param graphics
     * @param hemlEventCollection the heml events requiring painting
     * @param fontName the name of the font in which the labels are to be written
     * @param startFontSize the original font size to try painting with
     * @param minFontSize the minimum font size to try painting with
     * @throws AvailabilityException if the labels would not fit onto the map
     * @throws GridException if the labels began outside the bounds of the subsequent <code>Grid</code>
     * @throws EmptyStringException if a label to be painted was empty
     **/
    public void paintLoop(Graphics graphics, 
                          HemlEventCollection hemlEventCollection, 
                          String fontName, int startFontSize, int minFontSize)
                   throws AvailabilityException, GridException, 
                          EmptyStringException
    {

        try
        {
        	if (VERBOSE){
            	System.out.println("Trying to paint at : " + startFontSize);
            }
            paint(graphics, hemlEventCollection, fontName, startFontSize);
        }
        catch (AvailabilityException avEx)
        {

            if (startFontSize == minFontSize)
            {
                throw avEx;
            }
            else
            {
                paintLoop(graphics, hemlEventCollection, fontName, startFontSize - 1, minFontSize);
            }
        }
    }

    /**
     * Paints the reqired heml event and location labels to the map if possible.
     * @param graphics
     * @param hemlEventCollection
     * @param fontName
     * @param fontSize
     * @throws AvailabilityException
     * @throws GridException
     * @throws EmptyStringException
     **/
    public void paint(Graphics graphics, 
                      HemlEventCollection hemlEventCollection, String fontName, 
                      int fontSize)
               throws AvailabilityException, GridException, 
                      EmptyStringException
    {
        float columnWidth = 4f; // width of point's oval + 1 to avoid overlap
        org.apache.batik.svggen.SVGGraphics2D g2 = (org.apache.batik.svggen.SVGGraphics2D)graphics;
        java.awt.Font font = new java.awt.Font(fontName, java.awt.Font.PLAIN, 
                                               fontSize);
        WrappingSvgText wst = new WrappingSvgText(g2);
        g2.setFont(font);

        HemlEventMapPlotter[] current;
        Composite c_alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .2f);
        Composite c_black = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .99f);

        // plot all points on grid before plotting on map in case of AvEx
        current = toHemlEventMapPlotter(hemlEventCollection);

        //current = hemlEventCollection;
        GridBuilder gb = new GridBuilder(columnWidth, 1.3f, font, ADVANCE, g2, current, this.mapster);
        gb.processLocations();
       
        // if no AvEx thrown, plot all points
        //draw each of the labels and locations
        for (int i = 0; i < current.length; i++)
        {
            if (current[i].isPlotted())
            {
                org.w3c.dom.Element previousTop = g2.getTopLevelGroup();
                g2.setStroke(new java.awt.BasicStroke((float)fontSize / 17f));
                g2.setColor(current[i].getTextColor());
                g2.setComposite(c_black);
                
                // debugging code
                if (VERBOSE){
                	System.out.println("Drawing String: " + current[i].getText());
                	System.out.print("x: " + current[i].getRect().getX());
                	System.out.print(" y: " + current[i].getRect().getY());
                	System.out.println(" width: " + current[i].getRect().getWidth());
            	}

                //draw label, beginning at the recommended starting point
                if (current[i].isWrapped())
                {
                    wst.setColor(current[i].getTextColor());
                    float dummy = wst.print(current[i].getText(), 
                                            (float)current[i].getRect().getWidth(), 
                                            current[i].getJustification(), 
                                            fontName, fontSize, ADVANCE, 
                                            (float)current[i].getRect().getX(), 
                                            (float)current[i].getRect().getY() + 
                                            (fontSize / 4));              
                }
                else{
                    g2.drawString(current[i].getText(), 
                                  (float)current[i].getRect().getX(), 
                                  ((float)current[i].getRect().getY() + fontSize));
                }

                g2.setComposite(c_alpha);
                // you can also getShapeColor, but I'm trying to use same 
                // color for text and shape
                g2.setColor(current[i].getTextColor());
                System.out.println("I'm drawing a shape");
                //draw the location shape specified
                g2.fill(current[i].getShape());
                g2.setComposite(c_black);
                g2.setColor(current[i].getTextColor());
               	g2.draw(current[i].getShape());
                if (current[i] instanceof HemlEventMapPlotterForLocation) {
                   //System.out.println("Its a location");
                   //g2.setColor(Color.green);
                   //g2.draw(current[i].getRect());
                } 	
               	// draw text rectangle (for debugging purposes)
               	if (DEBUG){
         			g2.setColor(Color.green);
         			// if right justified and wrapped, need to adjust x,y coordinates of rectangle
            		if (current[i].getJustification().equals("RIGHT") && current[i].isWrapped()){
               	  		current[i].getRect().x = current[i].getRect().x-current[i].getRect().width;
             		}
            		g2.draw(current[i].getRect());
            	} 
            	
            	// draw line if necessary
				g2.setColor(current[i].getTextColor());
                if (current[i].getLine() != null)
                {
                    g2.draw(current[i].getLine());
                    if (VERBOSE){
		    			System.out.println(current[i].getLine().toString());
		    			System.out.println("has color: " + current[i].getTextColor().toString());
		    		}
                }
                else {
                	if (VERBOSE){
			 			System.out.println("No line: " + current[i].getText());
			 		}
				}
				
				// draw Grid overlay and base points for testing purposes
				if (DEBUG){
					if (i == current.length-2){
						g2.setColor(Color.red);
						gb.drawGrid("horizontal");
						g2.setColor(Color.green);
						gb.drawBaseCells();
					}
				}	
				
                org.w3c.dom.Element newTop = g2.getTopLevelGroup();
                newTop.setAttribute("id", current[i].getId());
                previousTop.appendChild(newTop);
                g2.setTopLevelGroup(previousTop);
            }
        }
    }

    /*
     *
     **/
    public HemlEventMapPlotter[] toHemlEventMapPlotter(HemlEventCollection hec)
    {

        HemlEventMapPlotter[] out = new HemlEventMapPlotter[hec.size()];
        java.util.ListIterator li = hec.listIterator();

        for (int x = 0; x < hec.size(); x++)
        {
            out[x] = (HemlEventMapPlotter)li.next();
        }

        return out;
    }

    /*
     *
     **/
    private org.w3c.dom.Element svgErrorReport(Throwable t)
    {

        // the SVG element we will return
        org.w3c.dom.Element e;

        // the object that generates wrapped svg from a string
        WrappingSvgText wst = new WrappingSvgText();

        // the string to be returned
        String out;

        //Avex's have a user-friendly error report
        if (t instanceof AvailabilityException)
        {
            out = t.toString();
        }

        // other exceptions, etc. put us in deep water.
        // we therefore format the complete stack trace.
        else
        {

            java.io.StringWriter sw = new java.io.StringWriter();
            java.io.PrintWriter pw = new java.io.PrintWriter(sw, true);
            t.printStackTrace(pw);
            out = sw.toString();

            //System.out.println(sw);
        }

        e = wst.generate(out, 400, WrappingSvgText.LEFT, "Times", 10, 1f);
        e.setAttribute("id", "HEML_ERROR");

        return e;
    }
}
// end HemlLocationAndEventBridge
