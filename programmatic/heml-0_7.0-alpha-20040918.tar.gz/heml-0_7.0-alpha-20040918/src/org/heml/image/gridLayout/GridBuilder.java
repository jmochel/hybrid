/*
************************************************************** 
* $RCSfile: GridBuilder.java,v $                             *
*                                                            *
* $Revision: 1.19 $                                           *
*                                                            *
* $Date: 2004/01/06 15:15:12 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.gridLayout;

import org.heml.image.text.WrappingSvgText;
import org.heml.image.hemlEvent.HemlEventMapPlotter;
import org.heml.image.hemlEvent.HemlEventWithText;
import org.heml.image.hemlEvent.LocationException;


/***
 * Creates a <code>Grid</code> based upon input values and processes placement of label locations.
 * Sets the <code>rectangle</code> in <code>HemlEventMapPlotter</code> to calculated label location.
 **/
public class GridBuilder {
    private final int FULL = 0; // constant variables for cell state
    private final int FREE = 1; // constant variables for cell state
    private final int CELL_PADDING = 0; // the number of cells required to prevent label run-ins (keep at zero for now)
    private final boolean VERBOSE = false; // level of output for debugging purposes

    // class variables to hold constructor's input parameters
    private java.awt.Font font; // current font
    private float advance;
    private java.awt.Graphics graphics;
    private HemlEventMapPlotter[] data; // data to be input and changed for output
    private float width; // width and height of the input map  
    private float height; // width and height of the input map  
    private float rows; // corresponding rows and columns for the grid
    private float columns; // corresponding rows and columns for the grid
    private float columnWidth; // variables for calculation of rows and columns with respect to map size
    private float coefficientForRowSize; // variables for calculation of rows and columns with respect to map size
    private Grid g;
    java.awt.geom.Point2D.Float[] base_array; // for testing purposes, holds all base points in cell coordinates.

    /*** 
     * Constructs and Initializes a <code>GridBuilder</code> based upon the input parameters. 
     * @param columnWidth the desired width of a single column in the grid
     * @param coefficientForRowSize determines the height of a row
     * @param font the font of the text to be placed
     * @param advance the desired advance
     * @param graphics the graphics object for drawing
     * @param array the data to be plotted
     * @param mapData information about the map data is to be plotted onto 
     * @throws GridException if the label plotting went beyond the boundaries of the <code>Grid</code>.
     * @throws AvailabilityException if the labels will not fit onto the current <code>Grid</code>.
     * @throws EmptyStringException if a label is empty.
     **/
    public GridBuilder(float columnWidth, float coefficientForRowSize, 
                       java.awt.Font font, float advance, 
                       java.awt.Graphics graphics, HemlEventMapPlotter[] array, 
                       CylindricalEquidistantMapDefinition mapData)
                throws GridException, AvailabilityException, 
                       EmptyStringException {
        this.width = mapData.mapWidth;
        this.height = mapData.mapHeight;
        this.columnWidth = columnWidth;
        this.font = font;
        this.advance = advance;
        this.graphics = graphics;
        this.coefficientForRowSize = coefficientForRowSize;
        this.data = array;
        base_array = new java.awt.geom.Point2D.Float[data.length];// initialize testing base_array
        createGrid(); // create the grid for cell searching
    }

    /*** 
     * Builds a <code>Grid</code> based on the class input parameters.  <code>Grid</code> dimensions are based
     * upon <code>graphic</code>'s height and width as well as selected <code>columnWidth</code>, <code>font<code>
     * size and a <code>coefficientForRowSize</code>.  Each label's location is then plotted on this <code>Grid g</code>
     * as an area covered by a shape or a 'point' depending upon the size of the shape.
     * @throws GridException if plotting labels requires the use of <code>Cell</code>'s outside of this <code>Grid g</code>.
     **/
    private void createGrid() throws GridException {
        // determine how many rows there will be in the grid
        // If mod!=0, last row will be amalgamated with last-1, because the grid is in integer values.
        rows = (int) Math.floor(
                       height / ((font.getSize()) * coefficientForRowSize));

        // determine how many columns there will be in the grid.
        // if mod!=0, last column will be amalgamated with column last-1.
        columns = (int) Math.floor(width / columnWidth);

        // create the new grid
        this.g = new Grid((int) rows, (int) columns);

        // plot all valid points onto grid
        for (int i = 0; i < data.length; i++) {
            try {
                plotPoint(data[i].getShape(), data[i].getBase());
                // set point in array for testing purposes
            	base_array[i] = data[i].getBase();
            }
            // if mapException is thrown (ie point is not within the bounds of the grid), set boolean plotted to false
             catch (MapException e) {
                data[i].setPlotted(false);
            }
            // if LocationRefException is thrown, this point cannot be plotted because we don't have the pertinent information
             catch (LocationException e){
             	data[i].setPlotted(false);
             }
        } // end for data.length
    }

    /**
     * Determines the best coordinates for each input event label and adds a <code>rectangle</code> to the <code>HemlEventMapPlotter
     * </code> for each of these event labels.  This <code>rectangle</code> represents the coordinates of the event label placement
     * in pixels.
     * @throws GridException if the label plotting went beyond the boundaries of the <code>Grid</code>.
     * @throws AvailabilityException if the labels will not fit onto the current <code>Grid</code>.
     * @throws EmptyStringException if a label is empty.     
     **/
    public void processEvents() 
    			throws GridException, AvailabilityException, EmptyStringException {
    	processLabels("event");
    }
    
    /** 
     * Determines the best coordinates for each input location label and adds a <code>rectangle</code> to the 
     * <code>HemlEventMapPlotter</code> for each of these location labels.  This <code>rectangle</code> represents the coordinates
     * of the location label placement in pixels.
     * @throws GridException if the label plotting went beyond the boundaries of the <code>Grid</code>.
     * @throws AvailabilityException if the labels will not fit onto the current <code>Grid</code>.
     * @throws EmptyStringException if a label is empty.
     **/
    public void processLocations() 
    			throws GridException, AvailabilityException, EmptyStringException {
    	processLabels("location");
    }	
    
    /** 
     * Determines the best coordinates for each input text string and adds a <code>rectangle</code> to the 
     * <code>HemlEventMapPlotter</code> for each of these text strings.  This <code>rectangle</code> represents the coordinates
     * of the text string placement in pixels.
     * @throws GridException if the string plotting went beyond the boundaries of the <code>Grid</code>.
     * @throws AvailabilityException if the labels will not fit onto the current <code>Grid</code>.
     * @throws EmptyStringException if a label is empty.
     **/
    public void processString() 
    			throws GridException, AvailabilityException, EmptyStringException {
    	processLabels("string");
    }

    /*** 
     * Plots location for each label.  To do this, it:
     * <ul>
     *  <li> determines how many <code>Cell</code>s on the <code>Grid</code> would be needed to accommodate the location's label
     *  <li> calculates the location shape's position on the <code>Grid</code>
     *  <li> determine text wrapping information
     *  <li> creates a <code>rectangle</code> in pixel coordinates and places it in the <code>LabelAndLocation</code> array. 
	 * </ul>
	 * @param labelType the labels to be plotted
	 *   <ul>
	 *      <li> "event" if the heml event's event labels are to be plotted
	 *      <li> "location" if the heml event's location labels are to be plotted
	 *		<li> "string" if a string other than just the heml event's label or location are to be plotted
	 *   </ul>
	 * @throws GridException if plotting labels requires the use of <code>Cell</code>'s outside of this <code>Grid g</code>. 
	 * @throws AvailabilityException if the labels will not fit onto <code>Grid</code>.
	 * @throws EmptyStringException if the label or string text is empty.
     **/
    private void processLabels(String labelType) throws GridException, 
                                                AvailabilityException, 
                                                EmptyStringException {
        int cellsRequired=0;
        float wrapHeight=0f;
        java.awt.geom.Rectangle2D.Float rect; // variable to hold new data that will be added to to_calculate
        StringMeasurer sm = new StringMeasurer(font.getName(), font.getSize(), 
                                               graphics);
        WrappingSvgText wrapInfo = new WrappingSvgText();
        Grid.Cell[] found; // array holding cells for label location
        Grid.Cell cell; // base cell for searching
        GridSearcher find; // superclass reference

        // for all of the plotted objects in the array, calculate label location
        for (int i = 0; i < data.length; i++) {
            if (data[i].isPlotted()) {
				// determine how many cells the label requires
                cellsRequired = (int) Math.ceil(sm.getWidth(data[i].getText()) / this.columnWidth);            	
            	// debugging script
            	if (VERBOSE){
		    		System.out.println("Measuring text:\n" + data[i].getText());
					System.out.println((float) sm.getWidth(data[i].getText()));
                	System.out.println(" ");
                	System.out.print("Searching for " + data[i].getText() + ": ");
					System.out.println("column width: " + this.columnWidth + " cells required: " + cellsRequired);
				}
                // cells required should be greater than zero
                if (cellsRequired <= 0) {
                    throw new EmptyStringException(
                            "String length zero, which is not allowed");
                }

                find = new GridSearcher(this.g);

                // determine wrapping information
                	wrapHeight = wrapInfo.getHeight(data[i].getText(), 
                                                       this.width / 4, "LEFT", 
                                                       this.font.getFontName(), 
                                                       this.font.getSize(), 
                                                       this.advance);

                
                // calculate wrapHeight with respect to grid
                float gridWrapHeight = wrapHeight / (font.getSize() * this.coefficientForRowSize);
                try {
                	cell = getCell((float) data[i].getBase().getX(), 
                               	   (float) data[i].getBase().getY());
                }
                catch (LocationException e){ cell = null; } // will be caught previously, so no need to deal with here
                
                try {
                    found = find.getLabelCells((cellsRequired+CELL_PADDING), cell, 
                                               gridWrapHeight);
                }
                // if there are no more available cells, and the search has not been completed
                 catch (AvailabilityException e) {
                    e.setData(i, font.getSize(), (int) rows, (int) columns);
                    throw e;
                }
                rect = createRect(found, wrapHeight);


                // set required LabelAndLocation information
                data[i].setRect(rect);
                data[i].setJustification(find.justification);
                // only check if line is required if rectangle does not actually intersect with shape
                if (!data[i].getRect()
                            .intersects(data[i].getShape().getBounds2D())) {
                    setLine(data[i], find.justification);
                } else {
                    data[i].setLine(null);
                }

                data[i].setWrapped(isWrapped(found));
            } // end if plotted
        } // end for i
    }

    /** 
     * Plots a point on the grid. Small point coordinates or shapes that are sufficiently small
     * are set to FULL indicating that this area cannot be overwritten.
     * @param shape is the area covering the associated label.
     * @param base is the centre point of the input shape (ie the starting point of associated label).
     * @throws GridException if plotting labels requires the use of <code>Cell</code>'s outside of this <code>Grid g</code>.
     * @throws MapException if point to be plotted is outside the boundaries of the <code>Grid</code>.
     **/
    private void plotPoint(java.awt.Shape shape, 
                           java.awt.geom.Point2D.Float base)
                    throws GridException, MapException {
        // if base point lies outside of map bounds, throw MapException
        if ((base.getX() < 0) || (base.getY() < 0) || 
                (base.getX() > this.width) || (base.getY() > this.height)) {
            throw new MapException();
        }
        
        // set base point to FULL
		g.setState(getCell((float) base.getX(), (float) base.getY()), FULL);
        
        java.awt.geom.Rectangle2D bounds = shape.getBounds2D();

        // if shape's height or width is < one font, set entire shape to full, else set point to full
        /* currently causing problems with the grid, so out for now
        if ((bounds.getHeight() <= font.getSize()) || (bounds.getWidth() <= font.getSize())) {
            for (int w = 0; w <= bounds.getWidth(); w++) {
                for (int h = 0; h <= bounds.getHeight(); h++) {
                    g.setState(getCell((float) (bounds.getX() + w), (float) (bounds.getY() + h)), FULL);
                }
            }
        } 
        else {
            g.setState(getCell((float) base.getX(), (float) base.getY()), FULL);
        }
        */
    }

    /*** 
     * Calculates the pixel x and y coordinates of a <code>Cell</code>.  
     * <br>NOTE: some precision may be lost as the original pixel values were floats 
     * and the cell storage is integer.  The smaller the <code>columnWidth</code> 
     * and <code>fontSize</code>, the greater the precision.
     * @param c the <code>Cell</code> to be converted to pixel coordinates.
     * @return the pixel coordinates of the input <code>Cell</code>.
     **/
    private java.awt.geom.Point2D.Float getPixels(Grid.Cell c) {
        float x;
        float y;

        // calculate x coordinate
        x = (float) c.column * this.columnWidth;

        // calculate y coordinate
        y = (float) c.row * (font.getSize() * this.coefficientForRowSize);

        return new java.awt.geom.Point2D.Float(x, y);
    }

    /*** 
     * Calculates the row and column coordinates for the <code>Grid</code>, 
     * from corresponding input pixel coordinates.
     * @param x the x pixel coordinate
     * @param y the y pixel coordinate
     * @return the <code>Cell</code> representing the <code>Grid</code> coordinates of the input pixels.
     * @throws Grid Exception if plotting labels requires the use of <code>Cell</code>'s outside of this <code>Grid g</code>. 
     **/
    private Grid.Cell getCell(float x, float y) throws GridException {
        Grid.Cell c;

        // calculate cell column
        float xCol = x / this.columnWidth;

        // calculate cell row
        float yRow = y / (font.getSize() * this.coefficientForRowSize);

        // create corresponding Grid.Cell
        // if there is an exception, it is possibly caused by the pixel coordinate lying within
        // one of the grid gutters
        try {
            c = g.cellFactory((int)Math.floor(yRow), (int)Math.floor(xCol));

            return c;
        }
        // deal with points in the gutter areas at the bottom and right of the grid
         catch (GridException e) {
            // deals with points in the gutter row at bottom of grid
            if (((int) yRow == rows) && ((int) xCol < columns)) {
                c = g.cellFactory((int) yRow - 1, (int) xCol);

                return c;
            }
            // deals with points in the gutter column at the right of the grid
            else if (((int) yRow < rows) && ((int) xCol == columns)) {
                c = g.cellFactory((int) yRow, (int) xCol - 1);

                return c;
            }
            // deals with points that lie in gutter cell at the bottom right corner of the grid
            else if (((int) yRow == rows) && ((int) xCol == columns)) {
                c = g.cellFactory((int) yRow - 1, (int) xCol - 1);

                return c;
            } else {
                throw e; // throw e if requested cell is definitely outside of grid bounds
            }
        } // end catch GridException e
    }

    /*** 
     * Creates a <code>rectangle</code> that represents the area the label may be produced in.  The
     * coordinates are in pixels and relative to an upper left corner of (0,0).
     * @param c an <code>array</code> of <code>Cell</code>s representing the area on the <code>Grid</code> that contains the label.
     * @param wrapHeight represents the height of the text to indicate depth of text wrapping.
     * @return a <code> rectangle representing the placement of the label in pixels.
     **/
    private java.awt.geom.Rectangle2D.Float createRect(Grid.Cell[] c, float wrapHeight) {
        float x;
        float y;
        float height;
        float width;
        int counter = 0;

        // calculate width; if wrapped, set to wrapping width
        if (c[0].row != c[c.length - 1].row) {
            width = this.width / 4;
        } 
        else {
            width = c.length * this.columnWidth;
            
        }
        
        // calculate height
        height = wrapHeight;

        // calculate x coordinate
        // if not wrapped and left, needs to be set to last cell in the array
        if ((c[0].row == c[c.length - 1].row) && (c[0].column > c[c.length - 1].column)) {
            x = getPixels(c[c.length - 1]).x;
        } else {
            x = getPixels(c[0]).x;
        }

        // calculate y coordinate
        y = getPixels(c[0]).y;

        return new java.awt.geom.Rectangle2D.Float(x, y, width, height);
    }

    /***
     * Sets the coordinates of line between base point of event location and label placement, if necessary.
     * @param he the information for the current label and <code>rectangle</code>.
     **/
    private void setLine(HemlEventMapPlotter he, String justification) {
        java.awt.geom.Rectangle2D.Float textRect = new java.awt.geom.Rectangle2D.Float();
        java.awt.geom.Point2D.Float base;
        java.awt.geom.Point2D.Float endPoint;
        java.awt.geom.Line2D.Float line;
        
        try {
        	base = he.getBase();
        }
        catch (LocationException e){ base = null; } // will be caught previously, so no need to deal with here

        textRect.setRect(he.getRect().x, he.getRect().y, he.getRect().width, he.getRect().height);
        
        // set end point x coordinate to closest x point on rectangle to base
		endPoint = getClosestPoint(textRect, base, justification);
		
		line = new java.awt.geom.Line2D.Float(base, endPoint);

		// if line is less than 10 pixels, not required
        //BGR: it seems lines are needed all the time
	//if (endPoint.distance(line.x1, line.y1, line.x2, line.y2) > 10) {
            he.setLine(line);
        //} else {
        //    he.setLine(null);
        //}
    }
    
    /**
     * Determines closest point on input rectangle to input point.
     * @param rect the <code>Rectangle</code> to find a point on
     * @param point the <code>Point</code> to check distance against
     * @return the point on the <code>Rectangle</code> closest in distance to the <code>Point</code>
     **/
     private java.awt.geom.Point2D.Float getClosestPoint (java.awt.geom.Rectangle2D.Float rect, 
     		java.awt.geom.Point2D.Float point, String justification){
     	java.awt.geom.Point2D.Float closest = new java.awt.geom.Point2D.Float();
     	float y_alt = 0f;
     	
     	
     	// determine best x coordinate
     	// if the point lies somewhere along the x-axis, then the point's x coordinate is the closest possible x
     	if ( ((point.x > rect.x) && (point.x < (rect.x + rect.width)) &&  justification.equals("LEFT")) ||
     		 ((point.x < rect.x) && (point.x > (rect.x - rect.width)) &&  justification.equals("RIGHT")) ){
     		closest.x = point.x;
     	}
     	// if not, determine closest end point of rectangle to x coordinate of point
     	else if ( Math.abs(point.x - rect.x) <= Math.abs(point.x - (rect.x + rect.width)) ){
     		closest.x = rect.x;
     	}
     	else{
     		closest.x = rect.x + rect.width;
     	}
     	
     	// determine best y coordinate
     	// if the point lies somewhere along the y-axis, then the point's y coordinate is the closest possible y
     	if ( (point.y > rect.y) && (point.y < (rect.y + rect.height)) ){
     		closest.y = point.y;
     	}
     	// if not, determine closest end point of the rectangle to the y coordinate of point
     	else if ( Math.abs(point.y - rect.y) <= Math.abs(point.y - (rect.y + rect.height)) ){
     		closest.y = rect.y;
     	}
     	else{
     		closest.y = rect.y + rect.height;
     	}

     	return (closest);
     }

    	
    /**
     * Returns information about label's text wrapping.
     * @param c is an <code>Array</code> containing the <code>Cell</code>s over which the label is written.
     * @return true if the label has been wrapped; false otherwise.
     **/
    private boolean isWrapped(Grid.Cell[] c) {
        return (c[0].row != c[c.length - 1].row);
    }
    
    
    /**
     * Draws the Grid for plotting over the current map
     * <i>For testing purposes only </i>
     * @param toDraw string determining what to draw.
     * <ul>
     *    <li><code>horizontal</code> - draws horizontal lines of <code>Grid</code> only
     *    <li><code>vertical</code> - draws vertical lines of <code>Grid</code> only
     *    <li><code>all</code> - draws horizontal and vertical lines of <code>Grid</code>
     * </ul>
     */
     public void drawGrid(String toDraw){
     	int i;
     	
     	// draw all horizontal lines
     	if (toDraw.equals("all") || toDraw.equals("horizontal")){	
     		for (i = 0; i <= this.rows; i++){
     			this.graphics.drawLine(0, (int) Math.floor((i+1)*this.font.getSize()*coefficientForRowSize), 
     							   	(int)(this.columns*this.columnWidth),
     							   	(int) Math.floor((i+1)*this.font.getSize()*coefficientForRowSize));
     		}	
     	}	
     	// draw all vertical lines
     	if (toDraw.equals("all") || toDraw.equals("vertical")){
     		for (i = 0; i < this.columns; i++){
 	    		this.graphics.drawLine((int) Math.floor((i+1)*this.columnWidth), 0, 
 	    						   	   (int) Math.floor((i+1)*this.columnWidth), 
 	    						   	   (int) Math.floor(this.rows*this.font.getSize()*coefficientForRowSize));
     		}
     	}
     }
     
     
    /**
     * Draws the base search points in <code>Cell</code> coordinates
     * <i>For testing purposes only</i>
     */
     public void drawBaseCells(){
     	int i;
     	Grid.Cell current;

     	for (i = 0; i < base_array.length; i++){
     		try{
     			if (base_array[i]!=null){
     				current = getCell((float) base_array[i].getX(), (float) base_array[i].getY());
					this.graphics.drawRect((int)Math.floor(current.column*columnWidth),
					                       (int)Math.floor(current.row*this.font.getSize()*coefficientForRowSize),
					                       (int)Math.floor(width/columns),
					                       (int)Math.floor(height/rows));
				}
			}
			// not expecting any grid exceptions, so nothing to be done here.
			catch(GridException ge){}	
		}
	} 
    
} // end GridBuilder class

