/*
************************************************************** 
* $RCSfile: EmptyStringException.java,v $                                     *
*                                                            *
* $Revision: 1.4 $                                       *
*                                                            *
* $Date: 2002/11/03 17:15:43 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson brucerob@mta.ca                        *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************* 
*/
package org.heml.image.gridLayout;

/***
 * Signals that a label to be plotted on the <code>Grid</code> is empty.
 **/
public class EmptyStringException extends Exception {
	/***
     * Constructs an <code>EmptyStringException</code> without a detail message.
     **/
    public EmptyStringException() {
        super();
    }

    /**
	 * Constructs an <code>EmptyStringException</code> with the specified detail message. 
	 * The error message can later be retrieved by the <code>getMessage()</code> method.
	 * @param message the detail message.
	 */
    public EmptyStringException(String message) {
        super(message);
    }
}