/*
 ************************************************************** 
 * $RCSfile: CylindricalEquidistantMapDefinition.java,v $     *
 *                                                            *
 * $Revision: 1.10 $                                           *
 *                                                            *
 * $Date: 2002/12/06 14:21:25 $                               *
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Susan Barnett                                          *
 *     Bruce Robertson                                        *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 ************************************************************** 
 */
package org.heml.image.gridLayout;

/***
 * Stores relationship between latitude/longitude and x,y coordinates for a cylindrical equidistant map.
 **/
public class CylindricalEquidistantMapDefinition {
    public float yBottomLeft;
    public float yTopRight;
    public float xBottomLeft;
    public float xTopRight;
    public float latBottomLeft;
    public float latTopRight;
    public float longBottomLeft;
    public float longTopRight;
    public float yOffset = 0;
    public float xOffset = 0;
    public float mapHeight; // in pixels
    public float mapWidth; // in pixels

    /** 
     * Constructs and Initializes a <code>CylindricalEquidistantMapDefinition</code> based upon the input parameters.
     * @param yBottomLeft the y-coordinate of the bottom left corner of the map
     * @param yTopRight the y-coordinate of the top right corner of the map
     * @param xBottomLeft the x-coordinate of the bottom left corner of the map
     * @param xTopRight the x-coordinate of the top right corner of the map
     * @param latBottomLeft the latitude of the bottom left corner of the map
     * @param latTopRight the latitude of the top right corner of the map
     * @param longBottomLeft the longitude of the bottom left corner of the map
     * @param longTopRight the longitude of the top right corner of the map
     * @param yOffset the y-coordinate offset
     * @param xOffset the x-coordinate offset
     * @param mapWidth the map width in pixels
     * @param mapHeight the map height in pixels
     **/
    public CylindricalEquidistantMapDefinition(float yBottomLeft, 
                                               float yTopRight, 
                                               float xBottomLeft, 
                                               float xTopRight, 
                                               float latBottomLeft, 
                                               float latTopRight, 
                                               float longBottomLeft, 
                                               float longTopRight, 
                                               float yOffset, float xOffset, 
                                               float mapWidth, 
                                               float mapHeight) {
        this.yBottomLeft = yBottomLeft;
        this.yTopRight = yTopRight;
        this.xBottomLeft = xBottomLeft;
        this.xTopRight = xTopRight;
        this.latBottomLeft = latBottomLeft;
        this.latTopRight = latTopRight;
        this.longBottomLeft = longBottomLeft;
        this.longTopRight = longTopRight;
        this.yOffset = yOffset;
        this.xOffset = xOffset;
        this.mapWidth = mapWidth;
        this.mapHeight = mapHeight;
    }

    /***
     * Provides a report containing information on each of the parameters in this <code>CylindricalEquidistantMapDefinition</code>.
     */
    public void report() {
        System.out.println("this.yBottomLeft =" + yBottomLeft);
        System.out.println("this.yTopRight =" + yTopRight);
        System.out.println("this.xBottomLeft = " + xBottomLeft);
        System.out.println("this.xTopRight = " + xTopRight);
        System.out.println("this.latBottomLeft = " + latBottomLeft);
        System.out.println("this.latTopRight = " + latTopRight);
        System.out.println("this.longBottomLeft = " + longBottomLeft);
        System.out.println("this.longTopRight = " + longTopRight);
        System.out.println("this.yOffset = " + yOffset);
        System.out.println("this.xOffset = " + xOffset);
        System.out.println("this.mapWidth = " + mapWidth);
        System.out.println("this.mapHeight = " + mapHeight);
    }

    /**
     * Translates a latitude coordinate on this cylindrical equidistant map to relative y-coordinate.
     * @param latitude the latitude to be translated into y-coordinate.
     * @return the corresponding y-coordinate for the input latitude.
     **/
    public float latitudeToY(MapCoordinate latitude) {
        float single_latitude;

        // if hour is negative, minutes and seconds should also be treated as negative
        if (latitude.hours < 0f) {
            latitude.minutes *= -1f;
            latitude.seconds *= -1f;
        }

        single_latitude = latitude.hours + (latitude.minutes / 60f) + 
                          (latitude.seconds / 3600f);

        return (this.yOffset + this.yBottomLeft - 
               ((single_latitude - this.latBottomLeft) / (this.latTopRight - this.latBottomLeft) * (this.yBottomLeft - this.yTopRight)));
    }

    /**
     * Translates a longitude coordinate on this cylindrical equidistant map to relative x-coordinate.
     * @param longitude the longitude to be translated into x-coordinate.
     * @return the corresponding x-coordinate for the input longitude.
     **/
    public float longitudeToX(MapCoordinate longitude) {
        float single_longitude;

        // if hours is negative, minutes and seconds should also be treated as negative
        if (longitude.hours < 0f) {
            longitude.minutes *= -1f;
            longitude.seconds *= -1f;
        }

        single_longitude = longitude.hours + (longitude.minutes / 60f) + 
                           (longitude.seconds / 3600f);

        return (this.xOffset + this.xBottomLeft + 
               ((single_longitude - this.longBottomLeft) / (this.longTopRight - this.longBottomLeft) * (this.xTopRight - this.xBottomLeft)));
    }
}