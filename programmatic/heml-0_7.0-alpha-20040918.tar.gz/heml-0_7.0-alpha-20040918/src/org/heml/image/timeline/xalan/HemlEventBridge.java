package org.heml.image.timeline.xalan;

import java.awt.*;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;

import org.apache.xerces.dom.*;

import org.heml.chronology.format.*;

import org.heml.image.hemlEvent.*;
import org.heml.image.text.WrappingSvgText;
import org.heml.image.timeline.SimpleSvgTimeline;

import org.jdom.Element;
import org.jdom.Namespace;

import org.w3c.dom.*;


public class HemlEventBridge {
    java.util.Locale locale;
    String dateString;
    String type;
    String calendar;
    String fontName;
    int labelFontSize;
    int boundsFontSize;
    HemlTimelineCollection eventCollection;

    public HemlEventBridge(String requestLang, String country, String calendar, 
                           String fontName, int labelFontSize, 
                           int boundsFontSize) {
        this.locale = new java.util.Locale(requestLang, country);
        this.calendar = calendar;
        this.dateString = "G yyyy";
        eventCollection = new HemlTimelineCollection();
        this.fontName = fontName;
        this.labelFontSize = labelFontSize;
        this.boundsFontSize = boundsFontSize;
    }

    public void addEvent(org.w3c.dom.Node node, String link) {
        org.jdom.Element wrapper = org.heml.util.JdomUtils.convertToJdomElement(
                                           (org.w3c.dom.Element) node);
        HemlEventWithLink he = new HemlEventWithLink(wrapper, link);
        eventCollection.add(he);
    }

    public org.w3c.dom.Element generateSvg() {
        java.util.ArrayList eventLists = new java.util.ArrayList();
        java.util.ArrayList eventCollectionList;


        // slice collection into subcollections with respect to chronological concurrency
        eventCollectionList = eventCollection.getSliced();

        SimpleSvgTimeline timeline = new SimpleSvgTimeline(locale, calendar, 
                                                           dateString, fontName, 
                                                           labelFontSize, 
                                                           boundsFontSize, 
                                                           eventCollectionList);

        return timeline.getSvg();
    }
}
