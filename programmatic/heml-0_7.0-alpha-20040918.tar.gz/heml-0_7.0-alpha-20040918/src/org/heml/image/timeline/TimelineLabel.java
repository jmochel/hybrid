/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineLabel.java,v $   
*                                                            *
* $Revision: 1.19 $ 
*                                                            *
* $Date: 2003/03/21 13:19:53 $  
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.font.*;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.*;

import java.text.*;

//import com.sun.awt.svg.*;
import org.apache.batik.svggen.*;

import org.heml.image.text.WrappingSvgText;

import org.w3c.dom.*;


/**
 * Represents the positioned label for an event on a timeline. To be
 * distinguished from a <code>TimelineMarker</code>.
 */
public class TimelineLabel extends TimelinePart {
    private static final boolean VERBOSE = false;
    private static final float ADVANCE = 0.8f;
    public static WrappingSvgText svgTextWrapper = new WrappingSvgText();
    java.lang.String myString;
    int oldOffset;
    int newOffset;

    public TimelineLabel(long time, String text) {
        super(time, text);
        setFont(new java.awt.Font("Arial Unicode MS", java.awt.Font.PLAIN, 13)); //default
        setTimelineLineStyle(new TimelineLineStyle(java.awt.Color.black, 2));
    }

    public TimelineLabel(long time, String text, String link) {
        super(time, text);
        setFont(new java.awt.Font("Arial Unicode MS", java.awt.Font.PLAIN, 13)); //default
        setTimelineLineStyle(new TimelineLineStyle(java.awt.Color.blue, 2));
        this.setLink(link);
    }

    public TimelineLabel(long time, long endTime, String text, String link) {
        super(time, endTime, text);
        setFont(new java.awt.Font("Arial Unicode MS", java.awt.Font.PLAIN, 13)); //default
        setTimelineLineStyle(new TimelineLineStyle(java.awt.Color.blue, 1.6f));
        this.setLink(link);
    }

    public void drawPart(Graphics2D g2, Point2D pointAtLineStart, 
                         Point2D pointAtLineEnd, Point2D endPointAtLine, 
                         Point2D pointAtLabel, float width, boolean connected) {
        lineStyle.drawPart(g2, 
                           new Line2D.Float(pointAtLineStart, pointAtLineEnd));
        drawPart(g2, pointAtLineStart, pointAtLineEnd, pointAtLabel, width);
    }

    public void drawPart(Graphics2D g2, java.awt.geom.Point2D pointAtLineStart, 
                         java.awt.geom.Point2D pointAtLineEnd, 
                         java.awt.geom.Point2D pointAtLabel, float width) {
        java.awt.geom.Point2D midpoint = new java.awt.geom.Point2D.Float(
                                                 (float) pointAtLineStart.getX(), 
                                                 (float) pointAtLineStart.getY() + 
                                                 (((float) pointAtLineEnd.getY() - (float) pointAtLineStart.getY()) / 2f));
        boolean markIsDot = true;
        g2.setColor(java.awt.Color.blue);
        // this event should be represented by a vertical line with two
        // circles on the ends
        if ((pointAtLineEnd.getY() - pointAtLineStart.getY()) > 5) {
            g2.draw(new java.awt.geom.Ellipse2D.Float(
                            (float) (pointAtLineStart.getX() - 1.5), 
                            (float) (pointAtLineStart.getY() - 2.5f), 3f, 3f));

            g2.draw(new java.awt.geom.Ellipse2D.Float(
                            (float) (pointAtLineEnd.getX() - 1.5), 
                            (float) pointAtLineEnd.getY(), 3f, 3f));
            
             lineStyle.drawPart(g2,
                           new java.awt.geom.Line2D.Float(pointAtLineStart,
                                                           pointAtLineEnd));
             markIsDot = false; 
       } else {
            g2.draw(new java.awt.geom.Ellipse2D.Float(
                            (float) pointAtLineStart.getX(), 
                            (float) pointAtLineStart.getY(), 3f, 3f));
        }
                 // Draw a line joining the line to the label if the two 
        // are offset from each other 
        if (midpoint.getY() != pointAtLabel.getY()) {
            float connectingLineHorizontalOffset = 0;
            float connectingLineVerticalOffset = 0;
            if (markIsDot) { 
              connectingLineHorizontalOffset = 3f;
              connectingLineVerticalOffset = 2.7f;
             }
            java.awt.geom.Point2D.Float drawnPointAtLine =
              new java.awt.geom.Point2D.Float((float) (midpoint.getX()+connectingLineHorizontalOffset), (float) (midpoint.getY() + connectingLineVerticalOffset));

                   lineStyle.drawPart(g2,
                               new java.awt.geom.Line2D.Float(drawnPointAtLine,
                                                              pointAtLabel));
        }
        // If this is an SVG document we are printing, then wrap the label with 
        // a link to its url
        if (g2 instanceof org.apache.batik.svggen.SVGGraphics2D && 
               (this.link != null)) {
            SVGGraphics2D svggen = (SVGGraphics2D) g2;
            //Element previousTop = svggen.getTopLevelGroup();
            printCenteredAt((float) pointAtLabel.getX(), 
                            (float) pointAtLabel.getY(), width, g2);
            /*Document factory = svggen.getDOMFactory();
            Element a = factory.createElementNS("http://www.w3.org/2000/svg", "a");
            Element rect = factory.createElementNS("http://www.w3.org/2000/svg","rect");
             previousTop.appendChild(a);
            svggen.setTopLevelGroup(previousTop);
            Element newTop = svggen.getTopLevelGroup();
            Element wrapped = wrapWithLink(newTop, this.link, svggen);
            previousTop.appendChild(wrapped);
            svggen.setTopLevelGroup(previousTop);
            */
        }
        // otherwise, this is a non-SVG document, and the url is not used.    
        else {
            printCenteredAt((float) pointAtLabel.getX(), 
                            (float) pointAtLabel.getY(), width, g2);
        }
    }

    public float getHeight(float width, Graphics2D g2) {
        svgTextWrapper.setGraphics((org.apache.batik.svggen.SVGGraphics2D) g2);

        //System.out.println("TimelineLabel.getHeight(): calling on text: " + text);
        return svgTextWrapper.getHeight(text, width, WrappingSvgText.LEFT, 
                                        font.getFontName(), font.getSize(), 
                                        ADVANCE);
    }

    public void printCenteredAt(float x, float y, float width, Graphics2D g) {
        svgTextWrapper.setGraphics((org.apache.batik.svggen.SVGGraphics2D) g);

        String wrappingJustification;

        if (this.justification == TimelinePart.LEFT) {
            wrappingJustification = svgTextWrapper.LEFT;
        } else if (this.justification == TimelinePart.CENTER) {
            wrappingJustification = svgTextWrapper.CENTER;
        } else {
            wrappingJustification = svgTextWrapper.RIGHT;
        }

        float thisHeight = svgTextWrapper.getHeight(text, width, 
                                                    wrappingJustification, 
                                                    font.getFontName(), 
                                                    font.getSize(), ADVANCE);

        //System.out.println("Acc. to printCenteredAt the height is: " + thisHeight);
        float centeredY = y - (thisHeight / 2f) + 
                          ((float) font.getSize() / 4f);
        svgTextWrapper.print(text, width, wrappingJustification, 
                             font.getFontName(), font.getSize(), ADVANCE, x, 
                             centeredY, this.link);
    }

    /**********
      * Returns the element wrapped with an <code>xml:link</code>
      * tag.
      */
    private Element wrapWithLink(Element element, String link, 
                                 SVGGraphics2D svggen) {
        Document myDocument = svggen.getDOMFactory();
        Element a = myDocument.createElementNS("http://www.w3.org/2000/svg", 
                                               "svg:a");

        if (VERBOSE) {
            System.out.println("Adding a link to svg: " + this.link);
        }

        a.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", 
                         this.link);

        a.appendChild(element);

        return a;

        //to stop links being added so that the 
        //resulting svg can be converted to pdf by the buggy 
        //fop.
        //return element;
    }

    /***
     * Some old test code. See {@link SimpleSvgTimeline} instead.
     *
                
    public static void main(String[] args) {
                  
       Frame frame = new org.heml.util.ApplicationFrame("Testing TimelineLabel"){
    TimelineLabel tll = new TimelineLabel (TimelineScale.yearInSeconds*10, "A start is born!");
               TimelineLabel tl2 = new TimelineLabel(TimelineScale.yearInSeconds*15, "Adolescence");
               TimelineLabel tl3 = new TimelineLabel(TimelineScale.yearInSeconds*25, "Frisky");
               TimelineLabel tl4 = new TimelineLabel(TimelineScale.yearInSeconds*4, "Phoebe's Age");
               public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
               g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON);
                  
               tll.drawPart(g2);
               tl2.drawPart(g2);
               tl3.drawPart(g2);
               tl4.drawPart(g2);
           }
           };
       frame.setVisible(true);
    }
    */
}
