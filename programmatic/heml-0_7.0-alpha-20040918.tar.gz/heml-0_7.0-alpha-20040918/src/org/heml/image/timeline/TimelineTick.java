/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineTick.java,v $                                                  *
*                                                            *
* $Revision: 1.7 $                                                 *
*                                                            *
* $Date: 2002/10/17 23:31:18 $                                                     *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.AlphaComposite;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;

import org.heml.image.timeline.TimelinePart;


/**
 * Represents a mark, or 'tick' which crosses the timeline and has no
 *  Associated text or label. This is probably used to mark the scale of the 
 * timeline.
 * 
 * 
 */
public class TimelineTick extends TimelineLabel {
    private float timelineWidth;

    public TimelineTick(long time, String text, float timelineWidth) {
        super(time, text);
        this.timelineWidth = timelineWidth;
    }

    public TimelineTick(long time, long endTime, String text, String link, 
                        float timelineWidth) {
        super(time, endTime, text, link);
        this.timelineWidth = timelineWidth;
    }

    public TimelineTick(long time, String text, String link, 
                        float timelineWidth) {
        super(time, text, link);
        this.timelineWidth = timelineWidth;
    }

    public void drawPart(Graphics2D g2, java.awt.geom.Point2D pointAtLineStart, 
                         java.awt.geom.Point2D pointAtLineEnd, 
                         java.awt.geom.Point2D pointAtLabel, float width) {
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 
                                                   0.1f));

        java.awt.geom.Line2D horizontalLine = new java.awt.geom.Line2D.Float(width + 5f, 
                                                                             (float) pointAtLineStart.getY(), 
                                                                             timelineWidth, 
                                                                             (float) pointAtLineStart.getY());
        lineStyle.drawPart(g2, horizontalLine);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 
                                                   0.5f));
        printCenteredAt(width, (float) pointAtLabel.getY(), width, g2);
    }
}