/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineScale.java,v $               
*                                                            *
* $Revision: 1.4 $                                       *
*                                                            *
* $Date: 2002/10/17 23:31:18 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

/**
 * This represents the scale of the timeline in cm and equivalent 
 * <code>time</code> which is a (big) quantity of miliseconds produced 
 * by some <code>getTime</code> method.
 * <p>
 * Ideally, we'd be able to change this and the <code>TimelineGenerator</code>
 * would be a listener and would redraw itself.
 * <p>
 * We'll probably need to provide a <code>getOptimumTimelineScale</code>
 *  factory method in the Generator and an <code>ImpossibleTimelineScale</code>
 * exception.
 */
public class TimelineScale {
    final static float pixelsPerCm = 72f / 2.2f; // are there 2.2 cm in an inch?
    final static long yearInSeconds = 31536000000L;
    private final static boolean VERBOSE = false;
    long seconds;
    float cm;

    public TimelineScale(long seconds, int cm) {
        this.seconds = seconds;
        this.cm = (float) cm;
    }

    public TimelineScale(long milliseconds, float pixels) {
        this.seconds = milliseconds;

        this.cm = pixels / pixelsPerCm;
    }

    public float givePixelsForTime(long secondsIn) {
        float cmPerSeconds = (cm / (float) seconds);
        float location = (float) secondsIn * cmPerSeconds * pixelsPerCm;

        if (VERBOSE) {
            System.out.println("Location is: " + location);
        }

        return location;
    }

    public String toString() {
        return givePixelsForTime(yearInSeconds) + "pixels per year";
    }

    /**
     * Contains some test code.
     */
    public static void main(String[] args) {
        int cms = java.lang.Integer.parseInt(args[0]);
        float yearsPer = 1f / (float) cms;
        TimelineScale scale = new TimelineScale(yearInSeconds, 
                                                java.lang.Integer.parseInt(
                                                        args[0]));
        System.out.println("On scale of " + yearsPer + "Yr/cm");
        System.out.println("2 years = " + 
                           scale.givePixelsForTime(yearInSeconds * 2) + 
                           " pixels");
    }
}