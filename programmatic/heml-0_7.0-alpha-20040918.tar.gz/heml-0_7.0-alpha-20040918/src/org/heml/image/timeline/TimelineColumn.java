/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineColumn.java,v $                          *
*                                                            *
* $Revision: 1.13 $                                           *
*                                                            *
* $Date: 2004/05/05 11:27:46 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;


/**
 * Represents a column of possibly quite different timeline parts 
 * for use in a vertically-oriented timline and renders them
 * in such a way as their texts do not collide.
 *
 * 
 * 
 */
public class TimelineColumn
{

    private final static boolean VERBOSE = false;
    TimedObjectCollection collection;
    float nextFreeY = 0;
    TimelineScale scale;
    float startY;
    long startTime;
    float endY;
    long endTime;
    float startX;
    float endX;
    float lineLength; //the drawn line, not line of text
    private float width;
    private float textWidth;

    public TimelineColumn(TimedObjectCollection collection, 
                          TimelineScale scale, float startY, long startTime, 
                          float endY, long endTime, float startX, float endX, 
                          float lineLength)
    {
        this.collection = collection;
        this.scale = scale;
        this.startY = startY;
        this.startTime = startTime;
        this.endY = endY;
        this.endTime = endTime;
        this.startX = startX;
        this.endX = endX;
        this.lineLength = lineLength;
        this.width = Math.abs(endX - startX);
        this.textWidth = width - lineLength;

        if (VERBOSE)
        {
            System.out.println("My width is: " + this.width);
        }
    }

    /***
     * Provides the scale at which this column renders most appropriately
     ***/
    public TimelineScale getPreferredScale()
    {

        return scale;
    }

    public void setScale(TimelineScale scale)
    {
        this.scale = scale;
    }

    public void setStartTime(long startTime)
    {
        this.startTime = startTime;
    }

    public void setEndTime(long endTime)
    {
        this.endTime = endTime;
    }

    public void draw(Graphics2D g2)
    {

        TimelineColumnBadness dummy = draw(g2, true);
    }

    public TimelineColumnBadness draw(Graphics2D g2, boolean forReal)
    {

        float baseLine;
        float comfortSpace;
        nextFreeY = startY;

        int badnessFactor = 0;
        Timed[] myParts = collection.giveSortedArray();
        Point2D.Float pointAtLabel;

        for (int i = 0; i < myParts.length; i++)
        {

            if (VERBOSE)
            {
                System.out.println(
                        "myParts length: " + myParts.length + 
                        " and this is " + i + " whose time is " + 
                        myParts[i].giveTime());
            }

            float optimumStartPosition = timeToPosition(myParts[i].giveTime());
            float optimumEndPosition = timeToPosition(myParts[i].getEndTime());

            if (VERBOSE)
            {
                System.out.println(
                        "optimum position is: " + optimumStartPosition);
                System.out.println("next Free y is: " + nextFreeY);
            }

            Point2D.Float pointAtLineStart = new Point2D.Float(startX, 
                                                               optimumStartPosition);
            Point2D.Float pointAtLineEnd = new Point2D.Float(startX, 
                                                             optimumEndPosition);
            float midpoint = optimumStartPosition + 
                             ((optimumEndPosition - optimumStartPosition) / 2);
            float textStart = midpoint - 
                              (myParts[i].getHeight(width, g2) / 2f);

            if ((textStart >= nextFreeY) || (i == 0))
            {

                if (VERBOSE)
                {
                    System.out.println("opt. greater than nextFreeY");
                }

                pointAtLabel = new Point2D.Float(startX + lineLength, midpoint);
                nextFreeY = midpoint + 
                            (myParts[i].getHeight(width, g2) / 2f) + 
                            myParts[i].getLeading(g2);
            }
            else
            {

                // :NOTE: dangerous, first call could bump up against ArrayOutOfBounds
                // exception.
                baseLine = nextFreeY + 
                           (myParts[i].getHeight(width, g2) / 2f);
                pointAtLabel = new Point2D.Float(startX + lineLength, baseLine);
                nextFreeY = baseLine + 
                            (myParts[i].getHeight(width, g2) / 2f) + 
                            myParts[i].getLeading(g2);
            }

            if (forReal)
            {
                myParts[i].drawPart(g2, pointAtLineStart, pointAtLineEnd, 
                                    pointAtLabel, width);
            }

            //calculate badnessFactor
            badnessFactor += (int)(pointAtLabel.getY() - midpoint);
        }

        return new TimelineColumnBadness((int)(badnessFactor / myParts.length), 
                                         scale);
    }

    public float timeToPosition(long time)
    {

        return scale.givePixelsForTime(time - startTime) + startY;
    }
}
