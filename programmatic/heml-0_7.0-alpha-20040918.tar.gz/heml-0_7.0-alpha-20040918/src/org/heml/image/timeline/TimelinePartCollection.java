/*
**************************************************************
*                                                            * 
* $RCSfile: TimelinePartCollection.java,v $                                                  *
*                                                            *
* $Revision: 1.4 $                                                 *
*                                                            *
* $Date: 2002/10/17 23:31:18 $                                                     *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.util.Vector;


/**
* A place to put and sort associated timeline parts.
* For instance, a group of timeline Labels which will share
* the same x position should be put in this and sorted
* so they can be drawn together.
* <p>
* Another example is the tics that mark the scale of the timeline.
* <p>
* this may need to be an abstract with specific parts' collections
* subclassed, since (I think) we need to cast them when we return them
* though it might be possible to cast an array.
*/
public class TimelinePartCollection extends TimedObjectCollection {
    public TimelinePartCollection() {
        super();
    }

    public void addObject(TimelinePart part) {
        collection.add(part);
    }

    public void addAll(TimelinePartCollection otherCollection) {
        collection.addAll((java.util.Collection) otherCollection.collection);
    }

    /*
    public TimelinePart[] giveSortedArray() {
                    
    Timed[] myParts = super.giveSortedArray();//in order now, at least.
    TimelinePart[] myArray = new TimelinePart[myParts.length];
    for (int x =0; x<array.length; x++) {
     myArray[x] = (TimelinePart) timedArray[x];
     }
    return myArray;
    }
    */

    // This code
    public void setTimelineLineStyle(TimelineLineStyle lineStyle) {
        TimelinePart[] mine = getMyArray();
        java.util.Vector myNewCollection = new java.util.Vector();

        for (int x = 0; x < mine.length; x++) {
            mine[x].setTimelineLineStyle(lineStyle);
            myNewCollection.add(mine[x]);
        }

        collection = myNewCollection;
    }

    public void setFont(java.awt.Font font) {
        TimelinePart[] mine = getMyArray();
        java.util.Vector myNewCollection = new java.util.Vector();

        for (int x = 0; x < mine.length; x++) {
            mine[x].setFont(font);
            myNewCollection.add(mine[x]);
        }

        collection = myNewCollection;
    }

    public void setJustification(int justification) {
        TimelinePart[] mine = getMyArray();
        java.util.Vector myNewCollection = new java.util.Vector();

        for (int x = 0; x < mine.length; x++) {
            mine[x].setJustification(justification);
            myNewCollection.add(mine[x]);
        }

        collection = myNewCollection;
    }

    public void setColor(java.awt.Color color) {
        TimelinePart[] mine = getMyArray();
        java.util.Vector myNewCollection = new java.util.Vector();

        for (int x = 0; x < mine.length; x++) {
            mine[x].setColor(color);
            myNewCollection.add(mine[x]);
        }

        collection = myNewCollection;
    }

    private TimelinePart[] getMyArray() {
        Timed[] myParts = super.giveSortedArray(); //in order now, at least.
        TimelinePart[] myArray = new TimelinePart[myParts.length];

        for (int x = 0; x < myArray.length; x++) {
            myArray[x] = (TimelinePart) myParts[x];
        }

        return myArray;
    }
}