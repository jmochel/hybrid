/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineColumnBadness.java,v $                          *
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2004/05/05 11:26:45 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

public class TimelineColumnBadness
{

    //Represents just how awful this is from 1 to 100
    int badnessFactor;
    TimelineScale originalScale;
    private static boolean VERBOSE = false;

    public TimelineColumnBadness(int badnessFactor, 
                                 TimelineScale originalScale)
    {
        this.badnessFactor = badnessFactor;
        this.originalScale = originalScale;
    }

    /***
     * A rough estimate of a scale that would better suit the circumstances.
     **/
    public TimelineScale getBetterScale()
    {

        if (badnessFactor <= 20)
        {

            return originalScale;
        }
        else
        {

            float pixels = originalScale.givePixelsForTime(
                                   TimelineScale.yearInSeconds);

            if (VERBOSE)
                System.out.println(
                        "original scale had " + pixels + " pixels per year");

            return new TimelineScale(TimelineScale.yearInSeconds, 
                                     (pixels * (float)badnessFactor) / 20f);
        }
    }

    /***
     * Returns the badnessFactor for this instance.
     **/
    public int getBadnessFactor()
    {

        return badnessFactor;
    }

    public String toString()
    {

        return "badness factor: " + badnessFactor + " on scale of " + 
               originalScale.toString();
    }
}