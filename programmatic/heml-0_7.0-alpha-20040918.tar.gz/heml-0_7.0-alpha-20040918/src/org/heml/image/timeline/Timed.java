/*
**************************************************************
*                                                            * 
* $RCSfile: Timed.java,v $                      
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2002/10/17 23:31:18 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.Graphics2D;


/***
 * Interface implemented by any part of a timeline that can report its 
 *<code>time</code> value ?(and can be drawn).
 */
public interface Timed {
    /*** The milliseconds before/after (computer's) epoch at which this
     * <code>Timed</code> object <i>begins</i> on the timeline. Should be
     * called <code>getTime</code>, I think.
     */
    abstract long giveTime();

    /*** The milliseconds before/after (computer's) epoch at which this
     * <code>Timed</code> object <i>ends</i> on the timeline. 
     */
    abstract long getEndTime();

    /*** The <code>Graphics2D</code> drawing routine for this object. The
     * object that collects this <code>Timed</code> and others, typically in a
     * column with <code>TimelineColumn</code>, passes a point to which it is
     * to refer on the timeline and a point at which it is to start drawing its
     * label.
     * 
     * <p> The latter may well not be aligned with the former because the code
     * that collects and renders these objects together in columns or rows may
     * need to jostle them around.  The two locations are passed as points
     * becuase they need not represent a line.  a 'dog-legged' line from the
     * timeline to the label is, for instance, a nice way to associate point
     * with label.
            
     * Should probably be called <code>draw</code> or
     * <code>paint</code> or something canonical
     */
    void drawPart(Graphics2D g2, java.awt.geom.Point2D atLineStart, 
                  java.awt.geom.Point2D atLineEnd, 
                  java.awt.geom.Point2D atLabel, float width);

    /***
     * Returns the height of this rendered object. 
     */
    abstract float getHeight(float width, Graphics2D g2);

    /*** 
     * Returns the leading of this rendered object. Leading is understood as
     * the amount of space needed around an object to make it comfortably
     * intellegible. Though based on the <code>FontMetrics</code> method of the
     * same name, it can, should and must be used for things like ticks and
     * other decorations.  <p> Note that the <code>FontMetrics</code> method in
     * some implementations always returns
     *<code>0.0</code>. In <code>TimelineLabel</code> I've therefore written my
     * own rough leading code as a fraction of the pt size of the font.
     */
    abstract float getLeading(Graphics2D g2);
}