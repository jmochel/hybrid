/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineLineStyle.java,v $                                                  *
*                                                            *
* $Revision: 1.2 $                                                 *
*                                                            *
* $Date: 2002/08/23 17:45:19 $                                                     *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D.*;


/**
 * Bundles together all the things needed to make a line. 
 */
public class TimelineLineStyle {
    final static float standardStrokeWidth = 2f;
    final static int standardCap = java.awt.BasicStroke.CAP_ROUND;
    final static int standardJoin = java.awt.BasicStroke.JOIN_ROUND;
    java.awt.Color color;
    java.awt.geom.Line2D line;
    java.awt.BasicStroke stroke;

    public TimelineLineStyle(java.awt.Color color, float width) {
        this.color = color;
        this.stroke = new java.awt.BasicStroke(width, standardCap, standardJoin);
    }

    /**
     * Class defaults to a standard stroke with <code>java.awt.BasicStroke.CAP_ROUND
     * </code> and <code>java.awt.BasicStroke.JOIN_ROUND</code> but alternatives can be 
     * set with this method.
     */
    public void setStroke(java.awt.BasicStroke stroke) {
        this.stroke = stroke;
    }

    public java.awt.BasicStroke getStroke() {
        return stroke;
    }

    public java.awt.Color getColor() {
        return color;
    }

    public void drawPart(java.awt.Graphics2D g2, java.awt.geom.Line2D line) {
        g2.setStroke(this.stroke);
        g2.setPaint(this.color);
        g2.draw(line);
    }

    public static void main(String[] args) {
        final TimelineLineStyle tlLine = new TimelineLineStyle(
                                                 java.awt.Color.blue, 12f);
        final java.awt.geom.Line2D aLine = new java.awt.geom.Line2D.Float(100f, 
                                                                          100f, 
                                                                          100f, 
                                                                          200f);
        System.out.println("Testing TimelineLineStyle: ");
        System.out.println("  Drawing line with color: " + tlLine.color);
        System.out.println("  stroke: " + tlLine.getStroke());
        System.out.println("  line: " + aLine);

        Frame frame = new org.heml.util.ApplicationFrame("Testing TimelineLine") {
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                tlLine.drawPart(g2, aLine);
            }
        };

        frame.setVisible(true);
    }
}