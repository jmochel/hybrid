/*
**************************************************************
*                                                            * 
* $RCSfile: TimelinePart.java,v $                                   
*                                                            *
* $Revision: 1.5 $                                    
*                                                            *
* $Date: 2002/10/17 23:31:18 $                          
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Graphics2D;
import java.awt.font.*;


/**
 * The superclass for all single-point timeline parts. (That excludes 
 * periods, which are made of two of these.)
 */
public abstract class TimelinePart implements Timed {
    public static int RIGHT = 1;
    public static int CENTER = 0; //bow to the spelling police
    public static int LEFT = -1; //default value
    java.awt.Font font;
    java.awt.Color color;
    long time; // Note: 'time' is the variable name used for the seconds from

    // or after epoch. A Date is something else.
    long endTime;
    String text;
    String link;
    TimelineLineStyle lineStyle;
    public int justification;

    public TimelinePart(long time, String text) {
        this.time = time;
        this.endTime = time;
        this.text = text;
        this.justification = LEFT; //default value
    }

    public TimelinePart(long time, long endTime, String text) {
        this.time = time;
        this.endTime = endTime;
        this.text = text;
        this.justification = LEFT;
    }

    public TimelinePart(long time, String text, TimelineLineStyle lineStyle) {
        this.time = time;
        this.endTime = time;
        this.text = text;
        this.lineStyle = lineStyle;
        this.justification = LEFT;
    }

    public TimelinePart(long time, long endTime, String text, 
                        TimelineLineStyle lineStyle) {
        this.time = time;
        this.text = text;
        this.lineStyle = lineStyle;
        this.justification = LEFT;
        this.endTime = endTime;
    }

    public abstract void drawPart(java.awt.Graphics2D g2, 
                                  java.awt.geom.Point2D pointAtLineStart, 
                                  java.awt.geom.Point2D pointAtLineEnd, 
                                  java.awt.geom.Point2D pointAtLabel, 
                                  float width);

    public void setFont(java.awt.Font font) {
        this.font = font;
    }

    public java.awt.Font getFont() {
        return this.font;
    }

    public void setColor(java.awt.Color color) {
        this.color = color;
    }

    public java.awt.Color getColor() {
        return this.color;
    }

    public float getLeading(Graphics2D g2) {
        g2.setFont(this.getFont());

        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = font.getLineMetrics(text, frc);

        if (lm.getLeading() == 0.0f) {
            return (this.getHeight(100f, g2) / 10f) + 3f;
        } else {
            return lm.getLeading() + 3f;
        }
    }

    public abstract float getHeight(float width, Graphics2D g2);

    public float getFontHeight(Graphics2D g2) {
        g2.setFont(this.getFont());

        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = font.getLineMetrics(text, frc);

        return lm.getHeight();
    }

    public void setLink(String link) {
        this.link = link;
    }

    public void setJustification(int justification) {
        if ((justification < LEFT) || (justification > RIGHT)) {
            //:NOTE: insert exception here
            System.out.println("I really should throw and exception here");
        } else {
            this.justification = justification;
        }
    }

    public long giveTime() {
        return this.time;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public TimelineLineStyle getLineStyle() {
        return this.lineStyle;
    }

    public void setTimelineLineStyle(TimelineLineStyle lineStyle) {
        this.lineStyle = lineStyle;
    }
}