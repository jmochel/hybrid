/*
**************************************************************
*                                                            * 
* $RCSfile: TimedObjectCollection.java,v $                                                  *
*                                                            *
* $Revision: 1.4 $                                                 *
*                                                            *
* $Date: 2002/10/17 23:31:18 $                                                     *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import java.awt.*;
import java.awt.Graphics2D;

import java.util.Vector;


/**
     * A place to put and sort associated timeline parts.
     * For instance, a group of Labels for a vertically-oriented timeline
     * which will share
     * the same x position should be put in this and sorted
     * so they can be drawn together. (This is what happens in <code>TimelineColumn</code>.
     * <p>
     * Another example is the tics that mark the scale of the timeline.
     */
public class TimedObjectCollection {
    java.util.Vector collection;

    public TimedObjectCollection() {
        this.collection = new Vector();
    }

    public void addObject(Timed timed) {
        collection.add(timed);
    }

    public void addAll(TimedObjectCollection otherCollection) {
        collection.addAll((java.util.Collection) otherCollection.collection);
    }

    /**
     * Returns an array of {@link Timed} objects sorted in order of their
     * <code>time</code> values. 
     * 
     * 
     */
    public Timed[] giveSortedArray() {
        Object[] array = collection.toArray();
        Timed[] timedArray = new Timed[array.length];

        for (int x = 0; x < array.length; x++) {
            timedArray[x] = (Timed) array[x];
        }

        TimedObjectComparator comparator = new TimedObjectComparator();
        java.util.Arrays.sort(timedArray, comparator);

        return timedArray;
    }

    public long earliestTime() {
        long currentTime;

        // :NOTE: should check for empty collection
        Timed aTimed = (Timed) collection.elementAt(0);

        long smallest = aTimed.giveTime();

        for (int x = 0; x < collection.size(); x++) {
            aTimed = (Timed) collection.elementAt(x);
            currentTime = aTimed.giveTime();

            if (currentTime < smallest) {
                smallest = currentTime;
            }
        }

        return smallest;
    }

    public long latestTime() {
        // :NOTE: should check for empty collection
        Timed aTimed = (Timed) collection.elementAt(0);
        long currentTime;
        long largest = aTimed.getEndTime();

        for (int x = 0; x < collection.size(); x++) {
            aTimed = (Timed) collection.elementAt(x);
            currentTime = aTimed.getEndTime();

            if (currentTime > largest) {
                largest = currentTime;
            }
        }

        return largest;
    }

    public static void main(String[] args) {
    }
}