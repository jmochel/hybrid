/*
 **************************************************************
 *                                                            *
 * $RCSfile: SimpleSvgTimeline.java,v $
 *                                                            *
 * $Revision: 1.26 $
 *                                                            *
 * $Date: 2004/09/08 17:45:25 $
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 *                                                            *
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            *
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 */
package org.heml.image.timeline;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.Graphics2D.*;
import java.awt.event.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.geom.Point2D;

import java.io.*;

import java.util.*;
import java.util.GregorianCalendar;

import javax.swing.*;

import org.apache.batik.dom.svg.SVGDOMImplementation;
import org.apache.batik.svggen.*;
import org.apache.batik.svggen.SVGGraphics2D;

import org.apache.xerces.dom.*;

import org.heml.chronology.parse.*;

import org.heml.image.hemlEvent.*;

import org.w3c.dom.*;
import org.w3c.dom.svg.*;


/**A basic timeline, whose configuration is mostly hard-coded or 
 * self-determined, rendered in SVG and entered through methods meant to 
 * be called from xslt extensions.
 */
public class SimpleSvgTimeline
{

    public static String CLASSPATH = "org.heml.chronology.parse.";
    static private TimelineLineStyle mainLine = new TimelineLineStyle(
                                                        java.awt.Color.green, 
                                                        5f);
    static private TimelineLineStyle timeTicks = new TimelineLineStyle(
                                                         java.awt.Color.blue, 
                                                         2f);
    static private float LINEX = 65f;
    static private float TITLEX = LINEX;
    static private float STARTINGY = 20f;
    static private float TITLEY = STARTINGY - 30;
    static private float MINIMALLENGTH = 400f;
    static private boolean VERBOSE = true;
    public TimelineScale defaultScale = new TimelineScale(
                                                TimelineScale.yearInSeconds * 2, 
                                                1);
    public TimelineColumn[] columns;

    //public TimelineColumn column2;
    private TimelinePartCollection[] collections;
    private float endingY;
    private String title = "";
    private TimelineLabel aLabel;
    public long startingTime;
    public long endingTime;
    public Locale locale;
    public String boundsCalendarType;
    public String boundsDateFormat;
    private java.awt.Font boundsFont;
    private java.awt.Font labelFont;
    private java.awt.Font titleFont = new java.awt.Font("trebuchet ms", 
                                                        java.awt.Font.ITALIC, 
                                                        16);
    private TimelineColumn timingColumn;
    private float columnWidth;
    private float timelineWidth = 800;
    private float timelineHeight = 1600;

    public SimpleSvgTimeline(Locale locale, String boundsCalendarType, 
                             String boundsDateFormat, String fontName, 
                             int labelFontSize, int boundsFontSize, 
                             java.util.ArrayList hemlEventCollections)
    {

        int numberOfColumns = hemlEventCollections.size();
        labelFont = new java.awt.Font(fontName, java.awt.Font.PLAIN, 
                                      labelFontSize);
        boundsFont = new java.awt.Font(fontName, java.awt.Font.PLAIN, 
                                       boundsFontSize);

        if (VERBOSE)
            System.out.println("number of columns is: " + numberOfColumns);

        columns = new TimelineColumn[numberOfColumns];
        this.locale = locale;
        this.boundsCalendarType = boundsCalendarType;
        this.boundsDateFormat = "G y"; //boundsDateFormat;
        this.collections = new TimelinePartCollection[numberOfColumns];

        for (int x = 0; x < numberOfColumns; x++)
        {
            collections[x] = new TimelinePartCollection();
        }

        // take each of the eventCollections we've been passed
        // add a label to the appropriate timelinepartcollection for each of them
        java.util.ListIterator li = hemlEventCollections.listIterator();
        int counter = 0;
        int eventCounter = 0;

        while (li.hasNext())
        {

            HemlTimelineCollection htc = (HemlTimelineCollection)li.next();
            java.util.ListIterator innerIterator = htc.listIterator();
            eventCounter = 0;

            while (innerIterator.hasNext())
            {

                HemlEventWithLink e = (HemlEventWithLink)innerIterator.next();

                //System.out.println(
                //        "EventCollections #" + counter + " event#" +
                //        eventCounter + " has value of: " + e.getLabel());
                addLabel(e.getLabel(), e.getEarliestTime(), e.getLatestTime(), 
                         e.getLink(), counter);
                eventCounter++;
            }

            counter++;
        }
    }

    /**
     * Adds an event label to the timeline. These can be included at 
     * any point in the proceedings.
     *
     */
    public void setTitle(String text)
    {
        this.title = text;
    }

    public void setFontName(String fontName)
    {
        this.boundsFont = new java.awt.Font(fontName, java.awt.Font.PLAIN, 16);
        this.labelFont = new java.awt.Font(fontName, java.awt.Font.PLAIN, 14);
    }

    public void addLabel(String text, String language, String country, 
                         String type, String aDateString, String aCalendar, 
                         String link, int columnNumber)
    {

        if (VERBOSE)
        {
            System.out.println("Registering Date: " + aDateString);
            System.out.println("  language: " + language);
            System.out.println("  country: " + country);
            System.out.println("  format: " + type);
            System.out.println("  calendar: " + aCalendar);
        }

        DateParser dp = getDateParser(type);
        dp.setString(aDateString);

        long time = dp.getEarliestTime();

        if (VERBOSE)
        {
            System.out.println("  correspoding time: " + time);
        }

        //avoid printing errors by making sure every text has *some*
        //content
        if (text == null)
        {
            text = " ";
        }

        collections[columnNumber].addObject(new TimelineLabel(time, text, link));
    }

    public void addLabel(String text, long time, String link, int columnNumber)
    {

        TimelineLabel tl = new TimelineLabel(time, text, link);

        //  System.out.println(
        //           "column number is: " + columnNumber +
        //           " the collection is: " + collections[columnNumber] +
        //           "\ntl is: " + tl);
        collections[columnNumber].addObject(tl);
    }

    public void addLabel(String text, long startTime, long endTime, 
                         String link, int columnNumber)
    {

        TimelineLabel tl = new TimelineLabel(startTime, endTime, text, link);

        //System.out.println("column number is: " + columnNumber);
        //System.out.println(
        //        "the collection is: " + collections[columnNumber] +
        //        "\ntl is: " + tl);
        collections[columnNumber].addObject(new TimelineLabel(startTime, 
                                                              endTime, text, 
                                                              link));
    }

    private DateParser getDateParser(String parserName)
    {

        DateParser year = new Year();
        String className = CLASSPATH + parserName;

        if (VERBOSE)
            System.out.println("Trying to load: " + className);

        try
        {

            Class foo = Class.forName(className);
            DateParser parser = (DateParser)foo.newInstance();

            return parser;
        }
        catch (Exception e)
        {

            return year;

            //System.exit(0);
        }
    }

    private long earliestTimeFromCollections()
    {

        long earliest = collections[0].earliestTime();

        for (int x = 1; x < collections.length; x++)
        {

            if (collections[x].earliestTime() < earliest)
            {
                earliest = collections[x].earliestTime();
            }
        }

        return earliest;
    }

    private long latestTimeFromCollections()
    {

        long latest = collections[0].latestTime();
        long thisLatest = latest;

        for (int x = 1; x < collections.length; x++)
        {
            thisLatest = collections[x].latestTime();

            if (thisLatest > latest)
            {
                latest = thisLatest;
            }
        }

        return latest;
    }

    public org.w3c.dom.Element getSvg()
    {

        long latestTime = latestTimeFromCollections();
        long earliestTime = earliestTimeFromCollections();

        // when there is only one event, these will be equal,
        // causing all sorts of hell to break loose. Spanning them out
        // a bit should help.
        boolean singleEventFlag = false;

        /*
        if (latestTime -  earliestTime < TimelineScale.yearInSeconds) {
          latestTime += TimelineScale.yearInSeconds;
          earliestTime -= TimelineScale.yearInSeconds;
          singleEventFlag = true;
          }
         */
        org.w3c.dom.Document theDoc = null;
        org.w3c.dom.Element dummy = null;

        //Get an SVG G2 env.
        DOMImplementation impl = SVGDOMImplementation.getDOMImplementation();
        String svgNS = SVGDOMImplementation.SVG_NAMESPACE_URI;
        SVGDocument doc = (SVGDocument)impl.createDocument(svgNS, "svg", null);
        SVGGeneratorContext ctx = SVGGeneratorContext.createDefault(doc);
        ctx.setEmbeddedFontsOn(true);

        SVGGraphics2D svggen = new SVGGraphics2D(ctx, false);

        /*
                Document      domFactory = new DocumentImpl();
                SVGGraphics2D svggen = new SVGGraphics2D(domFactory);
        */

        //Set alpha compositing
        svggen.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 
                                                       0.5f));
        svggen.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING, 
                                java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        svggen.setBackground(Color.white);

        String useCssStr = System.getProperty("useCss", "true");
        boolean useCss = useCssStr.equalsIgnoreCase("true"); //svggen.setSVGCanvasSize(new Dimension(800, 800));

        //        if (VERBOSE) {
        //  System.out.println("bounds.endTime(): " + bounds.endTime() +
        //                       " bounds.startTime() " + bounds.startTime());
        // }
        this.defaultScale = new TimelineScale(latestTime - earliestTime, 
                                              MINIMALLENGTH);

        /*    if (singleEventFlag) {
              defaultScale = new TimelineScale(TimelineScale.yearInSeconds *2, 1);
             } */
        endingY = STARTINGY + 
                  defaultScale.givePixelsForTime(latestTime - earliestTime);

        if (VERBOSE)
        {
            System.out.println("Scale is: " + defaultScale.toString());
            System.out.println("Ending y: " + endingY);
        }

        //how wide should each column be?
        float fixedColumnWidth = 550f / (float)columns.length;

        if (fixedColumnWidth > 100f)
        {
            columnWidth = fixedColumnWidth;
        }
        else
        {
            columnWidth = 120f;
        }

        timelineWidth = (50f + columnWidth) * (float)columns.length + 50f;

        float nonTimingColumnsOffset = 20f;

        //Now iterate through the columns to find the best 'scale'
        //for each of them
        for (int x = 0; x < columns.length; x++)
        {
            collections[x].setFont(labelFont);
            columns[x] = new TimelineColumn(collections[x], defaultScale, 
                                            STARTINGY, earliestTime, 200000, 
                                            latestTime, 
                                            LINEX + (columnWidth * x) + 
                                            nonTimingColumnsOffset, 
                                            (LINEX + 
                                                (columnWidth * (x + 1)) + 
                                                nonTimingColumnsOffset) - 
                                            20f, 10f);
        }

        //find the largest necessary scale, using defaultScale as a floor
        TimelineScale biggestScale = defaultScale;

        for (int x = 0; x < columns.length; x++)
        {

            //this is a bogus initialization to set up the
            //following loop
            TimelineColumnBadness badness = new TimelineColumnBadness(100, 
                                                                      biggestScale);
            int counter = 0;

            while ((badness.getBadnessFactor() > 20) && (counter < 5))
            {
                columns[x].setScale(biggestScale);
                badness = columns[x].draw(svggen, false);

                if (VERBOSE)
                    System.out.println(
                            "Badness calc. iteration #" + counter + 
                            "\nBadness " + badness.toString());

                biggestScale = badness.getBetterScale();

                if (VERBOSE)
                    System.out.println(
                            "better scale: " + biggestScale.toString());

                counter++;
            }
        }

        //set all columns to have the scale that is the largest any
        //of them needs
        for (int x = 0; x < columns.length; x++)
        {
            columns[x].setScale(biggestScale);
        }

        //Get the bounds, based on the scale calculated above
        TimelineBoundsGenerator bounds = new TimelineBoundsGenerator(
                                                 earliestTime, latestTime, 
                                                 biggestScale, timelineWidth, 
                                                 locale, locale.getLanguage(), 
                                                 boundsDateFormat, 
                                                 boundsCalendarType, 
                                                 boundsFont);

        if (VERBOSE)
            System.out.println(
                    "after bounds generator...\nbounds.startTime(): " + 
                    bounds.startTime() + "\nbounds.endTime(): " + 
                    bounds.endTime());

        TimelinePartCollection startAndStop = bounds.getBounds();
        startAndStop.setJustification(TimelinePart.RIGHT);
        timingColumn = new TimelineColumn(startAndStop, biggestScale, 
                                          STARTINGY, bounds.startTime(), 
                                          200000, bounds.endTime(), LINEX, 
                                          LINEX - 75f, -10f);

        // calculate the height of the timeline based on the info in the
        //   timing column, adding a bit for good measure
        timelineHeight = timingColumn.timeToPosition(bounds.endTime()) + 
                         50f;

        if (VERBOSE)
        {
            System.out.println(
                    "Timeline dimension is px: " + timelineWidth + " x " + 
                    timelineHeight);
        }

        // Now that bounds has decided on a best start and end point, feed
        //   this back into the columns
        for (int x = 0; x < columns.length; x++)
        {
            columns[x].setStartTime(bounds.startTime());
            columns[x].setEndTime(bounds.endTime());
        }

        this.paint(svggen);
        svggen.setSVGCanvasSize(new Dimension((int)timelineWidth, 
                                              (int)timelineHeight));

        org.w3c.dom.Element root = svggen.getRoot();

        return root;
    }

    private void drawTitle(Graphics2D g2)
    {
        g2.setFont(titleFont);

        // trust me...
        java.awt.FontMetrics fm = g2.getFontMetrics();
        java.awt.geom.Rectangle2D.Float bounds = (java.awt.geom.Rectangle2D.Float)fm.getStringBounds(
                                                         title, g2);
        float width = bounds.width;
        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = titleFont.getLineMetrics(title, frc);
        float offset = lm.getAscent() / 2;

        if (VERBOSE)
        {
            System.out.println("Offset: " + offset);
        }

        float newY = TITLEY + offset;

        //g2.setPaint(this.color);
        float x = TITLEX - (width / 2f);
        g2.drawString(title, x, newY);

        /*
           java.awt.AlphaComposite transparent = java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC_OVER, 0.3f);
           g2.setComposite(transparent);
           g2.drawString("Dynamically generated today", x, newY+29);
         */
    }

    public Dimension getPreferredSize()
    {

        return new Dimension(800, 800);
    }

    public void paint(Graphics g)
    {

        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                            RenderingHints.VALUE_ANTIALIAS_ON);
        drawTitle(g2);

        //mainLine.drawPart(g2,
        //                  new java.awt.geom.Line2D.Float(LINEX, STARTINGY,
        //                                                 LINEX, endingY));
        timingColumn.draw(g2);

        for (int x = 0; x < columns.length; x++)
        {
            columns[x].draw(g2);
        }
    }

    public static void main(String[] args)
                     throws IOException
    {

        /*
           if (args.length < 1) {
               System.out.println("Please provide a filename for svg output");
               System.exit(0);
           }
                                   
           String fileName = args[0];
           SimpleSvgTimeline testLine = new SimpleSvgTimeline(
                                                new java.util.Locale("en", "US"), 
                                                "Gregorian", "G yyyy", 2);
           testLine.setTitle("Wars & Births");
                                   
           testLine.addLabel("My Birth", "en", "UK", "XMLSchemaGYear", "1966", 
                             "Gregorian", "http://www.heml.org", 0);
           testLine.addLabel("End of WWII", "en", "UK", "XMLSchemaGYear", "1945", 
                             "Gregorian", "http://www.heml.org", 0);
           testLine.addLabel("Dad's birth", "en", "UK", "XMLSchemaDate", 
                             "1929-05-29", "Gregorian", "http://www.heml.org", 0);
           testLine.addLabel("Joel's birth", "en", "UK", "XMLSchemaDate", 
                             "2000-09-17", "Gregorian", "http://www.heml.org", 1);
           testLine.addLabel("Pelop. War", "en", "UK", "XMLSchemaGYear", "-431", 
                             "Gregorian", "http://www.heml.org", 1);
                                   
           Document svgRoot = testLine.getSvg();
                                   
           System.exit(0);
         */
    } //end main
}
