/*
**************************************************************
*                                                            * 
* $RCSfile: TimelineBoundsGenerator.java,v $     
*                                                            *
* $Revision: 1.18 $                            
*                                                            *
* $Date: 2004/09/08 17:45:25 $                  
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.timeline;

import com.ibm.icu.util.*;

import java.awt.Font;

import java.util.Locale;

import org.heml.chronology.InternationalCalendarFactory;
import org.heml.chronology.format.*;
import org.heml.chronology.parse.*;

import org.heml.util.*;


public class TimelineBoundsGenerator
{

    static final boolean VERBOSE = true;
    boolean UP = true;
    int foo;
    long earliestTime;
    long latestTime;
    long startTime;
    long endTime;
    String outputCalendar;
    Locale locale;
    String language;
    String textFormat;
    TimelinePartCollection collection;
    TimelineScale scale;
    Font font;

    /***
     * Produces a {@link TimelinePartCollection} consisting of two 
     * {@link TimelineLabel}s: the starting point, which is formed by 
     * rounding down from the <code>earliestTime</code> and the ending point,
     * which is found by rounding up from the <code>latestTime</code>.
     */
    public TimelineBoundsGenerator(long earliestTime, long latestTime, 
                                   TimelineScale scale, float timelineWidth, 
                                   Locale locale, String language, 
                                   String textFormat, String outputCalendar, 
                                   Font font)
    {
        this.earliestTime = earliestTime;
        this.latestTime = latestTime;
        this.scale = scale;
        this.locale = locale;
        this.language = language;
        this.textFormat = textFormat;
        this.outputCalendar = outputCalendar;
        this.font = font;

        int period = 0;
        XMLSchemaGYearFormatter formatter = new XMLSchemaGYearFormatter();
        int earliestYear = formatter.getFormattedDate(earliestTime);
        int latestYear = formatter.getFormattedDate(latestTime) + 1;
        int distance = latestYear - earliestYear;
        long subperiod = 0l;
        float pixelTargetFloor = 20f;
        int possiblePeriod = 1;

        //Experiment in working out the span that best suits, down to seconds
        // if these arent good, then go for a year period below
        long timeSpan = latestTime - earliestTime;
        long day = 1000 * 60 * 60 * 24;
        int boundsCalendarType;
        int ticksCalendarType;
        int endYearAdjustment;
        Calendar cal = InternationalCalendarFactory.getCalendarInstanceStatic(
                               locale, outputCalendar);

        //a system like years BC
        cal.setTimeInMillis(latestTime);
        cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 1);

        if (latestTime > cal.getTime().getTime())
        {
            endYearAdjustment = -1;
        }
        else
        {
            endYearAdjustment = 1;
        }

        if (VERBOSE)
            System.out.println(
                    "EarliestTime:" + earliestTime + "\nLatestTime:" + 
                    latestTime + "\nTimeSpan: " + timeSpan + "\ndays?: " + 
                    timeSpan / day + "\nendYearAdjustment: " + 
                    endYearAdjustment);

        if (timeSpan > TimelineScale.yearInSeconds)
        {

            if (VERBOSE)
                System.out.println("span is larger than a year");

            boundsCalendarType = Calendar.YEAR;

            InternationalCalendarsFormatter eraChecker = new InternationalCalendarsFormatter(
                                                                 language, 
                                                                 locale.getCountry(), 
                                                                 outputCalendar, 
                                                                 "G");
            java.util.Date now = new java.util.Date();

            if (!eraChecker.getFormattedDate(earliestTime).equals(eraChecker.getFormattedDate(now.getTime())))
            {
                textFormat = "G y";
                if (VERBOSE) System.out.println("using era");
            }
            else
            {
                textFormat = "y";
            }

            cal.setTimeInMillis(earliestTime);
            cal.set(Calendar.MONTH, cal.getMinimum(Calendar.MONTH));
            cal.set(Calendar.DAY_OF_MONTH, 
                    cal.getMinimum(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            startTime = cal.getTime().getTime();
            cal.setTimeInMillis(latestTime);
            cal.set(Calendar.YEAR, cal.get(Calendar.YEAR) + 
                    endYearAdjustment);
            cal.set(Calendar.MONTH, cal.getMinimum(Calendar.MONTH));
            cal.set(Calendar.DAY_OF_MONTH, 
                    cal.getMinimum(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            endTime = cal.getTime().getTime();
        }
        else if (timeSpan > TimelineScale.yearInSeconds / 12l)
        {
            boundsCalendarType = Calendar.MONTH;
            textFormat = "y MMMM";
            cal.setTimeInMillis(earliestTime);
            cal.set(Calendar.DAY_OF_MONTH, 
                    cal.getMinimum(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            startTime = cal.getTime().getTime();
            cal.setTimeInMillis(latestTime);
            cal.set(Calendar.DAY_OF_MONTH, 
                    cal.getMinimum(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            cal.set(Calendar.MILLISECOND, cal.getMinimum(Calendar.MILLISECOND));
            cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) + 1);
            endTime = cal.getTime().getTime();

            if (VERBOSE)
                System.out.println("Bounds are months");
        }
        else if (timeSpan > TimelineScale.yearInSeconds / 365l)
        {
            boundsCalendarType = Calendar.DAY_OF_MONTH;
            textFormat = "y MMMM d";

            if (VERBOSE)
                System.out.println("bounds are days");

            cal.setTimeInMillis(earliestTime);
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            startTime = cal.getTime().getTime();
            cal.setTimeInMillis(latestTime);
            cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            cal.set(Calendar.MILLISECOND, cal.getMinimum(Calendar.MILLISECOND));
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) + 1);
            endTime = cal.getTime().getTime();
        }
        else if (timeSpan > TimelineScale.yearInSeconds / (365l * 24l))
        {
            boundsCalendarType = Calendar.HOUR;
            textFormat = "y MMMM d H'h'";

            if (VERBOSE)
                System.out.println("bounds are hours");

            cal.setTimeInMillis(earliestTime);
            cal.set(Calendar.HOUR, cal.get(Calendar.HOUR) -1);
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            startTime = cal.getTime().getTime();
            cal.setTimeInMillis(latestTime);
            cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            cal.set(Calendar.HOUR, cal.get(Calendar.HOUR) + 1);
            endTime = cal.getTime().getTime();
        }
        else
        {
            boundsCalendarType = Calendar.MINUTE;

            if (VERBOSE)
                System.out.println("bounds are minutes");

            textFormat = "y MMMM d H:mm";
            cal.setTimeInMillis(earliestTime);
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            startTime = cal.getTime().getTime();
            cal.setTimeInMillis(latestTime);
            cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + 1);
            cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
            endTime = cal.getTime().getTime();
        }

        //find ideal period for this scale
        // period is set to 0 until we find a proper value
        float pixels;

        while (period == 0)
        {
            pixels = (float)scale.givePixelsForTime(
                             TimelineScale.yearInSeconds * possiblePeriod);

            if (pixels > pixelTargetFloor)
            {
                period = possiblePeriod;
            }
            else
            {
                possiblePeriod = possiblePeriod * 10;
            }
        }

        if (scale.givePixelsForTime(TimelineScale.yearInSeconds) > 100f)
        {
            subperiod = TimelineScale.yearInSeconds / 4l;
        }

        int startYear = earliestYear;
        int endYear = latestYear;
        int tickStart = roundUpOnPeriod(period, startYear);
        int tickEnd = roundDownOnPeriod(period, endYear);

        // get long for startDate and endDate (use 'G yyyy')
        // Now, from the data we've gathered, make a collection of two
        // Timed objects, the start and end.
        Year parser = new Year();
        parser.setInt(startYear);
        parser.setInt(endYear);

        if (VERBOSE)
        {
            System.out.println(
                    "Country is: " + locale.getCountry() + " loc.lang is: " + 
                    locale.getLanguage() + " language is: " + language);
        }

        InternationalCalendarsFormatter icf = new InternationalCalendarsFormatter(
                                                      language, 
                                                      locale.getCountry(), 
                                                      outputCalendar, 
                                                      textFormat);
        InternationalCalendarsFormatter monthFormatter = new InternationalCalendarsFormatter(
                                                                 language, 
                                                                 locale.getCountry(), 
                                                                 outputCalendar, 
                                                                 "MMMM d");
        InternationalCalendarsFormatter dayFormatter = new InternationalCalendarsFormatter(
                                                               language, 
                                                               locale.getCountry(), 
                                                               outputCalendar, 
                                                               "d");
        InternationalCalendarsFormatter hourFormatter = new InternationalCalendarsFormatter(
                                                                language, 
                                                                locale.getCountry(), 
                                                                outputCalendar, 
                                                                "H:00");
        InternationalCalendarsFormatter minuteFormatter = new InternationalCalendarsFormatter(
                                                                  language, 
                                                                  locale.getCountry(), 
                                                                  outputCalendar, 
                                                                  ":mm");
        collection = new TimelinePartCollection();
        collection.addObject(new TimelineTick(startTime, 
                                              icf.getFormattedDate(startTime), 
                                              timelineWidth));
        collection.addObject(new TimelineTick(endTime, 
                                              icf.getFormattedDate(endTime), 
                                              timelineWidth));
        collection.setFont(font);

        //now get less important inner ticks
        int yearPointer = tickStart;
        boolean displayedYears = false;
        Font smallTickFont = font.deriveFont(font.getSize2D() - 2f);

        while (yearPointer < endYear)
        {

            if (VERBOSE)
                System.out.println(
                        "Yearpointer:" + yearPointer + "\ntickEnd: " + 
                        tickEnd + "\nendYearAdjustment: " + 
                        endYearAdjustment);

            parser.setInt(yearPointer);

            long pointerTime = parser.getEarliestTime();
            TimelineTick aTick = new TimelineTick(pointerTime, 
                                                  icf.getFormattedDate(
                                                          pointerTime), 
                                                  timelineWidth);
            aTick.setFont(smallTickFont);
            collection.addObject(aTick);
            yearPointer += period;
            displayedYears = true;
        } // end while

        //now get the months, if necessary
        // get an appropriate calendar object
        // System.out.println("scale is: " + scale.givePixelsForTime(TimelineScale.yearInSeconds));
        boolean displayedMonths = false;
        boolean displayedDays = false;
        boolean displayedHours = false;
        boolean displayedMinutes = false;

        if (scale.givePixelsForTime(TimelineScale.yearInSeconds) > 100f)
        {
           if (VERBOSE) System.out.println("We're going to draw some months");
            Font smallerTickFont = font.deriveFont(font.getSize2D() - 3);
            Calendar rollingCal = InternationalCalendarFactory.getCalendarInstanceStatic(
                                          locale, outputCalendar);

            //set it to the beginning of our period
            rollingCal.setTimeInMillis(startTime);

            int numberOfMonthsInYear = rollingCal.getMaximum(Calendar.MONTH);

            if (VERBOSE)
                System.out.println(
                        "There are " + numberOfMonthsInYear + 
                        " months in a year");

            rollingCal.set(Calendar.DAY_OF_MONTH, 
                           rollingCal.getMinimum(Calendar.DAY_OF_MONTH));
            rollingCal.set(Calendar.HOUR, rollingCal.getMinimum(Calendar.HOUR));
            rollingCal.set(Calendar.MINUTE, 
                           rollingCal.getMinimum(Calendar.MINUTE));
            rollingCal.set(Calendar.SECOND, 
                           rollingCal.getMinimum(Calendar.SECOND));
            rollingCal.set(Calendar.MILLISECOND, 
                           rollingCal.getMinimum(Calendar.MILLISECOND));

            if (boundsCalendarType == Calendar.MONTH || boundsCalendarType == Calendar.YEAR)
                rollingCal.add(Calendar.MONTH, 1);

            long monthInMillis = 30l * 24l * 60l * 60l * 1000l;

            while (rollingCal.getTimeInMillis() + monthInMillis < endTime)
            {

                if (VERBOSE)
                    System.out.println(
                            "endTime: " + endTime + "\nrollingCaltime: " + 
                            rollingCal.getTimeInMillis());

                TimelineTick newTick = new TimelineTick(rollingCal.getTimeInMillis(), 
                                                        monthFormatter.getFormattedDate(rollingCal.getTimeInMillis()), 
                                                        timelineWidth);
                newTick.setFont(smallerTickFont);
                collection.addObject(newTick);
                rollingCal.add(Calendar.MONTH, 1);

                //skip the first month, which should have been dealt with in years
                if ((boundsCalendarType == Calendar.YEAR) && 
                    rollingCal.get(Calendar.MONTH) == rollingCal.getMinimum(
                                                              Calendar.MONTH))
                    rollingCal.add(Calendar.MONTH, 1);
            }

            displayedMonths = true;
        }

        if (scale.givePixelsForTime(TimelineScale.yearInSeconds) > 5000f)
        {

            Font smallerTickFont = font.deriveFont(font.getSize2D() - 4);
            Calendar rollingCal = InternationalCalendarFactory.getCalendarInstanceStatic(
                                          locale, outputCalendar);

            //set it to the beginning of our period
            rollingCal.setTimeInMillis(startTime);
            rollingCal.set(Calendar.HOUR_OF_DAY, 
                           rollingCal.getMinimum(Calendar.HOUR_OF_DAY));
            rollingCal.set(Calendar.MINUTE, 
                           rollingCal.getMinimum(Calendar.HOUR_OF_DAY));
            rollingCal.set(Calendar.SECOND, 
                           rollingCal.getMinimum(Calendar.SECOND));
            rollingCal.set(Calendar.DAY_OF_YEAR, 
                           rollingCal.get(Calendar.DAY_OF_YEAR) + 1);

            while (rollingCal.getTimeInMillis() < endTime)
            {

                TimelineTick newTick = new TimelineTick(rollingCal.getTimeInMillis(), 
                                                        monthFormatter.getFormattedDate(rollingCal.getTimeInMillis()), 
                                                        timelineWidth);
                newTick.setFont(smallerTickFont);
                collection.addObject(newTick);
                rollingCal.add(Calendar.DAY_OF_YEAR, 1);

                //if we've already diplayed month names, then skip the labelling
                // of the first of the month
                if (displayedMonths && 
                    rollingCal.get(Calendar.DAY_OF_MONTH) == 1)
                {
                    rollingCal.add(Calendar.DAY_OF_YEAR, 1);
                }
            }

            displayedDays = true;
        }

        if (scale.givePixelsForTime(TimelineScale.yearInSeconds) > 90000)
        {

            //we're dealing with hour-to-hour
            Font smallerTickFont = font.deriveFont(font.getSize2D() - 4);
            Calendar rollingCal = InternationalCalendarFactory.getCalendarInstanceStatic(
                                          locale, outputCalendar);
            rollingCal.setTimeInMillis(startTime);
            rollingCal.set(Calendar.MINUTE, 0);
            rollingCal.set(Calendar.SECOND, 0);
            rollingCal.set(Calendar.HOUR_OF_DAY, 
                           rollingCal.get(Calendar.HOUR_OF_DAY) + 1);

            long halfHourInMillis = 1000l * 60 * 30;

            while (rollingCal.getTimeInMillis() + halfHourInMillis < endTime)
            {

                TimelineTick newTick = new TimelineTick(rollingCal.getTimeInMillis(), 
                                                        hourFormatter.getFormattedDate(rollingCal.getTimeInMillis()), 
                                                        timelineWidth);
                newTick.setFont(smallerTickFont);
                collection.addObject(newTick);
                rollingCal.add(Calendar.HOUR_OF_DAY, 1);

                if (displayedDays && 
                    (rollingCal.get(Calendar.HOUR_OF_DAY) == 0))
                {
                    rollingCal.add(Calendar.HOUR_OF_DAY, 1);
                }
            }

            displayedHours = true;
        }

        if (scale.givePixelsForTime(TimelineScale.yearInSeconds) > 5000000)
        {

            //we're dealing with minute-to-minute
            Font smallerTickFont = font.deriveFont(font.getSize2D() - 4);
            Calendar rollingCal = InternationalCalendarFactory.getCalendarInstanceStatic(
                                          locale, outputCalendar);
            rollingCal.setTimeInMillis(startTime);
            rollingCal.set(Calendar.SECOND, 0);
            rollingCal.set(Calendar.MINUTE, 
                           rollingCal.get(Calendar.MINUTE) + 1);

            while (rollingCal.getTimeInMillis() < endTime)
            {

                TimelineTick newTick = new TimelineTick(rollingCal.getTimeInMillis(), 
                                                        minuteFormatter.getFormattedDate(rollingCal.getTimeInMillis()), 
                                                        timelineWidth);
                newTick.setFont(smallerTickFont);
                collection.addObject(newTick);
                rollingCal.add(Calendar.MINUTE, 1);

                if (displayedHours && 
                    (rollingCal.get(Calendar.MINUTE) == 0))
                {
                    rollingCal.add(Calendar.MINUTE, 1);
                }
            }
        }
    }

    /****
     * @return the nearest smaller number on the period specified.
     * I.e. period=10 and value=-231 results in -240
     */
    protected static int roundDownOnPeriod(int period, int value)
    {

        double a = value / (float)period;
        double floor = java.lang.Math.floor(a) * (float)period;

        if (VERBOSE)
        {
            System.out.println("Your double fraction: " + a);
            System.out.println("Your floor: " + floor);
        }

        int intFloor = (int)floor;

        //There is no year '0' in Islamic, Gregorian, etc.
        if (intFloor == 0)
        {

            return 1;
        }
        else
        {

            return intFloor;
        }
    }

    /**
     * @return the nearest larger number on the period specified. I.e.
     * period=100 and value=1901 results in 2000.
     */
    protected static int roundUpOnPeriod(int period, int value)
    {

        double a = value / (float)period;
        double ceiling = java.lang.Math.ceil(a) * (float)period;
        Double d = new Double(ceiling);
        int out = d.intValue();

        if (VERBOSE)
        {
            System.out.println("**Round up on period:");
            System.out.println("  period: " + period);
            System.out.println("  value: " + value);
            System.out.println("  ceiling: " + ceiling);
            System.out.println(" out: " + d.intValue());
        }

        if (value == out) //to avoid events coming just after the label.
        {

            return out + period;
        }
        else
        {

            return d.intValue();
        }
    }

    public TimelinePartCollection getBounds()
    {

        return collection;
    }

    public long startTime()
    {

        return startTime;
    }

    public long endTime()
    {

        return endTime;
    }
}
