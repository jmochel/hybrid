/*
 ************************************************************** 
 * $RCSfile: HemlEventMapPlotterForLocation.java,v $                     *
 *                                                            *
 * $Revision: 1.2 $                                           *
 *                                                            *
 * $Date: 2004/09/08 17:45:25 $                               *
 *                                                            *
 * Copyright (C) 2003 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Bruce Robertson                                        *
 *     Susan Barnett                                          *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 ************************************************************** 
 */
package org.heml.image.hemlEvent;
import org.heml.image.gridLayout.CylindricalEquidistantMapDefinition;


public class HemlEventMapPlotterForLocation
    extends HemlEventMapPlotter
{
    public HemlEventMapPlotterForLocation(org.jdom.Element eventElement, 
                                          CylindricalEquidistantMapDefinition map)
    {
        super(eventElement, map);
	this.locationLabel = eventElement.getChild("Location", ns)
                                          .getChild("LocationLabelSet", ns)
                                          .getChild("Label", ns).getText();
    }

    public HemlEventMapPlotterForLocation()
    {
        super();
    }
    private String getLocationLabel() {
	return locationLabel;
    }
    public String getText() {
	    return getLocationLabel();
    }
        /***
     * Returns the id string.
     * @return the <code>HemlEvent</code>'s event id
     **/
    public String getId() {
        return eventElement.getChild("Location", ns).getAttributeValue("id");       
        //return this.id;
    }

}
