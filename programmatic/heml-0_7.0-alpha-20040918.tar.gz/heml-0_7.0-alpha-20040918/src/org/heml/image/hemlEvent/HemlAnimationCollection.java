/*
************************************************************** 
* $RCSfile: HemlAnimationCollection.java,v $                 *
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2003/10/03 21:25:35 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.hemlEvent;

import java.util.Comparator;

/**
 * Holds a collection of <code>HemlEvent</code>s for animation purposes.
 */
public final class HemlAnimationCollection extends HemlEventCollection {
	private final boolean VERBOSE = false; // level of debugging output
    // variables to aid in the calculation of event visibility
    private long visibilityDuration = 0;
    private long minimumDuration = 0;
    private long span; // chronological span of all events
    private long minimumSpan; // minimum span of an individual event

    /** 
	 * Constructs and initializes a <code>HemlAnimationCollection</code>.
	 * @param visibilityDuration the minimum duration time that any event will be visible
	 * @param minimumDuration the minimum duration of the animation
	 */ 
    public HemlAnimationCollection(long visibilityDuration, long minimumDuration) {
        super();
        this.visibilityDuration = visibilityDuration;
        this.minimumDuration    = minimumDuration;
    }

    /***
     * Constructs and initializes a <code>HemlAnimatoinCollection</code>.
     * @param listIn a list of <code>HemlEvent</code>s.
     */
    public HemlAnimationCollection(java.util.List listIn) {
        super(listIn);
    }

    /**
     * Returns a list of <code>HemlAnimationCollection</code>s, representing the original
     * input list but sliced according to chronological concurrency.
     * @return a list of <code>HemlAnimationCollection</code>s containing this <code>HemlAnimationCollection</code>s
     * <code>HemlEvent</code>s sorted according to chronological concurrency.
     */
    public final java.util.ArrayList getSliced() {
        int  start = 0;
        long latest = 0;

        // sort into chronological order before split
        java.util.Collections.sort(eventList, comparator);

        // get span of all events
        this.span = Math.abs(getLatest() - getEarliest());

        // calculate the minimum span an event will be visible for
        this.minimumSpan = this.span / (this.minimumDuration/this.visibilityDuration);

        li = eventList.listIterator();

        java.util.ArrayList sliced = new java.util.ArrayList();

        // check every event in the list for array positioning
        while (li.hasNext()) {
            start = li.nextIndex();

            if (isOverlapping((HemlEvent) this.eventList.get(li.nextIndex()))) {
                latest = ((HemlEvent) li.next()).getEarliestTime() + this.minimumSpan;
            } else {
                latest = ((HemlEvent) li.next()).getLatestTime();
            }

            if (li.hasNext()) {
                slice(latest);
            }

            HemlAnimationCollection current = new HemlAnimationCollection(
                                                      this.subList(start, 
                                                                   li.nextIndex()));
            sliced.add(current);

            if (VERBOSE) {
                System.out.println("Current collection split to hold:");

                for (int j = 0; j < current.size(); j++) {
                    System.out.println(((HemlEvent) current.get(j)).id);
                    System.out.println("Earliest time: " + ((HemlEvent) current.get(j)).getEarliestTime());
                    System.out.println("Latest time: " + ((HemlEvent) current.get(j)).getLatestTime());
                }
                System.out.println("Current latest time is " + latest);
            }
        }
        
        if (VERBOSE){
        	System.out.println("Collection sliced into " + sliced.size() + " collections");
        }
        
        return sliced;
    }


    /**
     * Determines if an event will overlap if its span is set to minimum span visibility
     * @param event the event to be checked
     * @return true if event span is less than minimumSpan; false otherwise.
     **/
    private boolean isOverlapping(HemlEvent event) {
    	if (VERBOSE){
        	System.out.print("in overlapping and " + (event.getLatestTime() - event.getEarliestTime()));
        }
        if (event.getLatestTime() - event.getEarliestTime() < this.minimumSpan) {
            if (VERBOSE){ System.out.println(" and returned true"); }
            return true;
        } else {
            if (VERBOSE){ System.out.println(" and returned false"); }
            return false;
        }
    }

    /**
     * Set latest time to current + minimumSpan to account for minimum visibility in the animation.
     * @param current the current span of the <code>HemlEvent</code> being checked.
     * @return the new span of the <code>HemlEvent</code>
     **/
    private long setLatestTime(long current) {
        return (current + this.minimumSpan);
    }

    /**
     * Returns the earliest time for a <code>HemlEvent</code> in the current <code>HemlAnimationCollection</code>.
     * @return the earliest time for a <code>HemlEvent</code> in the current <code>HemlAnimationCollection</code>.
     **/
    private long getEarliest() {
        return ((HemlEvent) this.eventList.get(0)).getEarliestTime();
    }

    /**
     * Returns the latest time for a <code>HemlEvent</code> in the current <code>HemlAnimationCollection</code>.
     * @return the latest time for a <code>HemlEvent</code> in the current <code>HemlAnimationCollection</code>.
     **/
    private long getLatest() {
        long latest = ((HemlEvent) this.eventList.get(0)).getLatestTime();

        for (int i = 1; i < this.eventList.size(); i++) {
            if (((HemlEvent) this.eventList.get(i)).getLatestTime() > latest) {
                latest = ((HemlEvent) this.eventList.get(i)).getLatestTime();
            }
        }

        return latest;
    }

    /** 
     * Calculates the end value of a slice of <code>HemlEvent</code>s
     * @param the value of the current latest time in the list.
     **/
    private void slice(long latest) {
        // if the next event begins before the current one ends, it must be added to current list
        if (((HemlEvent) li.next()).getEarliestTime() <= latest) {
            
            // if the event time needs adjustment for minimum event visibility, do so
            if (isOverlapping((HemlEvent)this.eventList.get(li.previousIndex()))){
            	latest = ((HemlEvent)li.previous()).getEarliestTime() + this.minimumSpan;
            }
            else{
            	latest = ((HemlEvent) li.previous()).getLatestTime();
            }
            
            // if the event ends after the current event, its latest time becomes 'latest'
            if (((HemlEvent) li.next()).getLatestTime() > latest) {
                latest = ((HemlEvent) li.previous()).getLatestTime();
                Object dummy = li.next();
            }

            if (li.hasNext()) {
                slice(latest);
            }
        } else {
            Object dummy = li.previous();
        }
    }
}