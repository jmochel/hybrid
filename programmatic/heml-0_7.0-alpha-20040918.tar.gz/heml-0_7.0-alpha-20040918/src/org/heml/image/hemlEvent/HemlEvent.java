/*
************************************************************** 
* $RCSfile: HemlEvent.java,v $                               *
*                                                            *
* $Revision: 1.3 $                                          *
*                                                            *
* $Date: 2004/09/08 17:45:24 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.hemlEvent;

import org.apache.xerces.dom.*;

import org.heml.chronology.parse.Chronology;

import org.jdom.Element;
import org.jdom.Namespace;

import org.w3c.dom.*;


/***
 * Holds event information for java manipulation
 **/
public class HemlEvent {
    private static final boolean VERBOSE = false;
    protected String label;
    protected String id;
    protected Namespace ns;
    private long earliestTime;
    private long latestTime;
    private org.w3c.dom.Element chronologyDomElement;
    protected org.jdom.Element locationElement, eventElement;
    protected Chronology chronology;
	/**
	 * Constructs and initializes an empty <code>HemlEvent</code>.
	 */
    public HemlEvent() {}


	/**
	 * Constructs and initializes a <code>HemlEvent</code>.
	 * @param eventElement the DOM element containing the desired Heml event information
	 */
    public HemlEvent(org.jdom.Element eventElement) {
        org.jdom.Element locationElement;
        this.eventElement = eventElement;
        this.ns = eventElement.getNamespace();
        this.id = eventElement.getAttributeValue("id");
        this.label = org.heml.util.JdomUtils.getStringDeep(eventElement.getChild("EventLabelSet", ns).getChild("Label", ns));

        //Set Chronology Variables
        chronologyDomElement = org.heml.util.JdomUtils.convertToDomElement(
                                                           eventElement.getChild(
                                                                   "Chronology", 
                                                                   ns));
        chronology = new Chronology();
        chronology.setElement(chronologyDomElement);
        this.latestTime = chronology.getLatestTime();
        this.earliestTime = chronology.getEarliestTime();

        if (VERBOSE) {
            System.out.println("HemlEvent constructed an event: \n\tid:" + id + 
                               "\n\tlabel: " + label + "\n\tearliest time: " + 
                               getEarliestTime() + "\n\tlatest time: " + 
                               getLatestTime());
        }
    }

    /***
     * Returns the label string.
     * @return the <code>HemlEvent</code>'s event label
     **/
    public String getLabel() {
        return this.label;
    }

    /***
     * Returns the id string.
     * @return the <code>HemlEvent</code>'s event id
     **/
    public String getId() {
        return this.id;
    }

	/***
	 * Returns the latest time
	 * @return the <code>HemlEvent</code>'s chronology information for latest time
	 **/
    public long getLatestTime() {
        return this.latestTime;
    }

	/***
	 * Returns the earliest time
	 * @return the <code>HemlEvent</code>'s chronology information for earliest time
	 **/
    public long getEarliestTime() {
        return this.earliestTime;
    }
}
