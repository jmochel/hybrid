/*
************************************************************** 
* $RCSfile: HemlEventCollection.java,v $                               *
*                                                            *
* $Revision: 1.2 $                                          *
*                                                            *
* $Date: 2004/09/08 17:45:24 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.hemlEvent;

import java.util.Comparator;


/**
 * Holds a collection of <code>HemlEvent</code>s.
 */
public class HemlEventCollection {
    protected static boolean VERBOSE = false;
    protected static ChronologicalComparator comparator = 
            new ChronologicalComparator();
    java.util.ArrayList eventList;
    java.util.ListIterator li;


    /** 
	 * Constructs and initializes an empty <code>HemlEventCollection</code>.
	 */ 
    public HemlEventCollection() {
        eventList = new java.util.ArrayList();
        li = eventList.listIterator();
    }

    /***
     * Constructs and initializes a <code>HemlEventCollection</code>.
     * @param listIn a list of <code>HemlEvent</code>s.
     */
    public HemlEventCollection(java.util.List listIn) {
        eventList = new java.util.ArrayList(listIn);
    }

    /**
     * Appends a <code>HemlEvent</code> to the end of this collection.
     * @param e the <code>HemlEvent</code> to be added to the collection.
     */
    public void add(HemlEvent e) {
        eventList.add(e);
    }

    /**
     * Returns the number of elements in this collection.
     * @return the number of <code>HemlEvent</code>s in this collection.
     */
    public int size() {
        return eventList.size();
    }

    /**
     * Returns the <code>HemlEvent</code> at the specified position in this collection.
     * @param index the index of <code>HemlEvent</code> to return.
     * @return the <code>HemlEvent</code> at the specified position in this collection.
     */
    public HemlEvent get(int index) {
        return (HemlEvent) eventList.get(index);
    }

    /**
     * Provides the listIterator for this collection.
     * @return iterator for ordered iteration over this collection of <code>HemlEvent</code>s.
     */
    public java.util.ListIterator listIterator() {
        return eventList.listIterator();
    }

    /**
     * Generates a <code>List</code> that is a slice of this <code>HemlEventCollection</code>.
     * Use with <code>HemlEventCollection(List)</code> constructor to make sub-copies.
     * @param fromList low endpoint (inclusive) of the <code>subList</code>.
     * @param toList high endpoint (exclusive) of the <code>subList</code>.
     * @return a <code>List</code> containing the specified range within this list.
     */
    public java.util.List subList(int fromList, int toList) {
        return eventList.subList(fromList, toList);
    }
}
