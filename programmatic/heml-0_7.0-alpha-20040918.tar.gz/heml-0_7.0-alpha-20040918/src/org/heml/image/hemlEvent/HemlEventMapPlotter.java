/*
 ************************************************************** 
 * $RCSfile: HemlEventMapPlotter.java,v $                     *
 *                                                            *
 * $Revision: 1.6 $                                           *
 *                                                            *
 * $Date: 2003/10/29 22:43:12 $                               *
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Bruce Robertson                                        *
 *     Susan Barnett                                          *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 ************************************************************** 
 */
package org.heml.image.hemlEvent;

import org.heml.image.gridLayout.MapCoordinate;
import org.heml.image.gridLayout.CylindricalEquidistantMapDefinition;

import diva.util.java2d.Polygon2D;

import java.awt.*;

import org.apache.xerces.dom.*;

import org.jdom.Element;
import org.jdom.Namespace;

import org.w3c.dom.*;


/***
 * Holds event information for java manipulation and map information for label plotting using <code>GridBuilder</code> class.
 * @see GridBuilder
 **/
public class HemlEventMapPlotter extends HemlEvent {
    private static final boolean VERBOSE = false;
    protected String locationLabel;
    private String justification = " ";
    private CylindricalEquidistantMapDefinition map;
    private MapCoordinate[] latitudes;
    private MapCoordinate[] longitudes;
    private java.awt.Shape shape;
    private java.awt.geom.Rectangle2D outline;
    private java.awt.geom.Rectangle2D.Float rect = null;
    private java.awt.geom.Line2D.Float line = null;
    private boolean plotted = true;
    private boolean wrapped = false;
    private Color textColor = Color.black;
    private Color shapeColor = Color.red;
    /**
	 * Constructs and initializes an empty <code>HemlEventMapPlotter</code>.
	 */
    public HemlEventMapPlotter() {
        super();
    }

	/**
	 * Constructs and initializes a <code>HemlEventMapPlotter</code>.  Determines a shape
	 * on the map that represents the event location's latitude and longitude in x,y coordinates.
	 * @param eventElement the DOM element containing the desired HEML event information
	 * @param map the map dimensions upon which label placement will be based
	 */
    public HemlEventMapPlotter(org.jdom.Element eventElement, 
                               CylindricalEquidistantMapDefinition map) {
        super(eventElement); // call superclass constructor

        this.map = map;
	//set default colours
        this.textColor = java.awt.Color.black;
	this.shapeColor = java.awt.Color.red;
        org.jdom.Element polygonElement;
        org.jdom.Element point;
        org.jdom.Element locationElement;
        org.jdom.Element latitudeElement;
        org.jdom.Element longitudeElement;
        float latHours;
        float latMinutes;
        float latSeconds;
        float longHours;
        float longMinutes;
        float longSeconds;
        locationElement = eventElement.getChild("Location", ns);

        //don't process if we don't have a location or if event label is empty
        if ((locationElement != null) ) {//((locationElement != null) && (getText().length() != 0)) {
            java.util.ArrayList latList = new java.util.ArrayList();
            java.util.ArrayList longList = new java.util.ArrayList();
            polygonElement = locationElement.getChild("Polygon", this.ns);

            if (polygonElement != null) {
                java.util.Iterator points = polygonElement.getChildren()
                                                          .iterator();

                while (points.hasNext()) {
                    point = (org.jdom.Element) points.next();
                    latitudeElement = point.getChild("Latitude", this.ns);
                    longitudeElement = point.getChild("Longitude", this.ns);

                    //don't process if we dont' have lat/long
                    if ((latitudeElement != null) && 
                            (longitudeElement != null)) {
                        latHours = floatFromElementsAttribute(latitudeElement, 
                                                              "hours");
                        latMinutes = floatFromElementsAttribute(latitudeElement, 
                                                                "minutes");
                        latSeconds = floatFromElementsAttribute(latitudeElement, 
                                                                "seconds");
                        longHours = floatFromElementsAttribute(longitudeElement, 
                                                               "hours");
                        longMinutes = floatFromElementsAttribute(
                                              longitudeElement, "minutes");
                        longSeconds = floatFromElementsAttribute(
                                              longitudeElement, "seconds");

                        float latTotal = latHours + latMinutes + latSeconds;
                        float longTotal = longHours + longMinutes + 
                                          longSeconds;

                        MapCoordinate lat = new MapCoordinate(latHours, 
                                                              latMinutes, 
                                                              latSeconds);
                        MapCoordinate longitude = new MapCoordinate(longHours, 
                                                                    longMinutes, 
                                                                    longSeconds);


                        // add them to the arrays
                        latList.add(lat);
                        longList.add(longitude);
                    }
                }
            }
            //code for non-polygon elements
            else {
                latitudeElement = locationElement.getChild("Latitude", this.ns);
                longitudeElement = locationElement.getChild("Longitude", 
                                                            this.ns);

                //don't process if we dont' have lat/long
                if ((latitudeElement != null) && (longitudeElement != null)) {
                    latHours = floatFromElementsAttribute(latitudeElement, 
                                                          "hours");
                    latMinutes = floatFromElementsAttribute(latitudeElement, 
                                                            "minutes");
                    latSeconds = floatFromElementsAttribute(latitudeElement, 
                                                            "seconds");
                    longHours = floatFromElementsAttribute(longitudeElement, 
                                                           "hours");
                    longMinutes = floatFromElementsAttribute(longitudeElement, 
                                                             "minutes");
                    longSeconds = floatFromElementsAttribute(longitudeElement, 
                                                             "seconds");

                    float latTotal = latHours + latMinutes + latSeconds;
                    float longTotal = longHours + longMinutes + longSeconds;

                    MapCoordinate lat = new MapCoordinate(latHours, latMinutes, 
                                                          latSeconds);
                    MapCoordinate longitude = new MapCoordinate(longHours, 
                                                                longMinutes, 
                                                                longSeconds);


                    // add them to the arrays
                    latList.add(lat);
                    longList.add(longitude);
                }
            }

            this.latitudes = toMapCoordinates(latList);
            this.longitudes = toMapCoordinates(longList);
            setShape(createShape());
        }
    }

    private MapCoordinate[] toMapCoordinates(java.util.ArrayList l) {
        MapCoordinate[] out = new MapCoordinate[l.size()];

        for (int x = 0; x < l.size(); x++) {
            out[x] = (MapCoordinate) l.get(x);
        }

        return out;
    }

    private float floatFromElementsAttribute(Element e, String attributeName) {
        try {
            String s = e.getAttributeValue(attributeName);

            return Float.parseFloat(s);
        } catch (Exception excep) {
            return 0f;
        }
    }

    /*** 
     * Returns the value of the current rectangle
     * @return a rectangle containing the x,y coordinates of the placed event label.
     **/
    public java.awt.geom.Rectangle2D.Float getRect() {
        return this.rect;
    }

    /*** 
     * Returns the <code>String</code> value of current justification
     * @return the justification (right or left) of the event label if the label is justified;
     * else the <code>String</code> is empty i.e. "  " not null.
     **/
    public String getJustification() {
        return this.justification;
    }

    /*** 
     * Returns the event label's line.
     * @return the line from event location to event label if required; NULL otherwise.
     **/
    public java.awt.geom.Line2D.Float getLine() {
        return this.line;
    }

    /*** 
     * Returns the current shape
     * @return the shape representing the latitude/longitude of the event's location in x,y coordinates.
     **/
    public java.awt.Shape getShape() {
        return this.shape;
    }
    
    /**
     * Returns the text associated with the <code>HemlEventMapPlotter</code>
     * @returns the text string for the current <code>HemlEventMapPlotter</code>
     */
    public String getText() {
		return getLabel();
    }
    
    /**
     * Returns wrapping information for the event label
     * @return true if the event label was wrapped when plotted; false otherwise.
     **/
    public boolean isWrapped() {
        return this.wrapped;
    }

    /** 
     * Returns plotting information for the event label
     * @return true if the event was successfully plotted onto the map; false otherwise.
     **/
    public boolean isPlotted() {
        return this.plotted;
    }

    /***
     * Creates a shape from the given lat/long information. **NOTE: currently only handles polygons 
     * @return the shape representing the event location's latitude and longitude in x,y coordinates
     **/
    private java.awt.Shape createShape() {
        float[] xpoints;
        float[] ypoints;
        int npoints = latitudes.length;

        if (npoints > 1) {
            Polygon2D.Float poly = new Polygon2D.Float();
            xpoints = new float[latitudes.length];
            ypoints = new float[latitudes.length];

            for (int i = 0; i < latitudes.length; i++) {
                if (VERBOSE) {
                    System.out.println("Plotting point no. " + i + 
                                       ":\n\tx: " + 
                                       map.longitudeToX(longitudes[i]) + 
                                       "\n\ty: " + 
                                       map.latitudeToY(latitudes[i]));
                }

                poly.lineTo(map.longitudeToX(longitudes[i]), 
                            map.latitudeToY(latitudes[i]));
            }

            return poly;
        } else {
            java.awt.geom.Ellipse2D.Float shape = new java.awt.geom.Ellipse2D.Float();
            float x; // shape values to be set
            float y; // shape values to be set
            float width = 3f; // shape values to be set
            float height = 3f; // shape values to be set


            // get x, y coordinates from lat/long
            x = map.longitudeToX(this.longitudes[0]);
            y = map.latitudeToY(this.latitudes[0]);
            shape.setFrame(x, y, width, height);

            return shape;
        }
    }

    /***
     * Sets the colour of the rendered text
     * @param color
     **/
    public void setTextColor(java.awt.Color color) {
	    this.textColor = color;
    }

    public Color getTextColor() {
	    return textColor;
    }

    public Color getShapeColor() {
	    return shapeColor;
    }

    /***
     * Sets the colour of the rendered shape or dot
     * @param color
     **/
    public void setShapeColor(java.awt.Color color) {
	    this.shapeColor = color;
    }
    /***
     * Sets the value of this shape
     * @param shape the desired shape representing the location for this event
     **/
    private void setShape(java.awt.Shape shape) {
        this.shape = shape;
    }

    /*** 
     * Sets the value of this rectangle
     * @param rect the desired rectangle representing the label placement on the map 
     **/
    public void setRect(java.awt.geom.Rectangle2D.Float rect) {
        this.rect = rect;
    }

    /***
     * Sets the label wrapping information
     * @param wrapped boolean representing whether the event label required wrapping
     **/
    public void setWrapped(boolean wrapped) {
        this.wrapped = wrapped;
    }

    /***
     * Sets the label plotting information
     * @param plotted boolean representing whether the event label was successfully plotted
     **/
    public void setPlotted(boolean plotted) {
        this.plotted = plotted;
    }

    /***
     * Sets the value of the line from shape to rect
     * @param line the line from the event's location to its label on the map.
     **/
    public void setLine(java.awt.geom.Line2D.Float line) {
        this.line = line;
    }

    /***
     * Sets the justification for any text wrapping
     * @param jus <ul>
     *			    <li> if label required right justification, jus set to "right"
     *              <li> if label required left justification, jus set to "left"
     *            </ul>
     **/
    public void setJustification(String jus) {
        this.justification = jus;
    }
    
    
   /***
     * Determines the base to search from for the current shape.
     * @return the x,y coordinates of the central point (or most convenient point near the centre) of the
     * shape representing the x,y coordinates of the event location's latitude and longitude.
     * @throws LocationException if there is no available latitude/longitude information
     **/
    public java.awt.geom.Point2D.Float getBase() throws LocationException {
        java.awt.geom.Rectangle2D shapeBounds;
        java.awt.geom.Point2D.Float testPoint;
        java.awt.geom.Point2D.Float point;

                                                    
        // if there are no coordinates, cannot plot, so throw LocationException, indicating this condition
        if (this.shape == null){
        	throw new LocationException();
        }
        
        shapeBounds = this.shape.getBounds2D();
        point = new java.awt.geom.Point2D.Float((float) shapeBounds.getCenterX(), 
                                                (float) shapeBounds.getCenterY());

        // if the centre of the bounding box is not within the shape, find point within the shape
        if (!this.shape.contains(point)) {
            // search along axis from point (in direction of thinnest part of the rectangle)
            if (shapeBounds.getHeight() < shapeBounds.getWidth()) {
                while (!this.shape.contains(point) && shapeBounds.contains(point)) {
                    point = new java.awt.geom.Point2D.Float((float) point.getX(), (float) point.getY() + 1);
                }
                // determine the best centred position for the y coordinate of the point by determining the length of the shape
                // at this x coordinate
                testPoint = point;
                while (this.shape.contains(testPoint)){
                    testPoint = new java.awt.geom.Point2D.Float((float) testPoint.getX(), (float) testPoint.getY() + 1);
                }
                point = new java.awt.geom.Point2D.Float((float) point.getX(), (float) ((point.getY() + testPoint.getY()-1)/2));
                // if it wasn't found in the shortest direction, search the other direction
                if (!this.shape.contains(point)) {
                    // reset point to centre of shapeBounds for searching
                    point = new java.awt.geom.Point2D.Float((float) shapeBounds.getCenterX(), (float) shapeBounds.getCenterY());
                    while (!this.shape.contains(point) && shapeBounds.contains(point)) {
                        point = new java.awt.geom.Point2D.Float((float) point.getX(), (float) point.getY() - 1);
                    }
                    // determine the best centred position for the y coordinate of the point by determining the length of the shape
                    // at this x coordinate
                    testPoint = point;
                    while (this.shape.contains(testPoint)){
                        testPoint = new java.awt.geom.Point2D.Float((float) testPoint.getX(), (float) testPoint.getY() - 1);
                    }
                    point = new java.awt.geom.Point2D.Float((float) point.getX(), (float) ((point.getY() + testPoint.getY()+1)/2));
                }   
            } 
            else {
                while (!this.shape.contains(point) && shapeBounds.contains(point)) {
                    point = new java.awt.geom.Point2D.Float((float) point.getX() + 1, (float) point.getY());
                }
                // determine the best centred position for the x coordinate of the point by determining the length of the shape
                // at this y coordinate
                testPoint = point;
                while (this.shape.contains(testPoint)){
                    testPoint = new java.awt.geom.Point2D.Float((float) testPoint.getX() + 1, (float) testPoint.getY());
                }
                point = new java.awt.geom.Point2D.Float((float) ((point.getX() + testPoint.getX()-1)/2), (float) point.getY());
                // if it wasn't found in the shortest direction, search the other direction
                if (!this.shape.contains(point)) {
                    // reset point to centre of shapeBounds for searching
                    point = new java.awt.geom.Point2D.Float((float) shapeBounds.getCenterX(), (float) shapeBounds.getCenterY());
                    while (!this.shape.contains(point) && shapeBounds.contains(point)) {
                        point = new java.awt.geom.Point2D.Float((float) point.getX() - 1, (float) point.getY());
                    }
                    // determine the best centred position for the x coordinate of the point by determining the length of the shape
                    // at this y coordinate
                    testPoint = point;
                    while (this.shape.contains(testPoint)){
                        testPoint = new java.awt.geom.Point2D.Float((float) testPoint.getX() - 1, (float) testPoint.getY());
                    }
                     point = new java.awt.geom.Point2D.Float((float) ((point.getX() + testPoint.getX()+1)/2), (float) point.getY());
                }
            }
        }
        return point;
    }
}
