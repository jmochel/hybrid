/*
 ************************************************************** 
 * $RCSfile: HemlEventMapPlotterForInputText.java,v $                     *
 *                                                            *
 * $Revision: 1.1 $                                           *
 *                                                            *
 * $Date: 2003/03/14 03:42:46 $                               *
 *                                                            *
 * Copyright (C) 2000 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            * 
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Bruce Robertson                                        *
 *     Susan Barnett                                          *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 ************************************************************** 
 */
package org.heml.image.hemlEvent;
import org.heml.image.gridLayout.CylindricalEquidistantMapDefinition;

import org.jdom.Element;
import org.jdom.Namespace;

public class HemlEventMapPlotterForInputText
    extends HemlEventMapPlotter
{
	String text;
    public HemlEventMapPlotterForInputText(org.jdom.Element eventElement, 
                                          CylindricalEquidistantMapDefinition map, String text)
    {
        super(eventElement, map);
	this.text = text;
    }

    public HemlEventMapPlotterForInputText()
    {
        super();
    }

    public String getText() {
	    return this.text;
    }
}
