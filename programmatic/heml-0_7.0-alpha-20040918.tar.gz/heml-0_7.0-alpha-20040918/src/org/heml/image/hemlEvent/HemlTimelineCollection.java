/*
************************************************************** 
* $RCSfile: HemlTimelineCollection.java,v $                  *
*                                                            *
* $Revision: 1.4 $                                           *
*                                                            *
* $Date: 2004/04/07 16:44:21 $                               *
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
* Author:                                                    *
*     Bruce Robertson                                        *
*     Susan Barnett                                          *
*                                                            *
* Contributors:                                              *
*                                                            *
*                                                            *
************************************************************** 
*/
package org.heml.image.hemlEvent;

import java.util.Comparator;

/**
 * Holds a collection of <code>HemlEvent</code>s for timeline purposes.
 */
public final class HemlTimelineCollection extends HemlEventCollection {
	
    static boolean VERBOSE = false;
    /** 
	 * Constructs and initializes an empty <code>HemlTimelineCollection</code>.
	 */ 
    public HemlTimelineCollection() {
        super();
    }

    /***
     * Constructs and initializes a <code>HemlTimelineCollection</code>.
     * @param listIn a list of <code>HemlEvent</code>s.
     */
    public HemlTimelineCollection(java.util.List listIn) {
        super(listIn);
    }
    
    /**
     * Returns a list of <code>HemlTimelineCollection</code>s, representing the original
     * input list but sliced according to chronological concurrency.
     * Each <code>HemlTimelineCollection</code> in the list represents one column for the timeline.
     * @return a list of <code>HemlTimelineCollection</code>s containing this <code>HemlTimelineCollection</code>s
     * <code>HemlEvent</code>s sorted according to chronological concurrency.
     */
    public final java.util.ArrayList getSliced() {
        java.util.ArrayList sliced = new java.util.ArrayList(); // list containing sliced HemlTimelineCollections
        HemlTimelineCollection column = new HemlTimelineCollection(); // initial column
        HemlEvent current; // holds event currently being placed
        int candidate = 0; // holds best candidate for event placement in sliced
  
        // sort the list chronologically
        java.util.Collections.sort(eventList, comparator);
        li = eventList.listIterator();
        
        // add first event to collection and list
        column.add((HemlEvent) li.next());
        sliced.add(column);
        // while there are events to be checked, place them
        while (li.hasNext()) {
        	current = (HemlEvent) li.next();
        	//System.out.println("In while loop and candidate is " + candidate + " " + current.getLabel());
        	// check the current event's concurrency with the latest event in each collection
        	for(int i=0; i<sliced.size(); i++){
        	//	System.out.print("In for loop " + i);
        		// if current was concurrent with both candidates (i.e. sliced[0]), then move onto next index
        		if (candidate == -1){
        			candidate = i;
        		}
        		candidate = getCandidateIndex(current,candidate,i,
        					(HemlTimelineCollection)sliced.get(candidate),(HemlTimelineCollection)sliced.get(i));
        		if (VERBOSE) System.out.println(" Returned from getCandidateIndex successfully");
        	}
        	//System.out.println(current.getLabel() + " candidate is " + candidate + " with " + sliced.size() + " columns");
        	// if all collections had concurrent times, create new collection for list
        	if (candidate == -1){
        		if (VERBOSE) System.out.print("Adding new column ");
        		sliced.add(new HemlTimelineCollection());
                ((HemlTimelineCollection) sliced.get(sliced.size()-1)).add(current);
                //System.out.println("and added successfully");
        	}
        	// else add event to candidate list
        	else{
        	//	System.out.print("Adding to column " + candidate);
        		((HemlTimelineCollection) sliced.get(candidate)).add(current);
        	//	System.out.println(" and added successfully");
        	}
        	// reset candidate for next search
        	candidate = 0;
        }
        //System.out.println("Returning from sliced call and there are " + sliced.size() + " columns in the list.");
        return (sliced);
    }
    
    /**
     * Compares two <code>HemlTimelineCollection</code>s against the input <code>HemlEvent</code> for concurrency.  
     * The <code>HemlTimelineCollection</code> with the largest chronological distance to the <code>HemlEvent</code>
     * is selected as the candidate.  If both <code>HemlEventTimeline</code>s are concurrent to the <code>HemlEvent</code>
     * -1 is returned.
     * @param event the <code>HemlEvent</code> to be used for comparison.
     * @param in1 the index of the first <code>HemlTimelineCollection</code> for comparison.
     * @param in2 the index of the second <code>HemlTimelineCollection</code> for comparison.
     * @param co1 the first <code>HemlTimelineCollection</code> for comparison.
     * @param co2 the second <code>HemlTimelineCollection</code> for comparison.
     * @return the index of the most suitable candidate <code>HemlTimelineCollection</code> if one was found; -1 otherwise.
     **/
     int getCandidateIndex(HemlEvent event, int in1, int in2, HemlTimelineCollection co1, HemlTimelineCollection co2){
     	boolean co1Concurrent, co2Concurrent;
     	long distance1 = 0, distance2 = 0;
     	int candidate;

     	// check concurrency of each candidate
     	co1Concurrent = concurrent( event, (HemlEvent)(co1.get(co1.size()-1)) );
     	co2Concurrent = concurrent( event, (HemlEvent)(co2.get(co2.size()-1)) );
     	// if both collections are concurrent with event, candidate is -1 to indicate this
     	if (co1Concurrent && co2Concurrent){
	     	candidate = -1;
    	}
    	// if only 1 collection is concurrent with event, candidate is the other, whic is most suitable
    	else if (!co1Concurrent && co2Concurrent){
    		candidate = in1;
    	}
    	else if (co1Concurrent && !co2Concurrent){
    		candidate = in2;
    	}
    	// if neither are concurrent, check for the collection with the greatest chronological distance from event
    	else{
    		distance1 = getChronologicalDistance((HemlEvent)(co1.get(co1.size()-1)), event);
    		distance2 = getChronologicalDistance((HemlEvent)(co2.get(co2.size()-1)), event);
    		// return the collection with the farthest distance as candidate
    		if (distance1 >= distance2){
    			candidate = in1;
    		}
    		else {
    			candidate = in2;
    		}
    	}
    	return candidate;
    }
     	
        
    /**
     * Determines whether two events occur concurrently at any point in time.
     * @param current the first <code>HemlEvent</code> to be checked.
     * @param current the second <code>HemlEvent</code> to be checked.
     * @return true if the two <code>HemlEvent</code>s are concurrent at any point in time; false otherwise.
     **/
    private boolean concurrent(HemlEvent current, HemlEvent check) {
        return !(current.getLatestTime() < check.getEarliestTime() || 
               current.getEarliestTime() > check.getLatestTime());
    }
    
    /**
     * Determines the chronological distance between two <code>HemlEvent</code>s.
     * @param he1 the first <code>HemlEvent</code> for comparison.
     * @param he2 the second <code>HemlEvent</code> for compariston.
     * @return the time in milliseconds between each event
     **/
     private long getChronologicalDistance(HemlEvent he1, HemlEvent he2){
     	//System.out.println("event 1 latest time is " + he1.getLatestTime() + " event 2 earliest time is " he2.getEarliestTime());
     	//System.out.println("The difference is " + (he1.getLatestTime()-he2.getEarliestTime()));
		return (Math.abs(he1.getLatestTime()-he2.getEarliestTime()));

     }
}
