/*
**************************************************************
*                                                            * 
* $RCSfile: KeyRing.java,v $   
*                                                            *
* $Revision: 1.2 $ 
*                                                            *
* $Date: 2002/08/23 17:45:19 $  
*                                                            *
* Copyright (C) 2000 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.text;

import java.util.Vector;


public class KeyRing {
    private static final boolean VERBOSE = false;
    private Vector vector;

    public KeyRing() {
        vector = new Vector();
    }

    public String checkKey(String key) {
        for (int x = 0; x < vector.size(); x++) {
            String current = (String) vector.elementAt(x);

            if (VERBOSE) {
                System.out.println("KeyRing.checkKey(): x = " + x + " key= " + 
                                   key + " current element = " + current);
            }

            if (key.equals(current)) {
                return current;
            }
        }

        vector.add(key);

        return key;
    }

    public static void main(String[] args) {
    }
}