/*
**************************************************************
*                                                            * 
* $RCSfile: SvgTextTable.java,v $   
*                                                            *
* $Revision: 1.9 $ 
*                                                            *
* $Date: 2002/10/17 23:31:18 $  
*                                                            *
* Copyright (C) 2002 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.text;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.font.*;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.*;

import java.text.*;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;

import org.apache.xalan.extensions.XSLProcessorContext;
import org.apache.xalan.templates.ElemExtensionCall;

//import com.sun.awt.svg.*;
import org.apache.xerces.dom.*;

import org.apache.xpath.DOMHelper;
import org.apache.xpath.objects.XNodeSet;

import org.w3c.dom.*;


/**
 * Represents the positioned label for an event on a timeline. To be
 * distinguished from a <code>TimelineMarker</code>.
 */
public class SvgTextTable extends WrappingSvgText {
    private static boolean VERBOSE = false;
    private float spaceBetweenColumns;
    private float spaceBetweenRows;
    private float columnWidth;
    private float currentX;
    private float currentY;
    private float maxHeight;
    private String fontName;
    private int fontSize;
    private float height = 0;
    private int columnNumber = 0;

    public SvgTextTable() {
        this(200f, 10f, 10f, 10, "Arial");
    }

    public SvgTextTable(float columnWidth, float spaceBetweenColumns, 
                        float spaceBetweenRows, int fontSize, String fontName) {
        super();
        this.columnWidth = columnWidth;
        this.spaceBetweenColumns = spaceBetweenColumns;
        this.spaceBetweenRows = spaceBetweenRows;
        this.fontSize = fontSize;
        this.fontName = fontName;
    }

    public org.w3c.dom.Node parseTable(org.w3c.dom.Node in) {
        org.jdom.Element tableElement = org.heml.util.JdomUtils.convertToJdomElement(
                                                (org.w3c.dom.Element) in);
        org.jdom.Namespace ns = tableElement.getNamespace();
        java.util.List rowList = tableElement.getChildren("row", ns);

        for (int x = 0; x < rowList.size(); x++) {
            parseRow((org.jdom.Element) rowList.get(x));
            newRow();
        }

        //System.out.println(tableElement.getName());
        return g2.getTopLevelGroup();
    }

    public void parseRow(org.jdom.Element row) {
        //System.out.println("Added row: " + row.getName());
        org.jdom.Element cell;
        org.jdom.Namespace ns = row.getNamespace();
        String link = "";
        String justification;
        float width;
        java.util.List cells = row.getChildren("column", ns);
        org.jdom.Namespace xlink = org.jdom.Namespace.getNamespace(
                                           "http://www.w3.org/2000/xlink/namespace/");

        for (int x = 0; x < cells.size(); x++) {
            cell = (org.jdom.Element) cells.get(x);
            justification = cell.getAttributeValue("justification");

            //System.out.println("For cell " + cell.getText() + " justification is " + justification);
            if (justification != null) {
                setJustification(justification);
            } else {
                setJustification(LEFT);
            }

            try {
                width = Float.parseFloat(cell.getAttributeValue("width"));
            } catch (NumberFormatException e) {
                System.out.println(e);
                width = columnWidth;
            } catch (NullPointerException e) {
                System.out.println(e);
                width = columnWidth;
            }

            link = cell.getAttributeValue("href");

            java.util.List attributes = cell.getAttributes();

            //System.out.println("Link is " + link + " and widht is " + width);
            if ((link == null) || link.equals("")) {
                addCell(width, cell.getText());
            } else {
                addCell(width, cell.getText(), link);
                link = "";
            }
        }
    }

    public void newRow() {
        currentX = 0f;
        columnNumber = 0;
        currentY = currentY + maxHeight + spaceBetweenRows;
        maxHeight = 0f;
    }

    public void addCell(float width, String text) {
        height = print(text, width, LEFT, fontName, fontSize, 0.8f, 
                       ((columnWidth + spaceBetweenColumns) * columnNumber), 
                       currentY) - currentY;

        if (height > maxHeight) {
            maxHeight = height;
        }

        columnNumber++;
    }

    public void addCell(float width, String text, String link) {
        height = printWithLink(text, width, LEFT, fontName, fontSize, 0.8f, 
                               ((columnWidth + spaceBetweenColumns) * columnNumber), 
                               currentY, link) - currentY;

        if (height > maxHeight) {
            maxHeight = height;
        }

        columnNumber++;
    }

    /*
      public void addCell(String text, String link, float passedInColumnWidth, String justification) {
         height = printWithLink(text, passedInColumnWidth, justification, "Times New Roman", 12, 0.8f, ((columnWidth + spaceBetweenColumns) * columnNumber), currentY, link) - currentY;
          if (height > maxHeight) {
             maxHeight = height;
          }
          columnNumber++;
       }
    */
    public static org.w3c.dom.Node parseTableStatic(float columnWidth, 
                                                    float spaceBetweenRows, 
                                                    float spaceBetweenColumns, 
                                                    int fontSize, 
                                                    String fontName, 
                                                    org.w3c.dom.Node in) {
        SvgTextTable stt = new SvgTextTable(columnWidth, spaceBetweenRows, 
                                            spaceBetweenColumns, fontSize, 
                                            fontName);

        return stt.parseTable(in);
    }

    /*
      public static void main(String args[]) {
    SvgTextTable table = new SvgTextTable(100f, 10f, 10f);
    table.addCell("Gratitude, respect and pride.", "http://www.cbc.ca");
    table.addCell("But for the most part, the Queen conformed to the solemn regality of the day, offering her thanks not only for her Jubilee year, but for the 49 years preceding it.");
    table.newRow();
    table.addCell("It's been a pretty remarkable 50 years, by any standard, she said.");
    table.addCell("The day started out with a royal procession through the streets of London from Buckingham Palace to St. Paul's Cathedral.");
    table.newRow();
    table.addCell("Wow");
    table.addCell("Woookoo");
    table.dump(); 
    }
    */
}