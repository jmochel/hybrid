/*
**************************************************************
*                                                            * 
* $RCSfile: WrappingSvgText.java,v $   
*                                                            *
* $Revision: 1.19 $ 
*                                                            *
* $Date: 2003/02/13 16:13:38 $  
*                                                            *
* Copyright (C) 2002 Bruce G. Robertson                      *
*                                                            *
**************************************************************
*                                                            *
* This package is free software; you can redistribute        *
* it and/or modify it under the terms of the GNU Lesser      *
* General Public License as published by the Free Software   *
* Foundation; either version 2.1 of the License, or (at      *
* your option) any later version.                            *
*                                                            * 
* This package is distributed in the hope that it will be    *
* useful, but WITHOUT ANY WARRANTY; without even the implied *
* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
* PURPOSE.  See the GNU Lesser General Public License for    *
* more details.                                              *
*                                                            *
* You should have received a copy of the GNU Lesser General  *
* Public License along with this package; if not, write      *
* to the Free Software Foundation, Inc., 59 Temple Place,    *
* Suite 330, Boston, MA  02111-1307  USA                     *
*                                                            *
**************************************************************
*/
package org.heml.image.text;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font.*;
import java.awt.Graphics2D;
import java.awt.font.*;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.*;

import java.text.*;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.*;

import org.apache.xalan.extensions.XSLProcessorContext;
import org.apache.xalan.templates.ElemExtensionCall;

//import com.sun.awt.svg.*;
import org.apache.xerces.dom.*;

import org.apache.xpath.DOMHelper;
import org.apache.xpath.objects.XNodeSet;

import org.w3c.dom.*;


/**
 * Generates and measures wrapped svg text. 
 */
public class WrappingSvgText {
    private static boolean VERBOSE = false;
    public static final String LEFT = "left"; //default value
    public static final String RIGHT = "right";
    public static final String CENTER = "center";
    public static final String NO_LINK = "";
    String justification = LEFT;
    String text = "";
    java.awt.Color colour;
    java.awt.Font font = new java.awt.Font("Verdana", java.awt.Font.PLAIN, 13);
    protected org.apache.batik.svggen.SVGGraphics2D g2;
    protected float advance;

    public WrappingSvgText() {
        Document domFactory = new DocumentImpl();
        g2 = new SVGGraphics2D(domFactory);
        g2.setSVGCanvasSize(new Dimension(600, 800));
        initialize();
    }

    public WrappingSvgText(SVGGraphics2D graphics) {
        g2 = graphics;
        initialize();
    }

    private void initialize() {
        setFont(font);
        setColor(java.awt.Color.black); //default value
        setAdvance(0.8f); //default value
    }

    public void setGraphics(SVGGraphics2D graphics) {
        g2 = graphics;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setColor(java.awt.Color colour) {
        this.colour = colour;
    }

    public void setFont(java.awt.Font font) {
        this.font = font;
    }

    public void setJustification(String justification) {
        this.justification = justification;
    }

    public void setAdvance(float advance) {
        this.advance = advance;
    }

    public void dump() {
        try {
            java.io.OutputStreamWriter out = new java.io.OutputStreamWriter(
                                                     System.out);
            g2.stream(out, false); //not using css
        } catch (Exception e) {
            System.out.println("Exception on write: " + e);
        }
    }

    public Element generate(String text, float width, String justification, 
                            String fontName, int fontSize, float advance) {
        setText(text);
        setFont(new java.awt.Font(fontName, java.awt.Font.PLAIN, fontSize));
        setAdvance(advance);
        setJustification(justification);
        print(text, width, justification, fontName, fontSize, advance, 0f, 0f, NO_LINK);

        Element out = g2.getTopLevelGroup();

        return out;
    }

    public float getHeight(String text, float width, String justificationParam, 
                           String fontName, int fontSize, float advance) {
        setText(text);
        setFont(new java.awt.Font(fontName, java.awt.Font.PLAIN, fontSize));
        setAdvance(advance);
        setJustification(justification);

        float totalHeight = 0f;
        int oldOffset = 0;
        int newOffset = 0;
        float ascent;
        TextLayout layout;
        AttributedString as = new AttributedString(text);
        setFont(font);
        as.addAttribute(TextAttribute.FONT, font);

        LineBreakMeasurer measurer = new LineBreakMeasurer(as.getIterator(), 
                                                           g2.getFontRenderContext());

        while (measurer.getPosition() < as.getIterator().getEndIndex()) {
            layout = measurer.nextLayout(width);
            ascent = layout.getAscent() * advance;
            totalHeight += (layout.getDescent() + layout.getLeading() + ascent);
        }

        Float f = new Float(totalHeight);

        return totalHeight;
    }

    public void print(float width) {
        float dummy = print(getText(), width, justification, font.getName(), 
                            font.getSize(), advance, 0f, 0f, NO_LINK);
    }

    public float print(float width, String localText) {
        return print(localText, width, justification, font.getName(), 
                     font.getSize(), advance, 0f, 0f, NO_LINK);
    }

    public float print(String localText, float width, String justificationParam,        String fontName, int fontSize, float advanceParam,
                       float xParam, float yParam) {
        return print(localText, width, justificationParam, fontName, fontSize,
            advanceParam, xParam, yParam, NO_LINK);
          }

        public float print(String localText, float width, String justificationParam, 
                       String fontName, int fontSize, float advanceParam, 
                       float xParam, float yParam, String link) {
        float x = xParam;
        float y = yParam;
        float lineAdvance;
        java.awt.geom.Point2D.Float pen = new java.awt.geom.Point2D.Float(x, y);
        int oldOffset;
        int newOffset = 0;
        float ascent = 0f;
        java.awt.Font thisFont = new java.awt.Font(fontName, 
                                                   java.awt.Font.PLAIN, 
                                                   fontSize);
        setAdvance(advanceParam);
        setJustification(justificationParam);

        if (VERBOSE) {
            System.out.println("String is: " + localText);
            System.out.println("Total width is: " + width);
        }

        AttributedString as = new AttributedString(localText);

        if (VERBOSE) {
            System.out.println("Font is: " + thisFont);
        }

        if (VERBOSE) {
            System.out.println("g2 is: " + g2);
        }

        g2.setFont(thisFont);
        g2.setColor(colour);
        as.addAttribute(TextAttribute.FONT, thisFont);
        as.addAttribute(TextAttribute.FOREGROUND, colour);

        LineBreakMeasurer measurer = new LineBreakMeasurer(as.getIterator(), 
                                                           g2.getFontRenderContext());

        while (measurer.getPosition() < as.getIterator().getEndIndex()) {
            oldOffset = newOffset;
            newOffset = measurer.nextOffset(width);

            if (VERBOSE) {
                System.out.println("this offset runs: " + oldOffset + " to " + 
                                   newOffset);
                System.out.println("that is: #" + 
                                   localText.substring(oldOffset, newOffset) + 
                                   "#");
            }

            TextLayout layout = measurer.nextLayout(width);
            lineAdvance = layout.getAdvance();

            ascent = layout.getAscent() * advance;
            pen.y += ascent; //one half space between lines of single event

            //the actual point at which the pen drops depends on the 
            //justification of this line's rendering.
            float thisLinesX;

            if (justification.equalsIgnoreCase(RIGHT)) {
                thisLinesX = x - lineAdvance;
            } else if (justification.equalsIgnoreCase(CENTER)) {
                thisLinesX = x - (lineAdvance / 2f);
            } else {
                thisLinesX = x;
            }

            int temporaryNewOffset = newOffset;

            if (localText.charAt(newOffset - 1) == ' ') {
                temporaryNewOffset = newOffset - 1;
            }


            //            layout.draw(g2, thisLinesX, pen.y);
            //this will produce a <text element
            g2.drawString(localText.substring(oldOffset, temporaryNewOffset), 
                          thisLinesX, pen.y);
            if (link != "" && link != null) {
            Element previousTop = g2.getTopLevelGroup(false);
            Document factory = g2.getDOMFactory();
            Element a = factory.createElementNS("http://www.w3.org/2000/svg", "a");
            a.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", link);
            Element rect = factory.createElementNS("http://www.w3.org/2000/svg", "rect");
            rect.setAttribute("x", Float.toString(thisLinesX));
            rect.setAttribute("y", Float.toString(pen.y - ascent));
            rect.setAttribute("opacity", "0");
            rect.setAttribute("width", Float.toString(width));
            rect.setAttribute("height", Float.toString(ascent));
             a.appendChild(rect);
            previousTop.appendChild(a);
             //a.appendChild(previousTop);
             //previousTop.appendChild(a);
             g2.setTopLevelGroup(previousTop);
           }
            pen.y += (layout.getDescent() + layout.getLeading());
        }

        oldOffset = 0;
        newOffset = 0;

        return pen.y;
    }

    protected float printWithLink(String localText, float width, 
                                  String justificationParam, String fontName, 
                                  int fontSize, float advanceParam, 
                                  float xParam, float yParam, String link) {
        float  height = print (localText, width, justificationParam, fontName, fontSize, advanceParam, xParam, yParam, link);
        return height;
    }

    protected float printWithLink(String localText, float width, String link) {
        setText(localText);

        float height = print(localText, width, justification, font.getName(), font.getSize(), advance, 0f, 0f, link);

        return height;
    }

    /**********
      * Returns the element wrapped with an <code>xml:link</code>
      * tag.
      */
    private Element wrapWithLink(Element element, String link) {
        Document myDocument = g2.getDOMFactory();
        Element a = myDocument.createElement("a");

        if (VERBOSE) {
            System.out.println("Adding a link to svg: " + link);
        }

        a.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", link);
        a.appendChild(element);

        return a;

        //Comment the above line, and uncomment the following
        //to stop links being added so that the 
        //resulting svg can be converted to pdf by the buggy 
        //fop.
        //return element;
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage:");
            System.out.println(
                    "org.heml.image.text.WrappingSvgText StringToBeWrapped WrappingWidth {LEFT|RIGHT|CENTER} [FontName] [FontSize] [Advance]");
            System.out.println(
                    "(For a list of font families on your system, run org.heml.util.ListFontNames)");
            System.exit(0);
        }

        java.lang.Float widthObject = java.lang.Float.valueOf(args[1]);
        float width = widthObject.floatValue();
        String justification = args[2];
        WrappingSvgText wst = new WrappingSvgText();
        wst.setJustification(justification);

        //default font
        Font localFont = new java.awt.Font("Verdana", java.awt.Font.PLAIN, 13);

        if (args.length > 3) {
            localFont = new java.awt.Font(args[3], java.awt.Font.PLAIN, 
                                          java.lang.Integer.parseInt(args[4]));
        }

        float advance = 0.8f;

        if (args.length > 5) {
            java.lang.Float advanceObject = java.lang.Float.valueOf(args[5]);
            advance = advanceObject.floatValue();
        }

        wst.setAdvance(advance);

        float foo = wst.print(args[0], width, justification, args[3], 
                              java.lang.Integer.parseInt(args[4]), advance, 0f, 
                              0f, NO_LINK);
        wst.dump();
        System.out.println("Final y = " + foo);

        //     System.out.println("Height: " + wst.getHeight(width));
    }
}
