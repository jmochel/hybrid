/*
 **************************************************************
 *                                                            *
 * $RCSfile: SvgFontEmbedder.java,v $
 *                                                            *
 * $Revision: 1.3 $
 *                                                            *
 * $Date: 2003/02/19 14:01:53 $
 *                                                            *
 * Copyright (C) 2002 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 *                                                            *
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            *
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 */
package org.heml.image.text;

import java.awt.*;
import java.awt.Color.*;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.*;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.*;

import java.text.*;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.dom.svg.*;
import org.apache.batik.svggen.*;

import org.apache.xalan.extensions.XSLProcessorContext;
import org.apache.xalan.templates.ElemExtensionCall;


//import com.sun.awt.svg.*;
import org.apache.xerces.dom.*;

import org.apache.xpath.DOMHelper;
import org.apache.xpath.objects.XNodeSet;

import org.w3c.dom.*;
import org.w3c.dom.svg.*;


/**
 * Uses the Batik SVGGraphics2D environment to produce an svg:defs element
 * containing the smallest necessary font and glyph definitions. Call
 * <code>registerFont(text, fontName)</code> for each svg:text element in the document,
 * then get the defs with the <code>getEmbeddedFonts()</code> method The
 * web/xslt/util/svgEmbedFonts.xsl file from the Heml project
 * (http://www.heml.org) illustrates how to  use this code within a Xalan
 * xslt envrionment to embed fonts in arbitrary SVG documents. 
 * <p>This code has been tested with Batik's 1.5b2 and 1.5b4 releases. Future releases may well
 * place the necessary <code>svg:def</code> element in a different place. This would require
 * a rewrite of this class' <code>registerFont()</code> method.
 *<p>This class works in the following way. Each call to <code>registerFont()</code> draws a bogus text string on a Batik SVGGraphics2D environment which has been
 * set to use embedded fonts. The <code>getEmbeddedFonts()</code> method copies the svg:def element to which Batik writes its font definitions
 */
public class SvgFontEmbedder
{

    SVGGraphics2D svggen;

    public SvgFontEmbedder()
    {

        DOMImplementation   impl  = SVGDOMImplementation.getDOMImplementation();
        String              svgNS = SVGDOMImplementation.SVG_NAMESPACE_URI;
        SVGDocument         doc   = (SVGDocument)impl.createDocument(svgNS, 
                                                                     "svg", 
                                                                     null);
        SVGGeneratorContext ctx   = SVGGeneratorContext.createDefault(doc);
        ctx.setEmbeddedFontsOn(true);
        svggen = new SVGGraphics2D(ctx, false);
    }

    /**
     * Indicates the use of <code>fontName</code> on the string
     * <code>text</code>
     * 
     * @param text the String that will be displayed
     * @param fontName the name of the font that will display the text
     */
    public void registerFont(String text, String fontName)
    {

        //Sometimes fonts from SVG have bogus single quotes around them
        if (fontName.startsWith("'"))
        {
            fontName = fontName.substring(1, fontName.length() - 1);

            // System.out.println("Detected single quotes, using fontName: " + fontName);
        }

        //System.out.println("SvgFontEmbedder: " + text + " fontname: " + fontName);
        Font font = new Font(fontName, java.awt.Font.PLAIN, 10);
        svggen.setFont(font);
        svggen.drawString(text, 100f, 100f);
    }

    /**
     * @return an <code>svg:defs</code> element containing the fonts and
     *         glyphs necessary to display the texts which have been
     *         specified  through sucessive calls to {@link fontName}
     */
    public Element getEmbeddedFonts()
    {

        Element gElement = (Element)svggen.getRoot().getElementsByTagNameNS(
                                            SVGDOMImplementation.SVG_NAMESPACE_URI, 
                                            SVGDOMImplementation.SVG_G_TAG).item(
                                   0);
        Element defs = (Element)gElement.getElementsByTagNameNS(
                                        SVGDOMImplementation.SVG_NAMESPACE_URI, 
                                        SVGDOMImplementation.SVG_DEFS_TAG).item(
                               0);

        return defs;
    }

    /**
     * A test of this class. Pass in 1) A sample text string, and 2) a font
     * name string. The method will print the corresponding svg:def element
     * to System.out
     */
    public static void main(String[] args)
    {

        if (args.length < 2)
        {
            System.out.println("Usage:");
            System.out.println(
                    "org.heml.image.text.SvgFontEmbedder String FontName");
            System.out.println(
                    "(For a list of font families on your system, run org.heml.util.ListFontNames)");
            System.exit(0);
        }

        SvgFontEmbedder fontEmb = new SvgFontEmbedder();
        fontEmb.registerFont(args[0], args[1]);

        try
        {

            org.apache.xml.serialize.XMLSerializer serializer = 
                    new org.apache.xml.serialize.XMLSerializer(System.out, 
                                                               new org.apache.xml.serialize.OutputFormat());
            serializer.serialize(fontEmb.getEmbeddedFonts());
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
