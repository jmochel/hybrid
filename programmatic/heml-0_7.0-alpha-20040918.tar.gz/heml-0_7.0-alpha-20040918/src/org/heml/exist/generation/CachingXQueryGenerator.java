/*
 **************************************************************
 * $RCSfile: CachingXQueryGenerator.java,v $                               *
 *                                                            *
 * $Revision: 1.3 $                                          *
 *                                                            *
 * $Date: 2004/09/08 17:46:43 $                               *
 *                                                            *
 * Copyright (C) 2004 Bruce G. Robertson                      *
 *                                                            *
 **************************************************************
 * This package is free software; you can redistribute        *
 * it and/or modify it under the terms of the GNU Lesser      *
 * General Public License as published by the Free Software   *
 * Foundation; either version 2.1 of the License, or (at      *
 * your option) any later version.                            *
 *                                                            *
 * This package is distributed in the hope that it will be    *
 * useful, but WITHOUT ANY WARRANTY; without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR    *
 * PURPOSE.  See the GNU Lesser General Public License for    *
 * more details.                                              *
 *                                                            *
 * You should have received a copy of the GNU Lesser General  *
 * Public License along with this package; if not, write      *
 * to the Free Software Foundation, Inc., 59 Temple Place,    *
 * Suite 330, Boston, MA  02111-1307  USA                     *
 *                                                            *
 **************************************************************
 * Author:                                                    *
 *     Bruce Robertson                                        *
 *                                                            *
 * Contributors:                                              *
 *                                                            *
 *                                                            *
 **************************************************************
 */
package org.heml.exist.generation;

import java.io.IOException;

import java.util.Map;

import org.apache.avalon.framework.parameters.Parameters;

import org.apache.cocoon.ProcessingException;
import org.apache.cocoon.caching.CacheableProcessingComponent;
import org.apache.cocoon.components.source.SourceUtil;
import org.apache.cocoon.environment.ObjectModelHelper;
import org.apache.cocoon.environment.SourceResolver;

import org.apache.excalibur.source.Source;
import org.apache.excalibur.source.SourceException;
import org.apache.excalibur.source.SourceValidity;

import org.exist.cocoon.XQueryGenerator;

import org.xml.sax.SAXException;


/**
 A XQueryGenerator which allows caching of its responses. The cache key is the 
 URL query string. For instance, a query such as 
 ?query=descendant%3A%3Aheml%3APersonRef%2F%40uriRef%3D%22%23gos-person-999%22
 would be cached and could be used for various views.
 **/
public class CachingXQueryGenerator
    extends XQueryGenerator
    implements CacheableProcessingComponent
{
    public java.io.Serializable getKey()
    {

        String uriQuery = null;
        String xqueryPart = null;
        String xQuery = null;
        try
        {
            uriQuery = ObjectModelHelper.getRequest(objectModel).getQueryString();
          //System.out.println("uriQuery: " + uriQuery);
          int queryStart=uriQuery.indexOf("query=");
          //System.out.println("index of query " + queryStart);
          String mine  = uriQuery.substring(queryStart);
          //System.out.println("mine: " + mine);
          int ampersandIndex = mine.indexOf("&");
          if (ampersandIndex == -1) {
           xQuery = mine;
          }
          else {
            xQuery = mine.substring(0,ampersandIndex);
          }
          //System.out.println("Xquery: " + xQuery);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

        //the queryText has <return> characters, which seem to end the caching
        //key. This is either bad for us or pointless, so I've skipped using
        //it in the key.
        String theKey = xQuery;

        //System.out.println("cachingxquery: Key --" + theKey);
        return theKey;
    }

    public SourceValidity getValidity()
    {

        //Returns the validity of the xquery file, which is a decent compromise
        return this.inputSource.getValidity();
    }
}
