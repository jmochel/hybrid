//***************************************************************//
//                                                               //
//   $RCSfile: mapAnimation.js,v $                               //
//                                                               //
//   $Revision: 1.49 $                                            //
//                                                               //
//   $Date: 2002/08/08 12:04:43 $                                //
//                                                               //
//   Copyright (C) 2002 Bruce Robertson                          //
//                      Susan Barnett                            //
//                                                               //
//***************************************************************//
//                                                               //
//   This package is free software; you can redistribute         //
//   it and/or modify it under the terms of the GNU Lesser       //
//   General Public License as published by the Free Software    //
//   Foundation; either version 2.1 of the License, or (at       //
//   your option) any later version.                             //
//                                                               //
//   This package is distributed in the hope that it will be     //
//   useful, but WITHOUT ANY WARRANTY; without even the implied  //
//   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR     //
//   PURPOSE.  See the GNU Lesser General Public License for     //
//   more details.                                               //
//                                                               //
//   You should have received a copy of the GNU Lesser General   //
//   Public License along with this package; if not, write       //
//   to the Free Software Foundation, Inc., 59 Temple Place,     //
//   Suite 330, Boston, MA  02111-1307  USA                      //
//                                                               //
//***************************************************************//

  /**                 NOTE: all time is in milliseconds, all distances in pixels                    **/
  /** Couldn't use an anonymous function to pass in object to eventListener.  Adobe's viewer breaks **/
  /** Therefore must determine name of calling instance when using methods called by eventListeners **/

  /** global variables **/

  /* CONSTANTS */
  var FACTOR       = 4;           // fast forward/rewind factor
  var VIS_DURATION = 2000;        // floor for visibility of event
  var MIN_DURATION = 10000;       // minimum duration length
  var MAX_DURATION = 120000;      // maximum duration length
  var SLIDER_VIS   = 100;         // minimum time a date should be visible on slider
  var MS_PER_YEAR  = 31536000000; // number of ms in a year (ms*sec*min*hour*days_in_year)


  // declaration of variables that hold manipulating objects
  var gSVGObj;   // target SVG document
  var sliderObj; // timeline slider
  var durObj;    // duration slider
  var startButton;
  var stopButton;
  var pauseButton;
  var forwardButton;
  var rewindButton; 
  var hemlObj;   // events to be manipulated on map

  // date information
  var gEndDate;
  var gStartDate;

  // input presentation parameters
  var gLineBegins = 11;    // where does the line start? (x axis)
  var gLineLength;         // how long is the line?
  var gScale;              // scalar for map transformation matrix


  /******************************************
  *
  * init(e, duration, map_width, map_height, width_scale)
  *
  * - identify target svg object
  * - set line and time variables from input parameters
  * - create objects required for animated_map manipulation
  *
  *******************************************/
  function init(e, map_width, map_height, width_scale) {
    gSVGObj     = e.getTarget().getOwnerDocument(); // set target document
    gLineLength = map_width-(gLineBegins); // set length of line
    gScale = width_scale/map_width; // scale the timline length has changed for dragging calculations

    // set the slider line coordinates to match the map
    gSVGObj.getElementById('slider_line').setAttribute('x1', gLineBegins);
    gSVGObj.getElementById('slider_line').setAttribute('x2', gLineLength);

    // set mat attributes for picking up mouseup events
    gSVGObj.getElementById('mat').setAttribute('width',map_width);
    gSVGObj.getElementById('mat').setAttribute('height',(map_height+100));

    // set time information based on input parameters
    gStartDate    = new Date (earliestTime() * 1);
    gEndDate      = new Date (latestTime() * 1);

    // set the max/min duration times calculated on span of years - add 6000ms per 100 years
    var factor = (gEndDate.getFullYear()-gStartDate.getFullYear())/100;
    MAX_DURATION = MAX_DURATION+6000*factor;
    MIN_DURATION = MIN_DURATION+6000*factor;
    var duration = MIN_DURATION + (MIN_DURATION/2);

    // create objects to manipulate SVG
    sliderObj     = new Slider (duration);
    durObj        = new Duration();
    hemlObj       = new HemlEvent();   
    stopButton    = new Button ('stop');
    startButton   = new Button ('start');
    pauseButton   = new Button ('pause');
    forwardButton = new Button ('forward');
    rewindButton  = new Button ('rewind');

    // now that the timline information has been set, make it visible
    gSVGObj.getElementById('slider').setAttribute('visibility', 'visible');
  }




  /******************************************
  *
  * Duration class
  * ------------
  *
  * - calculates the desired duration
  * - reinitializes the slider based upon this duration
  * - slider will start from beginning after duration change
  *
  *******************************************/

  /***
  *
  * Duration constructor
  * 
  * - sets duration objects
  * - adds an event listener for drag 
  *
  ***/
  function Duration(){
    this.slider   = gSVGObj.getElementById('duration_slider');
    this.handler  = gSVGObj.getElementById('mat');
    this.active   = false; // is the mousedown?    
    this.timer    = gSVGObj.getElementById('duration_timer');
    this.delta    = (MAX_DURATION-MIN_DURATION)/180; // duration span/length of slider in pixels
    this.set_date = sliderObj.current;

    // set position of slider to match default duration time and set time label
    this.slider.setAttribute('transform','translate(' + ((sliderObj.duration-MIN_DURATION)/this.delta) + '0,)');
    var nText = gSVGObj.createTextNode(Math.round(sliderObj.duration/1000));
    this.timer.replaceChild(nText,this.timer.firstChild);

    this.slider.addEventListener("mousedown",this.startDrag,false);
  }


  /***
  *
  * Duration.startDrag(e)
  *
  * - get offset for duration slider dragging
  * - add event listeners for starting and stopping dragging
  *
  ***/
  Duration.prototype.startDrag = function (e){
    durObj.active = true;

    // manipulate animation and set buttons to show current state
    if (startButton.active){
      sliderObj.stop();
      stopButton.highlight.setAttribute('fill','crimson');
    }

    // set date for slider pointer
    if (sliderObj.current != gStartDate.getTime()){
	durObj.set_date = sliderObj.current;
    }

    // set offset for possible mousemove event
    var matrix    = e.getTarget().getParentNode().getCTM();
    durObj.offset = matrix.e - e.getClientX();

    // set outline rectangle to register mouseup event
    durObj.handler.setAttribute('pointer-events','visible');

    // register mouse events that will be handled following a mouseDown event
    durObj.handler.addEventListener("mousemove",durObj.drag,false);
    durObj.handler.addEventListener("mouseup",durObj.endDrag,false);
  };


  /***
  *
  * Duration.drag(e)
  *
  * - calculate new position for duration slider based upon 'e'
  *
  ***/
  Duration.prototype.drag = function (e){
    if (durObj.active){
      // calculate new position of pointer through a transformation			
      durObj.slider.setAttribute('transform',"translate(" + durObj.getX(e) + ",0)");
    }
  };


  /***
  *
  * Duration.endDrag(e)
  *
  * - calculate new duration based upon 'e'
  * - reset animation variables based upon new sliderObj.duration
  * - remove slider event listeners
  *
  ***/
  Duration.prototype.endDrag = function (e){
    var duration, position;

    if (durObj.active){
      var matrix   = e.getTarget().getParentNode().getCTM();
      position     = durObj.getX(e);
	   
      // extra check to make sure duration does not exceed max/min
      if      (position <=  0 ) { duration = MIN_DURATION; }
      else if (position >= 180) { duration = MAX_DURATION; }
      else                      { duration = MIN_DURATION + (durObj.delta*durObj.getX(e)); } // calculate by position

      var nText = gSVGObj.createTextNode(Math.round(duration/1000));
      durObj.timer.replaceChild(nText,durObj.timer.firstChild);

      // reset the slider object with new duration information
      sliderObj = new Slider (duration);

      // keep date at current position until restart
      sliderObj.setSlider(durObj.set_date);

      durObj.active = false;

      // prevent outline rectangle from picking up mouseup events
      durObj.handler.setAttribute('pointer-events','none');
	
      // deregister mouse events that will be handled following a mouseDown event
      durObj.handler.removeEventListener("mousemove",durObj.drag,false);
      durObj.handler.removeEventListener("mouseup",durObj.endDrag,false);
    }
  };


  /***
  *
  * Duration.getX(e)
  *
  * - calculate the transformation required on the x axis with respect to: 
  *     - current mouse event
  *     - x offset
  * - if mouse is beyond limits of selector, return coordinate for relative ends of selector
  *                    
  ***/
  Duration.prototype.getX = function (e){ 

    // if the x coordinate is to the left of the beginning of the selector, stop at beginning of selector
    if (e.getClientX() < 303){ return (303 + this.offset); }

    // if the x coordinate is to the right of the end of the selector, stop at the end of the selector
    else if (e.getClientX() > 433){ return (433 + this.offset); }

    // else calculate transformation on current x coordinate
    else { return (e.getClientX() + this.offset); } 
  };






  /******************************************
  *
  * Button class
  * ------------
  *
  * - allows for dragging of duration slider
  * - calculates the desired duration
  * - reinitializes the slider based upon this duration
  *
  *******************************************/

  /***
  *
  * Button constructor
  * 
  * - adds event listeners for onmouseup and hover 
  *
  ***/
  function Button(type){
    var listener;

    this.button    = gSVGObj.getElementById(type);
    this.highlight = gSVGObj.getElementById(type + '_indicator');
    this.active    = false;
    this.hover     = false;
    this.action    = type;

	// set variable 'listener' to appropriate function
    switch(type){
      case 'start':   listener = sliderObj.start;      break;
      case 'stop':    listener = sliderObj.stop;       break;
      case 'pause':   listener = sliderObj.pause;      break;
      case 'forward': listener = sliderObj.forward;    break;
      case 'rewind':  listener = sliderObj.rewind;     break;
    }

    this.button.addEventListener("mousedown", listener, false);
    this.button.addEventListener("mouseover",this.show, false);
  }


  /***
  *
  * Button.show(e)
  *
  * - onmouseover of control buttons, show colour
  * - add event listener for the mouseout event
  *
  ***/
  Button.prototype.show = function (e){
   instance = getButtonObject(e.getTarget().getParentNode().id);

   instance.hover = true;
   instance.highlight.setAttribute('fill','crimson');

   instance.button.addEventListener("mouseout",instance.hide,false);
  };


  /***
  *
  * Button.hide (e)
  *
  * - onmouseout of control buttons, hide colour if button not active
  * - remove mouseout event listener
  *
  ***/
  Button.prototype.hide = function (e){
    instance = getButtonObject(e.getTarget().getParentNode().id);

    // only hide colour if button not active
    if (!instance.active){
      instance.highlight.setAttribute('fill','none');
    }
    instance.hover = false;

    instance.button.removeEventListener("mouseout",instance.hide,false);
  };





  /******************************************
  *
  * Slider class
  * ------------
  *
  * - assigns and manipulates dates on timeline slider
  * - calculates the desired interval length
  * - manipulates the animation
  * - allows for dragging of slider
  *
  *******************************************/


  /***
  *
  * Slider constructor
  *
  * - calculates the interval in days and sets initial dates
  * - resolution of dates depends upon interval with respect to SLIDER_VIS
  * - NOTE: currently does not take leap years into account
  *
  ***/
  function Slider(duration){
    var startTextElem, endTextElem;

    this.duration    = duration;	
    this.active      = false;	
    this.slider      = gSVGObj.getElementById('slider_pointer');
    this.handler     = gSVGObj.getElementById('mat');
    this.start_text  = gSVGObj.getElementById('start_date');
    this.end_text    = gSVGObj.getElementById('end_date');
    this.interval_code; // holds the current interval set and clear code

    // calculate variables required for manipulation
    this.pixels_per_ms  = ((gLineLength-gLineBegins)*gScale)/this.duration;
    this.time_per_pixel = (gEndDate.getTime()-gStartDate.getTime())/((gLineLength-gLineBegins)*gScale);

    // determine how many ms in animation time with respect to historical year
    var time_slice = this.duration/(Math.abs(gEndDate.getTime()-gStartDate.getTime())/MS_PER_YEAR);

    // if the interval is too small to show months, the interval is set to years
    if (time_slice < (12*SLIDER_VIS)){
      this.interval   = time_slice;
      this.setSlider  = this.setToYear;
      this.setDate    = this.setYearIncrement;
      this.resolution = MS_PER_YEAR;      
      startTextElem   = gSVGObj.createTextNode(numToGregorianEraYear(gStartDate.getFullYear()));
      endTextElem     = gSVGObj.createTextNode(numToGregorianEraYear(gEndDate.getFullYear()));
    }   
    // if the interval is large enough to show months, but not large enough to show days, the interval is set to months
    else if (time_slice >= (12*SLIDER_VIS) && time_slice < (365*SLIDER_VIS)){ 
      this.interval   = this.duration/((Math.abs(gEndDate.getTime()-gStartDate.getTime())/(MS_PER_YEAR/12)));
      this.setSlider  = this.setToMonth;
      this.setDate    = this.setMonthIncrement;
      this.resolution = MS_PER_YEAR/12;
      startTextElem   = gSVGObj.createTextNode(numToGregorianEraYear(gStartDate.getFullYear()) + "-" + Number(gStartDate.getMonth()+1));
      endTextElem     = gSVGObj.createTextNode(numToGregorianEraYear(gEndDate.getFullYear()) + "-" + Number(gEndDate.getMonth()+1));     
    }
    // if the interval is large enough to show days, the interval is set to days
    else{    
      this.interval   = this.duration/((Math.abs(gEndDate.getTime()-gStartDate.getTime())/(MS_PER_YEAR/365)));
      this.setSlider  = this.setToDate; 
      this.setDate    = this.setDateIncrement;
      this.resolution = MS_PER_YEAR/365;
      startTextElem   = gSVGObj.createTextNode(numToGregorianEraYear(gStartDate.getFullYear()) + "-" + Number(gStartDate.getMonth()+1) + "-" + gStartDate.getDate());
      endTextElem     = gSVGObj.createTextNode(numToGregorianEraYear(gEndDate.getFullYear()) + "-" + Number(gEndDate.getMonth()+1) + "-" + gEndDate.getDate());    
    }

    // set timeline dates
    this.start_text.replaceChild(startTextElem,this.start_text.firstChild);       
    this.end_text.replaceChild(endTextElem,this.end_text.firstChild);
	   
    // set the initial slider date to start date if the slider is at the beginning of the timeline
    this.current = gStartDate.getTime();     
    this.setSlider(this.current);

    // add event listener in case of drag
    this.slider.addEventListener("mousedown",this.startDrag,false);
  }


  /***
  *
  * Slider.startDrag(e)
  *
  * - add event listeners for start and stop of drag
  * - allow covering rectangle to pick up mouseup event
  * - set offset value for drag
  *
  ***/
  Slider.prototype.startDrag = function(e){
    sliderObj.active = true;

    if (startButton.active){
      var pause_active = pauseButton.active;
      sliderObj.stop();
      stopButton.active = false;
      startButton.active = true;
      startButton.highlight.setAttribute('fill','crimson');
      if (pause_active){
        pauseButton.active = true;
        pauseButton.highlight.setAttribute('fill','crimson');
      }
    }

    // set offset for possible mousemove event
    var matrix       = e.getTarget().getParentNode().getCTM();
    sliderObj.offset = matrix.e - e.getClientX();

    // set outline rectangle to register mouseup event
    sliderObj.handler.setAttribute('pointer-events','visible');

    // register mouse events that will be handled following a mousedown event
    sliderObj.handler.addEventListener("mousemove",sliderObj.drag,false);
    sliderObj.handler.addEventListener("mouseup",sliderObj.endDrag,false);
  };


  /***
  *
  * Slider.drag(e)
  *
  * - x value set according to mouse's current coordinates
  * - transform slider pointer by x
  * - set visibility of events
  *
  ***/
  Slider.prototype.drag = function (e){
    if (sliderObj.active){
      // calculate current date via starting date + (pixels travelled * historical time per pixel)
      sliderObj.current = gStartDate.getTime() + ((e.getClientX()-((15+gLineBegins)*gScale))*sliderObj.time_per_pixel);

      // failsafe to make sure dates don't go beyond the start and end dates for the animation
      if (sliderObj.current < gStartDate.getTime()){ sliderObj.current = gStartDate.getTime(); }
      if (sliderObj.current > gEndDate.getTime())  { sliderObj.current = gEndDate.getTime();   }
 	
      // set pointer date and event visibility
      sliderObj.setSlider(sliderObj.current);			
      hemlObj.setForDrag();

      // calculate new position of pointer through a transformation			
      sliderObj.slider.setAttribute('transform',"translate(" + sliderObj.getX(e) + ",0)");
    }
  };


  /***
  *
  * Slider.endDrag(e)
  *
  * - if animation is currently running
  *   - restart animation with new values based upon 'e'
  * - remove event listeners
  *
  ***/

  Slider.prototype.endDrag = function (e){
    if (sliderObj.active){ 
      // determine new duration value (as the relative portion of this.duration)
      var new_duration = sliderObj.duration-((e.getClientX()-((15+gLineBegins)*gScale))*sliderObj.pixels_per_ms);
      hemlObj.animation.setAttribute('dur', new_duration + 'ms');

      // set translation to current mouse pointer less the original offset from zero
      sliderObj.slider.setAttribute('transform', 'translate(' + sliderObj.getX(e) + ',0)');

      // recalculate the end point of the animation based upon the above translation
      hemlObj.animation.setAttribute('to', (gLineLength-e.getClientX()) + ',0');

      hemlObj.setAnimationMid(new_duration);

      // start the animation if it was active immediately prior to drag
      if (startButton.active){
        sliderObj.intervalState("set");     
	// reset visibility attributes of event nodes to visible
        hemlObj.setVisibility("show");
        hemlObj.animation.beginElement();
	if (pauseButton.active){
          gSVGObj.getElementById('animated_svg').pauseAnimations();
	}
      }
    } // end if active

    // prevent outline rectangle from picking up mouseup events
    sliderObj.handler.setAttribute('pointer-events','none');

    // unregister mouse events that will be handled following a mousedown event
    sliderObj.handler.removeEventListener("mousemove",sliderObj.drag,false);
    sliderObj.handler.removeEventListener("mouseup",sliderObj.endDrag,false);

  };


  /***
  *
  * Slider.getX(e)
  *
  * - calculate the transformation required on the x axis with respect to: 
  *     - current mouse event
  *     - x offset
  * - if mouse is beyond limits of selector, return coordinate for relative ends of selector
  *                    
  ***/
  Slider.prototype.getX = function (e){ 
    // calculate new x coordinate while ensuring slider does not go beyond beginning or end of timeline
    // 15 is currently the translation on the x axis, so must be taken into account
    if      (e.getClientX() < (gLineBegins+15)) { return (gLineBegins + 15 + this.offset); }
    else if (e.getClientX() > gLineLength) { return (gLineLength + this.offset); }
    else    { return (e.getClientX() + this.offset); }// else calculate transformation on current x coordinate
  };


  /***
  * Slider.start(e)
  *
  * - start animation from the beginning with initial variables
  * - called when play button hit for
  *    - initial start
  *    - restart after stop or end of animation reached
  *    - restart while running
  *
  ***/

  Slider.prototype.start = function(e){

    // set control buttons to reflect current state
    stopButton.highlight.setAttribute('fill','none');
    stopButton.active = false;

    // if the animation is currently running, setInterval will need to be cleared
    if (startButton.active){
      sliderObj.intervalState("clear"); // clear last setInterval
    }

    // if element was paused when started, unpause it
    if (pauseButton.active && !durObj.active){ 
      gSVGObj.getElementById('animated_svg').unpauseAnimations(); 
      pauseButton.highlight.setAttribute('fill','none');    
    }  

    // set values to original state    
    hemlObj.setAnimationStart(); // set animation variables to initial values
    sliderObj.current = gStartDate.getTime();
    sliderObj.setSlider(sliderObj.current); // reset pointer date to beginning

    // reset visibility attributes of event nodes to visible
    hemlObj.setVisibility("show");

    // start animation and interval
    sliderObj.intervalState("set");
    hemlObj.animation.beginElement();
    startButton.active = true;

  };


  /***
  *
  * Slider.stop(e)
  *
  * - called when onclick stop button
  * - if animation is currently running 
  *   - unpauses animation if paused and calls ceaseAnimation()
  *
  ***/
  Slider.prototype.stop = function(e){

    // only need to stop animation if it is currently running
    if (startButton.active){	

      stopButton.active = true;
      startButton.active = false;

      // set control buttons to reflect current state
      startButton.highlight.setAttribute('fill','none');

      // end animation and clear interval
      hemlObj.stopAnimation();

      // if element was paused when started, unpause it
      if (pauseButton.active){ 
        gSVGObj.getElementById('animated_svg').unpauseAnimations(); 
        pauseButton.highlight.setAttribute('fill','none'); 
        pauseButton.active = false;   
      }
    } // end if active
  };


  /***
  *
  * Slider.pause(e)
  *
  * - execute only if animation is currently running
  * - if not paused, pause animation
  * - if paused, unpause animation
  *
  ***/
  Slider.prototype.pause = function(e){

    // only pause if the animation is already running
    if (startButton.active){

      if (gSVGObj.getElementById('animated_svg').animationsPaused()){ 
      	gSVGObj.getElementById('animated_svg').unpauseAnimations(); 
        pauseButton.highlight.setAttribute('fill','none');    
      }    
      else {
      	gSVGObj.getElementById('animated_svg').pauseAnimations();
        pauseButton.highlight.setAttribute('fill','crimson');
      }
    } // end if active
  };


  /***
  * Slider.rewind(e)
  *
  * - if the animation is running and unpaused
  *   - fast rewind animation by FACTOR while rewind button is pressed
  *   - add eventListener for mouseup to call resetting function
  *
  ***/

  Slider.prototype.rewind = function (e){
   // only allow fast rewinding if the animation is currently running and unpaused
    if (startButton.active && !pauseButton.active){
      rewindButton.active = true;
      rewindButton.highlight.setAttribute('fill','crimson'); 
      hemlObj.stopAnimation();

      // determine the distance travelled in animation time
      var relative_time = ((sliderObj.current - gStartDate)/sliderObj.resolution)*sliderObj.interval;

      // calculate new animation values
      var new_duration = relative_time/FACTOR; // set new duration less by FACTOR
      sliderObj.interval = sliderObj.interval/FACTOR;
      VIS_DURATION = VIS_DURATION/FACTOR;
      var position = sliderObj.pixels_per_ms*relative_time;

      // set animation attributes to new values
      hemlObj.animation.setAttribute('dur', new_duration + 'ms');
      gSVGObj.getElementById('slider_pointer').setAttribute('transform', 'translate(' + position + ',0)');
      hemlObj.animation.setAttribute('to', -position + ',0');

      // reset map set values
      hemlObj.setRewindAnimation(new_duration);

      // set date to decrement
      if (sliderObj.resolution == MS_PER_YEAR/365){
        sliderObj.setDate = sliderObj.setDateDecrement;
      }
      if (sliderObj.resolution == MS_PER_YEAR/12){
        sliderObj.setDate = sliderObj.setMonthDecrement;
      }
      else{
        sliderObj.setDate = sliderObj.setYearDecrement;
      }

      // reset visibility attributes of event nodes to visible
      hemlObj.setVisibility("show");
      // start animation with new values
      sliderObj.intervalState("set");
      hemlObj.animation.beginElement();

      // set outline rectangle to register mouseup event
      sliderObj.handler.setAttribute('pointer-events','visible');

      sliderObj.handler.addEventListener("mouseup",sliderObj.reset,false);

    } // end if running and unpaused

  };


  /***
  * Slider.forward(e)
  *
  * - if the animation is running and unpaused
  *   - fast forward animation by FACTOR while forward button is pressed
  *   - add eventListener for mouseup to call resetting function
  *
  ***/

  Slider.prototype.forward = function (e){

    // only allow fast forwarding if the animation is currently running and unpaused
    if (startButton.active && !pauseButton.active){
      forwardButton.active = true;
      forwardButton.highlight.setAttribute('fill','crimson'); 
      hemlObj.stopAnimation();

      // determine the distance travelled in animation time
      var relative_time = ((sliderObj.current - gStartDate)/sliderObj.resolution)*sliderObj.interval;

      // calculate new animation values
      var new_duration = (sliderObj.duration - relative_time)/FACTOR; // set new duration less by FACTOR
      sliderObj.interval = sliderObj.interval/FACTOR;
      VIS_DURATION = VIS_DURATION/FACTOR;
      var position = sliderObj.pixels_per_ms*relative_time;

      // set animation attributes to new values
      hemlObj.animation.setAttribute('dur', new_duration + 'ms');
      gSVGObj.getElementById('slider_pointer').setAttribute('transform', 'translate(' + position + ',0)');
      hemlObj.animation.setAttribute('to', (gLineLength-position-gLineBegins) + ',0');

      // reset map set values
      hemlObj.setAnimationMid(new_duration);

      // reset visibility attributes of event nodes to visible
      hemlObj.setVisibility("show");

      // start animation with new values
      sliderObj.intervalState("set");
      hemlObj.animation.beginElement();

      // set outline rectangle to register mouseup event
      sliderObj.handler.setAttribute('pointer-events','visible');

      sliderObj.handler.addEventListener("mouseup",sliderObj.reset,false);

    } // end if running and unpaused
  };


  /***
  * Slider.reset(e)
  *
  * - resets fast forward or rewind to normal speed and direction
  *
  ***/
  Slider.prototype.reset = function(e){

    hemlObj.stopAnimation();

    // hide ff/rew buttons
    rewindButton.highlight.setAttribute('fill','none'); 
    rewindButton.active = false;
    forwardButton.highlight.setAttribute('fill','none'); 
    forwardButton.active = false;

    // reset interval and visibility to original interval length
    sliderObj.interval = sliderObj.interval*FACTOR;
    VIS_DURATION = VIS_DURATION*FACTOR;

    // determine the distance travelled in time relative to sliderObj.duration to get the current position
    relative_time = ((sliderObj.current - gStartDate)/sliderObj.resolution)*sliderObj.interval;
    new_duration = sliderObj.duration - relative_time;
    position = sliderObj.pixels_per_ms*relative_time;

    // set the animation attributes to new variables
    hemlObj.animation.setAttribute('dur', new_duration + 'ms');
    gSVGObj.getElementById('slider_pointer').setAttribute('transform', 'translate(' + position + ',0)');
    hemlObj.animation.setAttribute('to', (gLineLength-position-gLineBegins) + ',0');

    hemlObj.setAnimationMid(new_duration);
    hemlObj.setVisibility("show");

    // in case of rewind, reset date to increment
    if (sliderObj.resolution == MS_PER_YEAR/365){
      sliderObj.setDate = sliderObj.setDateIncrement;
    }
    if (sliderObj.resolution == MS_PER_YEAR/12){
      sliderObj.setDate = sliderObj.setMonthIncrement;
    }
    else{
      sliderObj.setDate = sliderObj.setYearIncrement; 
    }

    // restart animation
    sliderObj.intervalState("set");
    hemlObj.animation.beginElement();

    // set outline rectangle to hidden from mouse events
    sliderObj.handler.setAttribute('pointer-events','none');

    sliderObj.handler.removeEventListener("mouseup",sliderObj.reset,false);
  };


  /***
  * Slider.intervalState (action){
  *
  * - will set or clear year interval depending upon the requested action
  *
  ***/

  Slider.prototype.intervalState = function (action){
    if (action == "set") {
	  sliderObj.interval_code = setInterval("sliderObj.setPointerDate()", sliderObj.interval);
	}
    if (action == "clear"){
	clearInterval(sliderObj.interval_code);
    }
  };


  /***
  *
  * Slider.setPointerDate()
  * 
  * - set map and slider values with respect to current animation duration
  * - if animation currently paused (by function or popup menu) don't change date
  *
  ***/

  Slider.prototype.setPointerDate = function(){
    // designed to catch any pause instructions coming from right click
    if (gSVGObj.getElementById('animated_svg').animationsPaused()){ 
      pauseButton.highlight.setAttribute('fill','crimson');
      pauseButton.active = true;     
    }
    else{
      pauseButton.active = false;
      if (pauseButton.hover == false){
        pauseButton.highlight.setAttribute('fill','none');
      }
      if (sliderObj.current < gEndDate || rewindButton.active){
        // set date to be displayed
        sliderObj.current = sliderObj.setDate(sliderObj.current);
        sliderObj.setSlider(sliderObj.current);
      }

    }  // end else not paused

  };


  /***
  *
  * Slider.setSlider(date)
  * 
  * - set date on sider 
  * - format is dependent upon resolution
  *
  ***/
  Slider.prototype.setToYear = function(date){
    current = new Date (date);
    slider_text = gSVGObj.getElementById('pointer_date');
    var nText = gSVGObj.createTextNode(numToGregorianEraYear(current.getFullYear()));
    slider_text.replaceChild(nText,slider_text.firstChild);
  };

  Slider.prototype.setToMonth = function(date){
    current = new Date (date);
    slider_text = gSVGObj.getElementById('pointer_date');
    var nText = gSVGObj.createTextNode(numToGregorianEraYear(current.getFullYear()) + "-" + Number(current.getMonth()+1));
    slider_text.replaceChild(nText,slider_text.firstChild);
  };

  Slider.prototype.setToDate = function (date){
    current = new Date (date);
    slider_text = gSVGObj.getElementById('pointer_date');
    var nText = gSVGObj.createTextNode(numToGregorianEraYear(current.getFullYear()) + "-" + Number(current.getMonth()+1) + "-" + current.getDate());
    slider_text.replaceChild(nText,slider_text.firstChild);
  };


  /***
  *
  * Slider.setDate(time)
  * 
  * - increment or decrement sliderObj.current
  * - size of change is dependent upon resolution
  *
  ***/
  Slider.prototype.setYearIncrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time + MS_PER_YEAR) > gEndDate){ return (gEndDate.getTime()); }
    else{ return(time + MS_PER_YEAR); }
  };
 
  Slider.prototype.setMonthIncrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time + (MS_PER_YEAR/12)) > gEndDate){ return (gEndDate.getTime()); }
    else{ return (time + (MS_PER_YEAR/12)); }
  };

  Slider.prototype.setDateIncrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time + (MS_PER_YEAR/365)) > gEndDate){ return (gEndDate.getTime()); }
    else{ return(time + (MS_PER_YEAR/365)); }
  };


  Slider.prototype.setYearDecrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time - MS_PER_YEAR) < gStartDate){ return (gStartDate.getTime()); }
    else{ return (time - MS_PER_YEAR); }
  }; 

  Slider.prototype.setMonthDecrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time - (MS_PER_YEAR/12)) < gStartDate){ return (gStartDate.getTime()); }
    else{ return (time - (MS_PER_YEAR/12)); }
  };
 
  Slider.prototype.setDateDecrement = function(time){
    // safeguard to make sure pointer doesn't go past end date
    if ((time - (MS_PER_YEAR/365)) < gStartDate){ return (gStartDate.getTime()); }
    else{ return (time - (MS_PER_YEAR/365)); }
  };




  /******************************************
  *
  * HemlEvent class
  * ------------
  *
  * - manipulates visibility and timing of events on animated map
  *
  *******************************************/

  /***
  *
  * HemlEvent constructor
  *
  * - creates an array that holds the events
  *
  ****/
  function HemlEvent () {
    this.aEvents = gSVGObj.getElementById("events").getElementsByTagName("g");
    this.animation =  gSVGObj.getElementById('pointer_motion');
  }


  /***
  *
  * HemlEvent.stopAnimation()
  *
  * - end animation element
  * - stop events from showing up on map
  * - clear interval
  *
  ***/
  HemlEvent.prototype.stopAnimation = function (){
    sliderObj.intervalState("clear"); // clear interval
    this.animation.endElement();
    this.setVisibility("hide");
  };


  /***
  *
  * HemlEvent.setAnimationStart()
  *
  *   - set animation values to initial values
  * 
  ***/
  HemlEvent.prototype.setAnimationStart = function(){
    var begin_time, event_start, event_end, event_duration;

    this.animation.setAttribute('dur', sliderObj.duration + 'ms');
    gSVGObj.getElementById('slider_pointer').setAttribute('transform', 'translate(0,0)'); // animation plays from the beginning again
    this.animation.setAttribute('to', (gLineLength-gLineBegins) + ',0');

    // reset map set values
    // for each event in the document, calculate its begin time relative to the timeline
    for (var i=0; i<this.aEvents.length; i++){

      // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
      if (this.aEvents.item(i).hasAttribute("visibility")){
        event_start = Number(this.aEvents.item(i).getElementsByTagName("eventStartTime").item(0).getAttribute("timing"));
	event_end   = Number(this.aEvents.item(i).getElementsByTagName("eventEndTime").item(0).getAttribute("timing"));
	begin_time  = (event_start-gStartDate)*(sliderObj.duration/(Math.abs(gStartDate-gEndDate)));
	event_duration = (event_end-event_start)*(sliderObj.duration/(Math.abs(gStartDate-gEndDate)));
	this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
	this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
	this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("dur", event_duration + "ms");
	if (event_duration > VIS_DURATION){
	  this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", event_duration + "ms");
	}
	else{
	  this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", VIS_DURATION + "ms");
	}
      } // end if has visibility attribute
    } // end for

  };


  /***
  *
  * HemlEvent.setAnimationMid(duration)
  *
  * - calculate new begin times for event visibility
  *   - based upon 'duration'
  * 
  ***/
  HemlEvent.prototype.setAnimationMid = function (duration){
	var begin_time, event_duration, event_start, event_end;

    // for each event in the document, calculate its begin time relative to the timeline
    for (var i=0; i<this.aEvents.length; i++){
      // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
      if (this.aEvents.item(i).hasAttribute("visibility")){
        event_start = new Date (Number(this.aEvents.item(i).getElementsByTagName("eventStartTime").item(0).getAttribute("timing")));
        event_end   = new Date (Number(this.aEvents.item(i).getElementsByTagName("eventEndTime").item(0).getAttribute("timing")));
        // only calculate a begin time if the event_end is >= current date
        if (event_end >= sliderObj.current){
          // if the event starts after gCurrentDate set from start
          if (event_start >= sliderObj.current){
            begin_time     = (event_start-sliderObj.current)*(duration/(Math.abs(sliderObj.current-gEndDate)));
            event_duration = (event_end-event_start)*(duration/(Math.abs(sliderObj.current-gEndDate)));
          }
          // else only show for the portion that still is to come
          else{
            begin_time     = 0;
            event_duration = (event_end-sliderObj.current)*(duration/(Math.abs(sliderObj.current-gEndDate)));
          }
          // set duration and begin times
          if (event_duration > VIS_DURATION){
            this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", event_duration + "ms");
          }
          else{
            this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", VIS_DURATION + "ms");
          }
          this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
          this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
          this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("dur", event_duration + "ms");	
        } // end if event_end >= current date
      } //  end if has visibility attribute
    } // end for

  };

  /***
  *
  * HemlEvent.setRewindAnimation(duration)
  *
  * - calculate new begin times for event visibility for rewind
  *   - based upon 'duration'
  * 
  ***/
  HemlEvent.prototype.setRewindAnimation = function (duration){
    var begin_time, event_duration, event_start, event_end;

    // for each event in the document, calculate its begin time relative to the timeline
    for (var i=0; i<this.aEvents.length; i++){
      // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
      if (this.aEvents.item(i).hasAttribute("visibility")){
        event_start = new Date (Number(this.aEvents.item(i).getElementsByTagName("eventStartTime").item(0).getAttribute("timing")));
        event_end = new Date (Number(this.aEvents.item(i).getElementsByTagName("eventEndTime").item(0).getAttribute("timing")));
          // only calculate a begin time if the event_start is <= current date
          if (event_start <= sliderObj.current){
            // if the event starts after sliderObj.current, set from end
            if (event_end <= sliderObj.current){
              begin_time     = (sliderObj.current-event_end)*(duration/(Math.abs(gStartDate-sliderObj.current)));
              event_duration = (event_end-event_start)*(duration/(Math.abs(gStartDate - sliderObj.current)));
            }
            // else only show for the portion that still is to come
            else{
              begin_time = 0;
              event_duration = (sliderObj.current-event_start)*(duration/(Math.abs(gStartDate-sliderObj.current)));
            }
            // set begin and duration variables
            if (event_duration > VIS_DURATION){
              this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", event_duration + "ms");
            }
            else{
              this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", VIS_DURATION + "ms");
            }
            this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
            this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("begin", "pointer_motion.begin+" + begin_time + "ms");
            this.aEvents.item(i).getElementsByTagName("set").item(1).setAttribute("dur", event_duration + "ms");
          }  // end if event_start<= current_date
        } // end if item has visibility attribute
      } // end for
  };


  /***
  *
  * HemlEvent.setForDrag()
  *
  * - set begin times and duration for events on animated map
  * - offset against the timeline animation 'pointer_motion' which is the animation controller
  *
  ***/
  HemlEvent.prototype.setForDrag = function (){
    // for each event in the document, set it visible or invisible
    for (var i=0; i<this.aEvents.length; i++){

      // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
      if (this.aEvents.item(i).hasAttribute("visibility")){
        var event_start = new Date(Number(this.aEvents.item(i).getElementsByTagName("eventStartTime").item(0).getAttribute("timing")));
        var event_end   = new Date(Number(this.aEvents.item(i).getElementsByTagName("eventEndTime").item(0).getAttribute("timing")));
        if(event_start <= sliderObj.current && event_end >= sliderObj.current){
          this.aEvents.item(i).setAttribute("visibility", "visible");
          this.aEvents.item(i).setAttribute("fill", "crimson");
        }
        else{
          this.aEvents.item(i).setAttribute("visibility", "hidden");
        }
      }  // end if has visibility attribute

    }  // end for
  };


  /***
  *
  * HemlEvent.setVisibility()
  *
  *   - set event label visibility
  * 
  ***/
  HemlEvent.prototype.setVisibility = function(state){
    if (state == "hide"){
      for (var i=0; i<this.aEvents.length; i++){
        // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
        if (this.aEvents.item(i).hasAttribute("visibility")){
          this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("dur", "0ms");
          this.aEvents.item(i).getElementsByTagName("set").item(0).setAttribute("begin", "pointer_motion.begin+0ms");
        }
      }
    }
    if (state == "show"){
      for (var i=0; i<this.aEvents.length; i++){
        // Batik returns nested 'g' tags, so must make sure we are dealing with the correct g's
        if (this.aEvents.item(i).hasAttribute("visibility")){
          this.aEvents.item(i).setAttribute("visibility", "hidden");
          this.aEvents.item(i).setAttribute("fill", "black");
        }
      }
    }
  };
	  


//********** PRIVATE FUNCTIONS ******************************//


  /***
  *
  * numToGregorianEraYear(number)
  *
  * - derive a date AD/BC from number +/-
  *
  ***/

  function numToGregorianEraYear(number) {
    if (number > 0) {
       return "AD " + number;
    }
    else { return "BC " + (number * -1); }
  }


  /***
  *
  * getButtonObject(id)
  *
  * - returns the object associated with the input button id
  *
  ***/
  function getButtonObject(id){
    switch(id){
      case 'start':              return startButton;    break;
      case 'stop':               return stopButton;     break;
      case 'pause':              return pauseButton;    break;
      case 'pause_indicator':    return pauseButton;    break;
      case 'forward':            return forwardButton;  break;
      case 'forward_indicator':  return forwardButton;  break;
      case 'rewind':             return rewindButton;   break;
      case 'rewind_indicator':   return rewindButton;   break;
      default:                   return null;
    }
  }

  /***
  *
  * earliestTime()
  *
  * - returns the earliest time for an historical event in the current nodeset
  *
  ***/
  function earliestTime() {
    timeNodes = document.getElementsByTagName( "eventStartTime");

    //set the result to the first value, then iterate over the rest
    // looking for a smaller value
    var result = timeNodes.item(0).getAttribute("timing") * 1;
    for (x=1; x < timeNodes.length; x++) {
      if (timeNodes.item(x).getAttribute("timing") * 1 < result) {
        result = timeNodes.item(x).getAttribute("timing") * 1;
      }
    }
    return result;
  }


  /***
  *
  * latestTime()
  *
  * - returns the latest time for an historical event in the current nodeset
  *
  ***/
  function latestTime() {
    timeNodes = document.getElementsByTagName("eventEndTime");
    var result = timeNodes.item(0).getAttribute("timing") *1;
    for (x=1; x < timeNodes.length; x++) {
      if (timeNodes.item(x).getAttribute("timing") * 1 > result) {
        result = timeNodes.item(x).getAttribute("timing") * 1;
      }
    }
    return result;
  }

