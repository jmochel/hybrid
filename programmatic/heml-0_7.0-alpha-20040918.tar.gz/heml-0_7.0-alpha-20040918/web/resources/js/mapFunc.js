//***************************************************************//
//                                                               //
//   $RCSfile: mapFunc.js,v $                                   //
//                                                               //
//   $Revision: 1.5 $                                            //
//                                                               //
//   $Date: 2002/06/18 15:39:25 $                                //
//                                                               //
//   Copyright (C) 2001 Susan Barnett and Bruce Robertson        //
//                                                               //
//***************************************************************//
//                                                               //
//   This package is free software; you can redistribute         //
//   it and/or modify it under the terms of the GNU Lesser       //
//   General Public License as published by the Free Software    //
//   Foundation; either version 2.1 of the License, or (at       //
//   your option) any later version.                             //
//                                                               // 
//   This package is distributed in the hope that it will be     //
//   useful, but WITHOUT ANY WARRANTY; without even the implied  //
//   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR     //
//   PURPOSE.  See the GNU Lesser General Public License for     //
//   more details.                                               //
//                                                               //
//   You should have received a copy of the GNU Lesser General   //
//   Public License along with this package; if not, write       //
//   to the Free Software Foundation, Inc., 59 Temple Place,     //
//   Suite 330, Boston, MA  02111-1307  USA                      //
//                                                               //
//***************************************************************//


  /****************************************************
  * Javascript code that makes the resulting map dynamic.
  ******************************************************/
  // global variables 
  var lastText;
  var gLastList;

  /*************************************************
  * When a resize event is called on the document,
  * the font size of texts and the size of the
  * circles that represent location points are
  * changed to scale.
  *************************************************/
  function zoom_resize(evt) {
    // get the document element
    var SVGDoc = evt.getTarget().getOwnerDocument();
    svgSVGObj = SVGDoc.getDocumentElement();

    // get the scale, or zoom factor: i.e. 2 for a 2x view.
    var scale = svgSVGObj.getCurrentScale();

    // get all the 'g' elements within the 'Locations' element
    var gs = SVGDoc.getElementById("Locations").getElementsByTagName("g");

    for (var count = 0; count <  gs.length; count++) {
      // on each of these, check to see if the id attribute begins with 'Location'
      first_eight =  gs.item(count).getAttribute("id").substring(0,8);

      if (first_eight == "Location") {
        // if it does, then the remaining string on the id attribute is the 
        // name of a location with a circle and text whose size should be changed
        event_identifier = gs.item(count).getAttribute("id").substring(9);
        circle = SVGDoc.getElementById("" + event_identifier);
        circle.setAttribute("r", 2/scale);
        circle.setAttribute("stroke-width", 1/scale);
        text = SVGDoc.getElementById(event_identifier + "_text");
        text.setAttribute("font-size", 10/scale);
        textTranslate = SVGDoc.getElementById(event_identifier + "_text_translate");
        textTranslate.setAttribute("transform", "translate(" + 5/scale + "," + 3/scale + ")");
      } // end if first_eight
    } // end for
  }

  /*******************************************************************
  * Function is called on mouseover of map location dot.  It hides
  * the last displayed map text and displays the current location
  ********************************************************************/
  function show_map_text(evt) {
    // Hide the last text (assuming there is a last text)
    if (lastText != null) {
      lastText.setAttribute("visibility", "hidden");
    }

    // get the 'text' element related to the moused-over
    // circle, and make it visible
    currentText = get_related_element(evt, "text");
    currentText.setAttribute("visibility", "visible");

    // now that we're done, our current stuff becomes old
    // we'll store them there so that when the function
    // is called again, it can make them invisible 
    lastText = currentText;
  }

    function show_table_text(evt) {
    // Hide the last event list on the table if it is set
    if (gLastList != null) {
      gLastList.setAttribute("visibility", "hidden");
    }
    // retrieve the desired location event list from target document
    currentList = get_related_element(evt,"table");
    currentList.setAttribute("visibility","visible");

    // record information about currently displayed list
    gLastList = currentList;
}

  function  get_related_element(evt, suffix) {
    SVGDoc = evt.getTarget().getOwnerDocument();
    var myId = evt.getTarget().id;
//    alert("getting element named: " + myId + "_" + suffix + ": " + SVGDoc.getElementById(myId + "_" + suffix));   
    return SVGDoc.getElementById(myId + "_" + suffix);
  }

