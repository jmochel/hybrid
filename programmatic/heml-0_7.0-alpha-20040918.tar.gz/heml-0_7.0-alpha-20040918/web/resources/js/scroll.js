

var squarePopped = false;

var currentScrollY = 0;
var scrollBy = 10;
var timerID = null;
var stopScroll = false;
function terminateTimer() {
 // alert("teminate called");
  //stopScroll = true;
  clearTimeout(timerID);
}

function startScrollUp() {
  timerID = setTimeout('scrollUp()',10);
}

function startScrollDown() {
  timerID = setTimeout('scrollDown()',10);
}

function scrollUp() {
if ((currentScrollY &lt; 5) ) {
  scroller = document.getElementById("scroller");
  currentScrollY = currentScrollY + scrollBy;
scroller.setAttribute("transform", "translate(0, " + currentScrollY + ")");
timerID = setTimeout('scrollUp()',100);//call myself
}
else {
stopScroll = false;
}
}

function scrollDown() {
scroller = document.getElementById("scroller");
if (currentScrollY > -280) {
  currentScrollY = currentScrollY - scrollBy;
  scroller.setAttribute("transform", "translate(0," + currentScrollY + ")");
  timerID = setTimeout('scrollDown()', 100);//call myself
 }
}

/* end from scroll */

/*
var outer;
var r;
var s;
var timevalue;
var timer_increment;
var max_time;
var startingValue;
var finalValue;
*/
function syncRect()
{
 // alert("doing sync");
   outer = document.getElementById("outer");
   r = document.rootElement;
   s = 1/r.currentScale;
   var inner = document.getElementById("inner");
   inner.setAttribute( "transform", "scale(" + s + "," + s + ")" );
   if (squarePopped) {
     squareY = 0;
     }
   else {
     squareY =  -380;
   }
   outer.setAttribute( "x", (-r.currentTranslate.x + 5) * s );
   outer.setAttribute( "y", (-r.currentTranslate.y + squareY) * s  );
   outer.setAttribute( "width", 400 *s );
   outer.setAttribute( "height", 400 * s );
}
function pop(evt) {
  //alert("doing pop");
   if (squarePopped == false) {lowerSquare();}
   else {raiseSquare();}
   squarePopped = !squarePopped;
   syncRect();
}

function raiseSquare() {
 // alert("doing raiseSquare");
  timevalue = 0;
  timer_increment = 5;
  max_time = 70;
  startingValue = 0;
  finalValue = -380;
  doRaise();
}

function lowerSquare() {
  timevalue = 0;
  timer_increment= 5;
  max_time  = 70;
  startingValue = -380;
  finalValue = 0;
  doRaise();
}
function doRaise() {
  //alert("doing doRaise");
  timevalue = timevalue + timer_increment;
  if (timevalue &gt; max_time) return;
  yPosition = (finalValue - startingValue) * (timevalue / max_time) + startingValue;
  outer.setAttribute( "y", (-r.currentTranslate.y + yPosition) * s);
   setTimeout("doRaise()", timer_increment);

}
document.rootElement.addEventListener( "SVGScroll", syncRect, false );
document.rootElement.addEventListener( "SVGResize", syncRect, false );
document.rootElement.addEventListener( "SVGZoom", syncRect, false );
syncRect();
