//***************************************************************//
//                                                               //
//   $RCSfile: cookieClass.js,v $                                //
//                                                               //
//   $Revision: 1.3 $                                           //
//                                                               //
//   $Date: 2002/07/22 18:16:28 $                                //
//                                                               //
//   Copyright (C) 2002 Bruce Robertson                          //
//                      Susan Barnett                            //
//                                                               //
//***************************************************************//
//                                                               //
//   This package is free software; you can redistribute         //
//   it and/or modify it under the terms of the GNU Lesser       //
//   General Public License as published by the Free Software    //
//   Foundation; either version 2.1 of the License, or (at       //
//   your option) any later version.                             //
//                                                               //
//   This package is distributed in the hope that it will be     //
//   useful, but WITHOUT ANY WARRANTY; without even the implied  //
//   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR     //
//   PURPOSE.  See the GNU Lesser General Public License for     //
//   more details.                                               //
//                                                               //
//   You should have received a copy of the GNU Lesser General   //
//   Public License along with this package; if not, write       //
//   to the Free Software Foundation, Inc., 59 Temple Place,     //
//   Suite 330, Boston, MA  02111-1307  USA                      //
//                                                               //
//***************************************************************//

	/*****
	* 
	* Cookie class creates and accesses cookies via
	* 
	* - write
	* - modify	
	* - getCookies
	* - read
	* - delete - delete is not implemented at this point because these are currently session cookies
	* - store
	* - isSet
	*
	* NOTE: this is currently not a general purpose class.  Properties are predefined for current HEML organisation.
	*
	*****/
	function Cookie (document) {
		// initialise cookie properties
		this.document = document;
		this.name     = "preferences=";
		this.path     = "/";
	}


	/*****
	* 
	* write (element, value)
	*
	* - initial write of value of the current cookie (as in name=value)
	* - will only write if the element has not already been assigned a value
	*
	*****/
	Cookie.prototype.write = function (element, value){
	    // check to make sure the element has not already been written
		if (this.name.indexOf(element) == -1){
			this.name = this.name + element + "&" + value + ":";
		}
	};


	/*****
	* 
	* modify (element, value)
	*
	* - changes value of the current cookie (as in name=value)
	* - if the element's value is not already stored in the cookie, it is added
	*
	*****/
	Cookie.prototype.modify = function (element, value){
		var element_start, element_end; // positions for substring breaks
		var first, second; // substrings for modification

		element_start = this.name.indexOf(element);

		// if the element is not defined, call write to add it to cookie
		if (element_start == -1){
			this.write(element, value);
		}

		// else modify the existing element value
		else{
			element_end = this.name.indexOf(":",element_start);
			// separate off substrings to keep
			first = this.name.substring(0,element_start);
			second = this.name.substring((element_end+1), this.name.length);
			// reset this.name with new element value
			this.name = first + element + "&" + value + ":" + second;
		}
	};
	

	/*****
	* 
	* getCookies (document)
	*
	* - retrieve the cookies from the current document and separate
	*   the information into Cookie fields
	*
	*****/
	Cookie.prototype.getCookies = function (document){
	
		this.name = document.cookie;
		//var cookie_string = document.cookie;

		// 'value' is the only information required
		//this.name = cookie_string.substring(0, (cookie_string.indexOf(";")+1));

		// initialise set cookie properties
		this.document = document;
		this.path     = "/";

	};


	/*****
	* 
	* read (element)
	*
	* - returns the value of the input element
	* - if element is not defined in cookie, returns NULL
	*
	*****/
	Cookie.prototype.read = function (element){
		var element_start, element_end; // positions for substring breaks

		element_start = this.name.indexOf(element);

		// may only retreive string if element is defined in cookie
		if (element_start == -1){
			return (null);
		}
		else{
			element_end = this.name.indexOf(":",element_start);
			return(this.name.substring((element_start+element.length+1), element_end));
		}
		
	};
	

	/*****
	* 
	* store
	*
	* - concatonates all information into a cookie string
	* - stores the cookie in this.document
	*
	*****/
	Cookie.prototype.store = function (){ 
		this.document.cookie = this.name + "; path=" + this.path;	
	};


	/*****
	* 
	* isSet ()
	*
	* - returns true if there is a cookie set 
	*
	*****/
	Cookie.prototype.isSet = function (){ 
		var test_string = document.cookie;
		var result      = test_string.indexOf("preferences");

		if (result == -1) { return false };
		else              { return true  };

	};